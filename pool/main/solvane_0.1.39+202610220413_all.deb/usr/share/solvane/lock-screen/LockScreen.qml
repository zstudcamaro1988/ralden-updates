/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — the lock screen
 *
 * What a Solvane computer shows when it has been left alone, or woken from
 * sleep: the time, the date, whatever is playing, and a padlock. The
 * drawing itself is SolvaneLock.qml; this file is what Plasma's locker
 * loads, and it is deliberately almost nothing.
 *
 * WHERE THIS FILE GOES, WHICH IS NOT WHERE IT IS KEPT.
 *
 * Plasma's locker takes its lock screen from one place only: LockScreen.qml
 * in Plasma's own shell package
 * (/usr/share/plasma/shells/org.kde.plasma.desktop/contents/lockscreen).
 * That was learned by asking the locker's own program, after a first
 * attempt had put this in Solvane's theme package - where themes kept
 * theirs until Plasma 6, and where nothing looks any more.
 *
 * So when Solvane is built, Plasma's file of that name is set aside
 * (dpkg-divert: an update then puts Plasma's new one aside too, instead of
 * over this) and a copy of this file takes its place. It is kept here, in
 * /usr/share/solvane/lock-screen, with the drawing it loads.
 *
 * WHY IT IS ALMOST NOTHING.
 *
 * This is the part that must not fail. It declares what the locker looks
 * for, and loads the drawing. If the drawing does not load - after an
 * update that moved something under it, say - it loads Plasma's own lock
 * screen instead, which is still beside it under its own name
 * (LockScreenUi.qml) and was written to be loaded exactly this way: it
 * asks its surroundings for a thing called `root` with the properties and
 * signals below, and this is one.
 *
 * WHAT THE LOCKER LOOKS FOR is copied from Plasma's own LockScreen.qml
 * (plasma-workspace 6.3), name for name.
 */

import QtQuick

Item {
    id: root

    property bool debug: false
    property string notification
    signal clearPassword()
    signal notificationRepeated()

    /* Set by the locker. */
    property bool viewVisible: false
    property bool suspendToRamSupported: false
    property bool suspendToDiskSupported: false

    /* Listened for by the locker. */
    signal suspendToDisk()
    signal suspendToRam()

    /* True once Solvane's drawing has failed to load and Plasma's own has
     * been asked for instead. The self-test and the build both read it. */
    property bool stock: false
    /* Solvane's drawing, and Plasma's own, which is beside wherever this
     * file has been put. Named, so that the program which loads this
     * before a computer is locked behind it can point them elsewhere. */
    property url drawing: "file:///usr/share/solvane/lock-screen/SolvaneLock.qml"
    property url stockUi: Qt.resolvedUrl("LockScreenUi.qml")
    /* Whichever of the two it is has finished loading. */
    readonly property bool ready: ui.status === Loader.Ready

    implicitWidth: 800
    implicitHeight: 600

    Loader {
        id: ui
        anchors.fill: parent
        focus: true
        source: root.stock ? root.stockUi : root.drawing
        onStatusChanged: {
            if (status === Loader.Error && !root.stock)
                root.stock = true
        }
    }
}
