/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — the lock screen: letting somebody else sign in
 *
 * Kept apart from the drawing, and loaded by it, because it needs a piece
 * of Plasma that Plasma calls private: it may be renamed by an update. If
 * it is, this file fails to load, the icon in the corner is not drawn, and
 * the lock screen is otherwise exactly as it was.
 */

import QtQuick
import org.kde.plasma.private.sessions as Sessions

Item {
    readonly property bool can: sessions.canSwitchUser
    signal asleep()

    function go() {
        sessions.switchUser()
    }

    Sessions.SessionManagement {
        id: sessions
        onAboutToSuspend: parent.asleep()
    }
}
