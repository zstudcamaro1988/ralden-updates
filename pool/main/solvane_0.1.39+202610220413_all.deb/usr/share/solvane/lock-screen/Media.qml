/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — the lock screen: what is playing
 *
 * Apart from the drawing for the same reason Switch.qml is. This asks
 * Plasma which player is the one that matters just now (it keeps exactly
 * one row for it, or none) and holds what it says in plain properties, so
 * the drawing never touches the private piece itself. With nothing
 * playing, or with this file unable to load, there is no card.
 */

import QtQuick
import org.kde.plasma.private.mpris as Mpris

Item {
    id: media

    readonly property bool present: players.count > 0 && (track !== "" || playing)
    property string track: ""
    property string artist: ""
    property string art: ""
    property bool playing: false
    property bool canControl: false
    property bool canPrevious: false
    property bool canNext: false
    property var player: null

    function previous() { if (player) player.Previous() }
    function toggle() { if (player) player.PlayPause() }
    function next() { if (player) player.Next() }

    Repeater {
        id: players
        model: Mpris.MultiplexerModel { }
        delegate: Item {
            Binding { target: media; property: "track"; value: model.track || "" }
            Binding { target: media; property: "artist"; value: model.artist || model.identity || "" }
            Binding { target: media; property: "art"; value: model.artUrl || "" }
            Binding { target: media; property: "playing"; value: model.playbackStatus === Mpris.PlaybackStatus.Playing }
            Binding { target: media; property: "canControl"; value: model.canControl === true }
            Binding { target: media; property: "canPrevious"; value: model.canGoPrevious === true }
            Binding { target: media; property: "canNext"; value: model.canGoNext === true }
            Binding { target: media; property: "player"; value: model.container }
        }
    }
}
