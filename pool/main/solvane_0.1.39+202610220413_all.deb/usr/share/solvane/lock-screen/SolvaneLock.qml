/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — the lock screen, as drawn
 *
 * WHAT THIS IS A COPY OF, AND WHERE IT IS NOT.
 *
 * The lock-screen picture supplied on 7 October 2026
 * (reference/6-lock.png), measured: every place and size below is a
 * hundredth of the screen's height (`u`), read off that picture. The time
 * in large thin figures, the date under it, a pale glass card for whatever
 * is playing, and along the foot a person on the left and a padlock in the
 * middle.
 *
 * Where it differs, and why:
 *
 *   The camera, bottom right. Nothing on this computer opens a camera from
 *   a locked screen. It is not drawn until something does.
 *
 *   The card for what is playing is there only while something is. A card
 *   that said "Cascade" with nothing playing would be a picture of a card.
 *
 *   The person, bottom left, lets somebody else sign in. It is drawn only
 *   if this computer says that can be done.
 *
 *   The picture does not show how the screen is unlocked. Here: press the
 *   padlock, or simply start typing. The padlock gives way to a box for
 *   the password - or, for somebody who has none, to an Unlock button.
 *
 *   The photograph is whatever the lock screen is set to show (Solvane's
 *   mountains, unless it has been changed) with a blue veil over it. The
 *   picture's mountains are darker than Solvane's, and white figures on
 *   Solvane's pale sky cannot be read without it.
 *
 * ONLY QtQuick IS IMPORTED HERE. Three things lean on pieces of Plasma that
 * an update may rename - who else may sign in, what is playing, Caps Lock -
 * and each is in a file of its own, loaded from here. One that will not
 * load takes itself away and nothing else.
 *
 * WHAT THE LOCKER GIVES IT: `authenticator` (it checks the password),
 * `kscreenlocker_userName`, and the photograph, which the locker puts
 * behind everything by itself.
 */

import QtQuick

Item {
    id: lock
    objectName: "solvaneLock"

    readonly property real u: height / 100
    readonly property real hair: Math.max(1, Math.round(u * 0.12))
    readonly property string face: "Inter"
    readonly property color paper: "#FFFFFF"
    readonly property color ink: "#22365C"
    readonly property color quiet: "#5A6C8C"
    readonly property color wrong: "#FFE0DB"

    /* rest: the picture. ask: the password box. free: nothing to ask. */
    property string mode: "rest"
    property bool busy: false
    property bool reveal: false
    property string said: ""
    /* This account needs no password: the locker said yes without asking. */
    property bool open: false
    /* The padlock was pressed, or Enter: unlock as soon as that is known. */
    property bool wanted: false

    readonly property string who: kscreenlocker_userName

    /* For the program that photographs this screen, which has no player to
     * ask and no session to ask who else may sign in: {track, artist,
     * playing}, and whether to draw the person in the corner. The locker
     * sets neither, and what they draw does nothing when pressed. */
    property var stagedMedia: null
    property bool stagedOther: false
    readonly property var playing: stagedMedia !== null ? stagedMedia
        : (media.item !== null && media.item.present ? media.item : null)

    /* ---- the three pieces that may not be there --------------------------- */

    Loader {
        id: switcher
        source: "Switch.qml"
    }
    Connections {
        target: switcher.item
        ignoreUnknownSignals: true
        function onAsleep() { lock.settle() }
    }
    Loader {
        id: media
        source: "Media.qml"
    }
    Loader {
        id: caps
        source: "Caps.qml"
    }

    /* ---- locking and unlocking ------------------------------------------- */

    function wake(deliberately) {
        if (deliberately)
            lock.wanted = true
        if (lock.open) {
            if (lock.wanted) {
                Qt.quit()
                return
            }
            lock.mode = "free"
        } else if (lock.mode === "rest") {
            lock.mode = "ask"
            authenticator.startAuthenticating()
        }
        idle.restart()
        password.forceActiveFocus()
    }

    function settle() {
        idle.stop()
        lock.mode = "rest"
        lock.reveal = false
        lock.wanted = false
        lock.busy = false
        lock.said = ""
        password.text = ""
    }

    function answer() {
        if (lock.open) {
            Qt.quit()
            return
        }
        if (lock.busy || password.text === "")
            return
        lock.busy = true
        lock.said = ""
        authenticator.respond(password.text)
    }

    Connections {
        target: authenticator
        function onFailed(kind) {
            /* Only the password's own failure: a fingerprint reader that
             * did not recognise a finger says so by another road. */
            if (kind !== 0)
                return
            lock.busy = false
            lock.said = "That is not the password."
            password.text = ""
            grace.restart()
            idle.restart()
        }
        function onSucceeded() {
            if (authenticator.hadPrompt) {
                Qt.quit()
                return
            }
            /* Nothing was asked: this account has no password. Whatever
             * was typed while finding that out is not a password. */
            lock.open = true
            lock.busy = false
            password.text = ""
            if (lock.wanted)
                Qt.quit()
            else if (lock.mode === "ask")
                lock.mode = "free"
        }
        function onInfoMessageChanged() {
            if (authenticator.infoMessage !== "")
                lock.said = authenticator.infoMessage
        }
        function onErrorMessageChanged() {
            if (authenticator.errorMessage !== "")
                lock.said = authenticator.errorMessage
        }
        function onPromptForSecretChanged() {
            lock.reveal = false
            if (lock.mode !== "rest")
                password.forceActiveFocus()
        }
    }

    /* After a wrong password: three seconds, then it may be tried again. */
    Timer {
        id: grace
        interval: 3000
        onTriggered: {
            if (lock.said === "That is not the password.")
                lock.said = ""
            authenticator.startAuthenticating()
            password.forceActiveFocus()
        }
    }

    /* Left alone with nothing typed, it goes back to the picture. */
    Timer {
        id: idle
        interval: 12000
        onTriggered: {
            if (password.text === "" && !lock.busy)
                lock.settle()
            else
                restart()
        }
    }

    Component.onCompleted: password.forceActiveFocus()
    Keys.onEscapePressed: lock.settle()

    /* ---- the time ---------------------------------------------------------- */

    property date now: new Date()
    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: lock.now = new Date()
    }
    /* Hours and minutes the way this computer's language counts hours, and
     * nothing after them: the picture's 10:42 says neither AM nor PM.
     *
     * Worked out by hand. The toolkit will only count to twelve if it is
     * also allowed to write AM or PM: asked for hours and minutes alone it
     * wrote 23:30 on a computer set to American English, which is how this
     * was found. */
    readonly property bool twelve:
        Qt.locale().timeFormat(Locale.ShortFormat).toLowerCase().indexOf("a") >= 0
    readonly property string time: {
        var h = lock.now.getHours()
        var m = lock.now.getMinutes()
        var hours = lock.twelve ? String(h % 12 === 0 ? 12 : h % 12)
                                : (h < 10 ? "0" + h : String(h))
        return hours + ":" + (m < 10 ? "0" + m : String(m))
    }

    /* ---- the pieces, declared once ----------------------------------------- */

    /* A small drawing on a grid of 24. */
    component Glyph: Canvas {
        id: glyph
        property string kind: ""
        property color colour: lock.paper
        property real weight: 1.8
        property bool struck: false
        width: lock.u * 3
        height: width
        onKindChanged: requestPaint()
        onColourChanged: requestPaint()
        onWeightChanged: requestPaint()
        onStruckChanged: requestPaint()
        onWidthChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            var k = width / 24
            c.reset()
            c.scale(k, k)
            c.lineWidth = glyph.weight
            c.lineCap = "round"
            c.lineJoin = "round"
            c.strokeStyle = glyph.colour
            c.fillStyle = glyph.colour
            c.beginPath()
            if (kind === "padlock" || kind === "unlocked") {
                /* A solid body, as the picture's is, with its keyhole cut
                 * out; the shackle a thick line - let go on one side when
                 * there is nothing to ask. */
                c.lineWidth = 2.4
                if (kind === "padlock") {
                    c.moveTo(7.4, 11)
                    c.lineTo(7.4, 8.2)
                    c.arc(12, 8.2, 4.6, Math.PI, 0, false)
                    c.lineTo(16.6, 11)
                } else {
                    c.moveTo(7.4, 11)
                    c.lineTo(7.4, 7.4)
                    c.arc(12, 7.4, 4.6, Math.PI, Math.PI * 1.95, false)
                }
                c.stroke()
                c.beginPath()
                c.moveTo(6.6, 10.4)
                c.lineTo(17.4, 10.4)
                c.arcTo(19.2, 10.4, 19.2, 12.2, 1.8)
                c.lineTo(19.2, 19.4)
                c.arcTo(19.2, 21.2, 17.4, 21.2, 1.8)
                c.lineTo(6.6, 21.2)
                c.arcTo(4.8, 21.2, 4.8, 19.4, 1.8)
                c.lineTo(4.8, 12.2)
                c.arcTo(4.8, 10.4, 6.6, 10.4, 1.8)
                c.closePath()
                c.fill()
                c.globalCompositeOperation = "destination-out"
                c.beginPath()
                c.arc(12, 14.7, 1.5, 0, Math.PI * 2, false)
                c.fill()
                c.fillRect(11.3, 15.2, 1.4, 3.2)
                c.globalCompositeOperation = "source-over"
                return
            } else if (kind === "lock") {
                c.rect(6.2, 10.8, 11.6, 9)
                c.moveTo(8.6, 10.8)
                c.lineTo(8.6, 8.2)
                c.arc(12, 8.2, 3.4, Math.PI, 0, false)
                c.lineTo(15.4, 10.8)
                c.stroke()
                c.beginPath()
                c.arc(12, 15.3, 1.1, 0, Math.PI * 2, false)
                c.fill()
                return
            } else if (kind === "person") {
                /* A ring, a head, and shoulders that the ring cuts off. */
                c.arc(12, 12, 10, 0, Math.PI * 2, false)
                c.stroke()
                c.beginPath()
                c.arc(12, 9.4, 3.3, 0, Math.PI * 2, false)
                c.stroke()
                c.beginPath()
                c.arc(12, 21.4, 7.2, Math.PI * 1.17, Math.PI * 1.83, false)
                c.stroke()
                return
            } else if (kind === "eye") {
                c.moveTo(3.2, 12)
                c.bezierCurveTo(6.2, 6.6, 17.8, 6.6, 20.8, 12)
                c.bezierCurveTo(17.8, 17.4, 6.2, 17.4, 3.2, 12)
                c.moveTo(14.7, 12)
                c.arc(12, 12, 2.7, 0, Math.PI * 2, false)
                if (glyph.struck) {
                    c.moveTo(5.4, 4.8); c.lineTo(18.6, 19.2)
                }
            } else if (kind === "arrow") {
                c.moveTo(5, 12); c.lineTo(19, 12)
                c.moveTo(13.6, 6.6); c.lineTo(19, 12); c.lineTo(13.6, 17.4)
            } else if (kind === "pause") {
                c.fillRect(7, 5.5, 3.4, 13)
                c.fillRect(13.6, 5.5, 3.4, 13)
                return
            } else if (kind === "play") {
                c.moveTo(8, 5); c.lineTo(19, 12); c.lineTo(8, 19)
                c.closePath()
                c.fill()
                return
            } else if (kind === "previous" || kind === "next") {
                /* A bar and a triangle pointing at it. */
                var back = kind === "previous"
                c.fillRect(back ? 5 : 16.6, 6, 2.4, 12)
                c.beginPath()
                if (back) {
                    c.moveTo(19, 6); c.lineTo(9.4, 12); c.lineTo(19, 18)
                } else {
                    c.moveTo(5, 6); c.lineTo(14.6, 12); c.lineTo(5, 18)
                }
                c.closePath()
                c.fill()
                return
            }
            c.stroke()
        }
    }

    /* A button's face: rounded, lighter at the top. Drawn, because a
     * rounded Rectangle with a gradient in it comes out of the renderer a
     * computer falls back to with corners that do not match. */
    component Face: Canvas {
        id: face
        property real corner: 0
        property color light: "#000000"
        property color dark: "#000000"
        onCornerChanged: requestPaint()
        onLightChanged: requestPaint()
        onDarkChanged: requestPaint()
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            var w = width, h = height
            var r = Math.min(corner, w / 2, h / 2)
            c.reset()
            var shade = c.createLinearGradient(0, 0, 0, h)
            shade.addColorStop(0, face.light)
            shade.addColorStop(1, face.dark)
            c.fillStyle = shade
            c.beginPath()
            c.moveTo(r, 0)
            c.lineTo(w - r, 0)
            c.arcTo(w, 0, w, r, r)
            c.lineTo(w, h - r)
            c.arcTo(w, h, w - r, h, r)
            c.lineTo(r, h)
            c.arcTo(0, h, 0, h - r, r)
            c.lineTo(0, r)
            c.arcTo(0, 0, r, 0, r)
            c.closePath()
            c.fill()
        }
    }

    /* One of the three controls on the card for what is playing. */
    component Control: Item {
        id: control
        property string kind: ""
        property bool can: true
        signal pressed()
        width: lock.u * 4.6
        height: width
        opacity: can || lock.stagedMedia !== null ? 1 : 0.35
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: controlArea.pressed ? "#33223A66"
                 : controlArea.containsMouse ? "#1F223A66" : "transparent"
        }
        Glyph {
            anchors.centerIn: parent
            width: lock.u * 2.9
            kind: control.kind
            colour: lock.ink
        }
        MouseArea {
            id: controlArea
            anchors.fill: parent
            enabled: control.can
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                idle.restart()
                control.pressed()
            }
        }
    }

    /* ---- the veil ------------------------------------------------------------
     *
     * The photograph is behind everything, put there by the locker. This is
     * the blue between it and the white figures. It was measured to turn
     * Solvane's pale sky the colour of the lock-screen picture's; since
     * Alpine Mist (13 October 2026) the photograph is already the login
     * screen's dusk, and a mid blue at that strength would only have washed
     * it paler. So it is the dusk's own navy, lighter, and deeper at the
     * foot where the controls are. */
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#5216305C" }
            GradientStop { position: 0.6; color: "#4716305C" }
            GradientStop { position: 1.0; color: "#7A10244A" }
        }
    }

    /* Anywhere on the screen: wake it. */
    MouseArea {
        anchors.fill: parent
        onPressed: lock.wake(false)
    }

    /* ---- the time and the date ------------------------------------------------
     *
     * MEASURED AGAIN ON 8 OCTOBER 2026, AGAINST A PHOTOGRAPH OF A LOCKED MACHINE.
     *
     * The first sizes were read off the picture and the time came out at 70
     * per cent of the picture's: its figures are 41 of the picture screen's
     * 380 pixels tall - 10.8 per cent - and on the test machine they were
     * 7.8. Inter's figures are 0.727 of the size they are set at, so the
     * size is 10.8 / 0.727 of a hundredth of the screen's height; the date's
     * capitals are 2.6 per cent, the same way. The middle of each is where
     * the picture has it. */

    Text {
        id: clock
        anchors.horizontalCenter: parent.horizontalCenter
        y: lock.u * 27.6 - height / 2
        text: lock.time
        color: lock.paper
        font.family: lock.face
        font.pixelSize: lock.u * 14.8
        font.weight: Font.Light
        style: Text.Raised
        styleColor: "#33183660"
    }
    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        y: lock.u * 39.3 - height / 2
        text: Qt.formatDateTime(lock.now, "dddd, MMMM d")
        color: lock.paper
        font.family: lock.face
        font.pixelSize: lock.u * 3.6
        style: Text.Raised
        styleColor: "#33183660"
    }

    /* ---- what is playing --------------------------------------------------------- */

    Rectangle {
        id: card
        visible: lock.playing !== null
        anchors.horizontalCenter: parent.horizontalCenter
        y: Math.round(lock.u * 64.5 - height / 2)
        width: Math.round(lock.u * 52.6)
        height: Math.round(lock.u * 12.1)
        radius: lock.u * 2.6
        color: "#8FFFFFFF"
        border.width: lock.hair
        border.color: "#99FFFFFF"

        /* The record's own picture, or a plain blue square with a note. */
        Rectangle {
            id: sleeve
            x: lock.u * 2.2
            anchors.verticalCenter: parent.verticalCenter
            width: Math.round(lock.u * 8.4)
            height: width
            radius: lock.u * 1.3
            color: "#3D5C92"
            clip: true
            Text {
                anchors.centerIn: parent
                visible: art.status !== Image.Ready
                text: "♪"
                color: "#D8E4F6"
                font.pixelSize: lock.u * 4.2
            }
            Image {
                id: art
                anchors.fill: parent
                source: lock.playing !== null && lock.playing.art
                        ? lock.playing.art : ""
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                sourceSize.width: 256
                sourceSize.height: 256
            }
        }
        Column {
            anchors.left: sleeve.right
            anchors.leftMargin: lock.u * 2.4
            anchors.right: controls.left
            anchors.rightMargin: lock.u * 1.2
            anchors.verticalCenter: parent.verticalCenter
            spacing: lock.u * 0.5
            Text {
                width: parent.width
                elide: Text.ElideRight
                text: lock.playing !== null && lock.playing.track
                      ? lock.playing.track : "Untitled"
                textFormat: Text.PlainText
                color: lock.ink
                font.family: lock.face
                font.pixelSize: lock.u * 2.5
                font.weight: Font.DemiBold
            }
            Text {
                width: parent.width
                elide: Text.ElideRight
                visible: text !== ""
                text: lock.playing !== null && lock.playing.artist
                      ? lock.playing.artist : ""
                textFormat: Text.PlainText
                color: lock.quiet
                font.family: lock.face
                font.pixelSize: lock.u * 2.15
            }
        }
        Row {
            id: controls
            anchors.right: parent.right
            anchors.rightMargin: lock.u * 2.4
            anchors.verticalCenter: parent.verticalCenter
            spacing: lock.u * 1.5
            /* A staged card has nothing behind its buttons, and is only
             * ever photographed. */
            readonly property bool live: lock.stagedMedia === null
                                         && lock.playing !== null
                                         && lock.playing.canControl
            Control {
                kind: "previous"
                can: controls.live && lock.playing.canPrevious
                onPressed: lock.playing.previous()
            }
            Control {
                kind: lock.playing !== null && lock.playing.playing
                      ? "pause" : "play"
                can: controls.live
                onPressed: lock.playing.toggle()
            }
            Control {
                kind: "next"
                can: controls.live && lock.playing.canNext
                onPressed: lock.playing.next()
            }
        }
    }

    /* ---- the foot: somebody else, and the padlock --------------------------------- */

    Item {
        id: other
        readonly property bool real: switcher.item !== null
                                     && switcher.item.can
        visible: real || lock.stagedOther
        x: Math.round(lock.u * 11.0 - width / 2)
        y: Math.round(lock.u * 86.8 - height / 2)
        width: lock.u * 8
        height: width
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: otherArea.pressed ? "#40FFFFFF"
                 : otherArea.containsMouse ? "#26FFFFFF" : "transparent"
        }
        Glyph {
            anchors.centerIn: parent
            width: lock.u * 6.2
            kind: "person"
            weight: 1.5
        }
        MouseArea {
            id: otherArea
            anchors.fill: parent
            enabled: other.real
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: switcher.item.go()
        }
    }

    Item {
        id: padlock
        /* Above the box that takes its place: the box is there all the
         * time (see below), and a press on the padlock must reach the
         * padlock. */
        z: 2
        anchors.horizontalCenter: parent.horizontalCenter
        y: Math.round(lock.u * 86.8 - height / 2)
        width: lock.u * 11
        height: width
        opacity: lock.mode === "rest" ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 140 } }
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: padlockArea.pressed ? "#40FFFFFF"
                 : padlockArea.containsMouse ? "#26FFFFFF" : "transparent"
        }
        Glyph {
            anchors.centerIn: parent
            width: lock.u * 8.2
            kind: "padlock"
        }
        MouseArea {
            id: padlockArea
            anchors.fill: parent
            enabled: lock.mode === "rest"
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: lock.wake(true)
        }
    }

    /* ---- unlocking ------------------------------------------------------------------
     *
     * Where the padlock was. It is on the screen from the start with
     * nothing of it showing, because the box inside it is where the
     * keyboard goes: somebody who simply starts typing their password is
     * typing it here. */
    Item {
        id: asking
        z: 1
        anchors.horizontalCenter: parent.horizontalCenter
        y: Math.round(lock.u * 79.0)
        width: Math.round(lock.u * 44)
        height: lock.u * 18
        opacity: lock.mode === "rest" ? 0 : 1
        Behavior on opacity { NumberAnimation { duration: 140 } }

        Text {
            id: name
            anchors.horizontalCenter: parent.horizontalCenter
            y: 0
            text: lock.who
            textFormat: Text.PlainText
            color: lock.paper
            font.family: lock.face
            font.pixelSize: lock.u * 2.3
            font.weight: Font.Medium
            style: Text.Raised
            styleColor: "#33183660"
        }

        Rectangle {
            id: box
            y: Math.round(lock.u * 4.2)
            width: parent.width
            height: Math.round(lock.u * 5.8)
            radius: lock.u * 1.2
            visible: lock.mode !== "free"
            color: "#CC22406C"
            border.width: lock.hair
            border.color: password.activeFocus && lock.mode === "ask"
                          ? "#99FFFFFF" : "#40FFFFFF"

            Glyph {
                id: keyhole
                x: lock.u * 1.8
                anchors.verticalCenter: parent.verticalCenter
                width: lock.u * 2.9
                kind: "lock"
                weight: 2.0
                colour: "#E8EEF8"
            }
            Text {
                anchors.left: password.left
                anchors.verticalCenter: parent.verticalCenter
                visible: password.text === "" && password.preeditText === ""
                text: lock.busy ? "Checking…" : "Enter your password"
                color: "#C8D2E4"
                font.family: lock.face
                font.pixelSize: lock.u * 1.85
            }
            TextInput {
                id: password
                /* For the program that photographs this screen. */
                objectName: "password"
                anchors.left: keyhole.right
                anchors.leftMargin: lock.u * 1.3
                anchors.right: eye.left
                anchors.rightMargin: lock.u * 1.2
                anchors.verticalCenter: parent.verticalCenter
                height: parent.height
                verticalAlignment: TextInput.AlignVCenter
                clip: true
                focus: true
                readOnly: lock.busy || grace.running
                          || authenticator.graceLocked || lock.open
                cursorVisible: activeFocus && lock.mode === "ask" && !readOnly
                color: lock.paper
                selectionColor: "#5B8FE6"
                selectedTextColor: "#FFFFFF"
                font.family: lock.face
                font.pixelSize: lock.reveal ? lock.u * 1.95 : lock.u * 1.5
                font.letterSpacing: lock.reveal ? 0 : lock.u * 0.22
                echoMode: lock.reveal ? TextInput.Normal : TextInput.Password
                maximumLength: 512
                inputMethodHints: Qt.ImhNoPredictiveText
                                  | Qt.ImhNoAutoUppercase
                                  | Qt.ImhSensitiveData
                /* Enter on the picture is "let me in": for somebody with
                 * no password it is all there is to do. */
                onAccepted: {
                    if (lock.mode === "rest" || lock.open)
                        lock.wake(true)
                    else
                        lock.answer()
                }
                onTextEdited: {
                    if (lock.said !== "" && !grace.running)
                        lock.said = ""
                    lock.wake(false)
                }
            }
            Glyph {
                id: eye
                anchors.right: go.left
                anchors.rightMargin: lock.u * 1.5
                anchors.verticalCenter: parent.verticalCenter
                width: lock.u * 2.8
                kind: "eye"
                weight: 2.0
                struck: !lock.reveal
                colour: eyeArea.containsMouse ? lock.paper : "#E8EEF8"
                MouseArea {
                    id: eyeArea
                    anchors.fill: parent
                    anchors.margins: -lock.u * 0.9
                    enabled: lock.mode === "ask"
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        lock.reveal = !lock.reveal
                        idle.restart()
                        password.forceActiveFocus()
                    }
                }
            }
            /* The arrow at the end of the box: the same as Enter. */
            Item {
                id: go
                anchors.right: parent.right
                anchors.rightMargin: lock.u * 0.7
                anchors.verticalCenter: parent.verticalCenter
                width: Math.round(lock.u * 4.4)
                height: width
                Face {
                    anchors.fill: parent
                    corner: lock.u * 0.9
                    light: goArea.pressed ? "#3F7FE6"
                         : goArea.containsMouse ? "#63A5FB" : "#5398F7"
                    dark: goArea.pressed ? "#2B5FCB"
                        : goArea.containsMouse ? "#3D7CEC" : "#3170E4"
                }
                Glyph {
                    anchors.centerIn: parent
                    width: lock.u * 2.3
                    kind: "arrow"
                    weight: 2.2
                }
                MouseArea {
                    id: goArea
                    anchors.fill: parent
                    enabled: lock.mode === "ask"
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        password.forceActiveFocus()
                        lock.answer()
                    }
                }
            }
        }

        /* Nothing to ask: one button. */
        Item {
            id: letIn
            visible: lock.mode === "free"
            anchors.horizontalCenter: parent.horizontalCenter
            y: box.y
            width: Math.round(lock.u * 26)
            height: box.height
            Face {
                anchors.fill: parent
                corner: lock.u * 1.2
                light: letInArea.pressed ? "#3F7FE6"
                     : letInArea.containsMouse ? "#63A5FB" : "#5398F7"
                dark: letInArea.pressed ? "#2B5FCB"
                    : letInArea.containsMouse ? "#3D7CEC" : "#3170E4"
            }
            Row {
                anchors.centerIn: parent
                spacing: lock.u * 1.0
                Glyph {
                    anchors.verticalCenter: parent.verticalCenter
                    width: lock.u * 2.6
                    kind: "unlocked"
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Unlock"
                    color: "#FFFFFF"
                    font.family: lock.face
                    font.pixelSize: lock.u * 1.95
                    font.weight: Font.Medium
                }
            }
            MouseArea {
                id: letInArea
                anchors.fill: parent
                enabled: lock.mode === "free"
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: lock.wake(true)
            }
        }

        /* What went wrong, or what is about to. */
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            y: box.y + box.height + lock.u * 1.4
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            textFormat: Text.PlainText
            /* 1 is the locker's number for a fingerprint reader it has
             * found and is listening to. */
            text: lock.said !== "" ? lock.said
                : lock.mode !== "ask" ? ""
                : caps.item !== null && caps.item.on ? "Caps Lock is on."
                : (authenticator.authenticatorTypes & 1)
                  ? "Or touch the fingerprint reader."
                : ""
            color: lock.said !== "" ? lock.wrong : lock.paper
            font.family: lock.face
            font.pixelSize: lock.u * 1.8
            style: Text.Raised
            styleColor: "#40183660"
        }
    }
}
