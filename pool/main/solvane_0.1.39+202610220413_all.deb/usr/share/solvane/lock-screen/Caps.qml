/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — the lock screen: whether Caps Lock is on
 *
 * Apart from the drawing for the same reason Switch.qml is: it leans on a
 * private piece of Plasma. Without it the lock screen does not say that
 * Caps Lock is on, and does everything else.
 */

import QtQuick
import org.kde.plasma.private.keyboardindicator as Indicator

Item {
    readonly property bool on: key.locked

    Indicator.KeyState {
        id: key
        key: Qt.Key_CapsLock
    }
}
