/* SPDX-License-Identifier: Solvane-Source
 *
 * One entry of Settings' sidebar, as the picture draws them: a mark and a
 * word, and the chosen one on a rounded pill. 353 by 68 of the picture's
 * pixels; the mark's middle 37 in, the word 78 in.
 */
import QtQuick
import org.solvane.flowbar as Flow

Item {
    id: item

    property string glyph: ""
    property string label: ""
    property bool chosen: false

    signal picked()

    implicitWidth: Style.s(353)
    implicitHeight: Style.s(68)

    Rectangle {
        anchors.fill: parent
        radius: Style.s(18)
        color: item.chosen ? Style.accentTint
             : press.pressed ? Style.cardPressed
             : press.containsMouse ? Style.card : "transparent"
    }
    Flow.Glyph {
        x: Style.s(37) - width / 2
        anchors.verticalCenter: parent.verticalCenter
        width: Style.s(34)
        height: width
        kind: item.glyph
        ink: item.chosen ? Style.accentInk : Style.inkSoft
    }
    Text {
        x: Style.s(78)
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width - x - Style.s(16)
        text: item.label
        elide: Text.ElideRight
        color: Style.ink
        font.family: Style.family
        font.pixelSize: Style.sideSize
        font.weight: item.chosen ? Font.DemiBold : Font.Medium
    }
    MouseArea {
        id: press
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: item.picked()
    }
    Accessible.role: Accessible.PageTab
    Accessible.name: item.label
}
