/* SPDX-License-Identifier: Solvane-Source
 *
 * One of the three cards across the top of the picture's System page: a
 * mark on a tile, a title and a line under it. 398 by 118 of the
 * picture's pixels; the tile 70 square, 20 in; the words 115 in.
 */
import QtQuick
import org.solvane.flowbar as Flow

Item {
    id: card

    property string glyph: ""
    property int level: 3
    property string title: ""
    property string detail: ""

    signal picked()

    implicitWidth: Style.s(398)
    implicitHeight: Style.s(118)

    Rectangle {
        anchors.fill: parent
        radius: Style.s(22)
        color: press.pressed ? Style.cardPressed : press.containsMouse ? Style.cardLit : Style.card
        border.width: 1
        border.color: Style.edge
    }
    Rectangle {
        id: tile
        x: Style.s(20)
        anchors.verticalCenter: parent.verticalCenter
        width: Style.s(70)
        height: width
        radius: Style.s(16)
        color: Style.tile
        Flow.Glyph {
            anchors.centerIn: parent
            width: Style.s(40)
            height: width
            kind: card.glyph
            level: card.level
            ink: Style.ink
        }
    }
    Column {
        x: Style.s(115)
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width - x - Style.s(18)
        spacing: Math.round(Style.body * 0.22)
        Text {
            width: parent.width
            text: card.title
            elide: Text.ElideRight
            color: Style.ink
            font.family: Style.family
            font.pixelSize: Style.cardSize
            font.weight: Font.DemiBold
        }
        Text {
            width: parent.width
            text: card.detail
            elide: Text.ElideRight
            color: Style.inkSoft
            font.family: Style.family
            font.pixelSize: Style.detailSize
        }
    }
    MouseArea {
        id: press
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: card.picked()
    }
    Accessible.role: Accessible.Button
    Accessible.name: card.title
    Accessible.description: card.detail
}
