/* SPDX-License-Identifier: Solvane-Source
 *
 * One line of a group: what it is on the left (a title, a line under it),
 * and the control at the right. A hairline above every line but a group's
 * first, so a group reads as one card cut into rows, as the Control
 * Center's cards are.
 */
import QtQuick

Item {
    id: line

    property string title: ""
    property string detail: ""
    property bool usable: true
    // The control: put inside the line, it is placed at the right.
    default property alias control: slot.data
    // A control that wants the whole width under the words (a slider).
    property bool wide: false

    width: parent ? parent.width : implicitWidth
    implicitHeight: Math.max(Style.s(104),
                             words.implicitHeight + Style.s(44) + (wide ? slot.childrenRect.height + Style.s(18) : 0))

    Rectangle {
        visible: !line.Positioner.isFirstItem
        x: Style.s(28)
        width: parent.width - Style.s(56)
        height: 1
        color: Style.line
    }
    Column {
        id: words
        x: Style.s(28)
        y: line.wide ? Style.s(24) : Math.round((line.height - implicitHeight) / 2)
        width: (line.wide ? line.width - Style.s(56) : line.width - x - slot.width - Style.s(56))
        spacing: Math.round(Style.body * 0.2)
        opacity: line.usable ? 1 : 0.55
        Text {
            width: parent.width
            text: line.title
            wrapMode: Text.WordWrap
            color: Style.ink
            font.family: Style.family
            font.pixelSize: Style.cardSize
            font.weight: Font.Medium
        }
        Text {
            width: parent.width
            visible: text !== ""
            text: line.detail
            wrapMode: Text.WordWrap
            color: Style.inkSoft
            font.family: Style.family
            font.pixelSize: Style.detailSize
        }
    }
    Item {
        id: slot
        width: line.wide ? line.width - Style.s(56) : childrenRect.width
        height: childrenRect.height
        x: line.wide ? Style.s(28) : line.width - width - Style.s(28)
        y: line.wide ? words.y + words.implicitHeight + Style.s(18)
                     : Math.round((line.height - height) / 2)
    }
}
