/* SPDX-License-Identifier: Solvane-Source
 *
 * One of several: what is chosen now, in a pill with a down mark, and the
 * whole list on a piece of glass when it is pressed. `options` is
 * [{"key": ..., "label": ...}]; `chosen` is the key the machine says is
 * chosen now. Picking says which, and waits for the machine to agree.
 */
import QtQuick
import QtQuick.Templates as T
import org.solvane.flowbar as Flow

Item {
    id: choice

    property var options: []
    property string chosen: ""
    property bool usable: true
    property string label: ""
    signal picked(string key)

    readonly property string shownLabel: {
        for (var i = 0; i < options.length; i++)
            if (String(options[i].key) === String(chosen)) return options[i].label
        return ""
    }

    implicitWidth: Math.min(Style.s(560), Math.max(Style.s(260), words.implicitWidth + Style.s(110)))
    implicitHeight: Style.s(64)
    opacity: usable ? 1 : 0.45

    Rectangle {
        anchors.fill: parent
        radius: Style.s(16)
        color: press.pressed ? Style.cardPressed : press.containsMouse || list.opened ? Style.cardLit : Style.card
        border.width: 1
        border.color: list.opened ? Qt.rgba(126 / 255, 182 / 255, 245 / 255, 0.55) : Style.edge
    }
    Text {
        id: words
        x: Style.s(24)
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width - x - Style.s(70)
        text: choice.shownLabel
        elide: Text.ElideRight
        color: Style.ink
        font.family: Style.family
        font.pixelSize: Style.detailSize
        font.weight: Font.Medium
    }
    Flow.Glyph {
        anchors.right: parent.right
        anchors.rightMargin: Style.s(22)
        anchors.verticalCenter: parent.verticalCenter
        width: Style.s(28)
        height: width
        kind: "down"
        ink: Style.inkSoft
    }
    MouseArea {
        id: press
        anchors.fill: parent
        enabled: choice.usable && choice.options.length > 0
        hoverEnabled: true
        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: list.opened ? list.close() : list.open()
    }

    T.Popup {
        id: list
        y: choice.height + Style.s(8)
        width: Math.max(choice.width, Style.s(320))
        height: Math.min(contentHeight + topPadding + bottomPadding, Style.s(560))
        padding: Style.s(10)
        modal: false
        focus: true
        closePolicy: T.Popup.CloseOnEscape | T.Popup.CloseOnPressOutside
        background: Rectangle {
            radius: Style.s(18)
            color: "#243250"
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.12)
        }
        contentItem: ListView {
            id: view
            implicitHeight: contentHeight
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            model: choice.options
            delegate: Item {
                id: entry
                required property var modelData
                readonly property bool isChosen: String(modelData.key) === String(choice.chosen)
                width: view.width
                height: Style.s(64)
                Rectangle {
                    anchors.fill: parent
                    radius: Style.s(12)
                    color: entryPress.containsMouse ? Style.cardLit : "transparent"
                }
                Text {
                    x: Style.s(20)
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - x - Style.s(64)
                    text: entry.modelData.label
                    elide: Text.ElideRight
                    color: Style.ink
                    font.family: Style.family
                    font.pixelSize: Style.detailSize
                    font.weight: entry.isChosen ? Font.DemiBold : Font.Normal
                }
                Flow.Glyph {
                    visible: entry.isChosen
                    anchors.right: parent.right
                    anchors.rightMargin: Style.s(18)
                    anchors.verticalCenter: parent.verticalCenter
                    width: Style.s(28)
                    height: width
                    kind: "check"
                    ink: Style.accentInk
                }
                MouseArea {
                    id: entryPress
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        list.close()
                        if (!entry.isChosen) choice.picked(String(entry.modelData.key))
                    }
                }
            }
        }
    }
    Accessible.role: Accessible.ComboBox
    Accessible.name: choice.label
    Accessible.description: choice.shownLabel
}
