/* SPDX-License-Identifier: Solvane-Source */
import QtQuick

Text {
    x: Style.s(10)
    color: Style.ink
    font.family: Style.family
    font.pixelSize: Style.headingSize
    font.weight: Font.DemiBold
}
