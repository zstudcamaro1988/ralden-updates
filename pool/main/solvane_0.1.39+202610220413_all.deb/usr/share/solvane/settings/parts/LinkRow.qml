/* SPDX-License-Identifier: Solvane-Source
 *
 * One of the long rows under the picture's cards: a mark, a title, a line
 * under it and a chevron at the far end. 115 of the picture's pixels tall;
 * the mark's middle 50 in, the words 115 in, the chevron 43 from the end.
 */
import QtQuick
import org.solvane.flowbar as Flow

Item {
    id: row

    property string glyph: ""
    property string title: ""
    property string detail: ""
    property bool chevron: true

    signal picked()

    implicitHeight: Style.s(115)

    Rectangle {
        anchors.fill: parent
        radius: Style.s(18)
        color: press.pressed ? Style.cardPressed : press.containsMouse ? Style.cardLit : Style.card
        border.width: 1
        border.color: Style.edge
    }
    Flow.Glyph {
        x: Style.s(50) - width / 2
        anchors.verticalCenter: parent.verticalCenter
        width: Style.s(42)
        height: width
        kind: row.glyph
        ink: Style.inkSoft
    }
    Column {
        x: Style.s(115)
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width - x - Style.s(90)
        spacing: Math.round(Style.body * 0.22)
        Text {
            width: parent.width
            text: row.title
            elide: Text.ElideRight
            color: Style.ink
            font.family: Style.family
            font.pixelSize: Style.cardSize
            font.weight: Font.DemiBold
        }
        Text {
            width: parent.width
            visible: text !== ""
            text: row.detail
            elide: Text.ElideRight
            color: Style.inkSoft
            font.family: Style.family
            font.pixelSize: Style.detailSize
        }
    }
    Flow.Glyph {
        visible: row.chevron
        anchors.right: parent.right
        anchors.rightMargin: Style.s(43) - width / 2
        anchors.verticalCenter: parent.verticalCenter
        width: Style.s(30)
        height: width
        kind: "next"
        ink: Style.inkSoft
    }
    MouseArea {
        id: press
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: row.picked()
    }
    Accessible.role: Accessible.Button
    Accessible.name: row.title
    Accessible.description: row.detail
}
