/* SPDX-License-Identifier: Solvane-Source
 *
 * A switch, the Control Center's: a pill, the knob a white circle at the
 * left when off and the right when on, the track the accent when on. It
 * says it was flipped and waits for the machine to agree - the page sets
 * `on` from what the machine reports, so a switch that could not be thrown
 * goes back by itself.
 */
import QtQuick

Item {
    id: toggle

    property bool on: false
    property bool usable: true
    property string label: ""          // for screen readers; the line says it
    signal flipped()

    implicitWidth: Style.s(84)
    implicitHeight: Style.s(48)
    opacity: usable ? 1.0 : 0.45

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: toggle.on ? Style.accent : Qt.rgba(1, 1, 1, 0.22)
        Behavior on color { ColorAnimation { duration: 140 } }
    }
    Rectangle {
        readonly property real gap: Math.max(2, Style.s(4))
        width: toggle.height - gap * 2
        height: width
        radius: width / 2
        y: gap
        x: toggle.on ? toggle.width - width - gap : gap
        color: "#FFFFFF"
        Behavior on x { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
    }
    MouseArea {
        anchors.fill: parent
        anchors.margins: -Style.s(8)
        enabled: toggle.usable
        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: toggle.flipped()
    }
    Accessible.role: Accessible.CheckBox
    Accessible.checkable: true
    Accessible.checked: toggle.on
    Accessible.name: toggle.label
}
