/* SPDX-License-Identifier: Solvane-Source
 *
 * A line to type in: a rounded field, a soft word in it until something is
 * typed, a mark at the front when it is for finding something. What is
 * typed is `text`; Return says `accepted`, and a person typing (not the
 * text being set) says `edited`. `secret` draws a password as dots.
 */
import QtQuick
import org.solvane.flowbar as Flow

Item {
    id: field

    property alias text: input.text
    property string placeholder: ""
    property string glyph: ""          // "search", or "" for none
    property bool usable: true
    // A password: dots on the screen, and nothing for the clipboard.
    property bool secret: false
    signal accepted()
    signal edited()

    function focusIt() { input.forceActiveFocus() }

    implicitWidth: Style.s(520)
    implicitHeight: Style.s(72)
    opacity: usable ? 1 : 0.45

    Rectangle {
        anchors.fill: parent
        radius: Style.s(18)
        color: input.activeFocus ? Style.cardLit : Style.card
        border.width: 1
        border.color: input.activeFocus ? Qt.rgba(126 / 255, 182 / 255, 245 / 255, 0.55) : Style.edge
    }
    Flow.Glyph {
        id: mark
        visible: field.glyph !== ""
        x: Style.s(24)
        anchors.verticalCenter: parent.verticalCenter
        width: visible ? Style.s(30) : 0
        height: width
        kind: field.glyph
        ink: Style.inkSoft
    }
    TextInput {
        id: input
        anchors.left: mark.visible ? mark.right : parent.left
        anchors.leftMargin: mark.visible ? Style.s(16) : Style.s(24)
        anchors.right: parent.right
        anchors.rightMargin: Style.s(24)
        anchors.verticalCenter: parent.verticalCenter
        enabled: field.usable
        clip: true
        echoMode: field.secret ? TextInput.Password : TextInput.Normal
        color: Style.ink
        selectionColor: Style.accent
        selectedTextColor: "#FFFFFF"
        font.family: Style.family
        font.pixelSize: Style.cardSize
        onAccepted: field.accepted()
        onTextEdited: field.edited()
        Text {
            visible: input.text === ""
            anchors.verticalCenter: parent.verticalCenter
            text: field.placeholder
            color: Style.inkFaint
            font: input.font
        }
    }
    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.IBeamCursor
        acceptedButtons: Qt.NoButton
    }
    Accessible.role: Accessible.EditableText
    Accessible.name: field.placeholder
}
