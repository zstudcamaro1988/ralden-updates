/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - Settings
 *
 * The owner's picture (reference/2d-settings.jpg): a sidebar of sections
 * down the left, the chosen one on a pill; the section's page beside it,
 * its title at the top. In Alpine Mist's navy, as every Solvane window is.
 *
 * THIS FILE ONLY DRAWS AND NAVIGATES. Each page is handed `areas` - one
 * object per part of the machine (areas.py), each with a `state` to show
 * and an `act(verb, value)` to change it - and says which page to open
 * next. So every page can be photographed before a build with made-up
 * objects (tools/preview-events/settings.py), and a page that asks for
 * something no area answers is found by the checker, not by a person
 * pressing a button that does nothing.
 *
 * THE SIDEBAR HAS ONLY WHAT IS BUILT. The picture has ten sections. A
 * section is added here on the day its page exists: an entry that opens
 * an empty page is a promise the program cannot keep. docs/settings.md
 * says which are built and in what order the rest come.
 */
import QtQuick
import QtQuick.Window
import org.kde.kirigami as Kirigami
import "parts"

Window {
    id: window

    required property var areas
    required property string startPage
    property string page: startPage

    title: "Settings"
    color: Style.window
    visible: true

    // The picture's 26-pixel sidebar labels at Plasma's own size: the
    // window is the picture, at the scale everything else is written in.
    readonly property real body: Math.max(11, Math.round(Kirigami.Units.gridUnit * 0.72))
    Binding { target: Style; property: "body"; value: window.body }
    Binding { target: Style; property: "u"; value: window.body / 26 }

    // Wider than the picture's 1729: at the picture's width the cards cut
    // their lines short ("Brightness, Night Light...", seen on the test
    // machine on 15 October 2026), and Solvane's lines say more than the
    // picture's. The picture is a crop; how big the window is, it does not say.
    width: Math.min(Screen.desktopAvailableWidth - 40, Math.round(2200 * body / 26))
    height: Math.min(Screen.desktopAvailableHeight - 40, Math.round(1300 * body / 26))
    minimumWidth: Math.round(1180 * body / 26)
    minimumHeight: Math.round(640 * body / 26)

    // The sections of the sidebar, in the picture's order.
    readonly property var sections: [
        { "key": "system", "name": "System", "glyph": "system" },
        { "key": "bluetooth", "name": "Bluetooth", "glyph": "bluetooth" },
        { "key": "network", "name": "Network", "glyph": "wifi" },
        { "key": "personalization", "name": "Personalization", "glyph": "brush" },
        { "key": "apps", "name": "Apps", "glyph": "apps" },
        { "key": "accounts", "name": "Accounts", "glyph": "person" },
        { "key": "privacy", "name": "Privacy", "glyph": "shield" },
        { "key": "updates", "name": "Updates", "glyph": "update" },
        // The picture's second "Updates", which has a clock for its mark.
        { "key": "time", "name": "Time & Language", "glyph": "clock" },
        { "key": "about", "name": "About", "glyph": "info" }
    ]
    // The pages under a section, and the section each belongs to.
    readonly property var pages: ({
        "system":        { "file": "SystemPage.qml",        "section": "system", "area": "power" },
        "display":       { "file": "DisplayPage.qml",       "section": "system", "area": "display" },
        "sound":         { "file": "SoundPage.qml",         "section": "system", "area": "sound" },
        "notifications": { "file": "NotificationsPage.qml", "section": "system", "area": "" },
        "power":         { "file": "PowerPage.qml",         "section": "system", "area": "power" },
        "multitasking":  { "file": "MultitaskingPage.qml",  "section": "system", "area": "multitasking" },
        "keyboard":      { "file": "KeyboardPage.qml",      "section": "system", "area": "keyboard" },
        "layouts":       { "file": "LayoutsPage.qml",       "section": "system", "area": "keyboard", "parent": "keyboard" },
        "shortcuts":     { "file": "ShortcutsPage.qml",     "section": "system", "area": "shortcuts", "parent": "keyboard" },
        "pointing":      { "file": "PointingPage.qml",      "section": "system", "area": "pointing" },
        "bluetooth":     { "file": "BluetoothPage.qml",     "section": "bluetooth", "area": "bluetooth" },
        "network":       { "file": "NetworkPage.qml",       "section": "network", "area": "network" },
        "personalization": { "file": "PersonalizationPage.qml", "section": "personalization", "area": "look" },
        "apps":          { "file": "AppsPage.qml",          "section": "apps",   "area": "apps" },
        "accounts":      { "file": "AccountsPage.qml",      "section": "accounts", "area": "accounts" },
        "privacy":       { "file": "PrivacyPage.qml",       "section": "privacy", "area": "privacy" },
        "updates":       { "file": "UpdatesPage.qml",       "section": "updates", "area": "updates" },
        "time":          { "file": "TimePage.qml",          "section": "time",   "area": "time" },
        "timezone":      { "file": "TimezonePage.qml",      "section": "time",   "area": "time", "parent": "time" },
        "about":         { "file": "AboutPage.qml",         "section": "about",  "area": "about" }
    })
    readonly property var current: pages[page] || pages["system"]
    readonly property string section: current.section

    function sectionName(key) {
        for (var i = 0; i < sections.length; i++)
            if (sections[i].key === key) return sections[i].name
        return ""
    }
    function go(next) {
        if (pages[next]) window.page = next
    }
    // Back is the page this one was opened from: its `parent` where it has
    // one (Add a layout, under Keyboard), else its section's own page.
    function back() {
        var up = window.current.parent || window.section
        if (window.page !== up) window.page = up
    }

    // Only the open page's part of the machine is asked about, and asked
    // again every few seconds while it is open.
    property string watching: ""
    function watchFor(key) {
        var next = (pages[key] || {}).area || ""
        if (next === watching) return
        if (watching !== "" && areas[watching]) areas[watching].watch(false)
        watching = next
        if (watching !== "" && areas[watching]) areas[watching].watch(true)
    }
    // Each page is made with `areas` already given, so nothing on it is
    // ever drawn from an object it has not been handed yet.
    //
    // THE PAGE IS LOOKED UP HERE, NOT READ FROM `current`. Seen on the test
    // machine on 15 October 2026: called from onPageChanged, `current` had
    // not yet caught up with `page`, and every page showed the one before
    // it - the sidebar said System over the About page.
    function show() {
        var p = window.pages[window.page] || window.pages["system"]
        shown.setSource("pages/" + p.file, { "areas": window.areas })
        scroller.contentY = 0
    }
    onPageChanged: { show(); watchFor(page) }
    Component.onCompleted: { show(); watchFor(page) }

    Shortcut {
        sequences: [StandardKey.Back, "Alt+Left", "Backspace"]
        onActivated: window.back()
    }
    Shortcut {
        sequences: [StandardKey.Close, StandardKey.Quit]
        onActivated: window.close()
    }

    // ---- the sidebar ------------------------------------------------------------
    Rectangle {
        id: sidebar
        width: Style.s(405)
        height: parent.height
        color: Style.sidebar

        Column {
            x: Style.s(30)
            y: Style.s(37)
            spacing: Style.s(1)
            Repeater {
                model: window.sections
                SideItem {
                    required property var modelData
                    glyph: modelData.glyph
                    label: modelData.name
                    chosen: window.section === modelData.key
                    onPicked: window.go(modelData.key)
                }
            }
        }
    }

    // ---- the page ------------------------------------------------------------------
    Flickable {
        id: scroller
        anchors.left: sidebar.right
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        contentWidth: width
        contentHeight: holder.height + Style.s(80)
        clip: true
        boundsBehavior: Flickable.StopAtBounds

        Item {
            id: holder
            x: Style.s(40)
            y: Style.s(37)
            width: scroller.width - Style.s(40) - Style.s(44)
            height: shown.item ? shown.item.implicitHeight : 0

            Loader {
                id: shown
                width: parent.width
            }
            Connections {
                target: shown.item
                ignoreUnknownSignals: true
                function onOpen(next) { window.go(next) }
                function onBack() { window.back() }
            }
        }
    }
}
