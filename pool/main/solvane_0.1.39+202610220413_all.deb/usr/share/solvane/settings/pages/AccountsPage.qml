/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - Accounts
 *
 *   Your account    your picture, your name, your login name and whether
 *                   you administer this computer; the name and the picture
 *                   changed through AccountsService, the password through
 *                   passwd itself (it asks the system whether the current
 *                   one is right and whether the new one will do).
 *   Other people    who else has an account here, each with Remove (asked
 *                   again, with the choice of keeping their files) unless
 *                   they are signed in now.
 *   Add someone     a name, a username (the First Start's suggestion from
 *                   the name), administrator or not, a password. Through
 *                   Settings' people helper: AccountsService, which asks
 *                   for an administrator's password. Not on the disc, whose
 *                   accounts are gone at the next restart.
 *   More            Plasma's own window for accounts.
 */
import QtQuick
// As Bar, not Flow: this page also uses QtQuick's own Flow (the pictures),
// and an import named Flow would hide it.
import org.solvane.flowbar as Bar
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.accounts : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property bool readable: st.known === true && st.failed !== true
    readonly property bool free: (st.busy || "") === ""
    readonly property var pictures: st.pictures || []
    readonly property var others: st.others || []

    // Adding someone: whether the username was typed (or only suggested),
    // and administrator or not.
    property bool loginTyped: false
    property bool newAdmin: false
    // The login of the person whose removal is being asked about, or "".
    property string removing: ""
    readonly property var removingWho: {
        for (var i = 0; i < others.length; i++)
            if (others[i].login === removing)
                return others[i]
        return null
    }
    readonly property string added: st.added || ""
    onAddedChanged: if (added !== "") {
        loginTyped = false
        newAdmin = false
        newName.text = ""
        newLogin.text = ""
    }

    // In the page: the boxes are emptied once what was typed has been sent.
    function sendPassword() {
        page.act("password", { "current": current.text, "new": fresh.text, "again": again.text })
        current.text = ""
        fresh.text = ""
        again.text = ""
    }
    function addPerson() {
        page.act("add", { "name": newName.text, "login": newLogin.text, "admin": page.newAdmin,
                          "password": newPassword.text, "again": newAgain.text })
        newPassword.text = ""
        newAgain.text = ""
    }
    function removePerson(files) {
        page.act("remove", { "login": page.removing, "files": files })
        page.removing = ""
    }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle { text: "Accounts" }

        Note {
            visible: page.st.known === true && page.st.failed === true
            text: "AccountsService did not answer, so this account cannot be shown."
        }

        // Who you are, as the picture's cards are drawn.
        Rectangle {
            visible: page.readable
            width: parent.width
            height: Style.s(170)
            radius: Style.s(22)
            color: Style.card
            border.width: 1
            border.color: Style.edge
            Rectangle {
                id: face
                x: Style.s(28)
                anchors.verticalCenter: parent.verticalCenter
                width: Style.s(112)
                height: width
                radius: width / 2
                color: Style.accentTint
                // Round, photographs too (parts/Portrait.qml says why).
                Portrait {
                    anchors.fill: parent
                    visible: (page.st.pictureUrl || "") !== ""
                    source: page.st.pictureUrl || ""
                }
                Bar.Glyph {
                    visible: (page.st.pictureUrl || "") === ""
                    anchors.centerIn: parent
                    width: parent.width * 0.5
                    height: width
                    kind: "person"
                    ink: Style.ink
                }
            }
            Column {
                anchors.left: face.right
                anchors.leftMargin: Style.s(28)
                anchors.verticalCenter: parent.verticalCenter
                spacing: Style.s(8)
                Text {
                    text: page.st.name || page.st.login || ""
                    color: Style.ink
                    font.family: Style.family
                    font.pixelSize: Style.titleSize
                    font.weight: Font.DemiBold
                }
                Text {
                    text: (page.st.login || "") + " · "
                          + (page.st.admin === true ? "Administrator of this computer" : "Standard account")
                    color: Style.inkSoft
                    font.family: Style.family
                    font.pixelSize: Style.detailSize
                }
            }
        }

        Group {
            visible: page.readable
            heading: "Your name"
            Line {
                title: "Name"
                detail: "The name the login screen shows above your password."
                wide: true
                Row {
                    spacing: Style.s(16)
                    Field {
                        id: nameField
                        width: Style.s(520)
                        placeholder: page.st.name || "Your name"
                        usable: page.free
                        onAccepted: if (text !== "") { page.act("name", text); text = "" }
                    }
                    Button {
                        text: "Save"
                        usable: page.free && nameField.text !== ""
                        onPressed: { page.act("name", nameField.text); nameField.text = "" }
                    }
                }
            }
        }

        Column {
            visible: page.readable && page.pictures.length > 0
            width: parent.width
            spacing: Style.s(16)
            Heading { text: "Your picture" }
            Flow {
                width: parent.width
                spacing: Style.s(18)
                Repeater {
                    model: page.pictures
                    Rectangle {
                        id: choice
                        required property var modelData
                        readonly property bool isMine: modelData.path === page.st.picture
                        width: Style.s(120)
                        height: width
                        radius: width / 2
                        color: Style.card
                        border.width: isMine ? Style.s(5) : 1
                        border.color: isMine ? Style.accent : (pick.containsMouse ? Style.inkFaint : Style.edge)
                        Portrait {
                            anchors.fill: parent
                            anchors.margins: choice.isMine ? Style.s(8) : Style.s(4)
                            source: choice.modelData.url
                        }
                        MouseArea {
                            id: pick
                            anchors.fill: parent
                            hoverEnabled: true
                            enabled: page.free
                            cursorShape: Qt.PointingHandCursor
                            onClicked: page.act("picture", choice.modelData.path)
                        }
                    }
                }
            }
        }

        Note {
            visible: (page.st.busy || "") !== ""
            text: page.st.busy || ""
        }
        Note {
            visible: (page.st.note || "") !== ""
            text: page.st.note || ""
        }

        Group {
            visible: page.readable
            heading: "Your password"
            Line {
                title: "Change your password"
                detail: "Your current password first, then the new one twice."
                wide: true
                Column {
                    spacing: Style.s(14)
                    Field {
                        id: current
                        width: Style.s(520)
                        secret: true
                        placeholder: "Current password"
                        usable: page.free
                    }
                    Field {
                        id: fresh
                        width: Style.s(520)
                        secret: true
                        placeholder: "New password"
                        usable: page.free
                    }
                    Row {
                        spacing: Style.s(16)
                        Field {
                            id: again
                            width: Style.s(520)
                            secret: true
                            placeholder: "The new password again"
                            usable: page.free
                            onAccepted: page.sendPassword()
                        }
                        Button {
                            text: "Change"
                            strong: true
                            usable: page.free && current.text !== "" && fresh.text !== "" && again.text !== ""
                            onPressed: page.sendPassword()
                        }
                    }
                }
            }
        }
        Note {
            visible: (page.st.passwordNote || "") !== "" || page.st.passwordChanged === true
            text: page.st.passwordChanged === true
                  ? "Your password has been changed. Use the new one from now on."
                  : (page.st.passwordNote || "")
        }

        Note {
            visible: page.readable && page.st.live === true
            text: "People can be added once Solvane is installed: on this disc, an account "
                  + "would be gone at the next restart."
        }

        Group {
            visible: page.readable && page.others.length > 0
            heading: "Other people"
            Repeater {
                model: page.others
                Line {
                    required property var modelData
                    title: modelData.name
                    detail: modelData.login + " · " + (modelData.admin ? "Administrator" : "Standard account")
                            + (modelData.signedIn ? " · Signed in now" : "")
                    Button {
                        visible: page.st.live !== true && modelData.removable === true
                        text: "Remove"
                        usable: page.free && page.removing === ""
                        onPressed: page.removing = modelData.login
                    }
                }
            }
        }

        // Removing is asked about once more, with what happens to the files.
        Group {
            visible: page.removingWho !== null
            heading: "Remove " + (page.removingWho ? page.removingWho.name : "")
            Line {
                title: "Remove " + (page.removingWho ? page.removingWho.name : "") + "'s account?"
                detail: (page.removingWho ? page.removingWho.name : "")
                        + " will no longer be able to sign in. Their files are in "
                        + (page.removingWho ? page.removingWho.home : "")
                        + ": they can be kept there, or removed with the account."
                wide: true
                Row {
                    spacing: Style.s(16)
                    Button {
                        text: "Cancel"
                        onPressed: page.removing = ""
                    }
                    Button {
                        text: "Keep their files"
                        usable: page.free
                        onPressed: page.removePerson(false)
                    }
                    Button {
                        text: "Remove their files too"
                        strong: true
                        usable: page.free
                        onPressed: page.removePerson(true)
                    }
                }
            }
        }

        Group {
            visible: page.readable && page.st.live !== true
            heading: "Add someone"
            Line {
                title: "Their name"
                detail: "As the login screen will show it."
                wide: true
                Field {
                    id: newName
                    width: Style.s(520)
                    placeholder: "Their name"
                    usable: page.free
                    onTextChanged: {
                        page.act("suggest", text)
                        if (!page.loginTyped)
                            newLogin.text = page.st.suggestion || ""
                    }
                }
            }
            Line {
                title: "Username"
                detail: "What they will sign in with: lower-case letters and digits, starting with a letter."
                wide: true
                Field {
                    id: newLogin
                    width: Style.s(520)
                    placeholder: "Username"
                    usable: page.free
                    onEdited: page.loginTyped = text !== ""
                }
            }
            Line {
                title: "Administrator"
                detail: page.newAdmin
                        ? "Can install programs and change anything on this computer."
                        : "A standard account: their own files and settings, and nothing else."
                Switch {
                    on: page.newAdmin
                    usable: page.free
                    label: "Administrator"
                    onFlipped: page.newAdmin = !on
                }
            }
            Line {
                title: "Their password"
                detail: "They can change it in Settings, under Accounts, once they have signed in."
                wide: true
                Column {
                    spacing: Style.s(14)
                    Field {
                        id: newPassword
                        width: Style.s(520)
                        secret: true
                        placeholder: "Password"
                        usable: page.free
                    }
                    Row {
                        spacing: Style.s(16)
                        Field {
                            id: newAgain
                            width: Style.s(520)
                            secret: true
                            placeholder: "The password again"
                            usable: page.free
                            onAccepted: page.addPerson()
                        }
                        Button {
                            text: "Add"
                            strong: true
                            usable: page.free && newLogin.text !== "" && newPassword.text !== ""
                                    && newAgain.text !== ""
                            onPressed: page.addPerson()
                        }
                    }
                }
            }
        }
        Note {
            visible: (page.st.peopleNote || "") !== "" || page.added !== ""
            text: page.added !== ""
                  ? page.added + " can sign in now, with the username " + (page.st.addedLogin || "") + "."
                  : (page.st.peopleNote || "")
        }

        Column {
            visible: page.readable
            width: parent.width
            spacing: Style.s(16)
            Heading { text: "More" }
            LinkRow {
                width: parent.width
                glyph: "person"
                title: "Other account settings"
                detail: "Plasma's own window for people's accounts"
                onPicked: page.act("more", true)
            }
        }
    }
}
