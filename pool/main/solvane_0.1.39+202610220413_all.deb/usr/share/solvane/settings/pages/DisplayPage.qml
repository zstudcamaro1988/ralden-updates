/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - System - Display
 *
 *   Brightness     the screen's backlight (brightnessctl), as the Control
 *                  Center sets it. A screen with none - a desktop monitor,
 *                  the test machine - says so instead of drawing a slider.
 *   Night Light    KWin's, through /usr/lib/solvane/night-light, the same
 *                  program the Control Center uses: on or off, how warm,
 *                  and whether only from sunset to sunrise where you are.
 *   Resolution,    the screen, through kscreen-doctor. A change is undone
 *   Orientation    by itself after fifteen seconds unless it is kept.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.display : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property var orientations: [
        { "key": "none", "label": "Upright" },
        { "key": "left", "label": "Turned left" },
        { "key": "right", "label": "Turned right" },
        { "key": "inverted", "label": "Upside down" }
    ]

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Display"
            parentName: "System"
            onBack: page.back()
        }

        // ---- kept, or changed back ---------------------------------------------
        Rectangle {
            visible: page.st.asking === true
            width: parent.width
            height: keepColumn.implicitHeight + Style.s(56)
            radius: Style.s(22)
            color: Style.accentTint
            border.width: 1
            border.color: Qt.rgba(126 / 255, 182 / 255, 245 / 255, 0.45)
            Column {
                id: keepColumn
                x: Style.s(28)
                y: Style.s(28)
                width: parent.width - Style.s(56)
                spacing: Style.s(20)
                Text {
                    width: parent.width
                    text: "Keep this?"
                    color: Style.ink
                    font.family: Style.family
                    font.pixelSize: Style.cardSize
                    font.weight: Font.DemiBold
                }
                Note {
                    text: "The screen changes back in " + (page.st.secondsLeft || 0)
                          + (page.st.secondsLeft === 1 ? " second" : " seconds")
                          + " unless you keep it - so a screen that cannot show it comes back by itself."
                }
                Row {
                    spacing: Style.s(16)
                    Button { text: "Keep"; strong: true; onPressed: page.act("keep", true) }
                    Button { text: "Change back"; onPressed: page.act("revert", true) }
                }
            }
        }

        // ---- brightness and colour ---------------------------------------------
        Group {
            heading: "Brightness and colour"

            Line {
                title: "Brightness"
                detail: !page.st.brightnessKnown ? ""
                      : page.st.brightnessAvailable ? page.st.brightness + "%"
                      : "This screen's brightness is set on the screen itself."
                wide: page.st.brightnessAvailable === true
                Rail {
                    visible: page.st.brightnessAvailable === true
                    width: parent ? parent.width : implicitWidth
                    value: page.st.brightness || 0
                    label: "Brightness"
                    onChosen: function(v) { page.act("brightness", v) }
                }
            }
            Line {
                title: "Night Light"
                detail: !page.st.nightKnown ? ""
                      : !page.st.nightAvailable ? "Not available on this screen."
                      : page.st.warmth > 0 ? "Warmer colours, easier on the eyes at night."
                      : "Off"
                usable: page.st.nightAvailable === true
                Switch {
                    on: (page.st.warmth || 0) > 0
                    usable: page.st.nightAvailable === true
                    label: "Night Light"
                    onFlipped: page.act("nightLight", !on)
                }
            }
            Line {
                visible: page.st.nightAvailable === true && (page.st.warmth || 0) > 0
                title: "Warmth"
                detail: "From a little warmer to as warm as it goes."
                wide: true
                Rail {
                    width: parent ? parent.width : implicitWidth
                    value: page.st.warmth || 0
                    label: "Warmth"
                    onChosen: function(v) { page.act("warmth", Math.max(1, v)) }
                }
            }
            Line {
                visible: page.st.nightAvailable === true
                title: "Only from sunset to sunrise"
                detail: page.st.adaptivePossible ? "At the times the sun sets and rises where you are."
                      : "Needs to know where you are first: it is worked out from the internet connection."
                usable: page.st.adaptivePossible === true
                Switch {
                    on: page.st.adaptive === true
                    usable: page.st.adaptivePossible === true
                    label: "Only from sunset to sunrise"
                    onFlipped: page.act("adaptive", !on)
                }
            }
        }

        // ---- the screen ------------------------------------------------------------
        Group {
            heading: "Screen"

            Line {
                title: "Resolution"
                detail: !page.st.screenKnown ? ""
                      : (page.st.resolutions || []).length === 0 ? "This screen did not say what it can show."
                      : ""
                usable: (page.st.resolutions || []).length > 0
                Choice {
                    visible: (page.st.resolutions || []).length > 0
                    options: page.st.resolutions || []
                    chosen: page.st.resolution || ""
                    usable: page.st.asking !== true
                    label: "Resolution"
                    onPicked: function(key) { page.act("resolution", key) }
                }
            }
            Line {
                visible: page.st.screenName !== undefined && page.st.screenName !== ""
                title: "Orientation"
                Choice {
                    options: page.orientations
                    chosen: page.st.rotation || "none"
                    usable: page.st.asking !== true
                    label: "Orientation"
                    onPicked: function(key) { page.act("rotation", key) }
                }
            }
        }
    }
}
