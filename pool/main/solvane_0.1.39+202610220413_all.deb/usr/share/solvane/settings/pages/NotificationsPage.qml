/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - System - Notifications
 *
 * Plasma's own notification settings (NotifySource.qml, loaded apart):
 * Do Not Disturb - the Control Center's Focus tile and Plasma's bell are
 * the same switch - and how notifications appear. Changed here, the bell
 * and the tile change with it.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property bool ready: source.status === Loader.Ready
    readonly property var n: ready ? source.item : null
    readonly property var cfg: n ? n.settings : null

    readonly property var positions: [
        { "key": "0", "label": "Near the bell" },
        { "key": "3", "label": "Top right" },
        { "key": "1", "label": "Top left" },
        { "key": "6", "label": "Bottom right" },
        { "key": "4", "label": "Bottom left" }
    ]
    readonly property var timeouts: [
        { "key": "3000", "label": "3 seconds" },
        { "key": "5000", "label": "5 seconds" },
        { "key": "10000", "label": "10 seconds" },
        { "key": "20000", "label": "20 seconds" }
    ]

    Loader {
        id: source
        source: "NotifySource.qml"
    }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Notifications"
            parentName: "System"
            onBack: page.back()
        }

        Note {
            visible: source.status === Loader.Error
            text: "Plasma's notification settings could not be loaded, so they cannot be changed here."
        }

        Group {
            visible: page.ready
            heading: "Do Not Disturb"
            Line {
                title: "Do Not Disturb"
                detail: !page.n ? ""
                      : page.n.held ? "On - notifications are kept, and shown when it is turned off."
                      : page.n.heldByApps && page.n.holders.length > 0 ? "On while " + page.n.holders[0] + " asks for it."
                      : "Off"
                Switch {
                    on: page.n ? (page.n.held || page.n.heldByApps) : false
                    label: "Do Not Disturb"
                    onFlipped: page.n.setHeld(!on)
                }
            }
            Line {
                title: "Let urgent ones through"
                detail: "Critical notifications - a battery about to run out - are shown even then."
                Switch {
                    on: page.cfg ? page.cfg.criticalPopupsInDoNotDisturbMode : false
                    label: "Let urgent ones through"
                    onFlipped: page.n.set("criticalPopupsInDoNotDisturbMode", !on)
                }
            }
            Line {
                title: "While the screen is shared"
                detail: "Turn on Do Not Disturb by itself while another program shows this screen."
                Switch {
                    on: page.cfg ? page.cfg.inhibitNotificationsWhenScreenSharing : false
                    label: "While the screen is shared"
                    onFlipped: page.n.set("inhibitNotificationsWhenScreenSharing", !on)
                }
            }
        }

        Group {
            visible: page.ready
            heading: "Banners"
            Line {
                title: "Where they appear"
                Choice {
                    options: page.positions
                    chosen: page.cfg ? String(page.cfg.popupPosition) : "0"
                    label: "Where they appear"
                    onPicked: function(key) { page.n.set("popupPosition", parseInt(key)) }
                }
            }
            Line {
                title: "How long they stay"
                Choice {
                    options: page.timeouts
                    chosen: page.cfg ? String(page.cfg.popupTimeout) : "5000"
                    label: "How long they stay"
                    onPicked: function(key) { page.n.set("popupTimeout", parseInt(key)) }
                }
            }
            Line {
                title: "Play a sound"
                Switch {
                    on: page.cfg ? !page.cfg.notificationSoundsInhibited : false
                    label: "Play a sound"
                    onFlipped: page.n.set("notificationSoundsInhibited", on)
                }
            }
            Line {
                title: "Show the less important ones too"
                detail: "Some programs mark a notification as of low importance; those are shown as a banner only with this on."
                Switch {
                    on: page.cfg ? page.cfg.lowPriorityPopups : false
                    label: "Show the less important ones too"
                    onFlipped: page.n.set("lowPriorityPopups", !on)
                }
            }
        }
    }
}
