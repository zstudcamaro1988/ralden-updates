/* SPDX-License-Identifier: Solvane-Source
 *
 * Plasma's own notification settings, for the Notifications page.
 *
 * The same object Plasma's bell and the Control Center's Focus tile use
 * (org.kde.notificationmanager's Settings; its properties were read off
 * the image's own .qmltypes, 14 October 2026). KEPT APART, as the Control
 * Center keeps it: if a Plasma release moves it, this file fails to load,
 * and the page says notifications cannot be set here - the rest of
 * Settings is unharmed.
 */
import QtQuick
import org.kde.notificationmanager as NotificationManager

Item {
    id: source

    readonly property var settings: plasma

    // Do Not Disturb "until I turn it off" is written as Plasma's bell
    // writes it: a year from now.
    property date now: new Date()
    readonly property bool held: !isNaN(plasma.notificationsInhibitedUntil)
                                 && plasma.notificationsInhibitedUntil > now
    readonly property bool heldByApps: plasma.notificationsInhibitedByApplication
    readonly property var holders: plasma.notificationInhibitionApplications

    function setHeld(wanted) {
        if (wanted) {
            var until = new Date()
            until.setFullYear(until.getFullYear() + 1)
            plasma.notificationsInhibitedUntil = until
        } else {
            plasma.notificationsInhibitedUntil = undefined
            plasma.revokeApplicationInhibitions()
        }
        plasma.save()
        source.now = new Date()
    }
    function set(name, value) {
        plasma[name] = value
        plasma.save()
    }

    NotificationManager.Settings {
        id: plasma
        live: true
    }
    Timer {
        interval: 30000
        running: true
        repeat: true
        onTriggered: source.now = new Date()
    }
}
