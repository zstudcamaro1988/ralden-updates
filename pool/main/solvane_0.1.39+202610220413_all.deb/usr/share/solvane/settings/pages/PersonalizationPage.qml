/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - Personalization
 *
 *   Wallpaper   the picture on the desktop: Solvane's own (Alpine Mist), or
 *               one from the Pictures folder, the newest first. Chosen, it
 *               goes on the desktop (plasma-apply-wallpaperimage) and on the
 *               lock screen (kscreenlockerrc). The login screen is drawn
 *               before anybody signs in, from a picture only an
 *               administrator may change; it keeps Solvane's mountains, and
 *               the page says so.
 *   Colours     Alpine Mist, Solvane's own, and the only ones there are so
 *               far - said, not offered.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.look : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property var choices: st.choices || []

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle { text: "Personalization" }

        Column {
            visible: page.st.known === true
            width: parent.width
            spacing: Style.s(16)
            Heading { text: "Wallpaper" }

            Flow {
                width: parent.width
                spacing: Style.s(20)
                Repeater {
                    model: page.choices
                    Item {
                        id: tile
                        required property var modelData
                        width: Style.s(300)
                        height: Style.s(169) + Style.s(52)

                        Rectangle {
                            id: frame
                            width: parent.width
                            height: Style.s(169)
                            radius: Style.s(14)
                            color: Style.card
                            border.width: tile.modelData.chosen ? Style.s(5) : 1
                            border.color: tile.modelData.chosen ? Style.accent
                                          : (press.containsMouse ? Style.inkFaint : Style.edge)
                            Image {
                                anchors.fill: parent
                                anchors.margins: tile.modelData.chosen ? Style.s(7) : Style.s(3)
                                source: tile.modelData.url
                                sourceSize: Qt.size(Style.s(320), Style.s(180))
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                smooth: true
                            }
                            MouseArea {
                                id: press
                                anchors.fill: parent
                                hoverEnabled: true
                                enabled: page.st.busy !== true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: page.act("picture", tile.modelData.path)
                            }
                        }
                        Text {
                            anchors.top: frame.bottom
                            anchors.topMargin: Style.s(10)
                            width: parent.width
                            elide: Text.ElideRight
                            horizontalAlignment: Text.AlignHCenter
                            text: tile.modelData.name
                            color: tile.modelData.chosen ? Style.ink : Style.inkSoft
                            font.family: Style.family
                            font.pixelSize: Style.detailSize
                            font.weight: tile.modelData.chosen ? Font.Medium : Font.Normal
                        }
                    }
                }
            }

            Note {
                text: page.choices.length > 1
                      ? "The pictures in your " + (page.st.folder || "Pictures") + " folder, the newest first. The desktop and the lock screen show the one chosen; the login screen keeps Solvane's mountains."
                      : "Pictures put in your " + (page.st.folder || "Pictures") + " folder are shown here to choose from. The desktop and the lock screen show the one chosen; the login screen keeps Solvane's mountains."
            }
            Note {
                visible: page.st.busy === true
                text: "Putting it on the desktop…"
            }
            Note {
                visible: (page.st.note || "") !== ""
                text: page.st.note || ""
            }
        }

        Group {
            heading: "Colours"
            Line {
                title: "Alpine Mist"
                detail: "Solvane's own colours, drawn to go with its mountains. They are the only ones so far."
            }
        }
    }
}
