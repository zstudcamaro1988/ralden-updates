/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - System - Power & Battery
 *
 *   The battery    read from /sys/class/power_supply, as the bar's pane
 *                  reads it; a desktop has none and says it is plugged in.
 *   Power mode     power-profiles-daemon's, where it has a driver that can
 *                  change something on this machine. Its stand-in driver
 *                  only remembers a choice, and then no choice is drawn.
 *                  Solvane's image has TLP instead (the two cannot both be
 *                  installed), which saves power by itself, and says so.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.power : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property var profileNames: ({
        "power-saver": "Power saver",
        "balanced": "Balanced",
        "performance": "Performance"
    })
    readonly property var profileOptions: {
        var list = []
        var names = st.profiles || []
        for (var i = 0; i < names.length; i++)
            list.push({ "key": names[i], "label": profileNames[names[i]] || names[i] })
        return list
    }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Power & Battery"
            parentName: "System"
            onBack: page.back()
        }

        Group {
            heading: "Battery"
            Line {
                title: !page.st.known ? ""
                     : page.st.hasBattery ? page.st.battery + "%" : "No battery"
                detail: !page.st.known ? ""
                      : page.st.hasBattery
                        ? (page.st.charging ? "Charging" : page.st.full ? "Fully charged"
                           : page.st.onMains ? "Plugged in, not charging" : "On battery")
                        : "This computer runs from the mains."
            }
        }

        Group {
            heading: "Power mode"
            Line {
                visible: page.profileOptions.length > 0
                title: "Power mode"
                detail: "Quieter and longer on battery, or faster."
                Choice {
                    options: page.profileOptions
                    chosen: page.st.profile || ""
                    label: "Power mode"
                    onPicked: function(key) { page.act("profile", key) }
                }
            }
            Line {
                visible: page.st.profileKnown === true && page.profileOptions.length === 0
                title: page.st.manager === "tlp" ? "Looked after by itself" : "No power modes on this computer"
                detail: page.st.manager === "tlp"
                        ? "TLP, Solvane's power manager, saves more power on battery than on the mains, without being asked. There is no mode to choose."
                        : "Nothing on this computer can be set to run faster or to save power, so there is nothing to choose between."
            }
        }
    }
}
