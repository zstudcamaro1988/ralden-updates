/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - System - Keyboard - Keyboard shortcuts
 *
 * The keys that work wherever you are, as Plasma's kglobalaccel holds them:
 * KWin's (the overview, the workspaces, the windows), Plasma's, the search
 * panel's, the volume keys. Grouped by what they belong to; the ones with
 * a key first, and every action there is when something is looked for.
 *
 * CHANGING ONE: "Change" waits for the next key pressed with its
 * modifiers - Escape gives up, and a key another action has is refused
 * with its name, rather than taken from it without saying.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.shortcuts : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    property string wanted: ""
    property string waitingFor: ""     // the action whose key is being pressed

    readonly property var shown: {
        var all = st.actions || []
        var words = wanted.toLowerCase().split(/\s+/).filter(function(w) { return w !== "" })
        var groups = []
        var at = {}
        for (var i = 0; i < all.length; i++) {
            var a = all[i]
            if (words.length === 0 && a.keys === "") continue
            var text = (a.name + " " + a.componentName + " " + a.keys).toLowerCase()
            var ok = true
            for (var k = 0; k < words.length; k++)
                if (text.indexOf(words[k]) < 0) { ok = false; break }
            if (!ok) continue
            if (at[a.componentName] === undefined) {
                at[a.componentName] = groups.length
                groups.push({ "name": a.componentName, "actions": [] })
            }
            groups[at[a.componentName]].actions.push(a)
        }
        return groups
    }

    implicitHeight: column.implicitHeight

    // The key pressed while waiting. Modifiers alone are not a shortcut;
    // Escape gives up.
    Item {
        id: catcher
        focus: page.waitingFor !== ""
        Keys.onPressed: function(event) {
            if (page.waitingFor === "") return
            event.accepted = true
            if (event.key === Qt.Key_Escape) { page.waitingFor = ""; return }
            if ([Qt.Key_Control, Qt.Key_Shift, Qt.Key_Alt, Qt.Key_Meta, Qt.Key_Super_L,
                 Qt.Key_Super_R, Qt.Key_AltGr, Qt.Key_CapsLock, Qt.Key_unknown].indexOf(event.key) >= 0)
                return
            page.act("set", { "id": page.waitingFor, "key": event.key, "modifiers": event.modifiers })
            page.waitingFor = ""
        }
    }
    onWaitingForChanged: if (waitingFor !== "") catcher.forceActiveFocus()

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Keyboard shortcuts"
            parentName: "Keyboard"
            onBack: page.open("keyboard")
        }

        Field {
            width: parent.width
            glyph: "search"
            placeholder: "Find a shortcut, or what it does"
            onTextChanged: page.wanted = text
        }

        Rectangle {
            visible: (page.st.note || "") !== ""
            width: parent.width
            height: noteText.implicitHeight + Style.s(44)
            radius: Style.s(22)
            color: Style.accentTint
            Note {
                id: noteText
                x: Style.s(28)
                y: Style.s(22)
                width: parent.width - Style.s(56)
                color: Style.ink
                text: page.st.note || ""
            }
        }

        Repeater {
            model: page.shown
            Group {
                required property var modelData
                heading: modelData.name
                Repeater {
                    model: modelData.actions
                    Line {
                        required property var modelData
                        title: modelData.name
                        detail: page.waitingFor === modelData.id ? "Press the keys now - Escape to leave it as it is."
                              : modelData.keys !== "" ? modelData.keys : "No key"
                        Row {
                            spacing: Style.s(12)
                            Button {
                                visible: modelData.keys !== modelData.defaults
                                text: "Default"
                                onPressed: page.act("reset", modelData.id)
                            }
                            Button {
                                visible: modelData.keys !== ""
                                text: "Clear"
                                onPressed: page.act("clear", modelData.id)
                            }
                            Button {
                                text: page.waitingFor === modelData.id ? "Waiting…" : "Change"
                                strong: page.waitingFor === modelData.id
                                onPressed: page.waitingFor = (page.waitingFor === modelData.id ? "" : modelData.id)
                            }
                        }
                    }
                }
            }
        }

        Note {
            visible: page.st.known === true && page.shown.length === 0
            text: page.st.available === false ? "Plasma's shortcut service did not answer."
                  : page.wanted !== "" ? "No shortcut does that." : "No keys are set."
        }
    }
}
