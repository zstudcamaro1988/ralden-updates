/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - Time & Language (the picture's second "Updates", whose mark is
 * a clock).
 *
 *   Date and time   whether the clock sets itself from the internet
 *                   (systemd-timesyncd, through timedated), and the date and
 *                   time typed in when it does not.
 *   Time zone       where the clock is, and a page to find another place
 *                   (the First Start's list: zone1970.tab and iso3166.tab).
 *   Language        what it is, and that Solvane's own windows are in
 *                   English only so far - nothing here changes it, and the
 *                   page does not pretend to.
 *   Keyboard        the layouts are on the Keyboard page, which this opens.
 *
 * Each change goes to timedated, which asks polkit, which may ask for an
 * administrator's password in Plasma's own window; the page says it is
 * making the change until timedated answers, and says why when it refuses.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.time : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property bool readable: st.known === true && st.failed !== true
    readonly property bool free: st.busy !== true

    readonly property string autoDetail: {
        var now = st.now ? st.now + ". " : ""
        if (st.canAuto !== true)
            return now + "Nothing on this computer can ask the internet for the time."
        if (st.auto !== true)
            return now + "Set by hand."
        if (st.synced === true)
            return now + "In step with the internet's clock."
        return now + "Not yet checked against the internet's clock; it will be once this computer is online."
    }
    function joined(parts) {
        return parts.filter(function(p) { return p !== undefined && p !== "" }).join(" · ")
    }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle { text: "Time & Language" }

        Note {
            visible: page.st.known === true && page.st.failed === true
            text: "The clock's settings could not be read: timedatectl did not answer."
        }

        Group {
            visible: page.readable
            heading: "Date and time"
            Line {
                title: "Set the time automatically"
                detail: page.autoDetail
                usable: page.st.canAuto === true && page.free
                Switch {
                    on: page.st.auto === true
                    usable: page.st.canAuto === true && page.free
                    label: "Set the time automatically"
                    onFlipped: page.act("auto", !on)
                }
            }
            Line {
                visible: page.st.auto !== true
                title: "Set the date and time"
                detail: "The date as year, month and day, and the time. Changing it may ask for an administrator's password."
                wide: true
                Row {
                    spacing: Style.s(16)
                    Field {
                        id: dateField
                        width: Style.s(300)
                        placeholder: page.st.today || "2026-10-20"
                        usable: page.free
                    }
                    Field {
                        id: timeField
                        width: Style.s(240)
                        placeholder: page.st.clock || "7:05 PM"
                        usable: page.free
                    }
                    Button {
                        text: "Set"
                        usable: page.free
                        onPressed: page.act("setTime", {
                            "date": dateField.text !== "" ? dateField.text : dateField.placeholder,
                            "time": timeField.text !== "" ? timeField.text : timeField.placeholder
                        })
                    }
                }
            }
        }

        Group {
            visible: page.readable
            heading: "Time zone"
            Line {
                title: page.st.place || page.st.zone || ""
                detail: page.joined([page.st.where, page.st.offset])
                Button {
                    text: "Change"
                    usable: page.free
                    onPressed: page.open("timezone")
                }
            }
        }

        Note {
            visible: page.st.busy === true
            text: "Making the change…"
        }
        Note {
            visible: (page.st.note || "") !== "" && page.st.busy !== true
            text: page.st.note || ""
        }

        Group {
            heading: "Language"
            Line {
                title: Qt.locale().nativeLanguageName
                detail: "Solvane's own windows are written in English, and only in English so far."
            }
        }

        Column {
            width: parent.width
            spacing: Style.s(16)
            Heading { text: "Keyboard" }
            LinkRow {
                width: parent.width
                glyph: "keyboard"
                title: "Keyboard layouts"
                detail: "The letters each key types, on the Keyboard page"
                onPicked: page.open("keyboard")
            }
        }
    }
}
