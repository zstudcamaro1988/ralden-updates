/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - System - Keyboard ("Shortcuts, text input, layout" in the
 * picture).
 *
 *   Typing       whether a key held down repeats, how soon and how fast,
 *                and whether Num Lock is on when Solvane starts - kcminputrc
 *                [Keyboard], Plasma's own.
 *   Layouts      the keyboard layouts, the first the one Solvane starts
 *                with - kxkbrc [Layout], Plasma's own; the names are the
 *                X keyboard database's (/usr/share/X11/xkb/rules/evdev.xml).
 *   Shortcuts    the keys that do something wherever you are: a page of
 *                their own.
 *
 * The picture's "text input" is an input method - typing Chinese or
 * Japanese - and there is none on the image; the layouts are what there is.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.keyboard : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property var numLockOptions: [
        { "key": "on", "label": "On" },
        { "key": "off", "label": "Off" },
        { "key": "keep", "label": "As it was left" }
    ]
    // The rails are 0 to 100; these are what they stand for.
    readonly property int delayLeast: 150
    readonly property int delayMost: 1000
    readonly property int rateLeast: 5
    readonly property int rateMost: 60
    function toRail(v, least, most) { return Math.round((v - least) * 100 / (most - least)) }
    function fromRail(v, least, most) { return Math.round(least + v * (most - least) / 100) }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Keyboard"
            parentName: "System"
            onBack: page.back()
        }

        Group {
            heading: "Typing"
            Line {
                title: "Repeat a key held down"
                detail: "Holding a key types it again and again."
                Switch {
                    on: page.st.repeat === true
                    label: "Repeat a key held down"
                    onFlipped: page.act("repeat", !on)
                }
            }
            Line {
                visible: page.st.repeat === true
                title: "Start repeating after"
                detail: (page.st.delay || 0) + " milliseconds"
                wide: true
                Rail {
                    width: parent ? parent.width : implicitWidth
                    value: page.toRail(page.st.delay || page.delayLeast, page.delayLeast, page.delayMost)
                    label: "Start repeating after"
                    onChosen: function(v) { page.act("delay", page.fromRail(v, page.delayLeast, page.delayMost)) }
                }
            }
            Line {
                visible: page.st.repeat === true
                title: "Repeat"
                detail: (page.st.rate || 0) + " times a second"
                wide: true
                Rail {
                    width: parent ? parent.width : implicitWidth
                    value: page.toRail(page.st.rate || page.rateLeast, page.rateLeast, page.rateMost)
                    label: "Repeat rate"
                    onChosen: function(v) { page.act("rate", page.fromRail(v, page.rateLeast, page.rateMost)) }
                }
            }
            Line {
                title: "Num Lock when Solvane starts"
                Choice {
                    options: page.numLockOptions
                    chosen: page.st.numLock || "keep"
                    label: "Num Lock when Solvane starts"
                    onPicked: function(key) { page.act("numLock", key) }
                }
            }
        }

        Group {
            heading: "Layouts"
            Repeater {
                model: page.st.layouts || []
                Line {
                    required property var modelData
                    required property int index
                    title: modelData.label
                    detail: index === 0 ? ((page.st.layouts || []).length > 1 ? "The one Solvane starts with" : "") : ""
                    Row {
                        spacing: Style.s(12)
                        Button {
                            visible: index > 0
                            text: "First"
                            onPressed: page.act("firstLayout", modelData.key)
                        }
                        Button {
                            visible: (page.st.layouts || []).length > 1
                            text: "Remove"
                            onPressed: page.act("removeLayout", modelData.key)
                        }
                    }
                }
            }
            Line {
                title: "Add a layout"
                detail: (page.st.layouts || []).length > 1 && (page.st.switchKeys || "") !== ""
                        ? "Switch between them with " + page.st.switchKeys + "."
                        : "Another language's letters, or another arrangement of them."
                Button {
                    text: "Add"
                    onPressed: page.open("layouts")
                }
            }
        }

        Column {
            width: parent.width
            spacing: Style.s(16)
            Heading { text: "Shortcuts" }
            LinkRow {
                width: parent.width
                glyph: "keyboard"
                title: "Keyboard shortcuts"
                detail: "The keys that work wherever you are"
                onPicked: page.open("shortcuts")
            }
        }
    }
}
