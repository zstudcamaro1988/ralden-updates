/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - Updates
 *
 *   Updates          how many are waiting, from the lists apt last fetched
 *                    (it fetches them every day by itself), and when that
 *                    was; Install opens Discover's updates, which asks for
 *                    the password, shows the progress and says when a
 *                    restart is wanted.
 *   Security fixes   install by themselves every day, without restarting
 *                    the computer (unattended-upgrades, set up on the
 *                    image); said, as apt-config reads it.
 *   What is waiting  each program, and its new version.
 *
 *   Solvane         Solvane's own parts are the package solvane (from
 *                   build 39): its version, when it was built, and where
 *                   its updates come from - Solvane's own signed archive,
 *                   at the address the installer gave this computer
 *                   (/etc/apt/sources.list.d/solvane.sources), and whether
 *                   apt has ever had an answer from there. Its updates are
 *                   in the list above with Debian's.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.updates : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property bool readable: st.known === true && st.failed !== true
    readonly property int count: st.count || 0
    readonly property var waiting: st.waiting || []

    // Nothing waiting is "Up to date" only once apt has looked: before
    // that, nothing waiting says nothing (seen on the disc, 21 October 2026).
    readonly property bool looked: (st.checked || "") !== ""
    readonly property string headline: count === 1 ? "1 update is waiting"
                                     : count > 1 ? count + " updates are waiting"
                                     : looked ? "Up to date" : "Not looked for yet"
    readonly property string checkedWords: looked
                                           ? "Last looked for " + st.checked + "."
                                           : "Debian's lists of updates are looked at every day while this computer is online."

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle { text: "Updates" }

        Note {
            visible: page.st.known === true && page.st.failed === true
            text: "apt did not answer, so what is waiting cannot be shown. Discover can still look."
        }

        Group {
            visible: page.st.known === true
            heading: "This computer"
            Line {
                title: page.readable ? page.headline : "Updates"
                detail: page.checkedWords
                Button {
                    text: page.count > 0 ? "Install" : page.looked ? "Look again" : "Look now"
                    strong: page.count > 0
                    onPressed: page.act("install", true)
                }
            }
            Line {
                title: "Security fixes"
                detail: page.st.automatic === true
                        ? "Installed by themselves every day, without restarting the computer. Everything else waits for you."
                        : "Not installed by themselves on this computer; they wait with the rest."
            }
        }

        Note {
            visible: (page.st.note || "") !== ""
            text: page.st.note || ""
        }

        Group {
            visible: page.readable && page.waiting.length > 0
            heading: page.count > page.waiting.length
                     ? "Waiting (the first " + page.waiting.length + " of " + page.count + ")"
                     : "Waiting"
            Repeater {
                model: page.waiting
                Line {
                    required property var modelData
                    title: modelData.name
                    detail: (modelData.security ? "A security fix · " : "")
                            + (modelData.old !== "" ? modelData.old + " to " + modelData.version
                                                     : modelData.version)
                }
            }
        }

        // Solvane's own parts: the package solvane, its version, and where
        // its updates come from (from build 39; before that, nothing).
        Group {
            visible: (page.st.solvaneVersion || "") !== ""
            heading: "Solvane"
            Line {
                title: "Solvane " + (page.st.solvaneVersion || "")
                detail: ((page.st.solvaneBuilt || "") !== "" ? "Built " + page.st.solvaneBuilt + ". " : "")
                        + "Settings, Files, the desktop's panes, the login and lock screens and Solvane's look."
            }
            Line {
                title: "Solvane's updates"
                detail: page.st.live === true
                        ? "Not looked for on the disc. An installed Solvane gets them from Solvane's own update server, signed, like Debian's."
                        : (page.st.solvaneFrom || "") === ""
                          ? "This computer was not given Solvane's update server, so nothing updates Solvane's own parts."
                          : "From Solvane's own update server, " + page.st.solvaneFrom + ", signed. "
                            + (page.st.solvaneReached === true
                               ? "They are installed with the rest, above."
                               : "It has not answered yet.")
            }
        }
        Note {
            visible: (page.st.solvaneVersion || "") === ""
            text: "Solvane's own parts - Settings, Files, the desktop's panes - came with the disc this computer was installed from, and nothing updates them."
        }
        Note {
            visible: page.st.live === true
            text: "On the disc, whatever is installed is gone at the next restart."
        }
    }
}
