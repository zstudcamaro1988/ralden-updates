/* SPDX-License-Identifier: Solvane-Source
 *
 * Settings - System - Mouse & Touchpad ("Pointer speed, gestures,
 * scrolling" in the picture).
 *
 *   Mouse        how fast the pointer goes, whether it goes further for a
 *                faster movement, which way the wheel scrolls, which
 *                button is which.
 *   Touchpad     the same speed and scrolling, and tapping, and leaving
 *                the pointer alone while typing.
 *
 * Each group is drawn only for what this computer has: a desktop with a
 * mouse has no touchpad group, and the VAIO has both.
 *
 * NO GESTURES. The picture's "gestures" are swipes with three and four
 * fingers; KWin has them on Wayland only, and Solvane runs on X11
 * (docs/settings.md). Tapping with two fingers to right-click is libinput's
 * and is here.
 *
 * NOT YET: two fingers or the edge to scroll. Which of them a touchpad can
 * do is its own (a 2009 touchpad may feel one finger only), and Settings
 * cannot ask it on X11 without xinput; a switch for a way it cannot scroll
 * would do nothing.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.pointing : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Mouse & Touchpad"
            parentName: "System"
            onBack: page.back()
        }

        Note {
            visible: page.st.known === true && page.st.appliesNow === false
                     && (page.st.mousePresent === true || page.st.touchpadPresent === true)
            text: "Changes here take effect the next time you sign in."
        }

        Group {
            visible: page.st.mousePresent === true
            heading: "Mouse"
            Line {
                title: "Pointer speed"
                wide: true
                Rail {
                    width: parent ? parent.width : implicitWidth
                    value: page.st.mouseSpeed || 0
                    label: "Mouse pointer speed"
                    onChosen: function(v) { page.act("mouseSpeed", v) }
                }
            }
            Line {
                title: "Speed up with faster movement"
                detail: "A quick flick takes the pointer further than a slow push. Off, it goes as far as the mouse does."
                Switch {
                    on: page.st.mouseAccel === true
                    label: "Speed up with faster movement"
                    onFlipped: page.act("mouseAccel", !on)
                }
            }
            Line {
                title: "Natural scrolling"
                detail: "The page moves the way the wheel turns, as it follows a finger on a phone."
                Switch {
                    on: page.st.mouseNatural === true
                    label: "Natural scrolling for the mouse"
                    onFlipped: page.act("mouseNatural", !on)
                }
            }
            Line {
                title: "Left-handed"
                detail: "The right button clicks and the left one opens menus."
                Switch {
                    on: page.st.leftHanded === true
                    label: "Left-handed"
                    onFlipped: page.act("leftHanded", !on)
                }
            }
        }

        Group {
            visible: page.st.touchpadPresent === true
            heading: "Touchpad"
            Line {
                title: "Pointer speed"
                wide: true
                Rail {
                    width: parent ? parent.width : implicitWidth
                    value: page.st.touchpadSpeed || 0
                    label: "Touchpad pointer speed"
                    onChosen: function(v) { page.act("touchpadSpeed", v) }
                }
            }
            Line {
                title: "Tap to click"
                detail: "Tap with one finger to click, with two to open a menu."
                Switch {
                    on: page.st.tap === true
                    label: "Tap to click"
                    onFlipped: page.act("tap", !on)
                }
            }
            Line {
                title: "Natural scrolling"
                detail: "The page moves the way your fingers do, as on a phone."
                Switch {
                    on: page.st.touchpadNatural === true
                    label: "Natural scrolling for the touchpad"
                    onFlipped: page.act("touchpadNatural", !on)
                }
            }
            Line {
                title: "Leave the pointer alone while typing"
                detail: "A palm brushing the touchpad does not move the pointer or click."
                Switch {
                    on: page.st.typingOff === true
                    label: "Leave the pointer alone while typing"
                    onFlipped: page.act("typingOff", !on)
                }
            }
        }

        Group {
            visible: page.st.known === true && page.st.mousePresent !== true && page.st.touchpadPresent !== true
            Line {
                title: "No mouse or touchpad found"
                detail: "Plug a mouse in and it appears here."
            }
        }
    }
}
