/* SPDX-License-Identifier: Solvane-Source
 *
 * One of the round buttons at the top right of the picture: a mark, a
 * circle behind it when the pointer is over it, and its name for screen
 * readers and for the moment the pointer rests on it.
 */
import QtQuick
import org.solvane.flowbar as Flow
import "../../settings/parts"

Item {
    id: tool

    property string glyph: ""
    property string label: ""
    property bool on: false
    property bool usable: true
    signal pressed()

    implicitWidth: Style.s(60)
    implicitHeight: Style.s(60)
    opacity: usable ? 1 : 0.35

    Rectangle {
        anchors.fill: parent
        radius: width / 2
        color: tool.on ? Style.accentTint
             : press.pressed ? Style.cardPressed
             : press.containsMouse ? Style.card : "transparent"
    }
    Flow.Glyph {
        anchors.centerIn: parent
        width: Style.s(34)
        height: width
        kind: tool.glyph
        ink: tool.on ? Style.accentInk : Style.inkSoft
    }
    MouseArea {
        id: press
        anchors.fill: parent
        enabled: tool.usable
        hoverEnabled: true
        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: tool.pressed()
    }
    // What it is, after the pointer has rested on it a moment.
    Rectangle {
        visible: press.containsMouse && hold.ready && tool.label !== ""
        z: 10
        anchors.top: parent.bottom
        anchors.topMargin: Style.s(8)
        anchors.horizontalCenter: parent.horizontalCenter
        width: tip.implicitWidth + Style.s(24)
        height: tip.implicitHeight + Style.s(14)
        radius: Style.s(10)
        color: "#0F172A"
        border.width: 1
        border.color: Style.edge
        Text {
            id: tip
            anchors.centerIn: parent
            text: tool.label
            color: Style.ink
            font.family: Style.family
            font.pixelSize: Style.detailSize
        }
    }
    Timer {
        id: hold
        property bool ready: false
        interval: 600
        running: press.containsMouse
        onRunningChanged: if (!running) ready = false
        onTriggered: ready = true
    }
    Accessible.role: Accessible.Button
    Accessible.name: tool.label
}
