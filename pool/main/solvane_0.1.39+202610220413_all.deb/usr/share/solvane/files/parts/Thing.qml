/* SPDX-License-Identifier: Solvane-Source
 *
 * One file or folder, drawn as the picture draws them:
 *
 *   tile     a large picture of it and its name under it - the picture's
 *            Pinned folders, and every folder shown as icons
 *   row      its mark in a rounded square, its name, and two columns -
 *            the picture's Recent list ("Documents", "Just now"), and
 *            every folder shown as a list
 *
 * A picture file shows the picture itself, made small. Pressing selects,
 * pressing twice opens, and the window decides what either means; this
 * only says what happened. It can be dragged out - onto another folder,
 * another window, another program - and, if it is a folder, have things
 * dropped on it.
 */
import QtQuick
import org.kde.kirigami as Kirigami
import "../../settings/parts"

Item {
    id: thing

    property var entry: ({})
    property string mode: "row"           // "tile" or "row"
    property bool selected: false
    property bool editing: false
    // The row's second and third columns. (Not `right`: every Item already
    // has a `right` - the anchor line - and Qt refuses a second one, which
    // is how the first build of Files did not open, 20 October 2026.)
    property string middleText: ""
    property string rightText: ""
    property var dragUrls: []             // what a drag from here carries

    signal clicked(int modifiers)
    signal opened()
    signal menu(real x, real y)
    signal renamed(string name)
    signal renameDropped()
    signal dropped(var urls, bool move)

    readonly property bool tile: mode === "tile"
    implicitWidth: tile ? Style.s(220) : Style.s(900)
    implicitHeight: tile ? Style.s(236) : Style.s(76)

    Rectangle {
        anchors.fill: parent
        anchors.margins: thing.tile ? Style.s(6) : 0
        radius: Style.s(16)
        color: drop.containsDrag ? Style.accentTint
             : thing.selected ? Style.accentTint
             : press.containsMouse ? Style.card : "transparent"
        border.width: thing.selected || drop.containsDrag ? 1 : 0
        border.color: Qt.rgba(126 / 255, 182 / 255, 245 / 255, 0.45)
    }

    // ---- its picture ---------------------------------------------------------------
    Item {
        id: mark
        // The picture's folders, 95 of its pixels across; a folder icon
        // draws about seven-tenths of its square.
        width: thing.tile ? Style.s(132) : Style.s(48)
        height: width
        x: thing.tile ? (thing.width - width) / 2 : Style.s(18)
        y: thing.tile ? Style.s(22) : (thing.height - height) / 2
        opacity: thing.entry.hidden ? 0.55 : 1

        // The picture's Recent rows sit each mark in a pale rounded square.
        Rectangle {
            visible: !thing.tile
            anchors.fill: parent
            radius: Style.s(12)
            color: Style.tile
        }
        Kirigami.Icon {
            visible: !thumb.visible
            anchors.centerIn: parent
            width: thing.tile ? parent.width : parent.width * 0.68
            height: width
            source: thing.entry.icon || "unknown"
        }
        Image {
            id: thumb
            visible: thing.entry.thumb === true && status === Image.Ready
            anchors.centerIn: parent
            width: thing.tile ? parent.width : parent.width * 0.78
            height: width
            source: thing.entry.thumb === true ? (thing.entry.url || "") : ""
            // Both sides at once: height bound to width is a loop, the
            // first build said so for every picture.
            sourceSize: thing.tile ? Qt.size(Style.s(224), Style.s(224))
                                   : Qt.size(Style.s(80), Style.s(80))
            fillMode: Image.PreserveAspectFit
            asynchronous: true
            smooth: true
        }
    }

    // ---- its name ----------------------------------------------------------------
    Text {
        id: name
        visible: !thing.editing
        x: thing.tile ? Style.s(12) : Style.s(90)
        y: thing.tile ? mark.y + mark.height + Style.s(12) : (thing.height - height) / 2
        width: thing.tile ? thing.width - Style.s(24) : thing.width * 0.5 - x
        horizontalAlignment: thing.tile ? Text.AlignHCenter : Text.AlignLeft
        text: thing.entry.label || thing.entry.name || ""
        // Between words where it can be ("READ ME FIRST.txt" broke as
        // "READ ME FIRS / T.txt" on the first build), inside one where not.
        wrapMode: thing.tile ? Text.WrapAtWordBoundaryOrAnywhere : Text.NoWrap
        maximumLineCount: thing.tile ? 2 : 1
        elide: thing.tile ? Text.ElideMiddle : Text.ElideRight
        color: Style.ink
        font.family: Style.family
        font.pixelSize: Style.cardSize
        font.weight: Font.Medium
    }
    Rectangle {
        visible: thing.editing
        x: name.x - Style.s(6)
        y: name.y - Style.s(6)
        width: name.width + Style.s(12)
        height: editor.implicitHeight + Style.s(12)
        radius: Style.s(8)
        color: Style.window
        border.width: 1
        border.color: Style.accent
        TextInput {
            id: editor
            x: Style.s(6)
            y: Style.s(6)
            width: parent.width - Style.s(12)
            color: Style.ink
            selectionColor: Style.accent
            selectedTextColor: "#FFFFFF"
            font: name.font
            clip: true
            horizontalAlignment: name.horizontalAlignment
            onAccepted: thing.renamed(text)
            Keys.onEscapePressed: thing.renameDropped()
            onActiveFocusChanged: if (!activeFocus && thing.editing) thing.renamed(text)
        }
    }
    onEditingChanged: {
        if (!editing)
            return
        editor.text = entry.name || ""
        // The name without its ending, as a person nearly always means.
        var dot = entry.isDir ? -1 : editor.text.lastIndexOf(".")
        editor.forceActiveFocus()
        editor.select(0, dot > 0 ? dot : editor.text.length)
    }

    // ---- the row's columns ----------------------------------------------------------
    Text {
        visible: !thing.tile
        x: thing.width * 0.55
        anchors.verticalCenter: parent.verticalCenter
        width: thing.width * 0.25
        text: thing.middleText
        elide: Text.ElideRight
        color: Style.inkSoft
        font.family: Style.family
        font.pixelSize: Style.detailSize + 1
    }
    Text {
        visible: !thing.tile
        x: thing.width * 0.82
        anchors.verticalCenter: parent.verticalCenter
        width: thing.width * 0.18 - Style.s(16)
        text: thing.rightText
        elide: Text.ElideRight
        color: Style.inkSoft
        font.family: Style.family
        font.pixelSize: Style.detailSize + 1
    }

    // ---- pressing, dragging, dropping -------------------------------------------------
    MouseArea {
        id: press
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        enabled: !thing.editing
        onClicked: function(mouse) {
            if (mouse.button === Qt.RightButton)
                thing.menu(mouse.x, mouse.y)
            else
                thing.clicked(mouse.modifiers)
        }
        onDoubleClicked: function(mouse) {
            if (mouse.button === Qt.LeftButton) thing.opened()
        }
        // Inside the MouseArea, not beside it: a handler is offered a press
        // before the item it belongs to, so it sees the press the
        // MouseArea then takes, and takes it over once the pointer has
        // moved far enough to be a drag. Beside it, the MouseArea would
        // take the press first and the drag would never start.
        DragHandler {
            id: dragging
            target: null
            acceptedButtons: Qt.LeftButton
        }
    }
    Drag.active: dragging.active
    Drag.dragType: Drag.Automatic
    Drag.supportedActions: Qt.CopyAction | Qt.MoveAction
    Drag.proposedAction: Qt.MoveAction
    Drag.mimeData: ({ "text/uri-list": thing.dragUrls.join("\r\n") })
    DropArea {
        id: drop
        anchors.fill: parent
        enabled: thing.entry.isDir === true
        onEntered: function(drag) {
            // Not a folder onto itself.
            var self = false
            for (var i = 0; i < drag.urls.length; i++)
                if (drag.urls[i].toString() === thing.entry.url) self = true
            drag.accepted = drag.hasUrls && !self
        }
        onDropped: function(drop) {
            var urls = []
            for (var i = 0; i < drop.urls.length; i++) urls.push(drop.urls[i].toString())
            thing.dropped(urls, drop.proposedAction === Qt.MoveAction)
            drop.acceptProposedAction()
        }
    }

    Accessible.role: Accessible.ListItem
    Accessible.name: thing.entry.label || thing.entry.name || ""
    Accessible.selected: thing.selected
}
