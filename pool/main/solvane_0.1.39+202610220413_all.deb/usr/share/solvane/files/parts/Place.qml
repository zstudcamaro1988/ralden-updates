/* SPDX-License-Identifier: Solvane-Source
 *
 * One entry of Files' sidebar, as the picture draws them: a mark and a
 * word, the open one on a rounded pill - the same as Settings' sidebar,
 * measured off the same kind of picture. A drive has an eject button at
 * its end, and a folder or a drive takes files dropped on it.
 */
import QtQuick
import org.solvane.flowbar as Flow
import "../../settings/parts"

Item {
    id: place

    property string glyph: ""
    property string label: ""
    property bool chosen: false
    property bool ejectable: false
    property string dropFolder: ""        // where files dropped here go, or ""

    signal picked()
    signal eject()
    signal dropped(var urls, bool move)

    implicitWidth: Style.s(353)
    implicitHeight: Style.s(68)

    Rectangle {
        anchors.fill: parent
        radius: Style.s(18)
        color: drop.containsDrag ? Style.accentTint
             : place.chosen ? Style.accentTint
             : press.pressed ? Style.cardPressed
             : press.containsMouse ? Style.card : "transparent"
        border.width: drop.containsDrag ? 1 : 0
        border.color: Style.accentInk
    }
    Flow.Glyph {
        x: Style.s(37) - width / 2
        anchors.verticalCenter: parent.verticalCenter
        width: Style.s(34)
        height: width
        kind: place.glyph
        ink: place.chosen ? Style.accentInk : Style.inkSoft
    }
    Text {
        x: Style.s(78)
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width - x - Style.s(16) - (place.ejectable ? Style.s(56) : 0)
        text: place.label
        elide: Text.ElideRight
        color: Style.ink
        font.family: Style.family
        font.pixelSize: Style.sideSize
        font.weight: place.chosen ? Font.DemiBold : Font.Medium
    }
    MouseArea {
        id: press
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: place.picked()
    }
    Tool {
        visible: place.ejectable
        anchors.right: parent.right
        anchors.rightMargin: Style.s(8)
        anchors.verticalCenter: parent.verticalCenter
        glyph: "eject"
        label: "Eject " + place.label
        onPressed: place.eject()
    }
    DropArea {
        id: drop
        anchors.fill: parent
        enabled: place.dropFolder !== ""
        onEntered: function(drag) { drag.accepted = drag.hasUrls }
        onDropped: function(drop) {
            var urls = []
            for (var i = 0; i < drop.urls.length; i++) urls.push(drop.urls[i].toString())
            place.dropped(urls, drop.proposedAction === Qt.MoveAction)
            drop.acceptProposedAction()
        }
    }
    Accessible.role: Accessible.PageTab
    Accessible.name: place.label
}
