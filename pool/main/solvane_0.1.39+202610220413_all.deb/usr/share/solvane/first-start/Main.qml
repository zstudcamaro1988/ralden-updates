/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — the first start
 *
 * The screen a newly installed Solvane starts at, once: a card on the
 * photograph that says Welcome to Solvane OS and asks whose computer this
 * is. /usr/bin/solvane-first-start says what it is for and what it runs as;
 * this file is only what it looks like.
 *
 * WHAT THIS IS A COPY OF, AND WHERE IT IS NOT YET.
 *
 * The third reference image (reference/3-welcome.png; the design spec,
 * section 3). The card is that picture's card, measured: 448 by 373 of its
 * pixels, the title and "Let's set up your experience." across the top, a
 * rail of steps down the left, and on a white sheet "Create Your Account",
 * four boxes one under another with what they are for written inside them,
 * an eye at the end of each password box, and a blue Continue at the
 * bottom right. `p` below is one pixel of that picture, and every place
 * and size on the card is written in them.
 *
 * Where it differs, and why. The reference's rail has seven steps; this
 * one has the two that exist, Account and Finish. Under the boxes the
 * reference offers a PIN, a fingerprint and a security key; none of the
 * three exists, and what is there instead is what the computer will be
 * called and what is wrong with what has been typed. A step that can be
 * seen and not taken is a promise, and this screen makes none it cannot
 * keep.
 *
 * ONE STEP THE REFERENCE HAS NOT GOT: Time Zone. It is on the rail only on
 * a computer that nothing could tell where it is - installed with no
 * internet, and still with none - and it is the only time the reference's
 * Back is drawn, because it is the only time there is somewhere to go
 * back to.
 *
 * EVERY SIZE HERE IS A FRACTION OF THE SCREEN'S HEIGHT, as on the boot
 * screen and for the same reason: `u` is one hundredth of it, `p` is a
 * fixed part of `u`, and the same file is then right on a 1366x768 laptop
 * and on a 4K monitor.
 *
 * ONLY QtQuick AND ITS WINDOW ARE IMPORTED. No Controls: the boxes below
 * are TextInput with a rectangle round them, and the small drawings are a
 * Canvas. This is drawn before there is a desktop, by an account that can
 * do nothing, on a computer that has no other way of getting an owner -
 * every module it does not import is one that cannot be missing on the
 * day.
 */

import QtQuick
import QtQuick.Window

Window {
    id: root

    visible: false
    title: "Solvane OS"
    color: "#16305C"

    /* Set from the program: true only when this is being tried in a window
     * on a desk. On the real screen there is no window manager. */
    property bool framed: false
    flags: framed ? Qt.Window : (Qt.Window | Qt.FramelessWindowHint)

    readonly property real u: height / 100
    readonly property real hair: Math.max(1, Math.round(u * 0.14))
    /* One pixel of the reference picture's card, which is 448 of them wide
     * and 373 high: 84 hundredths of the screen's height, or less on a
     * screen too narrow for that. */
    readonly property real p: Math.min(u * 84 / 373, (width - u * 8) / 448)

    /* ALPINE MIST (13 October 2026): the login screen's look, which the
     * owner chose as Solvane's normal appearance - white type on glass over
     * the photograph at dusk, where this was navy type on a pale card. */
    readonly property color ink: "#FFFFFF"
    readonly property color inkSoft: "#D6DEEC"
    readonly property color inkFaint: "#B7C4DB"
    readonly property color accent: "#4A90E2"
    readonly property color accentDeep: "#2F66C0"
    readonly property color wrongInk: "#FFB3AB"
    readonly property color cautionInk: "#F6CF86"
    readonly property string face: "Inter"

    /* ---- what has been typed, and what is wrong with it ----------------
     *
     * Nothing here decides anything. Every answer comes from the program,
     * which gets its rules from the one privileged file; this only remembers
     * which boxes somebody has been in, so that an untouched form is not
     * covered in red. */

    property bool loginTouched: false
    property bool againTouched: false
    property bool tried: false
    property bool reveal: false

    property var wrong: ({})
    property bool canGo: false
    property string note: ""
    property string computer: ""

    /* For photographs only (--fill): show the last page without an account
     * having been made. */
    readonly property string staged: first.fill.page ? first.fill.page : ""
    readonly property bool finished: first.done || staged === "done"
    readonly property bool working: first.busy || staged === "busy"

    /* Which of the sheet's pages is up: "account", or "zone" on a computer
     * that has to be told where it is. */
    property string page: "account"
    /* What the search on that page has found. */
    property var places: []

    function search() {
        root.places = first.zones(zoneBox.text)
    }

    function fields() {
        var touched = []
        if (root.loginTouched || root.tried)
            touched.push("login")
        if (root.againTouched || root.tried)
            touched.push("again")
        return {
            "name": nameBox.text,
            "login": loginBox.text,
            "password": passwordBox.text,
            "again": againBox.text,
            "touched": touched
        }
    }

    function refresh() {
        var typed = fields()
        root.wrong = first.problems(typed)
        root.canGo = first.ready(typed)
        root.note = first.passwordNote(passwordBox.text, againBox.text)
        root.computer = root.wrong.login ? "" : first.computerFor(loginBox.text)
    }

    function go() {
        if (root.working || root.finished || first.looking)
            return
        if (root.page === "zone") {
            if (first.zone !== "")
                first.create(fields())
            return
        }
        root.tried = true
        refresh()
        if (!root.canGo) {
            /* Put the keyboard where the trouble is. */
            if (loginBox.text === "" || root.wrong.login)
                loginBox.take()
            else if (root.wrong.password)
                passwordBox.take()
            else
                againBox.take()
            return
        }
        if (first.askZone) {
            /* Nothing could say where this computer is: ask, before the
             * account is made and this screen is over. */
            root.page = "zone"
            search()
            zoneBox.take()
            return
        }
        first.create(fields())
    }

    Component.onCompleted: {
        var given = first.fill
        if (given.name !== undefined)
            nameBox.text = given.name
        if (given.login !== undefined) {
            loginBox.text = given.login
            root.loginTouched = true
        }
        if (given.password !== undefined)
            passwordBox.text = given.password
        if (given.again !== undefined) {
            againBox.text = given.again
            root.againTouched = true
        }
        if (given.reveal === true)
            root.reveal = true
        if (given.tried === true)
            root.tried = true
        refresh()
        if (given.focus === "login")
            loginBox.take()
        else if (given.focus === "password")
            passwordBox.take()
        else if (given.focus === "none")
            root.contentItem.forceActiveFocus()
        else
            nameBox.take()
        if (given.page === "zone") {
            root.page = "zone"
            if (given.search !== undefined)
                zoneBox.text = given.search
            search()
            if (given.focus !== "none")
                zoneBox.take()
        }
    }

    /* The privileged program said no about one particular box: go there. */
    Connections {
        target: first
        function onChanged() {
            if (first.failure === "")
                return
            /* What was refused was typed on the first page. */
            root.page = "account"
            if (first.failedField === "login")
                loginBox.take()
            else if (first.failedField === "password")
                passwordBox.take()
        }
    }

    /* ---- the pieces, declared once ----------------------------------- */

    /* A small line drawing, on a grid of 24. The reference has one beside
     * each step and one in each password box; these are drawn rather than
     * shipped, so there is no picture file that could be missing. */
    component Glyph: Canvas {
        id: glyph
        property string kind: ""
        property color colour: root.inkSoft
        /* An eye with a line through it: what is typed is hidden. */
        property bool struck: false
        /* How heavy the line is, on the grid of 24. */
        property real weight: 1.7
        width: root.p * 12
        height: width
        onKindChanged: requestPaint()
        onColourChanged: requestPaint()
        onStruckChanged: requestPaint()
        onWeightChanged: requestPaint()
        onWidthChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            var k = width / 24
            c.reset()
            c.scale(k, k)
            c.lineWidth = glyph.weight
            c.lineCap = "round"
            c.lineJoin = "round"
            c.strokeStyle = glyph.colour
            c.beginPath()
            if (kind === "person") {
                c.moveTo(15.5, 8.6)
                c.arc(12, 8.6, 3.5, 0, Math.PI * 2, false)
                c.moveTo(5.2, 19.8)
                c.bezierCurveTo(5.2, 15.4, 8.3, 13.9, 12, 13.9)
                c.bezierCurveTo(15.7, 13.9, 18.8, 15.4, 18.8, 19.8)
            } else if (kind === "flag") {
                c.moveTo(6.5, 4.2); c.lineTo(6.5, 20.2)
                c.moveTo(6.5, 5.4); c.lineTo(18, 5.4); c.lineTo(15.4, 9.2)
                c.lineTo(18, 13); c.lineTo(6.5, 13)
            } else if (kind === "computer") {
                c.rect(4, 5.2, 16, 10.8)
                c.moveTo(12, 16); c.lineTo(12, 19.4)
                c.moveTo(8.4, 19.4); c.lineTo(15.6, 19.4)
            } else if (kind === "lock") {
                c.rect(6.5, 11, 11, 8.5)
                c.moveTo(8.8, 11)
                c.lineTo(8.8, 8.4)
                c.arc(12, 8.4, 3.2, Math.PI, 0, false)
                c.lineTo(15.2, 11)
            } else if (kind === "clock") {
                c.moveTo(20.2, 12)
                c.arc(12, 12, 8.2, 0, Math.PI * 2, false)
                c.moveTo(12, 7.4); c.lineTo(12, 12); c.lineTo(15.3, 14)
            } else if (kind === "back") {
                c.moveTo(14.5, 6); c.lineTo(8.5, 12); c.lineTo(14.5, 18)
            } else if (kind === "eye") {
                c.moveTo(3.2, 12)
                c.bezierCurveTo(6.2, 6.6, 17.8, 6.6, 20.8, 12)
                c.bezierCurveTo(17.8, 17.4, 6.2, 17.4, 3.2, 12)
                c.moveTo(14.7, 12)
                c.arc(12, 12, 2.7, 0, Math.PI * 2, false)
                if (glyph.struck) {
                    c.moveTo(5.4, 4.8); c.lineTo(18.6, 19.2)
                }
            }
            c.stroke()
        }
    }

    /* A button's face: rounded, and a little darker at the bottom. Drawn,
     * and not a Rectangle. A rounded Rectangle with a gradient in it comes
     * out of the renderer this is photographed with - and falls back to on
     * a computer whose graphics driver will not start - with its right-hand
     * corners squarer than its left. Seen on every photograph of every
     * blue button until 7 October 2026; putting the button on whole pixels
     * did not cure it. */
    component Face: Canvas {
        id: face
        property real corner: 0
        property color light: "#000000"
        property color dark: "#000000"
        onCornerChanged: requestPaint()
        onLightChanged: requestPaint()
        onDarkChanged: requestPaint()
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            var w = width, h = height
            var r = Math.min(corner, w / 2, h / 2)
            c.reset()
            var shade = c.createLinearGradient(0, 0, 0, h)
            shade.addColorStop(0, face.light)
            shade.addColorStop(1, face.dark)
            c.fillStyle = shade
            c.beginPath()
            c.moveTo(r, 0)
            c.lineTo(w - r, 0)
            c.arcTo(w, 0, w, r, r)
            c.lineTo(w, h - r)
            c.arcTo(w, h, w - r, h, r)
            c.lineTo(r, h)
            c.arcTo(0, h, 0, h - r, r)
            c.lineTo(0, r)
            c.arcTo(0, 0, r, 0, r)
            c.closePath()
            c.fill()
        }
    }

    /* A box to type in. What it is for is written inside it, as on the
     * reference, until something has been typed there. */
    /* Glass, as the login screen's card is (13 October 2026, Alpine Mist):
     * the photograph behind it out of focus - glass.jpg, made with the
     * photograph by tools/make-alpine-mist.py - a veil of white, and a thin
     * bright rim. Drawn, because nothing in plain QtQuick blurs, and the
     * same arithmetic as the login screen's for which part of the picture
     * is behind it. */
    component Glass: Canvas {
        id: glassFace
        property real corner: 0
        property url picture: first.art + "glass.jpg"
        property real veilTop: 0.10
        property real veilBottom: 0.03
        /* Navy between the photograph and the veil. The login card sits
         * over dark rock; this card is larger and reaches down into the
         * bright band of mist, where glass alone left white type at under
         * 2:1. Half navy brings the palest part of it to about 5:1. */
        property real tint: 0.52
        Component.onCompleted: loadImage(picture)
        onImageLoaded: requestPaint()
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            var w = width, h = height, r = Math.min(corner, w / 2, h / 2)
            var at = glassFace.mapToItem(null, 0, 0)
            c.reset()
            c.beginPath()
            c.moveTo(r, 0)
            c.lineTo(w - r, 0)
            c.arcTo(w, 0, w, r, r)
            c.lineTo(w, h - r)
            c.arcTo(w, h, w - r, h, r)
            c.lineTo(r, h)
            c.arcTo(0, h, 0, h - r, r)
            c.lineTo(0, r)
            c.arcTo(0, 0, r, 0, r)
            c.closePath()
            c.save()
            c.clip()
            if (isImageLoaded(picture)) {
                var cover = Math.max(root.width / 16, root.height / 9)
                var seenW = 16 * cover, seenH = 9 * cover
                var left = (root.width - seenW) / 2
                var top = (root.height - seenH) / 2
                c.drawImage(picture,
                            (at.x - left) / seenW * 960,
                            (at.y - top) / seenH * 540,
                            w / seenW * 960, h / seenH * 540,
                            0, 0, w, h)
            } else {
                c.fillStyle = "#5A7FB8"
                c.fillRect(0, 0, w, h)
            }
            c.fillStyle = "rgba(20, 42, 84, " + glassFace.tint + ")"
            c.fillRect(0, 0, w, h)
            var veil = c.createLinearGradient(0, 0, 0, h)
            veil.addColorStop(0, "rgba(255, 255, 255, " + glassFace.veilTop + ")")
            veil.addColorStop(1, "rgba(255, 255, 255, " + glassFace.veilBottom + ")")
            c.fillStyle = veil
            c.fillRect(0, 0, w, h)
            c.restore()
            c.lineWidth = Math.max(1, root.hair)
            c.strokeStyle = "rgba(255, 255, 255, 0.42)"
            c.stroke()
        }
    }

    component Box: Item {
        id: box
        property string label: ""
        property alias text: input.text
        property bool secret: false
        property bool bad: false
        property int limit: 64
        readonly property bool active: input.activeFocus
        signal edited()
        signal accepted()
        signal departed()
        /* Up or Down pressed in it: -1 or 1. A box over a list uses it. */
        signal stepped(int by)

        function take() {
            input.forceActiveFocus()
        }

        height: root.p * 24

        Rectangle {
            id: frame
            anchors.fill: parent
            radius: root.p * 5
            color: box.enabled ? "#BF2C4A70" : "#802C4A70"
            /* The same colour with nothing of it there: what the two fades
             * at the ends of the text fade to. */
            readonly property color clear: Qt.rgba(color.r, color.g,
                                                   color.b, 0)
            border.width: input.activeFocus ? root.hair * 2 : root.hair
            border.color: input.activeFocus ? root.accent
                        : box.bad ? root.wrongInk
                        : "#40FFFFFF"
            Behavior on border.color { ColorAnimation { duration: 110 } }

            /* Anywhere in the frame is the box, not only the line of text. */
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.IBeamCursor
                onPressed: input.forceActiveFocus()
            }
            Text {
                anchors.left: input.left
                anchors.right: input.right
                anchors.verticalCenter: parent.verticalCenter
                visible: input.text === "" && input.preeditText === ""
                text: box.label
                elide: Text.ElideRight
                color: root.inkFaint
                font.family: root.face
                font.pixelSize: root.p * 8.5
            }
            TextInput {
                id: input
                anchors.left: parent.left
                anchors.leftMargin: root.p * 9
                anchors.right: eye.visible ? eye.left : parent.right
                anchors.rightMargin: root.p * 8
                anchors.verticalCenter: parent.verticalCenter
                height: parent.height
                verticalAlignment: TextInput.AlignVCenter
                clip: true
                color: root.ink
                selectionColor: root.accent
                selectedTextColor: "#FFFFFF"
                font.family: root.face
                /* A password's dots are drawn smaller than its letters
                 * would be: at the size of the letters they are a row of
                 * beads, and heavier than anything else on the card. */
                font.pixelSize: box.secret && !root.reveal ? root.p * 6.8
                                                           : root.p * 9.3
                font.letterSpacing: box.secret && !root.reveal ? root.p * 0.9
                                                               : 0
                maximumLength: box.limit
                echoMode: box.secret && !root.reveal ? TextInput.Password
                                                     : TextInput.Normal
                selectByMouse: true
                activeFocusOnTab: true
                inputMethodHints: box.secret
                    ? (Qt.ImhNoPredictiveText | Qt.ImhNoAutoUppercase
                       | Qt.ImhSensitiveData)
                    : Qt.ImhNoPredictiveText
                onTextEdited: box.edited()
                onAccepted: box.accepted()
                Keys.onDownPressed: box.stepped(1)
                Keys.onUpPressed: box.stepped(-1)
                onActiveFocusChanged: if (!activeFocus) box.departed()

                /* How much of the text has gone out past the left edge:
                 * nothing, until there is more of it than fits. The first
                 * line is only there to be read - when the cursor moves or
                 * the text changes, this is worked out again. */
                readonly property real run: {
                    var moved = cursorRectangle.x + cursorPosition
                              + text.length
                    return contentWidth > width + 1
                         ? Math.max(0, -positionToRectangle(0).x) : 0
                }
            }
            /* Text longer than its box is cut at an edge, and a password's
             * dot cut in half there looks like a fault in the drawing.
             * Faded into the box, the same thing says "there is more this
             * way". Drawn only at an end where something really is cut. */
            Rectangle {
                visible: input.run > 1
                anchors.left: input.left
                anchors.verticalCenter: parent.verticalCenter
                width: root.p * 10
                height: parent.height - root.p * 5
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0.0; color: frame.color }
                    GradientStop { position: 1.0; color: frame.clear }
                }
            }
            Rectangle {
                visible: input.contentWidth - input.run > input.width + 1
                anchors.right: input.right
                anchors.verticalCenter: parent.verticalCenter
                width: root.p * 10
                height: parent.height - root.p * 5
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0.0; color: frame.clear }
                    GradientStop { position: 1.0; color: frame.color }
                }
            }
            /* The pointer is an I over the text as well. Takes no clicks. */
            MouseArea {
                anchors.fill: input
                acceptedButtons: Qt.NoButton
                cursorShape: Qt.IBeamCursor
            }
            /* The eye at the end of a password box. Struck through while
             * the password is hidden; pressing it shows both boxes, or
             * hides both again. */
            Glyph {
                id: eye
                visible: box.secret
                anchors.right: parent.right
                anchors.rightMargin: root.p * 9
                anchors.verticalCenter: parent.verticalCenter
                kind: "eye"
                weight: 2.0
                struck: !root.reveal
                colour: eyeArea.containsMouse ? root.accent : "#C3CDE0"
                MouseArea {
                    id: eyeArea
                    anchors.fill: parent
                    anchors.margins: -root.p * 5
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.reveal = !root.reveal
                }
            }
        }
    }

    /* One step of the rail: where somebody is, not somewhere to go. It
     * takes no clicks - there is no going back from having an account,
     * and no going forward without one. */
    component Step: Item {
        id: step
        property string kind: ""
        property string label: ""
        property bool current: false
        width: root.p * 112
        height: root.p * 26
        Rectangle {
            anchors.fill: parent
            radius: root.p * 6
            color: "#664A90E2"
            opacity: step.current ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 200 } }
        }
        Glyph {
            x: root.p * 7.5
            anchors.verticalCenter: parent.verticalCenter
            width: root.p * 13
            weight: 2.1
            kind: step.kind
            colour: root.ink
        }
        Text {
            x: root.p * 31
            anchors.verticalCenter: parent.verticalCenter
            text: step.label
            color: step.current ? root.ink : root.inkSoft
            font.family: root.face
            font.pixelSize: root.p * 8.6
            font.weight: step.current ? Font.Medium : Font.Normal
        }
    }

    /* A sentence under the boxes, with a drawing in front of it that says
     * what it is about. Takes no room when it has nothing to say. */
    component Remark: Item {
        id: remark
        property string kind: ""
        property string words: ""
        property color colour: root.inkSoft
        visible: words !== ""
        height: Math.max(sign.height, saying.height)
        Glyph {
            id: sign
            width: root.p * 11
            kind: remark.kind
            colour: remark.colour
        }
        Text {
            id: saying
            x: root.p * 17
            y: -root.p * 0.4
            width: remark.width - x
            text: remark.words
            wrapMode: Text.WordWrap
            color: remark.colour
            font.family: root.face
            font.pixelSize: root.p * 8.5
            lineHeight: 1.22
        }
    }

    /* A quiet word at the foot of the screen. */
    component Quiet: Item {
        id: quiet
        property string label: ""
        signal chosen()
        width: word.width + root.u * 4
        height: root.u * 5
        Rectangle {
            anchors.fill: parent
            radius: root.u * 1.4
            color: quietArea.pressed ? "#3DFFFFFF" : "#24FFFFFF"
            opacity: quietArea.containsMouse ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 120 } }
        }
        Text {
            anchors.horizontalCenter: word.horizontalCenter
            y: word.y + root.u * 0.16
            text: quiet.label
            color: "#66223A66"
            font: word.font
        }
        Text {
            id: word
            anchors.centerIn: parent
            text: quiet.label
            color: "#FFFFFF"
            font.family: root.face
            font.pixelSize: root.u * 2.3
            font.weight: Font.Medium
        }
        MouseArea {
            id: quietArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: quiet.chosen()
        }
    }

    /* ---- what is behind everything: the boot screen's photograph ------ */

    Image {
        anchors.fill: parent
        source: first.wallpaper
        fillMode: Image.PreserveAspectCrop
        asynchronous: false
        smooth: true
    }
    /* Alpine Mist: the photograph is already at dusk, so the pale
     * reference's veil that lifted the top is gone, the light behind the
     * card is faint, and the foot is deepened in navy. */
    Image {
        anchors.horizontalCenter: parent.horizontalCenter
        y: -root.u * 22
        width: root.u * 150
        height: root.u * 104
        source: first.art + "glow.png"
        opacity: 0.08
        smooth: true
    }
    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: root.u * 58
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#0016305C" }
            GradientStop { position: 0.55; color: "#4D16305C" }
            GradientStop { position: 1.0; color: "#8C10244A" }
        }
    }

    /* ---- the card ------------------------------------------------------
     *
     * 448 by 373 of the reference's own pixels (root.p is one of them),
     * and everything on it is where the reference has it. */

    Item {
        id: card
        /* On whole pixels, and so is the sheet on it and the button on
         * that. A rounded rectangle that starts or ends part of the way
         * through a pixel is drawn with corners that do not match - seen
         * on the first two photographs of this card, on the right-hand
         * side of its button. */
        x: Math.round((root.width - width) / 2)
        y: Math.round(Math.max(root.u * 3,
                               (root.height - height) / 2 - root.u * 2.5))
        width: Math.round(root.p * 448)
        height: Math.round(root.p * 373)

        readonly property real corner: root.p * 12

        /* A soft shadow, built from pale layers rather than a blur. */
        Repeater {
            model: 5
            Rectangle {
                required property int index
                anchors.fill: parent
                anchors.margins: -root.u * 0.45 * (index + 1)
                anchors.topMargin: -root.u * 0.45 * (index + 1) + root.u * 0.9
                anchors.bottomMargin: -root.u * 0.45 * (index + 1) - root.u * 0.9
                radius: card.corner + root.u * 0.45 * (index + 1)
                color: "#0A1B2A4A"
            }
        }
        /* The glass the whole card is made of: the login card's. */
        Glass {
            anchors.fill: parent
            corner: card.corner
        }

        /* -- the top: who is speaking ------------------------------------- */

        Text {
            id: welcome
            anchors.horizontalCenter: parent.horizontalCenter
            y: root.p * 28 - height / 2
            text: "Welcome to Solvane OS"
            color: root.ink
            font.family: root.face
            font.pixelSize: root.p * 16
            font.weight: Font.Medium
            font.letterSpacing: root.p * 0.1
        }
        Text {
            id: promise
            anchors.horizontalCenter: parent.horizontalCenter
            y: root.p * 48 - height / 2
            text: "Let’s set up your experience."
            color: root.inkSoft
            font.family: root.face
            font.pixelSize: root.p * 8.8
        }

        /* -- the left: the steps ------------------------------------------
         *
         * The two there are. The reference has seven; a step is added here
         * on the day there is something behind it. */

        Step {
            id: accountStep
            x: root.p * 6
            y: root.p * 77
            kind: "person"
            label: "Account"
            current: !root.finished && root.page === "account"
        }
        /* Only on a computer that has to be asked: see the top of this
         * file. Not while the internet is still being asked - a step that
         * comes and goes again in six seconds is worse than one that
         * arrives a little late. */
        Step {
            id: zoneStep
            readonly property bool wanted: root.page === "zone"
                                           || (first.askZone && !first.looking)
            x: accountStep.x
            y: accountStep.y + root.p * 29
            kind: "clock"
            label: "Time Zone"
            current: !root.finished && root.page === "zone"
            opacity: wanted ? 1 : 0
            visible: opacity > 0
            Behavior on opacity { NumberAnimation { duration: 200 } }
        }
        Step {
            id: finishStep
            x: accountStep.x
            y: accountStep.y + root.p * 29 * (zoneStep.wanted ? 2 : 1)
            kind: "flag"
            label: "Finish"
            current: root.finished
            Behavior on y { NumberAnimation { duration: 200 } }
        }
        /* The reference's Back, where the reference has it - on the one
         * page there is anything behind. */
        Item {
            id: back
            x: root.p * 14
            y: Math.round(root.p * 332)
            width: Math.round(root.p * 58)
            height: Math.round(root.p * 24)
            opacity: root.page === "zone" && !root.finished ? 1 : 0
            visible: opacity > 0
            enabled: !root.working
            activeFocusOnTab: true
            Behavior on opacity { NumberAnimation { duration: 200 } }
            Keys.onReturnPressed: back.chosen()
            Keys.onEnterPressed: back.chosen()
            Keys.onSpacePressed: back.chosen()
            function chosen() {
                root.page = "account"
                nameBox.take()
            }
            Rectangle {
                anchors.fill: parent
                radius: root.p * 6
                color: backArea.pressed ? "#47FFFFFF"
                     : backArea.containsMouse ? "#38FFFFFF" : "#26FFFFFF"
                border.width: back.activeFocus ? root.hair * 2 : root.hair
                border.color: back.activeFocus ? root.accent : "#4DFFFFFF"
            }
            Glyph {
                x: root.p * 8
                anchors.verticalCenter: parent.verticalCenter
                width: root.p * 10
                weight: 2.2
                kind: "back"
                colour: root.ink
            }
            Text {
                x: root.p * 24
                anchors.verticalCenter: parent.verticalCenter
                text: "Back"
                color: root.ink
                font.family: root.face
                font.pixelSize: root.p * 8.8
                font.weight: Font.Medium
            }
            MouseArea {
                id: backArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: back.chosen()
            }
        }
        Text {
            x: root.p * 14
            y: root.p * 356 - height
            width: root.p * 102
            opacity: root.page === "zone" && !root.finished ? 0 : 1
            Behavior on opacity { NumberAnimation { duration: 200 } }
            text: "This account is the administrator of this computer. "
                + "Other people can be given their own afterwards, in "
                + "Settings, under Accounts."
            wrapMode: Text.WordWrap
            color: root.inkSoft
            font.family: root.face
            font.pixelSize: root.p * 7.9
            lineHeight: 1.26
        }

        /* -- the sheet of paper everything else is on --------------------- */

        Rectangle {
            id: sheet
            x: Math.round(root.p * 131)
            y: Math.round(root.p * 66)
            width: Math.round(root.p * 286)
            height: Math.round(root.p * 299)
            radius: root.p * 8
            color: "#1AFFFFFF"
            border.width: root.hair
            border.color: "#40FFFFFF"
        }

        /* -- on it: the account ------------------------------------------- */

        Item {
            id: form
            x: sheet.x
            y: sheet.y
            width: sheet.width
            height: sheet.height
            opacity: root.finished || root.page !== "account" ? 0 : 1
            visible: opacity > 0
            enabled: !root.working && !root.finished
                     && root.page === "account"
            Behavior on opacity { NumberAnimation { duration: 220 } }

            readonly property real edge: root.p * 15
            readonly property real pitch: root.p * 32

            Text {
                id: heading
                x: root.p * 16
                y: root.p * 17 - height / 2
                text: "Create Your Account"
                color: root.ink
                font.family: root.face
                font.pixelSize: root.p * 10
                font.weight: Font.DemiBold
            }

            Box {
                id: nameBox
                x: form.edge
                y: root.p * 35
                width: form.width - form.edge * 2
                label: "Full Name"
                limit: 64
                onEdited: {
                    if (!root.loginTouched)
                        loginBox.text = first.suggestLogin(text)
                    root.refresh()
                }
                onAccepted: loginBox.take()
            }
            Box {
                id: loginBox
                x: form.edge
                y: nameBox.y + form.pitch
                width: nameBox.width
                label: "Username"
                limit: 31
                bad: root.wrong.login !== undefined
                     || first.failedField === "login"
                onEdited: {
                    root.loginTouched = text !== ""
                    root.refresh()
                }
                onAccepted: passwordBox.take()
                onDeparted: {
                    if (text !== "")
                        root.loginTouched = true
                    root.refresh()
                }
            }
            Box {
                id: passwordBox
                x: form.edge
                y: loginBox.y + form.pitch
                width: nameBox.width
                label: "Password"
                secret: true
                limit: 512
                bad: root.wrong.password !== undefined
                     || first.failedField === "password"
                onEdited: root.refresh()
                onAccepted: againBox.take()
            }
            Box {
                id: againBox
                x: form.edge
                y: passwordBox.y + form.pitch
                width: nameBox.width
                label: "Confirm Password"
                secret: true
                limit: 512
                bad: root.wrong.again !== undefined
                onEdited: root.refresh()
                onAccepted: root.go()
                onDeparted: {
                    if (text !== "")
                        root.againTouched = true
                    root.refresh()
                }
            }

            /* What follows from what has been typed, and what is wrong
             * with it. The reference has three ways of signing in without
             * a password here; none of the three exists, so none is drawn. */
            Column {
                id: remarks
                x: form.edge
                y: againBox.y + againBox.height + root.p * 13
                width: nameBox.width
                spacing: root.p * 7

                Remark {
                    id: loginRemark
                    width: remarks.width
                    readonly property bool trouble:
                        root.wrong.login !== undefined
                        || first.failedField === "login"
                    kind: trouble ? "person" : "computer"
                    words: root.wrong.login !== undefined ? root.wrong.login
                         : first.failedField === "login" ? first.failure
                         : root.computer !== ""
                             ? "This computer will be called "
                               + root.computer + "."
                         : ""
                    colour: trouble ? root.wrongInk : root.inkSoft
                }
                Remark {
                    id: passwordRemark
                    width: remarks.width
                    readonly property string trouble:
                        root.wrong.password !== undefined ? root.wrong.password
                        : root.wrong.again !== undefined ? root.wrong.again
                        : first.failure !== "" && first.failedField !== "login"
                            ? first.failure
                        : ""
                    kind: "lock"
                    words: trouble !== "" ? trouble : root.note
                    colour: trouble !== "" ? root.wrongInk : root.cautionInk
                }
            }

            /* The button. */
            Item {
                id: button
                x: Math.round(root.p * 142)
                y: Math.round(root.p * 262)
                width: Math.round(root.p * 129)
                height: Math.round(root.p * 24)
                activeFocusOnTab: true
                /* Not while the internet is being asked where this is:
                 * six seconds at the most, and nobody has typed a name
                 * and a password by then. */
                readonly property bool live: root.canGo && !root.working
                                             && !first.looking
                readonly property bool hot: buttonArea.containsMouse && live
                scale: buttonArea.pressed && live ? 0.985 : 1
                Behavior on scale { NumberAnimation { duration: 90 } }
                Keys.onReturnPressed: root.go()
                Keys.onEnterPressed: root.go()
                Keys.onSpacePressed: root.go()

                Face {
                    anchors.fill: parent
                    corner: root.p * 5
                    light: !button.live ? "#5D7399"
                         : buttonArea.pressed ? "#3F76CF"
                         : button.hot ? "#5A93E6" : "#4D86DE"
                    dark: !button.live ? "#50668C"
                        : buttonArea.pressed ? "#2D5DB8"
                        : button.hot ? "#4176D3" : "#376ACA"
                }
                /* The keyboard's ring. */
                Rectangle {
                    anchors.fill: parent
                    anchors.margins: -root.p * 2.4
                    radius: root.p * 7.4
                    color: "transparent"
                    border.width: root.hair * 2
                    border.color: root.accent
                    visible: button.activeFocus
                }
                Text {
                    anchors.centerIn: parent
                    text: root.working ? "Creating your account…"
                                       : "Continue"
                    color: "#FFFFFF"
                    opacity: button.live || root.working ? 1 : 0.85
                    font.family: root.face
                    font.pixelSize: root.working ? root.p * 8.2
                                                 : root.p * 9.2
                    font.weight: Font.DemiBold
                }
                MouseArea {
                    id: buttonArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: button.live ? Qt.PointingHandCursor
                                             : Qt.ArrowCursor
                    onClicked: {
                        button.forceActiveFocus()
                        root.go()
                    }
                }
            }
        }

        /* -- on it, on a computer that has to be asked: where it is --------
         *
         * A box to search in and the places it finds, each with the time
         * it is there now - the quickest way for somebody to know they
         * have the right one. The list is this system's own; nothing here
         * decides what a time zone is. */

        Item {
            id: zonePage
            x: sheet.x
            y: sheet.y
            width: sheet.width
            height: sheet.height
            opacity: !root.finished && root.page === "zone" ? 1 : 0
            visible: opacity > 0
            enabled: !root.working && !root.finished && root.page === "zone"
            Behavior on opacity { NumberAnimation { duration: 220 } }

            readonly property real row: Math.round(root.p * 22)

            function step(by) {
                if (root.places.length === 0)
                    return
                var at = -1
                for (var i = 0; i < root.places.length; i++)
                    if (root.places[i].zone === first.zone)
                        at = i
                at = Math.max(0, Math.min(root.places.length - 1, at + by))
                first.chooseZone(root.places[at].zone)
                zoneList.positionViewAtIndex(at, ListView.Contain)
            }

            Text {
                id: zoneHeading
                x: root.p * 16
                y: root.p * 17 - height / 2
                text: "Choose Your Time Zone"
                color: root.ink
                font.family: root.face
                font.pixelSize: root.p * 10
                font.weight: Font.DemiBold
            }
            Box {
                id: zoneBox
                x: form.edge
                y: root.p * 35
                width: form.width - form.edge * 2
                label: "Search for a city or a country"
                limit: 64
                onEdited: root.search()
                onStepped: function(by) { zonePage.step(by) }
                onAccepted: {
                    /* Enter with one place found takes it; Enter with a
                     * place taken goes on. */
                    if (first.zone === "" && root.places.length === 1)
                        first.chooseZone(root.places[0].zone)
                    else if (first.zone !== "")
                        root.go()
                }
            }
            ListView {
                id: zoneList
                x: form.edge
                y: zoneBox.y + zoneBox.height + root.p * 8
                width: zoneBox.width
                height: zonePage.row * 7
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: root.places
                delegate: Item {
                    id: place
                    required property var modelData
                    readonly property bool taken: modelData.zone === first.zone
                    width: zoneList.width - root.p * 6
                    height: zonePage.row
                    Rectangle {
                        anchors.fill: parent
                        radius: root.p * 5
                        color: place.taken ? "#404A90E2"
                             : placeArea.containsMouse ? "#1FFFFFFF"
                             : "transparent"
                    }
                    Text {
                        id: placeTime
                        anchors.right: parent.right
                        anchors.rightMargin: root.p * 8
                        anchors.verticalCenter: parent.verticalCenter
                        text: place.modelData.time
                        color: place.taken ? root.accentDeep : root.inkSoft
                        font.family: root.face
                        font.pixelSize: root.p * 8.2
                    }
                    Text {
                        id: placeCity
                        x: root.p * 8
                        anchors.verticalCenter: parent.verticalCenter
                        text: place.modelData.city
                        color: place.taken ? root.accentDeep : root.ink
                        font.family: root.face
                        font.pixelSize: root.p * 8.8
                        font.weight: Font.Medium
                    }
                    Text {
                        anchors.left: placeCity.right
                        anchors.leftMargin: root.p * 7
                        anchors.right: placeTime.left
                        anchors.rightMargin: root.p * 7
                        anchors.verticalCenter: parent.verticalCenter
                        text: place.modelData.where
                        elide: Text.ElideRight
                        color: root.inkFaint
                        font.family: root.face
                        font.pixelSize: root.p * 7.8
                    }
                    MouseArea {
                        id: placeArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: first.chooseZone(place.modelData.zone)
                        onDoubleClicked: {
                            first.chooseZone(place.modelData.zone)
                            root.go()
                        }
                    }
                }
                /* How far down the list this is, when there is more of it
                 * than fits. Shows; takes no clicks. */
                Rectangle {
                    visible: zoneList.contentHeight > zoneList.height
                    anchors.right: parent.right
                    width: Math.max(2, root.p * 2)
                    radius: width / 2
                    color: "#80FFFFFF"
                    y: zoneList.visibleArea.yPosition * zoneList.height
                    height: Math.max(root.p * 12,
                                     zoneList.visibleArea.heightRatio
                                     * zoneList.height)
                }
            }
            Remark {
                id: zoneRemark
                x: form.edge
                y: zoneList.y + zoneList.height + root.p * 9
                width: zoneBox.width
                kind: "clock"
                words: first.zone !== ""
                     ? "The clock will keep "
                       + first.zone.split("/").pop().replace(/_/g, " ")
                       + " time."
                     : root.places.length === 0
                     ? "No place by that name. Try a large city near you."
                     : "The internet could not say where this computer is. "
                       + "Choose a city in your time zone."
                colour: first.zone !== "" ? root.inkSoft : root.cautionInk
            }

            /* The same button, in the same place, for the same thing. */
            Item {
                id: zoneButton
                x: button.x
                y: button.y
                width: button.width
                height: button.height
                activeFocusOnTab: true
                readonly property bool live: first.zone !== ""
                                             && !root.working
                readonly property bool hot: zoneButtonArea.containsMouse
                                            && live
                scale: zoneButtonArea.pressed && live ? 0.985 : 1
                Behavior on scale { NumberAnimation { duration: 90 } }
                Keys.onReturnPressed: root.go()
                Keys.onEnterPressed: root.go()
                Keys.onSpacePressed: root.go()

                Face {
                    anchors.fill: parent
                    corner: root.p * 5
                    light: !zoneButton.live ? "#5D7399"
                         : zoneButtonArea.pressed ? "#3F76CF"
                         : zoneButton.hot ? "#5A93E6" : "#4D86DE"
                    dark: !zoneButton.live ? "#50668C"
                        : zoneButtonArea.pressed ? "#2D5DB8"
                        : zoneButton.hot ? "#4176D3" : "#376ACA"
                }
                Rectangle {
                    anchors.fill: parent
                    anchors.margins: -root.p * 2.4
                    radius: root.p * 7.4
                    color: "transparent"
                    border.width: root.hair * 2
                    border.color: root.accent
                    visible: zoneButton.activeFocus
                }
                Text {
                    anchors.centerIn: parent
                    text: root.working ? "Creating your account…"
                                       : "Continue"
                    color: "#FFFFFF"
                    opacity: zoneButton.live || root.working ? 1 : 0.85
                    font.family: root.face
                    font.pixelSize: root.working ? root.p * 8.2
                                                 : root.p * 9.2
                    font.weight: Font.DemiBold
                }
                MouseArea {
                    id: zoneButtonArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: zoneButton.live ? Qt.PointingHandCursor
                                                 : Qt.ArrowCursor
                    onClicked: {
                        zoneButton.forceActiveFocus()
                        root.go()
                    }
                }
            }
        }

        /* -- on it afterwards: the finish --------------------------------- */

        Item {
            id: after
            x: sheet.x
            y: sheet.y
            width: sheet.width
            height: sheet.height
            opacity: root.finished ? 1 : 0
            visible: opacity > 0
            Behavior on opacity { NumberAnimation { duration: 260 } }

            Rectangle {
                id: disc
                anchors.horizontalCenter: parent.horizontalCenter
                y: root.p * 76
                width: root.p * 44
                height: width
                radius: width / 2
                color: "#2E9B6A"
                /* A tick: an L, turned an eighth of the way round. */
                Item {
                    anchors.centerIn: parent
                    anchors.verticalCenterOffset: -root.p * 2.4
                    width: root.p * 21
                    height: root.p * 12
                    rotation: -45
                    Rectangle {
                        width: root.p * 3.7
                        height: parent.height
                        radius: width / 2
                        color: "#FFFFFF"
                    }
                    Rectangle {
                        y: parent.height - height
                        width: parent.width
                        height: root.p * 3.7
                        radius: height / 2
                        color: "#FFFFFF"
                    }
                }
            }
            Text {
                id: afterTitle
                anchors.horizontalCenter: parent.horizontalCenter
                y: disc.y + disc.height + root.p * 16
                width: parent.width - root.p * 30
                horizontalAlignment: Text.AlignHCenter
                text: nameBox.text.trim() !== ""
                    ? "This computer is yours, " + nameBox.text.trim().split(/\s+/)[0] + "."
                    : "This computer is yours."
                elide: Text.ElideRight
                color: root.ink
                font.family: root.face
                font.pixelSize: root.p * 14
                font.weight: Font.DemiBold
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                y: afterTitle.y + afterTitle.height + root.p * 6
                width: parent.width - root.p * 44
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
                text: passwordBox.text === ""
                    ? "The sign-in screen is next. Choose your name there; "
                      + "no password will be asked for."
                    : "The sign-in screen is next. Sign in there with the "
                      + "password you have just chosen."
                color: root.inkSoft
                font.family: root.face
                font.pixelSize: root.p * 9.8
                lineHeight: 1.24
            }
        }
    }

    /* ---- the foot of the screen ---------------------------------------
     *
     * A computer that is switched on and waiting at this screen has to be
     * able to be switched off again by somebody who is not ready to answer
     * it. */

    Row {
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.u * 93.2
        spacing: root.u * 2
        opacity: root.working || root.finished ? 0 : 1
        visible: opacity > 0
        Behavior on opacity { NumberAnimation { duration: 200 } }
        Quiet {
            label: "Restart"
            onChosen: first.restart()
        }
        Quiet {
            label: "Shut Down"
            onChosen: first.shutDown()
        }
    }
}
