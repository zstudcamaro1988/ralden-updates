/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — the clock, on the wallpaper
 *
 * WHY THIS IS A WIDGET AND NOT A SETTING.
 *
 * Everything else in the Solvane desktop so far — the palette, the dock, the
 * three dots on the right — turned out to be a line in a configuration file,
 * because Plasma is built to be reshaped. This is where that ends. The block
 * in the top left of every render we have made is a large time in Solvane's
 * own type, sitting directly on the photograph with no panel behind it, and
 * nothing in Plasma does that. It has to be written.
 *
 * It is also the right first thing to write, because everything after it —
 * the Control Center, universal search, Shield's window — is the same kind of
 * work, and this is small enough to get the conventions right in.
 *
 * WHAT IS REAL HERE AND WHAT IS NOT.
 *
 * The time and the date are real. The weather in the renders was not: it said
 * "Alpine Mist, light fog" because somebody typed that into a mockup, and
 * shipping it would be a desktop that lies on the first screen a person sees.
 * Since 13 October 2026 the weather is here, attached to an actual forecast
 * for an actual place: the town this computer's internet connection is in,
 * from /usr/lib/solvane/weather, and nothing at all when that is not known.
 *
 * WHY A TIMER RATHER THAN PLASMA'S TIME DATA ENGINE.
 *
 * The data engine works and is one more dependency on an API that has changed
 * shape twice. A clock needs to know what time it is, which JavaScript can
 * answer, and needs to be told when to look again, which a Timer can do. The
 * interval is a second only when seconds are shown; otherwise it ticks once a
 * minute and costs nothing on a laptop that is trying to save its battery.
 */

import QtQuick
import QtQuick.Layouts
import QtQuick.Window
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami
import org.solvane.flowbar as Flow

PlasmoidItem {
    id: root

    /* No panel behind it. This is the whole point of the widget: the type
     * sits on the photograph, the way it does in every render, rather than in
     * a tile that announces itself as a widget. */
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground

    preferredRepresentation: fullRepresentation

    /* ------------------------------------------------------------ the clock
     *
     * One Date, read when the timer fires and never in a binding. A binding
     * that called new Date() would be re-evaluated whenever anything it
     * touched changed and would still not update on its own, which is the
     * classic way a QML clock ends up frozen at the time the desktop
     * started. */
    property date now: new Date()

    readonly property bool showSeconds: Plasmoid.configuration.showSeconds
    readonly property bool use24Hour: Plasmoid.configuration.use24Hour
    readonly property bool showDate: Plasmoid.configuration.showDate

    Timer {
        id: tick

        /* A second when seconds are on the screen, otherwise a minute.
         *
         * Waking a laptop's CPU sixty times more often than the display
         * changes is the kind of cost nobody sees in a screenshot and
         * everybody feels in the battery, and this machine is from 2009.
         *
         * ON THE MINUTE, NOT A MINUTE FROM WHENEVER IT STARTED.
         *
         * Seen on a machine, 6 October 2026: this clock said 1:22 while the
         * dock's said 1:23, and the dock was right. A timer that fires every
         * sixty seconds fires sixty seconds after the desktop happened to
         * start - at forty seconds past, say, for the rest of the day - so
         * the clock was up to a minute late, always, and by a different
         * amount at every login.
         *
         * So each time it fires it asks how far into the minute it is, and
         * sets itself to fire again just after the next one begins. The 20
         * is the "just after": a timer that woke a few milliseconds early
         * would otherwise read the old minute and then sleep through the
         * new one. */
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: {
            // The time zone can change while the desktop is up: the live
            // disc learns where it is a moment after it starts
            // (/usr/lib/solvane/live-zone), and a laptop's owner can change
            // it. QML's Date keeps the zone it found at the start until it
            // is told; telling it costs nothing, so it is told every time.
            Date.timeZoneUpdated()
            var moment = new Date()
            root.now = moment
            var whole = root.showSeconds ? 1000 : 60000
            var into = moment.getMilliseconds()
                + (root.showSeconds ? 0 : moment.getSeconds() * 1000)
            interval = whole - into + 20
        }
    }
    /* Turning seconds on must not wait out the rest of a minute to show. */
    onShowSecondsChanged: tick.restart()

    /* The clock is also wrong for up to a minute after the machine wakes from
     * suspend, because the timer it was counting on was asleep too. Asking
     * again whenever the widget becomes visible costs one Date and fixes it. */
    onVisibleChanged: if (visible) now = new Date()

    /* --------------------------------------------------------- the palette
     *
     * Not Kirigami.Theme's text colour. This block is drawn on a photograph,
     * not on a panel, and the theme's foreground is chosen to sit on the
     * theme's background — on a bright alpine sky it disappears. White with a
     * shadow under it is what the from-scratch Solvane did and it is what
     * works over an image whose brightness is not known in advance. */
    readonly property color ink: "#FFFFFF"
    readonly property color inkSoft: "#D3E1EF"

    /* -------------------------------------------------------------- the sizes
     *
     * MEASURED OFF THE PICTURE, 13 OCTOBER 2026, AND A SHARE OF THE SCREEN.
     *
     * The picture's screen is 1146 of its pixels wide; scaled to 1920 the
     * time's figures are 42 pixels tall, the date's capitals 15, the
     * temperature's 30 and the place's 12. Inter's capitals are 0.727 of the
     * size they are set at, which gives the sizes below - at 1920, and in
     * the same proportion on any other screen, so the VAIO's clock is the
     * picture's shape too. It was 34 point for the time and 11 for the date,
     * which on a 1920 screen is three quarters of the picture's. */
    readonly property real k: Math.max(0.5, Screen.width / 1920)
    readonly property int timeSize: Math.round(58 * k)
    readonly property int suffixSize: Math.round(21 * k)
    readonly property int dateSize: Math.round(21 * k)
    readonly property int tempSize: Math.round(41 * k)
    readonly property int lineSize: Math.round(17 * k)
    readonly property int smallSize: Math.round(15 * k)

    /* The weather, from the same file and the same reader as the bar's last
     * pane, so the two can never say different things. Nothing is drawn
     * under the date until there is something true to draw. */
    Flow.Weather {
        id: weather
    }

    /* THERE WERE TWO LINES HERE AND THEY WERE BROKEN.
     *
     *     Layout.minimumWidth: block.implicitWidth
     *     Layout.minimumHeight: block.implicitHeight
     *
     * `block` is the ColumnLayout inside fullRepresentation below. Assigning
     * an Item to fullRepresentation wraps it in a Component, and ids declared
     * inside a component are not visible outside it - a nested scope can see
     * out, the enclosing scope cannot see in. So both were ReferenceErrors.
     *
     * QML does not stop on a ReferenceError in a binding. It evaluates to
     * undefined, the size is left unset, and nothing anywhere says so. The
     * widget would have come up sized by something other than its contents
     * and the file would have looked entirely reasonable.
     *
     * They were also unnecessary. The Item below already sets its own
     * implicit size from `block`, from inside the scope where `block` exists,
     * and Plasma sizes a widget from its representation. */

    fullRepresentation: Item {
        implicitWidth: block.implicitWidth
        implicitHeight: block.implicitHeight

        /* A soft darkening under the type, on all four sides.
         *
         * White text on a photograph is readable until the photograph has a
         * bright cloud exactly where the text is. Darkening the whole
         * wallpaper would be a lock screen; darkening a rectangle would be a
         * grey box. This is neither: a band held flat across the type and
         * feathered to nothing in every direction around it.
         *
         * IT WAS A Rectangle WITH A Gradient, AND THE FIRST PHOTOGRAPH OF A
         * REAL SOLVANE DESKTOP SHOWED WHAT THAT COST.
         *
         *     GradientStop { position: 0.00; color: Qt.rgba(0,0,0,0.00) }
         *     GradientStop { position: 0.16; color: Qt.rgba(0,0,0,0.48) }
         *     GradientStop { position: 0.80; color: Qt.rgba(0,0,0,0.46) }
         *     GradientStop { position: 1.00; color: Qt.rgba(0,0,0,0.00) }
         *
         * with a comment under it reading "Both edges fade, so there is no
         * edge to see." That was true of the top and the bottom and false of
         * the sides: a QML Gradient runs in ONE direction. On the screen it
         * was a grey rectangle in the corner with a hard vertical seam down
         * its right-hand side, and the seam is the first thing the eye finds
         * on an otherwise finished desktop.
         *
         * There is no way to fix that in QML with gradients. Stacking a
         * horizontal one on top makes the CORNERS darker rather than
         * lighter, because alpha compositing adds absorption instead of
         * multiplying transmission, and Qt 6 has no inline shaders to drop
         * to. So the falloff is a picture, and the picture is generated -
         * tools/make-clock-backdrop.py - rather than drawn by hand, so that
         * tests/check_tree.py can read the alpha back out of it and do the
         * contrast arithmetic against the wallpaper this tree ships.
         *
         * BorderImage AND NOT Image, WHICH IS THE WHOLE TRICK.
         *
         * A stretched Image would make the feather a fraction of the block,
         * so it would be twice as wide at the sides as at the top and would
         * change every time the date got longer. BorderImage draws the four
         * corners at their own size, stretches each edge along one axis, and
         * fills the middle - so the feather is 110 px in every direction at
         * every size, and the flat middle is whatever the type needs.
         *
         * The 110 is the source image's border in its own pixels and is a
         * property of that file; the margin below is 126 px, deliberately
         * larger, so there is flat alpha for 16 px beyond the type before
         * the falloff starts and no glyph ever sits on the slope. Both
         * numbers are checked against each other in tests/check_tree.py. */
        BorderImage {
            // FILLED TO THE TYPE, NOT TO THE RECTANGLE PLASMA RESERVED.
            //
            // `parent` here is the fullRepresentation Item, and Plasma
            // stretches that to the size the applet was given on the
            // desktop - 330x140 - not to the size of the two lines of text
            // inside it, which is nearer 210x60. Anchored to the parent,
            // the backdrop came up as a dark area more than twice the size
            // of the clock, with the type in its top-left corner and a
            // large empty expanse below and to the right of it.
            //
            // tools/preview-desktop.py had this right first and said so in
            // a comment: "Sized to the TYPE, not to the 360x150 in
            // appletsrc ... drawing to the reserved rectangle turned a soft
            // shading into a grey box." The picture was correct and the
            // widget was not.
            anchors.fill: block
            anchors.margins: -Kirigami.Units.gridUnit * 7
            z: -1
            source: Qt.resolvedUrl("../images/backdrop.png")
            border { left: 110; right: 110; top: 110; bottom: 110 }
            horizontalTileMode: BorderImage.Stretch
            verticalTileMode: BorderImage.Stretch
        }

        ColumnLayout {
            id: block
            spacing: Kirigami.Units.smallSpacing

            /* ---- the time ---- */
            RowLayout {
                spacing: Kirigami.Units.smallSpacing
                Layout.alignment: Qt.AlignLeft | Qt.AlignBottom

                Text {
                    id: timeText
                    text: {
                        var h = root.now.getHours();
                        var m = root.now.getMinutes();
                        if (!root.use24Hour) {
                            h = h % 12;
                            if (h === 0) h = 12;
                        }
                        var s = root.use24Hour && h < 10 ? "0" + h : "" + h;
                        s += ":" + (m < 10 ? "0" + m : m);
                        if (root.showSeconds) {
                            var sec = root.now.getSeconds();
                            s += ":" + (sec < 10 ? "0" + sec : sec);
                        }
                        return s;
                    }

                    color: root.ink
                    font.family: "Inter"
                    font.pixelSize: root.timeSize
                    font.weight: Font.Light
                    renderType: Text.NativeRendering

                    /* An outline, not a raised shadow.
                     *
                     * Text.Raised offsets a dark copy by one pixel. On a
                     * panel that is enough to lift the glyphs; on a
                     * photograph of a bright sky it is invisible, because
                     * the pixel it darkens is one pixel and the glyph has
                     * bright sky on all four sides of it.
                     *
                     * Text.Outline puts that dark edge all the way round,
                     * which is what makes white type work over an image
                     * whose brightness is not known in advance. It is how
                     * subtitles have been drawn for fifty years. */
                    style: Text.Outline
                    styleColor: Qt.rgba(0, 0, 0, 0.55)
                }

                /* AM/PM, small and sitting on the time's baseline rather than
                 * beside its middle. A twelve-hour clock whose suffix is the
                 * same size as the hour reads as four characters of time. */
                Text {
                    visible: !root.use24Hour
                    text: root.now.getHours() < 12 ? "AM" : "PM"
                    color: root.inkSoft
                    font.family: "Inter"
                    font.pixelSize: root.suffixSize
                    font.weight: Font.Medium
                    renderType: Text.NativeRendering
                    style: Text.Outline
                    styleColor: Qt.rgba(0, 0, 0, 0.55)
                    Layout.bottomMargin: Kirigami.Units.smallSpacing
                    Layout.alignment: Qt.AlignBottom
                }
            }

            /* ---- the date ----
             *
             * Qt.formatDateTime, not Qt.formatDate. Handed a JavaScript Date,
             * Qt.formatDate on this Qt takes the day in UTC: on the test
             * machine (US Central) the desktop said "Wednesday, October 21"
             * at 7:00 PM on Tuesday the 20th, the moment UTC passed
             * midnight. formatDateTime keeps the local day, as formatTime
             * keeps the local time. The checker refuses Qt.formatDate. */
            Text {
                visible: root.showDate
                text: Qt.formatDateTime(root.now, "dddd, MMMM d")
                color: root.ink
                opacity: 0.92
                font.family: "Inter"
                font.pixelSize: root.dateSize
                renderType: Text.NativeRendering
                style: Text.Outline
                styleColor: Qt.rgba(0, 0, 0, 0.6)
                Layout.alignment: Qt.AlignLeft
            }

            /* ---- the weather ----
             *
             * From the picture: a short rule under the date, then the sky's
             * drawing and the temperature, large; under them, set in line
             * with the temperature, the place, the sky in words, and the
             * day's high and low. */
            Rectangle {
                visible: weather.known
                Layout.topMargin: Math.round(14 * root.k)
                Layout.preferredWidth: Math.round(66 * root.k)
                Layout.preferredHeight: Math.max(1, Math.round(2 * root.k))
                radius: height / 2
                color: Qt.rgba(1, 1, 1, 0.55)
            }

            GridLayout {
                visible: weather.known
                columns: 2
                columnSpacing: Math.round(14 * root.k)
                rowSpacing: Math.round(4 * root.k)
                Layout.topMargin: Math.round(14 * root.k)

                Flow.Glyph {
                    kind: weather.kind
                    Layout.preferredWidth: Math.round(38 * root.k)
                    Layout.preferredHeight: Math.round(38 * root.k)
                    Layout.alignment: Qt.AlignVCenter
                }
                Text {
                    text: weather.temperature
                    color: root.ink
                    font.family: "Inter"
                    font.pixelSize: root.tempSize
                    font.weight: Font.Light
                    renderType: Text.NativeRendering
                    style: Text.Outline
                    styleColor: Qt.rgba(0, 0, 0, 0.55)
                }

                Item { Layout.preferredWidth: 1; Layout.preferredHeight: 1 }
                ColumnLayout {
                    spacing: Math.round(6 * root.k)
                    Text {
                        text: weather.place
                        color: root.ink
                        opacity: 0.92
                        font.family: "Inter"
                        font.pixelSize: root.lineSize
                        renderType: Text.NativeRendering
                        style: Text.Outline
                        styleColor: Qt.rgba(0, 0, 0, 0.6)
                    }
                    Text {
                        text: weather.condition
                        color: root.inkSoft
                        font.family: "Inter"
                        font.pixelSize: root.lineSize
                        renderType: Text.NativeRendering
                        style: Text.Outline
                        styleColor: Qt.rgba(0, 0, 0, 0.6)
                    }
                    Text {
                        visible: weather.high !== "" && weather.low !== ""
                        Layout.topMargin: Math.round(6 * root.k)
                        text: "\u2191 " + weather.high + "   \u2193 " + weather.low
                        color: root.inkSoft
                        font.family: "Inter"
                        font.pixelSize: root.smallSize
                        renderType: Text.NativeRendering
                        style: Text.Outline
                        styleColor: Qt.rgba(0, 0, 0, 0.6)
                    }
                }
            }
        }

        /* No click handler, deliberately.
         *
         * A clock that opens a calendar is the right design and there is no
         * calendar to open yet. Wiring a MouseArea to a toggle that reveals
         * nothing would be a control that looks like it works — which is the
         * same failure as the weather in the renders, at a smaller scale.
         *
         * When there is a Solvane calendar this is where it attaches, and the
         * cursor becomes a pointing hand on the same line. */
    }

    toolTipMainText: Qt.formatDateTime(now, "dddd, d MMMM yyyy")
    toolTipSubText: Qt.formatTime(now, use24Hour ? "HH:mm" : "h:mm AP")
}
