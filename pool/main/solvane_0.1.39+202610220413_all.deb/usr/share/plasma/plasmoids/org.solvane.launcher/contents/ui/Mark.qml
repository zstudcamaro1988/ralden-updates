/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - the first pane of the flow bar, as drawn
 *
 * A square of lighter glass with Solvane's S on it in white - the S of the
 * logo the owner chose on 13 October 2026, which replaced the picture's
 * silver ribbon S. The S is a picture (tools/make-logo.py); the glass is
 * the same pane every other part of the bar is drawn on.
 */
import QtQuick
import org.solvane.flowbar as Flow

Item {
    id: mark

    property bool open: false
    // Where the silver mark is on the image; a photograph of the drawing
    // taken anywhere else says where it put it.
    property url picture: "file:///usr/share/solvane/flowbar/mark.png"
    signal pressed()

    readonly property real h: Math.round(height * Flow.Look.share)
    implicitWidth: Math.round(h * Flow.Look.launcherWidth)

    Flow.Pill {
        width: parent.width
        height: mark.h
        fill: Flow.Look.launcherGlass
        lit: area.containsMouse
        pressed: area.pressed || mark.open

        Image {
            anchors.centerIn: parent
            height: Math.round(mark.h * 0.62)
            width: height
            source: mark.picture
            sourceSize.height: 256
            fillMode: Image.PreserveAspectFit
            smooth: true
            mipmap: true
        }

        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: mark.pressed()
        }
    }
}
