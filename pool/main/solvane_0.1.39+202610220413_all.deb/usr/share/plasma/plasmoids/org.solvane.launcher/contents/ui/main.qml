/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - the mark on the flow bar, which opens the menu
 *
 * WHY THIS IS NOT SIMPLY PLASMA'S MENU BUTTON.
 *
 * The menu is Plasma's (Kickoff) and stays Plasma's: the programs, the
 * favourites, the search inside it, the power buttons. But Kickoff draws
 * its own button - an icon, with nothing behind it - and in Plasma 6.3 the
 * most it will draw is an icon 64 pixels tall, centred in the dock. The
 * picture's first pane is a square of glass level with the other four.
 *
 * So the pane is drawn here, and Kickoff sits beside it with no icon at
 * all, which makes it no wider than nothing (its compactRepresentation
 * draws an icon only when it has one, and the width follows). Pressing the
 * pane asks Plasma to open "the launcher menu" - the same request the Meta
 * key makes - and the menu opens from the bar, beside the mark.
 *
 * THAT REQUEST NEEDS KICKOFF TO HAVE A SHORTCUT.
 *
 * Plasma opens the launcher menu by finding the first menu widget that has
 * a global shortcut and activating it. Plasma's own layout gives Kickoff
 * Alt+F1; Solvane's layout did not until 8 October 2026, which also means
 * the Meta key had nothing to open. The layout script now gives it Alt+F1.
 *
 * The request is made with a screen name in Plasma 6 and with none in some
 * earlier releases; it is tried the first way and then the second.
 */
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.plasma5support as Plasma5Support

PlasmoidItem {
    id: root

    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation
    toolTipMainText: i18n("Programs")
    toolTipSubText: i18n("Everything on this computer, and the way to turn it off")

    readonly property real drawn: pane.implicitWidth
    Layout.minimumWidth: drawn
    Layout.preferredWidth: drawn
    Layout.maximumWidth: drawn
    Layout.fillWidth: false

    Plasma5Support.DataSource {
        id: runner
        engine: "executable"
        connectedSources: []
        onNewData: function(source) { disconnectSource(source) }
    }

    readonly property string openMenu:
        "dbus-send --session --print-reply --dest=org.kde.plasmashell "
        + "/PlasmaShell org.kde.PlasmaShell.activateLauncherMenu string: "
        + ">/dev/null 2>&1 || dbus-send --session --print-reply "
        + "--dest=org.kde.plasmashell /PlasmaShell "
        + "org.kde.PlasmaShell.activateLauncherMenu >/dev/null 2>&1"

    // DRAWN AS THE WIDGET'S OWN CHILD, NOT AS A fullRepresentation.
    //
    // That is how Plasma's own task list does it. Drawn as a
    // fullRepresentation, with the widget's width read back through
    // fullRepresentationItem, the first build on the machine (8 October
    // 2026) came up with all four panes nought pixels wide: Plasma sized
    // each widget before that item existed and never asked again.
    Mark {
        id: pane
        anchors.fill: parent
        onPressed: {
            runner.disconnectSource(root.openMenu)
            runner.connectSource(root.openMenu)
        }
    }
}
