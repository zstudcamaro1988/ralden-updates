/* SPDX-License-Identifier: Solvane-Source */

import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as QQC2
import org.kde.kirigami as Kirigami

Kirigami.FormLayout {
    id: page

    // Read here, changed on the bar: a program is kept or let go by
    // pressing it with the right button there, where it can be seen.
    property var cfg_launchers: []

    QQC2.Label {
        Kirigami.FormData.label: i18n("Kept on the bar:")
        Layout.fillWidth: true
        textFormat: Text.PlainText
        text: (page.cfg_launchers || []).map(function(entry) {
            return String(entry).replace(/^applications:/, "").replace(/\.desktop$/, "")
        }).join("\n")
    }

    QQC2.Label {
        Layout.fillWidth: true
        Layout.maximumWidth: Kirigami.Units.gridUnit * 24
        wrapMode: Text.WordWrap
        font: Kirigami.Theme.smallFont
        opacity: 0.7
        text: i18n("To keep a program on the bar, or stop keeping it, press "
                 + "its icon on the bar with the right mouse button.")
    }
}
