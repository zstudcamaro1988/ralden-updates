/* SPDX-License-Identifier: Solvane-Source */

import org.kde.plasma.configuration

ConfigModel {
    ConfigCategory {
        name: i18n("Kept programs")
        icon: "window-pin"
        source: "configGeneral.qml"
    }
}
