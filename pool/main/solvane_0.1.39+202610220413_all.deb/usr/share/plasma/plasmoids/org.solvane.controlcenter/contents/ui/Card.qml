/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - one of the Control Center's cards
 *
 * The picture's panel is a pane of glass with lighter cards laid on it:
 * the three tiles, the Night Light card, the card of sliders, the media
 * card, the round buttons at the foot. Each is this: a rounded sheet a
 * shade lighter than the glass under it, a thin edge, and a hair of light
 * along its top, as the flow bar's panes have. Lighter still under the
 * pointer, when the card does something when pressed.
 *
 * In Alpine Mist the glass is navy and the cards are white at a few per
 * cent - the picture's white cards on pale glass, turned to night.
 */
import QtQuick

Item {
    id: card

    property real radius: 12
    property bool lit: false
    property bool pressed: false
    // On: the card is a control that is doing something (a tile that is
    // on). It takes a little of the accent, as the picture's blue marks do.
    property bool on: false
    default property alias content: inside.data

    Rectangle {
        anchors.fill: parent
        radius: card.radius
        color: card.pressed ? Qt.rgba(1, 1, 1, 0.13)
             : card.lit ? Qt.rgba(1, 1, 1, 0.105)
             : card.on ? Qt.rgba(74 / 255, 144 / 255, 226 / 255, 0.16)
             : Qt.rgba(1, 1, 1, 0.065)
        border.width: 1
        border.color: card.on ? Qt.rgba(74 / 255, 144 / 255, 226 / 255, 0.34)
                              : Qt.rgba(1, 1, 1, 0.08)
        Behavior on color {
            ColorAnimation { duration: 120 }
        }
    }

    // The light along the top, gone a third of the way down.
    Rectangle {
        anchors.fill: parent
        anchors.margins: 1
        radius: card.radius - 1
        gradient: Gradient {
            GradientStop { position: 0.0; color: Qt.rgba(1, 1, 1, 0.10) }
            GradientStop { position: 0.08; color: Qt.rgba(1, 1, 1, 0.03) }
            GradientStop { position: 0.35; color: Qt.rgba(1, 1, 1, 0.0) }
        }
    }

    Item {
        id: inside
        anchors.fill: parent
    }
}
