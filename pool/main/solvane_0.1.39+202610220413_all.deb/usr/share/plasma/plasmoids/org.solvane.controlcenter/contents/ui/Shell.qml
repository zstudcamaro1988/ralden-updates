/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — talking to the system, in one place
 *
 * WHY THIS SHELLS OUT, WHICH IS NOT THE OBVIOUS CHOICE.
 *
 * Every piece of state the Control Center shows — the volume, the brightness,
 * whether the radio is on, how much battery is left — has a proper interface
 * on Linux, and Plasma has a QML module wrapping each one. Using those would
 * be the tidy answer and it is the wrong one, because almost all of them are
 * *private*: org.kde.plasma.private.volume, .private.battery, .private.mpris.
 * Private means no API promise, and a widget built on them is a widget that
 * breaks on a Plasma point release, silently, on somebody else's machine.
 *
 * The commands below talk to WirePlumber, NetworkManager, BlueZ, KWin and
 * sysfs instead. Those are system interfaces with a decade of stability
 * behind them, documented, and identical on every distribution. The cost is
 * that reading them means starting a process.
 *
 * WHAT THAT COST ACTUALLY IS, AND WHERE IT IS PAID.
 *
 * About ten milliseconds each. Unnoticeable for a toggle — a person presses
 * Wi-Fi once. Very noticeable for a slider dragged across the screen, which
 * would be a hundred processes in a second on a laptop from 2009.
 *
 * So sliders do not run a command per frame. They move freely, and a timer
 * sends the value once the finger stops, which is the one moment the value
 * matters. And nothing polls while the panel is shut: a control panel that
 * wakes the processor every two seconds to read a battery nobody is looking
 * at is a control panel that costs its own battery.
 */

import QtQuick
import org.kde.plasma.plasma5support as Plasma5Support

QtObject {
    id: shell

    /* Emitted for every command that finishes. The caller matches on the
     * command string, which is why every call site below uses a distinct one
     * — two callers sharing a command would each get the other's answer. */
    signal finished(string command, int code, string out)

    property var source: Plasma5Support.DataSource {
        engine: "executable"
        connectedSources: []

        onNewData: function(name, data) {
            /* Disconnected first. The engine keeps a source connected until
             * it is told otherwise, and a source left connected re-runs on
             * every poll — which turns a one-off question into a background
             * process that never stops. */
            disconnectSource(name)
            shell.finished(name,
                           data["exit code"] !== undefined ? data["exit code"] : -1,
                           data["stdout"] ? ("" + data["stdout"]).trim() : "")
        }
    }

    function run(command) {
        if (!command) return
        /* Reconnecting an already-connected source does nothing, so a command
         * fired twice before the first finished would appear to be ignored.
         * Disconnecting first makes the second one replace the first, which
         * for "set the volume to this" is the behaviour that is wanted. */
        source.disconnectSource(command)
        source.connectSource(command)
    }
}
