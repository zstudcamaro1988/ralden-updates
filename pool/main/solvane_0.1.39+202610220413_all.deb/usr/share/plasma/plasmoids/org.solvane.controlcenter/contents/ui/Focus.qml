/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - Focus, which is Plasma's Do Not Disturb
 *
 * The picture's tile says "Focus / Deep Work", a named mode somebody typed
 * into a mockup. What a Plasma desktop has is Do Not Disturb: while it is
 * on, notifications are kept rather than shown. So the tile is that, and
 * says what it is doing: Off, On, until when, or which program is holding
 * notifications back (a video call or a presentation can).
 *
 * It is set through org.kde.notificationmanager's Settings - the same
 * object Plasma's own bell uses, writing the same file - so the bell and
 * the tile can never disagree. Switched on here it lasts until it is
 * switched off (Plasma's bell writes "a year from now" for that, and so
 * does this); switched off, it also lifts any program's hold.
 *
 * Loaded apart like the media and the session pieces, though this module
 * is not a private one, so that a failure costs the tile and nothing else.
 */
import QtQuick
import org.kde.notificationmanager as NotificationManager

Item {
    id: dnd

    property date now: new Date()
    readonly property date until: settings.notificationsInhibitedUntil
    readonly property bool timed: !isNaN(dnd.until.getTime()) && dnd.until > dnd.now
    readonly property bool held: settings.notificationsInhibitedByApplication
    readonly property var holders: settings.notificationInhibitionApplications
    readonly property bool on: dnd.timed || dnd.held

    function set(wanted) {
        if (wanted) {
            var d = new Date()
            d.setFullYear(d.getFullYear() + 1)
            settings.notificationsInhibitedUntil = d
        } else {
            settings.notificationsInhibitedUntil = undefined
            settings.revokeApplicationInhibitions()
        }
        settings.save()
        dnd.now = new Date()
    }

    NotificationManager.Settings {
        id: settings
        live: true
    }

    // So that "until 3:00 PM" turns into "Off" at three, not when the panel
    // is next opened.
    Timer {
        interval: 30000
        repeat: true
        running: true
        onTriggered: dnd.now = new Date()
    }
}
