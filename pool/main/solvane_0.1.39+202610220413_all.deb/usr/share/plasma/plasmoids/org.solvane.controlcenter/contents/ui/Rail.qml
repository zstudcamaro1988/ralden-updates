/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - a slider, drawn as the picture draws them
 *
 * A thin rail, the part up to the knob in the accent, and a round knob:
 * the rail 6 of the picture's pixels thick, the knob 26 across.
 *
 * THE DELAY IS THE DESIGN.
 *
 * Setting the volume or the screen means running a command, and running
 * a command per frame of a drag is a hundred processes a second on a
 * machine from 2009. So the knob moves freely and the value is sent when
 * the movement settles - a fifth of a second of quiet - and again when
 * the button is let go. While the knob is held, what the machine reports
 * does not move it: a slider that snaps back under a person's finger
 * feels broken even when it is working.
 *
 * `moving` is said as the knob moves, for the one control that can show a
 * change without making it: Night Light's preview.
 */
import QtQuick
import org.solvane.flowbar as Flow

Item {
    id: rail

    property real u: 0.55
    property int value: 0              // what the machine last said, 0-100
    property bool usable: true

    signal moving(int value)
    signal chosen(int value)

    readonly property real knob: Math.max(12, Math.round(26 * u))
    readonly property real thick: Math.max(3, Math.round(6 * u))
    property real shown: value         // where the knob is drawn
    property bool held: false

    implicitHeight: knob + Math.round(12 * u)
    opacity: usable ? 1.0 : 0.4

    onValueChanged: if (!held) shown = value

    readonly property real span: width - knob
    function at(x) {
        return Math.max(0, Math.min(100, Math.round((x - knob / 2) / Math.max(1, span) * 100)))
    }

    Rectangle {
        id: track
        x: rail.knob / 2
        width: rail.span
        height: rail.thick
        radius: height / 2
        anchors.verticalCenter: parent.verticalCenter
        color: Qt.rgba(1, 1, 1, 0.18)
    }
    Rectangle {
        x: track.x
        width: rail.span * rail.shown / 100
        height: rail.thick
        radius: height / 2
        anchors.verticalCenter: parent.verticalCenter
        color: rail.usable ? Flow.Look.accent : Qt.rgba(1, 1, 1, 0.3)
    }
    Rectangle {
        width: rail.knob
        height: width
        radius: width / 2
        x: rail.span * rail.shown / 100
        anchors.verticalCenter: parent.verticalCenter
        color: rail.usable ? Qt.rgba(92 / 255, 158 / 255, 236 / 255, 1) : Qt.rgba(1, 1, 1, 0.45)
        border.width: Math.max(1, Math.round(2 * rail.u))
        border.color: Qt.rgba(1, 1, 1, rail.held ? 0.85 : 0.55)
    }

    MouseArea {
        anchors.fill: parent
        enabled: rail.usable
        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        preventStealing: true
        onPressed: function(mouse) {
            rail.held = true
            rail.shown = rail.at(mouse.x)
            rail.moving(rail.shown)
            settle.restart()
        }
        onPositionChanged: function(mouse) {
            if (!pressed) return
            rail.shown = rail.at(mouse.x)
            rail.moving(rail.shown)
            settle.restart()
        }
        onReleased: {
            settle.stop()
            rail.held = false
            rail.chosen(rail.shown)
        }
        onCanceled: {
            settle.stop()
            rail.held = false
            rail.shown = rail.value
        }
    }
    WheelHandler {
        enabled: rail.usable
        onWheel: function(event) {
            var step = event.angleDelta.y > 0 ? 5 : -5
            rail.shown = Math.max(0, Math.min(100, rail.shown + step))
            rail.moving(rail.shown)
            wheelSettle.restart()
        }
    }

    // Fires when a drag pauses, so a slow drag changes the volume as it
    // goes rather than only at the end - what a person listening expects.
    Timer {
        id: settle
        interval: 200
        onTriggered: rail.chosen(rail.shown)
    }
    Timer {
        id: wheelSettle
        interval: 250
        onTriggered: rail.chosen(rail.shown)
    }
}
