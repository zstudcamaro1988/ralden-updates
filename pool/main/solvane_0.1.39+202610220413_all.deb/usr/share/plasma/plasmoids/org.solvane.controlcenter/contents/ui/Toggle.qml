/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - the switch beside "Adaptive Mode"
 *
 * The picture's: a pill 84 of its pixels by 48, the knob a white circle
 * that sits at the left when off. Off is a quiet grey track; on is the
 * accent, with the knob at the right. It moves when pressed and then
 * waits for the machine to agree - the panel sets `on` from what KWin
 * reports, so a switch that could not be thrown goes back by itself.
 */
import QtQuick
import org.solvane.flowbar as Flow

Item {
    id: toggle

    property real u: 0.55
    property bool on: false
    property bool usable: true
    signal flipped()

    width: Math.round(84 * u)
    height: Math.round(48 * u)
    opacity: usable ? 1.0 : 0.45

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: toggle.on ? Flow.Look.accent : Qt.rgba(1, 1, 1, 0.22)
        Behavior on color { ColorAnimation { duration: 140 } }
    }
    Rectangle {
        readonly property real gap: Math.max(2, Math.round(4 * toggle.u))
        width: toggle.height - gap * 2
        height: width
        radius: width / 2
        y: gap
        x: toggle.on ? toggle.width - width - gap : gap
        color: "#FFFFFF"
        Behavior on x { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
    }
    MouseArea {
        anchors.fill: parent
        anchors.margins: -Math.round(8 * toggle.u)
        enabled: toggle.usable
        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: toggle.flipped()
    }
}
