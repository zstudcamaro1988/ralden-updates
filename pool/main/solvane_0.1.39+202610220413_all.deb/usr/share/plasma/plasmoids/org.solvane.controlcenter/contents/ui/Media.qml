/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - what is playing, for the Control Center's media card
 *
 * LOADED APART, AND WHY.
 *
 * Only a private piece of Plasma says what is playing:
 * org.kde.plasma.private.mpris, the one Plasma's own media controller and
 * Solvane's lock screen use. Private means no promise across Plasma
 * releases, so it lives in this file and nothing else, and the panel loads
 * the file through a Loader. If an update renames the piece, this one file
 * fails to load, the media card is not drawn, and the rest of the panel is
 * exactly as it was. (The lock screen does the same, for the same reason.)
 *
 * The card is drawn only while something is playing or paused with a
 * track: a panel saying "Cascade - Kora" when nothing is playing would be
 * the worst version of the picture's card.
 */
import QtQuick
import org.kde.plasma.private.mpris as Mpris

Item {
    id: media

    readonly property bool present: players.count > 0 && (track !== "" || playing)
    property string track: ""
    property string artist: ""
    property string art: ""
    property bool playing: false
    property bool canControl: false
    property bool canPrevious: false
    property bool canNext: false
    property var player: null

    function previous() { if (player) player.Previous() }
    function toggle() { if (player) player.PlayPause() }
    function next() { if (player) player.Next() }

    Repeater {
        id: players
        model: Mpris.MultiplexerModel { }
        delegate: Item {
            Binding { target: media; property: "track"; value: model.track || "" }
            Binding { target: media; property: "artist"; value: model.artist || model.identity || "" }
            Binding { target: media; property: "art"; value: model.artUrl || "" }
            Binding { target: media; property: "playing"; value: model.playbackStatus === Mpris.PlaybackStatus.Playing }
            Binding { target: media; property: "canControl"; value: model.canControl === true }
            Binding { target: media; property: "canPrevious"; value: model.canGoPrevious === true }
            Binding { target: media; property: "canNext"; value: model.canGoNext === true }
            Binding { target: media; property: "player"; value: model.container }
        }
    }
}
