/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — search: the field in the dock, and the panel it opens
 *
 * Two things in one widget, as the Control Center is: the second pane of
 * the flow bar (Field.qml), always on the screen, and the panel it opens
 * (SearchPanel.qml), drawn from the owner's picture
 * (reference/2c-search.jpg). This file does the finding and the opening.
 *
 * SOLVANE DRAWS THE SEARCH; PLASMA DOES IT.
 *
 * KRunner already searches programs, settings, files, places, bookmarks,
 * sums and the web; it is translated into sixty languages and has had
 * twenty years of work put into ranking results well. Reimplementing that
 * badly to own it would be vanity. So the answers in the panel are
 * KRunner's, asked through Milou - the model Plasma's own search widget
 * and KRunner's window are drawn from (Results.qml) - and the panel is
 * Solvane's face on them: the picture's field, chips, cards and type.
 *
 * Until 14 October 2026 pressing the field opened KRunner's own window, a
 * bar across the top of the screen in Breeze's look, nothing like the
 * picture. Now it opens the picture.
 *
 * THE CHIPS ASK ONE RUNNER EACH, AND THERE IS NO "PEOPLE".
 *
 *   All       every runner
 *   Apps      krunner_services - programs, by name and by what they do
 *   Files     baloosearch, Plasma's file index - or, where the index is
 *             off, krunner_recentdocuments, the files opened lately, and
 *             the panel says so
 *   Settings  krunner_systemsettings - the pages of Settings
 *   Web       krunner_webshortcuts
 *
 * The picture has a sixth, People. Nothing on this machine knows anybody:
 * no address book is installed and no runner searches one (the runners were
 * listed off the test machine, 14 October 2026). A chip that can only ever
 * say "nothing found" is a promise the machine cannot keep, so it is not
 * drawn.
 *
 * THE KEYCAP TELLS THE TRUTH.
 *
 * The render showed "Ctrl K". Binding Ctrl+K globally would take it away
 * from every text editor on the machine, where it already means "delete to
 * the end of the line" or "insert a link". So the key is Meta+Space, which
 * is what Windows and macOS have trained everybody to reach for - and it is
 * now this widget's own: Plasma gives every widget a shortcut of its own
 * that opens it, and the layout script sets this one's to Meta+Space
 * (contents/layouts/org.kde.plasma.desktop-layout.js). KRunner keeps
 * Plasma's Alt+Space and Alt+F2, so anybody arriving from another Plasma
 * desktop finds its window where they left it.
 */

import QtQuick
import QtQuick.Window
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.plasma5support as Plasma5Support
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root

    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: compactRepresentation

    readonly property string placeholder: Plasmoid.configuration.placeholder
    readonly property string shortcutHint: Plasmoid.configuration.shortcutHint

    toolTipMainText: i18n("Search")
    toolTipSubText: root.shortcutHint.length > 0
                    ? i18n("Programs, settings and files — %1", root.shortcutHint)
                    : i18n("Programs, settings and files")

    /* ---------------------------------------------------------- the state */
    property string query: ""
    property string filter: "all"
    property int limit: 8
    property int currentIndex: 0
    // Whether Plasma's file index is on; asked each time the panel opens.
    property bool indexOn: false

    readonly property var filters: [
        { "key": "all", "name": i18n("All") },
        { "key": "apps", "name": i18n("Apps") },
        { "key": "files", "name": i18n("Files") },
        { "key": "settings", "name": i18n("Settings") },
        { "key": "web", "name": i18n("Web") }
    ]
    function runnerFor(key) {
        if (key === "apps") return "krunner_services"
        if (key === "files") return root.indexOn ? "baloosearch" : "krunner_recentdocuments"
        if (key === "settings") return "krunner_systemsettings"
        if (key === "web") return "krunner_webshortcuts"
        return ""
    }

    onQueryChanged: { root.currentIndex = 0; root.limit = 8 }
    onFilterChanged: { root.currentIndex = 0; root.limit = 8 }
    onExpandedChanged: {
        if (root.expanded) {
            root.opened = true
            shell.run(root.cmdIndex)
            if (recentPiece.status === Loader.Ready) recentPiece.item.refresh()
        } else {
            // Closed means finished with: the next search starts empty.
            root.query = ""
            root.filter = "all"
        }
    }

    /* ------------------------------------------------- the pieces loaded apart
     *
     * Each leans on a part of Plasma with no promise across releases, so
     * each is its own file behind a Loader: if one fails, the panel says so
     * and the dock is as it was. Neither is loaded until the panel is first
     * opened - KRunner's runners are a few megabytes nobody needs until
     * then - and both are kept from then on, so the second search is quick. */
    property bool opened: false
    Loader { id: resultsPiece; source: "Results.qml"; active: root.opened }
    Loader { id: recentPiece; source: "Recent.qml"; active: root.opened }

    readonly property bool canSearch: resultsPiece.status === Loader.Ready
    Binding {
        target: resultsPiece.item
        when: root.canSearch
        property: "query"
        value: root.query
    }
    Binding {
        target: resultsPiece.item
        when: root.canSearch
        property: "runner"
        value: root.runnerFor(root.filter)
    }
    Binding {
        target: resultsPiece.item
        when: root.canSearch
        property: "limit"
        value: root.limit
    }
    Binding {
        target: recentPiece.item
        when: recentPiece.status === Loader.Ready
        property: "appsTitle"
        value: i18n("Programs used lately")
    }
    Binding {
        target: recentPiece.item
        when: recentPiece.status === Loader.Ready
        property: "filesTitle"
        value: i18n("Files opened lately")
    }
    Connections {
        target: root.canSearch ? resultsPiece.item : null
        // A result can ask for the words to change - KRunner's helpers do,
        // to finish a command - and is answered as KRunner's window does.
        function onWantsQuery(text) { root.query = text }
    }

    /* ------------------------------------------------------- what is run
     *
     * Two commands only, neither with anything typed in it: whether the
     * file index is on, and the settings page for search. Opening a result
     * is KRunner's own run(), not a command line - what a person types is
     * never handed to a shell. */
    readonly property string cmdIndex: "balooctl6 status"
    Plasma5Support.DataSource {
        id: shell
        engine: "executable"
        connectedSources: []
        onNewData: function(source, data) {
            disconnectSource(source)
            if (source === root.cmdIndex) {
                var out = data["stdout"] ? String(data["stdout"]) : ""
                // "Baloo is currently disabled" when the index is off;
                // no balooctl6 at all is the same as off.
                root.indexOn = data["exit code"] === 0 && out.indexOf("disabled") < 0
                               && out.indexOf("Baloo") >= 0
            }
        }
        function run(cmd) {
            if (!cmd) return
            disconnectSource(cmd)
            connectSource(cmd)
        }
    }

    function collapseThen(command) {
        root.expanded = false
        if (command) shell.run(command)
    }

    /* ------------------------------------------------------------ the field
     *
     * A FIXED WIDTH, AND THIS USED TO SAY THE OPPOSITE.
     *
     * `Layout.fillWidth` does not tell a fitted panel how wide to be; it
     * tells the panel's layout "give me every spare pixel". In a panel with
     * lengthMode "fit" the two argue and the panel wins by growing to the
     * whole screen. Four boots came up with the dock running the full width
     * of the display, configured correctly the whole time, stretched by
     * this widget. So: a preferred width, pinned by a maximum, and no fill;
     * the minimum below it so that a very narrow screen can shrink it
     * rather than push the clock off the end.
     *
     * As the Control Center's pane is drawn, which was seen on the machine
     * at its right width (14 October 2026): the compact representation,
     * with its widths on itself. */
    compactRepresentation: Field {
        placeholder: root.placeholder
        shortcutHint: root.shortcutHint
        open: root.expanded

        Layout.fillWidth: false
        Layout.fillHeight: true
        Layout.minimumWidth: Math.round(implicitWidth * 0.66)
        Layout.preferredWidth: implicitWidth
        Layout.maximumWidth: implicitWidth

        onPressed: root.expanded = !root.expanded
    }

    /* ----------------------------------------------------------- the panel
     *
     * Sized so that the whole of it fits above the bar on the screen it is
     * on: the picture is 1219 of its pixels tall, and u is the share of the
     * screen's height that leaves, up to 0.58 - the Control Center's
     * largest, so the two panels' glass and type agree on a large screen. */
    fullRepresentation: Item {
        id: holder
        readonly property real u: Math.min(0.58, Math.max(0.42, Screen.height * 0.86 / 1219))
        Layout.minimumWidth: panel.implicitWidth
        Layout.preferredWidth: panel.implicitWidth
        Layout.maximumWidth: panel.implicitWidth
        Layout.minimumHeight: panel.implicitHeight
        Layout.preferredHeight: panel.implicitHeight
        Layout.maximumHeight: panel.implicitHeight

        // Typed into at once, as a search opened from the keyboard must be.
        Connections {
            target: root
            function onExpandedChanged() {
                if (root.expanded) panel.takeFocus()
            }
        }
        Component.onCompleted: if (root.expanded) panel.takeFocus()

        SearchPanel {
            id: panel
            width: implicitWidth
            height: implicitHeight
            u: holder.u
            body: Math.round(Kirigami.Units.gridUnit * 0.72)

            placeholder: i18n("Search programs, settings and files")
            query: root.query
            filters: root.filters
            filter: root.filter
            results: root.canSearch ? resultsPiece.item.model : null
            count: root.canSearch && root.query !== "" ? resultsPiece.item.count : 0
            busy: root.canSearch && resultsPiece.item.busy
            more: root.canSearch && root.query !== "" && resultsPiece.item.count >= root.limit
            recent: recentPiece.status === Loader.Ready ? recentPiece.item.model : null
            recentCount: recentPiece.status === Loader.Ready ? recentPiece.item.count : 0
            currentIndex: root.currentIndex

            moreText: i18n("Show more results")
            nothingText: !root.canSearch ? i18n("Search is not available")
                       : i18n("Nothing found")
            nothingDetail: {
                if (!root.canSearch)
                    return i18n("Plasma's search could not be loaded on this computer.")
                if (root.filter === "files" && !root.indexOn)
                    return i18n("File search is off on this computer, so only the files opened lately are looked through.")
                return ""
            }
            hintTitle: i18n("Type to search")
            hints: [
                i18n("Programs and the pages of Settings, by name or by what they do."),
                i18n("Files opened lately, and places such as Downloads."),
                i18n("Sums, such as 12*7.")
            ]

            onQueryEdited: function(text) { root.query = text }
            onFilterChosen: function(key) { root.filter = key }
            onIndexMoved: function(row) { root.currentIndex = row }
            onResultChosen: function(row) {
                if (resultsPiece.item.run(row))
                    root.expanded = false
            }
            onRecentChosen: function(row) {
                recentPiece.item.open(row)
                root.expanded = false
            }
            onMoreChosen: root.limit = 40
            onSettingsChosen: root.collapseThen("kcmshell6 kcm_plasmasearch")
            onCloseRequested: root.expanded = false
        }
    }
}
