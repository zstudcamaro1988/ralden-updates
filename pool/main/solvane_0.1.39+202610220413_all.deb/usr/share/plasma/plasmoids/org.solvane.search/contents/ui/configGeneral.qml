/* SPDX-License-Identifier: Solvane-Source */

import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as QQC2
import org.kde.kirigami as Kirigami

Kirigami.FormLayout {
    id: page

    property alias cfg_placeholder: placeholder.text
    property alias cfg_shortcutHint: shortcutHint.text

    QQC2.TextField {
        id: placeholder
        Kirigami.FormData.label: i18n("Placeholder:")
        Layout.fillWidth: true
    }

    QQC2.TextField {
        id: shortcutHint
        Kirigami.FormData.label: i18n("Keycap:")
        Layout.preferredWidth: Kirigami.Units.gridUnit * 10
    }

    QQC2.Label {
        Layout.fillWidth: true
        Layout.maximumWidth: Kirigami.Units.gridUnit * 24
        wrapMode: Text.WordWrap
        font: Kirigami.Theme.smallFont
        opacity: 0.7
        text: i18n("This is the label on the key, not the key itself. The "
                 + "key is this widget's own shortcut, set on the Keyboard "
                 + "Shortcuts page beside this one. If you change one, change "
                 + "the other — a keycap that names a key which does nothing "
                 + "is worse than no keycap.")
    }
}
