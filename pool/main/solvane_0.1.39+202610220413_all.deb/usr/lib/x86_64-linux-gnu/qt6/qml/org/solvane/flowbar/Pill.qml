/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - one pane of the flow bar's glass
 *
 * Rounded, nearly opaque, a hair of light along its top edge and a soft
 * shadow under it, as in the picture. What goes on it is the widget's
 * business; this only draws the pane, lighter while the pointer is over it
 * and darker while it is pressed, so a pane that does something looks like
 * one.
 *
 * NO BLUR, AND WHY.
 *
 * Real frosted glass needs the compositor to blur what is behind the pane,
 * and KWin will only do that for a whole window - here, the whole dock,
 * gaps and all, which would put a frosted band across the screen between
 * the panes where the picture shows clear wallpaper. The picture's panes
 * are so nearly opaque that the blur barely shows in them. So: none, and
 * the gaps stay clear.
 */
import QtQuick

Item {
    id: pane

    property bool lit: false
    property bool pressed: false
    // The mark's pane is a lighter glass than the rest, as in the picture.
    property color fill: Look.glass
    default property alias content: inside.data

    readonly property real r: height * Look.radius

    // THE SHADOW: six soft layers, each a little larger and further down.
    // Not an effect, so it costs a 2009 laptop six rectangles rather than
    // a pass of the GPU it does not really have.
    Repeater {
        model: 6
        Rectangle {
            required property int index
            readonly property real step: pane.height * 0.035
            x: -step * index * 0.6
            y: step * (index + 1)
            width: pane.width + step * index * 1.2
            height: pane.height
            radius: pane.r + step * index
            color: Look.shadow
            opacity: Look.shadowStrength / 6
        }
    }

    Rectangle {
        id: glass
        anchors.fill: parent
        radius: pane.r
        color: pane.pressed ? Qt.darker(pane.fill, 1.12)
             : pane.lit ? Qt.lighter(pane.fill, 1.12) : pane.fill
        border.width: 1
        border.color: Look.edge
        Behavior on color {
            ColorAnimation { duration: 120 }
        }
    }

    // The light along the top: brightest at the edge, gone a third of the
    // way down, as on every pane in the picture.
    Rectangle {
        anchors.fill: parent
        anchors.margins: 1
        radius: pane.r - 1
        gradient: Gradient {
            GradientStop { position: 0.0; color: Look.rim }
            GradientStop { position: 0.06; color: Qt.rgba(1, 1, 1, 0.10) }
            GradientStop { position: 0.35; color: Qt.rgba(1, 1, 1, 0.0) }
        }
    }

    Item {
        id: inside
        anchors.fill: parent
    }
}
