/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - the weather, as the desktop reads it
 *
 * /usr/lib/solvane/weather writes what it found to one file every half
 * hour (/run/solvane-weather/weather.json). This reads that file once a
 * minute and says what is in it, for the bar's last pane and for the clock
 * on the wallpaper, so that the two never disagree.
 *
 * WHAT IS SAID IS ONLY WHAT IS TRUE NOW. No file, a file that is not the
 * weather, or a file more than three hours old: `known` is false, and the
 * places that draw the weather draw nothing at all - not "--", not the last
 * temperature anybody saw.
 *
 * THE TEMPERATURE IN THE PERSON'S OWN UNITS. The file is in Celsius; a
 * language whose measurements are American (Qt's ImperialUSSystem, which is
 * what en_US is) is shown Fahrenheit, everybody else Celsius - the British
 * included, who weigh themselves in stones and the weather in degrees C.
 */
import QtQuick
import org.kde.plasma.plasma5support as Plasma5Support

Item {
    id: weather

    visible: false

    property var reading: null
    readonly property bool known: reading !== null

    readonly property string place: known ? reading.place : ""
    readonly property string condition: known ? reading.condition : ""
    readonly property string kind: known ? reading.kind : ""
    readonly property bool fahrenheit:
        Qt.locale().measurementSystem === Locale.ImperialUSSystem
    readonly property string temperature: known ? degrees(reading.celsius) : ""
    readonly property string high: known ? degrees(reading.high) : ""
    readonly property string low: known ? degrees(reading.low) : ""

    readonly property string file: "/run/solvane-weather/weather.json"
    readonly property int staleAfter: 3 * 3600

    function degrees(celsius) {
        if (typeof celsius !== "number" || !isFinite(celsius))
            return ""
        var shown = fahrenheit ? celsius * 9 / 5 + 32 : celsius
        return Math.round(shown) + "°"
    }

    // A stranger's file is checked as the program checks a stranger's
    // answer: the right shape, a place that is short text, and recent.
    function believable(r) {
        if (!r || typeof r !== "object")
            return false
        if (typeof r.place !== "string" || r.place.length === 0
                || r.place.length > 60)
            return false
        if (typeof r.celsius !== "number" || typeof r.fetched !== "number")
            return false
        if (typeof r.kind !== "string" || typeof r.condition !== "string")
            return false
        return Date.now() / 1000 - r.fetched < staleAfter
    }

    Plasma5Support.DataSource {
        id: reader
        engine: "executable"
        connectedSources: []
        onNewData: function(source, data) {
            disconnectSource(source)
            var parsed = null
            try {
                parsed = JSON.parse(data["stdout"] || "")
            } catch (e) {
                parsed = null
            }
            weather.reading = weather.believable(parsed) ? parsed : null
        }
    }

    function look() {
        var command = "cat " + file
        reader.disconnectSource(command)
        reader.connectSource(command)
    }

    Timer {
        interval: 60000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: weather.look()
    }
}
