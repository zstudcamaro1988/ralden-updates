/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - no line over a pane whose panel is open
 *
 * While a widget's popup on the dock is open, Plasma draws a line along the
 * top of the widget: the theme's widgets/tabbar, "south-active-tab" on a bar
 * at the bottom (Plasma's CompactApplet.qml, read off the test machine on
 * 14 October 2026). It is as wide as the whole widget, and each of the flow
 * bar's widgets holds the gap to its left as well as its pane - so the line
 * started 25 pixels left of the search pane, 24 left of the Control
 * Center's, and read as a mistake. The picture has no line: an open pane is
 * drawn pressed, by the pane itself.
 *
 * WHY NOT IN THE THEME. Making "south-active-tab" empty in Solvane's Plasma
 * theme would also take the mark off the chosen tab at the foot of Plasma's
 * own menu (Kickoff's footer) and off every Plasma tab bar, which use the
 * same piece. So it is hidden only over the panes that draw their own.
 *
 * HOW. CompactApplet names that line `expandedFeedback`, a property of its
 * own, and moves the widget's compact representation inside itself. This,
 * placed in a pane, walks up from the pane to the first item that has the
 * property and hides what it names. If a Plasma release renames it, nothing
 * is found and Plasma's line is simply back - nothing breaks.
 */
import QtQuick

Item {
    id: quiet
    visible: false
    width: 0
    height: 0

    // The pane this sits in. Plasma moves the pane, not this.
    readonly property Item pane: parent

    // Whether a line was found and hidden: for the self-test and the preview.
    property bool hidden: false

    function find() {
        var item = quiet.pane
        while (item) {
            if (item.expandedFeedback !== undefined) {
                if (item.expandedFeedback) {
                    item.expandedFeedback.visible = false
                    quiet.hidden = true
                }
                return
            }
            item = item.parent
        }
    }

    Connections {
        target: quiet.pane
        function onParentChanged() { quiet.find() }
    }
    Component.onCompleted: find()
}
