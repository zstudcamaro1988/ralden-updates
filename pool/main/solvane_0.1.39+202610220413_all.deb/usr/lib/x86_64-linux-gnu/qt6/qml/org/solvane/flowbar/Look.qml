/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - the flow bar, measured
 *
 * The bar along the foot of the desktop in the owner's picture
 * (reference/2-desktop.png) is five pieces of glass, not one bar: the mark,
 * the search field, the programs, the workspaces and the state of the
 * machine, each its own rounded pane with the wallpaper showing between
 * them. All five are drawn by Solvane's own widgets, so the same numbers
 * have to reach all of them. They are here, once.
 *
 * EVERY LENGTH IS A SHARE OF THE PANE'S HEIGHT.
 *
 * Read off the picture, in its own pixels, with the panes 40 of them tall:
 * so a gap of 25 is written 0.625. Measured that way, the bar is the same
 * shape on the VAIO's 1366 as on a 1920 screen, and nothing needs a second
 * set of numbers for a second screen. The layout script sets how thick the
 * dock is for the screen it finds; everything else follows from that.
 *
 * The mark on the first pane is a picture (tools/make-logo.py draws the
 * white S of Solvane's logo for it); the pane under it is drawn here like
 * the others.
 */
pragma Singleton
import QtQuick

QtObject {
    // The pane is this much of the dock's thickness. The rest is below it:
    // the picture's panes cast a shadow about a quarter of their height
    // deep, and a shadow needs somewhere to fall that is still the dock.
    readonly property real share: 0.8

    readonly property real radius: 0.21       // 8.5 of 40
    readonly property real gap: 0.625         // 25 of 40, all four the same

    // The mark's pane, the search field, one program, one workspace.
    readonly property real launcherWidth: 1.1 // 44 of 40
    readonly property real searchWidth: 6.7   // 268 of 40
    readonly property real slot: 1.05         // 42 of 40, icon to icon
    readonly property real icon: 0.72         // 29 of 40
    readonly property real space: 0.78        // 31 of 40, number to number
    readonly property real inset: 0.22        // 9 of 40, edge to first icon
    readonly property real stateInset: 0.4    // 16 of 40
    readonly property real stateGap: 0.55     // 22 of 40, between readings

    // Type, as a share of the pane's height, in pixels.
    readonly property real textSize: 0.21     // "Ask Solvane or type a command..."
    readonly property real timeSize: 0.27     // "10:42 AM"
    readonly property real numberSize: 0.24   // the workspaces

    // THE GLASS.
    //
    // Measured where the panes have nothing on them: (120,137,157) over a
    // sky of (193,206,223), and (118,135,156) over (168,190,215). A pane
    // that barely changes with what is behind it is nearly opaque, and
    // solving the two for a colour and a strength gives this.
    // ALPINE MIST'S GLASS (13 October 2026). The picture's panes are a pale
    // slate, (112,130,152) - glass over its pale sky. Alpine Mist is the
    // login screen's dusk, and the owner chose dark glass for it: the navy
    // of the login screen's round buttons, a little more solid so that the
    // white on it reads over the bright band of mist as well as over sky.
    readonly property color glass: Qt.rgba(36 / 255, 60 / 255, 104 / 255, 0.66)
    // The mark's pane is a lighter glass than the rest in the picture.
    readonly property color launcherGlass: Qt.rgba(66 / 255, 94 / 255, 142 / 255, 0.70)
    readonly property color edge: Qt.rgba(1, 1, 1, 0.16)
    readonly property color rim: Qt.rgba(1, 1, 1, 0.30)
    readonly property color shadow: Qt.rgba(20 / 255, 36 / 255, 60 / 255, 1)
    readonly property real shadowStrength: 0.20

    readonly property color ink: "#FFFFFF"
    readonly property color inkSoft: Qt.rgba(1, 1, 1, 0.82)
    readonly property color inkFaint: Qt.rgba(1, 1, 1, 0.45)

    // The accent the rest of Solvane uses (kdeglobals AccentColor), which
    // is also the blue of the current workspace in the picture.
    readonly property color accent: Qt.rgba(74 / 255, 144 / 255, 226 / 255, 1)
    readonly property color accentTint: Qt.rgba(74 / 255, 144 / 255, 226 / 255, 0.22)
    readonly property color lit: Qt.rgba(1, 1, 1, 0.20)

    readonly property string family: "Inter"
}
