/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS - the flow bar's small drawings
 *
 * The picture's bar is drawn in one hand: thin white strokes, rounded ends.
 * Plasma's icon theme has a version of each of these, in its own hand and
 * at its own sizes, and the bar would have been a row of Breeze icons on
 * Solvane's glass. So they are drawn here, from what each one says - and
 * what each one says comes from the machine, not from the picture: three
 * arcs of Wi-Fi only when the signal is strong, a battery only as full as
 * the battery is.
 *
 * kind:  "search"    the magnifier
 *        "overview"  the three-pane mark that opens the overview
 *        "next"      a chevron
 *        "wifi"      level 0-4 (0 is connected with almost no signal)
 *        "wired"     a cable is plugged in
 *        "offline"   no network at all
 *        "volume"    level 0-3; muted draws the speaker crossed out
 *        "battery"   level 0-100; charging adds the bolt
 *        the weather: "clear", "clear-night", "partly", "partly-night",
 *                    "cloud", "fog", "drizzle", "rain", "snow", "storm" -
 *                    the kinds /usr/lib/solvane/weather writes
 *        the Control Center's, in the same hand (14 October 2026):
 *                    "bluetooth", "focus", "adaptive", "sun-low",
 *                    "sun-high", "gear", "previous", "pause", "play",
 *                    "next-track", "note", "screenshot", "sleep", "lock",
 *                    "power"
 *        the search panel's: "tune" - which kinds of thing are searched
 *        Settings' (14 October 2026): "system", "monitor", "bell", "globe",
 *                    "brush", "apps", "person", "shield", "update", "clock",
 *                    "info", "multitask", "keyboard", "mouse", "back",
 *                    "down", "check", "rotate", "copy"
 *        Files' (20 October 2026): "home", "star", "folder", "folder-new",
 *                    "desktop", "document", "download", "picture", "music",
 *                    "video", "trash", "drive", "eject", "grid", "list",
 *                    "more", "sort", "up"
 */
import QtQuick

Canvas {
    id: glyph

    property string kind: ""
    property int level: 0
    property bool muted: false
    property bool charging: false
    property color ink: Look.ink

    onKindChanged: requestPaint()
    onLevelChanged: requestPaint()
    onMutedChanged: requestPaint()
    onChargingChanged: requestPaint()
    onInkChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()

    onPaint: {
        var c = getContext("2d")
        c.reset()
        var s = Math.min(width, height)
        if (s <= 0)
            return
        c.save()
        c.translate((width - s) / 2, (height - s) / 2)
        c.scale(s / 24, s / 24)                 // drawn on a 24-unit square
        c.strokeStyle = glyph.ink
        c.fillStyle = glyph.ink
        c.lineWidth = 1.7
        c.lineCap = "round"
        c.lineJoin = "round"

        function faint() { c.globalAlpha = 0.35 }
        function full() { c.globalAlpha = 1.0 }
        function box(x, y, w, h, r) {
            c.beginPath()
            c.moveTo(x + r, y)
            c.lineTo(x + w - r, y)
            c.arcTo(x + w, y, x + w, y + r, r)
            c.lineTo(x + w, y + h - r)
            c.arcTo(x + w, y + h, x + w - r, y + h, r)
            c.lineTo(x + r, y + h)
            c.arcTo(x, y + h, x, y + h - r, r)
            c.lineTo(x, y + r)
            c.arcTo(x, y, x + r, y, r)
            c.closePath()
        }

        // THE WEATHER, IN THE PICTURE'S OTHER HAND: filled, not drawn in
        // line - the cloud on the bar and under the clock is a solid white
        // shape with the sun behind it.
        function sun(x, y, r) {
            c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill()
            c.lineWidth = r * 0.42
            for (var a = 0; a < 8; a++) {
                var t = a * Math.PI / 4
                c.beginPath()
                c.moveTo(x + Math.cos(t) * r * 1.45, y + Math.sin(t) * r * 1.45)
                c.lineTo(x + Math.cos(t) * r * 1.95, y + Math.sin(t) * r * 1.95)
                c.stroke()
            }
        }
        function moon(x, y, r) {
            c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill()
            c.globalCompositeOperation = "destination-out"
            c.beginPath(); c.arc(x + r * 0.55, y - r * 0.35, r * 0.85, 0, Math.PI * 2)
            c.fill()
            c.globalCompositeOperation = "source-over"
        }
        function cloud(dy) {
            c.beginPath(); c.arc(8.2, 14.2 + dy, 4.2, 0, Math.PI * 2); c.fill()
            c.beginPath(); c.arc(12.8, 11.2 + dy, 5.4, 0, Math.PI * 2); c.fill()
            c.beginPath(); c.arc(17.4, 14.6 + dy, 3.8, 0, Math.PI * 2); c.fill()
            box(8.2, 13.4 + dy, 9.2, 5.0, 1.2); c.fill()
        }
        var sky = ["clear", "clear-night", "partly", "partly-night", "cloud",
                   "fog", "drizzle", "rain", "snow", "storm"]
        if (sky.indexOf(kind) >= 0) {
            c.lineCap = "round"
            if (kind === "clear") {
                sun(12, 12, 4.6)
            } else if (kind === "clear-night") {
                moon(11.5, 12.5, 6.5)
            } else if (kind === "partly" || kind === "partly-night") {
                faint()
                if (kind === "partly") sun(16, 8, 3.2)
                else moon(16, 8, 3.8)
                full()
                cloud(2)
            } else {
                var dy = kind === "cloud" ? 0.5 : -2.2
                cloud(dy)
                c.lineWidth = 1.6
                if (kind === "fog") {
                    c.beginPath(); c.moveTo(5, 19.5); c.lineTo(19, 19.5); c.stroke()
                    c.beginPath(); c.moveTo(7, 22.3); c.lineTo(17, 22.3); c.stroke()
                } else if (kind === "drizzle" || kind === "rain") {
                    var drops = kind === "rain" ? [8, 12, 16] : [10, 14]
                    for (var d = 0; d < drops.length; d++) {
                        c.beginPath()
                        c.moveTo(drops[d], 18.6); c.lineTo(drops[d] - 1.4, 22.2)
                        c.stroke()
                    }
                } else if (kind === "snow") {
                    var flakes = [[8, 19.6], [12, 21.6], [16, 19.6]]
                    for (var s = 0; s < flakes.length; s++) {
                        c.beginPath()
                        c.arc(flakes[s][0], flakes[s][1], 1.2, 0, Math.PI * 2)
                        c.fill()
                    }
                } else if (kind === "storm") {
                    c.beginPath()
                    c.moveTo(13, 17.4); c.lineTo(10.4, 21); c.lineTo(12.8, 21)
                    c.lineTo(11.2, 23.6); c.lineTo(15.2, 19.4); c.lineTo(12.8, 19.4)
                    c.lineTo(14.2, 17.4); c.closePath(); c.fill()
                }
            }
        } else if (kind === "search") {
            c.lineWidth = 2
            c.beginPath(); c.arc(10.5, 10.5, 6.5, 0, Math.PI * 2); c.stroke()
            c.beginPath(); c.moveTo(15.4, 15.4); c.lineTo(20.5, 20.5); c.stroke()
        } else if (kind === "tune") {
            // Three lines, each shorter than the last: what is searched,
            // narrowed. The search panel's button for which kinds of thing
            // search looks through.
            c.lineWidth = 2
            c.beginPath(); c.moveTo(4, 7); c.lineTo(20, 7); c.stroke()
            c.beginPath(); c.moveTo(7, 12); c.lineTo(17, 12); c.stroke()
            c.beginPath(); c.moveTo(10, 17); c.lineTo(14, 17); c.stroke()
        } else if (kind === "overview") {
            box(3.5, 4.5, 17, 15, 2.5); c.stroke()
            c.beginPath(); c.moveTo(10.5, 4.5); c.lineTo(10.5, 19.5); c.stroke()
            c.beginPath(); c.moveTo(10.5, 12); c.lineTo(20.5, 12); c.stroke()
        } else if (kind === "next") {
            c.lineWidth = 2
            c.beginPath(); c.moveTo(9.5, 6); c.lineTo(15.5, 12); c.lineTo(9.5, 18)
            c.stroke()
        } else if (kind === "wifi") {
            // The dot and three arcs; the ones the signal does not reach
            // are drawn faint, as every phone does it.
            for (var i = 1; i <= 3; i++) {
                if (level >= i + 1) full(); else faint()
                c.beginPath()
                c.arc(12, 19, 4.6 * i, Math.PI * 1.25, Math.PI * 1.75, false)
                c.stroke()
            }
            full()
            c.beginPath(); c.arc(12, 19, 1.6, 0, Math.PI * 2); c.fill()
        } else if (kind === "offline") {
            faint()
            for (var j = 1; j <= 3; j++) {
                c.beginPath()
                c.arc(12, 19, 4.6 * j, Math.PI * 1.25, Math.PI * 1.75, false)
                c.stroke()
            }
            full()
            c.beginPath(); c.moveTo(5, 4); c.lineTo(19, 20); c.stroke()
        } else if (kind === "wired") {
            box(8, 3.5, 8, 7, 1.5); c.stroke()
            c.beginPath(); c.moveTo(12, 10.5); c.lineTo(12, 14); c.stroke()
            c.beginPath(); c.moveTo(5, 14); c.lineTo(19, 14); c.stroke()
            c.beginPath(); c.moveTo(5, 14); c.lineTo(5, 17.5); c.stroke()
            c.beginPath(); c.moveTo(19, 14); c.lineTo(19, 17.5); c.stroke()
            box(2.5, 17.5, 5, 3.5, 1); c.stroke()
            box(16.5, 17.5, 5, 3.5, 1); c.stroke()
        } else if (kind === "volume") {
            c.beginPath()
            c.moveTo(3.5, 9.5); c.lineTo(7, 9.5); c.lineTo(11.5, 5.5)
            c.lineTo(11.5, 18.5); c.lineTo(7, 14.5); c.lineTo(3.5, 14.5)
            c.closePath(); c.stroke()
            if (muted) {
                c.beginPath(); c.moveTo(15, 9); c.lineTo(21, 15); c.stroke()
                c.beginPath(); c.moveTo(21, 9); c.lineTo(15, 15); c.stroke()
            } else {
                for (var k = 1; k <= 2; k++) {
                    if (level >= k) full(); else faint()
                    c.beginPath()
                    c.arc(11.5, 12, 3.6 * k, -Math.PI * 0.3, Math.PI * 0.3, false)
                    c.stroke()
                }
                full()
            }
        } else if (kind === "bluetooth") {
            c.beginPath()
            c.moveTo(7, 7.5); c.lineTo(17, 16.5); c.lineTo(12, 21)
            c.lineTo(12, 3); c.lineTo(17, 7.5); c.lineTo(7, 16.5)
            c.stroke()
        } else if (kind === "focus") {
            // A ring with a moon in it: the moon is everybody's sign for
            // Do Not Disturb, and the ring is the picture's.
            c.beginPath(); c.arc(12, 12, 8.5, 0, Math.PI * 2); c.stroke()
            moon(11.6, 12.4, 4.4)
        } else if (kind === "adaptive") {
            // The sun on the horizon: Night Light that follows the sun.
            c.beginPath(); c.moveTo(3, 17); c.lineTo(21, 17); c.stroke()
            c.beginPath(); c.arc(12, 17, 4.6, Math.PI, Math.PI * 2, false); c.stroke()
            for (var ray = 0; ray < 5; ray++) {
                var ta = Math.PI * (1.08 + ray * 0.21)
                c.beginPath()
                c.moveTo(12 + Math.cos(ta) * 6.8, 17 + Math.sin(ta) * 6.8)
                c.lineTo(12 + Math.cos(ta) * 8.8, 17 + Math.sin(ta) * 8.8)
                c.stroke()
            }
            c.beginPath(); c.moveTo(9, 20.5); c.lineTo(15, 20.5); c.stroke()
        } else if (kind === "sun-low" || kind === "sun-high") {
            // Drawn in line, unlike the weather's sun: these are controls,
            // and every control here is drawn in line.
            var high = kind === "sun-high"
            var core = high ? 4.2 : 3.4
            c.beginPath(); c.arc(12, 12, core, 0, Math.PI * 2); c.stroke()
            for (var sr = 0; sr < 8; sr++) {
                var ts = sr * Math.PI / 4
                c.beginPath()
                c.moveTo(12 + Math.cos(ts) * (core + 2.4), 12 + Math.sin(ts) * (core + 2.4))
                c.lineTo(12 + Math.cos(ts) * (core + (high ? 5.4 : 3.9)),
                         12 + Math.sin(ts) * (core + (high ? 5.4 : 3.9)))
                c.stroke()
            }
        } else if (kind === "gear") {
            for (var tooth = 0; tooth < 8; tooth++) {
                var tg = tooth * Math.PI / 4
                c.lineWidth = 2.6
                c.beginPath()
                c.moveTo(12 + Math.cos(tg) * 6.6, 12 + Math.sin(tg) * 6.6)
                c.lineTo(12 + Math.cos(tg) * 9.2, 12 + Math.sin(tg) * 9.2)
                c.stroke()
            }
            c.lineWidth = 1.8
            c.beginPath(); c.arc(12, 12, 6.4, 0, Math.PI * 2); c.stroke()
            c.beginPath(); c.arc(12, 12, 2.6, 0, Math.PI * 2); c.stroke()
        } else if (kind === "previous" || kind === "next-track") {
            // Filled, as the picture's are: these are the panel's boldest
            // marks, the ones a person reaches for without reading.
            c.save()
            if (kind === "next-track") { c.translate(24, 0); c.scale(-1, 1) }
            box(5, 5.5, 2.6, 13, 1); c.fill()
            c.beginPath(); c.moveTo(19, 5.8); c.lineTo(19, 18.2); c.lineTo(8.6, 12)
            c.closePath(); c.fill()
            c.restore()
        } else if (kind === "pause") {
            box(6.5, 4.5, 3.6, 15, 1.2); c.fill()
            box(13.9, 4.5, 3.6, 15, 1.2); c.fill()
        } else if (kind === "play") {
            c.beginPath(); c.moveTo(7.5, 4.8); c.lineTo(19, 12); c.lineTo(7.5, 19.2)
            c.closePath(); c.fill()
        } else if (kind === "note") {
            c.beginPath(); c.arc(8.5, 17.5, 2.8, 0, Math.PI * 2); c.fill()
            c.beginPath(); c.arc(17, 15.5, 2.8, 0, Math.PI * 2); c.fill()
            c.beginPath(); c.moveTo(11, 17.5); c.lineTo(11, 5.5); c.lineTo(19.5, 3.8)
            c.lineTo(19.5, 15.5); c.stroke()
        } else if (kind === "screenshot") {
            // The four corners of a frame being taken, and the lens.
            var cn = [[3.5, 5.5, 1, 1], [20.5, 5.5, -1, 1], [3.5, 18.5, 1, -1], [20.5, 18.5, -1, -1]]
            for (var q = 0; q < 4; q++) {
                c.beginPath()
                c.moveTo(cn[q][0], cn[q][1] + cn[q][3] * 4)
                c.lineTo(cn[q][0], cn[q][1])
                c.lineTo(cn[q][0] + cn[q][2] * 4, cn[q][1])
                c.stroke()
            }
            c.beginPath(); c.arc(12, 12, 3.4, 0, Math.PI * 2); c.stroke()
        } else if (kind === "sleep") {
            moon(11.5, 12.5, 7)
        } else if (kind === "lock") {
            box(5.5, 10.5, 13, 10, 2.2); c.stroke()
            c.beginPath()
            c.moveTo(8.5, 10.5); c.lineTo(8.5, 7.8)
            c.arc(12, 7.8, 3.5, Math.PI, Math.PI * 2, false)
            c.lineTo(15.5, 10.5); c.stroke()
        } else if (kind === "power") {
            c.lineWidth = 1.9
            c.beginPath(); c.arc(12, 13, 7.5, -Math.PI * 0.30, Math.PI * 1.30, false); c.stroke()
            c.beginPath(); c.moveTo(12, 3.5); c.lineTo(12, 11.5); c.stroke()
        } else if (kind === "system") {
            // A laptop: the screen and the deck below it.
            box(4.5, 5, 15, 10.5, 1.8); c.stroke()
            c.beginPath(); c.moveTo(2.5, 18.5); c.lineTo(21.5, 18.5); c.stroke()
        } else if (kind === "monitor") {
            box(3, 4.5, 18, 12, 2); c.stroke()
            c.beginPath(); c.moveTo(12, 16.5); c.lineTo(12, 19.5); c.stroke()
            c.beginPath(); c.moveTo(8, 19.5); c.lineTo(16, 19.5); c.stroke()
        } else if (kind === "bell") {
            c.beginPath()
            c.moveTo(6, 16.5)
            c.lineTo(6, 11)
            c.arc(12, 11, 6, Math.PI, Math.PI * 2, false)
            c.lineTo(18, 16.5)
            c.closePath()
            c.stroke()
            c.beginPath(); c.moveTo(4.5, 16.5); c.lineTo(19.5, 16.5); c.stroke()
            c.beginPath(); c.arc(12, 18.5, 2, 0, Math.PI, false); c.stroke()
            c.beginPath(); c.moveTo(12, 3.5); c.lineTo(12, 5); c.stroke()
        } else if (kind === "globe") {
            c.beginPath(); c.arc(12, 12, 8.5, 0, Math.PI * 2); c.stroke()
            c.beginPath(); c.ellipse(8, 3.5, 8, 17); c.stroke()
            c.beginPath(); c.moveTo(3.5, 12); c.lineTo(20.5, 12); c.stroke()
        } else if (kind === "brush") {
            // A brush stroke: the handle, and the bristles' tip.
            c.beginPath(); c.moveTo(19.5, 4.5); c.lineTo(11, 13); c.stroke()
            c.beginPath()
            c.moveTo(11, 13); c.quadraticCurveTo(13.5, 15.5, 10.5, 18)
            c.quadraticCurveTo(7.5, 20.5, 4.5, 19.5)
            c.quadraticCurveTo(6.5, 18, 6.5, 15.5)
            c.quadraticCurveTo(7, 12.5, 11, 13)
            c.stroke()
        } else if (kind === "apps") {
            box(4, 4, 6.5, 6.5, 1.6); c.stroke()
            box(13.5, 4, 6.5, 6.5, 1.6); c.stroke()
            box(4, 13.5, 6.5, 6.5, 1.6); c.stroke()
            box(13.5, 13.5, 6.5, 6.5, 1.6); c.stroke()
        } else if (kind === "person") {
            c.beginPath(); c.arc(12, 8.5, 3.8, 0, Math.PI * 2); c.stroke()
            c.beginPath()
            c.moveTo(4.5, 20)
            c.bezierCurveTo(5, 15, 8.5, 13.5, 12, 13.5)
            c.bezierCurveTo(15.5, 13.5, 19, 15, 19.5, 20)
            c.stroke()
        } else if (kind === "shield") {
            c.beginPath()
            c.moveTo(12, 3.5)
            c.lineTo(19, 6.2)
            c.lineTo(19, 11.5)
            c.bezierCurveTo(19, 16, 15.5, 19, 12, 20.5)
            c.bezierCurveTo(8.5, 19, 5, 16, 5, 11.5)
            c.lineTo(5, 6.2)
            c.closePath()
            c.stroke()
        } else if (kind === "update") {
            // Two arcs chasing each other round: what is brought up to date.
            c.beginPath(); c.arc(12, 12, 7.5, Math.PI * 1.08, Math.PI * 1.85, false); c.stroke()
            c.beginPath(); c.arc(12, 12, 7.5, Math.PI * 0.08, Math.PI * 0.85, false); c.stroke()
            c.beginPath(); c.moveTo(17.2, 3.6); c.lineTo(18.6, 6.6); c.lineTo(15.4, 7.3); c.stroke()
            c.beginPath(); c.moveTo(6.8, 20.4); c.lineTo(5.4, 17.4); c.lineTo(8.6, 16.7); c.stroke()
        } else if (kind === "clock") {
            c.beginPath(); c.arc(12, 12, 8.5, 0, Math.PI * 2); c.stroke()
            c.beginPath(); c.moveTo(12, 7); c.lineTo(12, 12); c.lineTo(15.5, 14); c.stroke()
        } else if (kind === "info") {
            c.beginPath(); c.arc(12, 12, 8.5, 0, Math.PI * 2); c.stroke()
            c.beginPath(); c.moveTo(12, 11); c.lineTo(12, 16.5); c.stroke()
            c.beginPath(); c.arc(12, 7.8, 1.1, 0, Math.PI * 2); c.fill()
        } else if (kind === "multitask") {
            box(3.5, 6, 11, 9, 1.6); c.stroke()
            box(9.5, 10, 11, 9, 1.6)
            c.save(); c.globalCompositeOperation = "destination-out"; c.fill(); c.restore()
            c.stroke()
        } else if (kind === "keyboard") {
            box(2.5, 6.5, 19, 11, 2); c.stroke()
            for (var kr = 0; kr < 2; kr++) {
                for (var kc = 0; kc < 5; kc++) {
                    c.beginPath(); c.arc(5.8 + kc * 3.1, 9.6 + kr * 2.6, 0.75, 0, Math.PI * 2); c.fill()
                }
            }
            c.beginPath(); c.moveTo(8, 15); c.lineTo(16, 15); c.stroke()
        } else if (kind === "mouse") {
            box(7, 3.5, 10, 17, 5); c.stroke()
            c.beginPath(); c.moveTo(12, 6.5); c.lineTo(12, 9.5); c.stroke()
        } else if (kind === "back") {
            c.lineWidth = 2
            c.beginPath(); c.moveTo(14.5, 6); c.lineTo(8.5, 12); c.lineTo(14.5, 18)
            c.stroke()
        } else if (kind === "down") {
            c.lineWidth = 2
            c.beginPath(); c.moveTo(6, 9.5); c.lineTo(12, 15.5); c.lineTo(18, 9.5)
            c.stroke()
        } else if (kind === "check") {
            c.lineWidth = 2.2
            c.beginPath(); c.moveTo(5, 12.5); c.lineTo(10, 17.5); c.lineTo(19, 7)
            c.stroke()
        } else if (kind === "rotate") {
            c.beginPath(); c.arc(12, 12.5, 7, Math.PI * 1.25, Math.PI * 2.9, false); c.stroke()
            c.beginPath(); c.moveTo(4.6, 4.5); c.lineTo(6.9, 7.6); c.lineTo(10.4, 6.3); c.stroke()
        } else if (kind === "copy") {
            box(8, 8, 11, 12, 2); c.stroke()
            c.beginPath(); c.moveTo(5, 15.5); c.lineTo(5, 6); c.arcTo(5, 4, 7, 4, 2)
            c.lineTo(14.5, 4); c.stroke()
        } else if (kind === "battery") {
            box(2.5, 7, 17, 10, 2.2); c.stroke()
            c.beginPath(); c.moveTo(21.5, 10.5); c.lineTo(21.5, 13.5); c.stroke()
            var fill = Math.max(0, Math.min(100, level)) / 100 * 13
            if (fill > 0.4) {
                box(4.5, 9, fill, 6, 1)
                c.fill()
            }
            if (charging) {
                c.globalCompositeOperation = "destination-out"
                c.lineWidth = 3.4
                c.beginPath(); c.moveTo(12, 6.5); c.lineTo(9, 12.5)
                c.lineTo(13, 11.5); c.lineTo(10, 17.5); c.stroke()
                c.globalCompositeOperation = "source-over"
                c.lineWidth = 1.4
                c.beginPath(); c.moveTo(12, 6.5); c.lineTo(9, 12.5)
                c.lineTo(13, 11.5); c.lineTo(10, 17.5); c.stroke()
            }
        } else if (kind === "home") {
            c.beginPath(); c.moveTo(3.5, 11); c.lineTo(12, 4); c.lineTo(20.5, 11); c.stroke()
            c.beginPath(); c.moveTo(6, 9.5); c.lineTo(6, 19.5); c.lineTo(18, 19.5)
            c.lineTo(18, 9.5); c.stroke()
            c.beginPath(); c.moveTo(10, 19.5); c.lineTo(10, 14); c.lineTo(14, 14)
            c.lineTo(14, 19.5); c.stroke()
        } else if (kind === "star") {
            c.beginPath()
            for (var sp = 0; sp < 10; sp++) {
                var sr = sp % 2 === 0 ? 8.5 : 3.8
                var sa = -Math.PI / 2 + sp * Math.PI / 5
                var sx = 12 + sr * Math.cos(sa), sy = 12.6 + sr * Math.sin(sa)
                if (sp === 0) c.moveTo(sx, sy); else c.lineTo(sx, sy)
            }
            c.closePath(); c.stroke()
        } else if (kind === "folder" || kind === "folder-new") {
            c.beginPath(); c.moveTo(3, 7); c.arcTo(3, 5, 5, 5, 2); c.lineTo(9, 5)
            c.lineTo(11, 7.5); c.lineTo(19, 7.5); c.arcTo(21, 7.5, 21, 9.5, 2)
            c.lineTo(21, 17); c.arcTo(21, 19, 19, 19, 2); c.lineTo(5, 19)
            c.arcTo(3, 19, 3, 17, 2); c.closePath(); c.stroke()
            if (kind === "folder-new") {
                c.beginPath(); c.moveTo(12, 10.5); c.lineTo(12, 16); c.stroke()
                c.beginPath(); c.moveTo(9.25, 13.25); c.lineTo(14.75, 13.25); c.stroke()
            }
        } else if (kind === "desktop") {
            box(3, 4.5, 18, 12, 2); c.stroke()
            c.beginPath(); c.moveTo(9, 20); c.lineTo(15, 20); c.stroke()
            c.beginPath(); c.moveTo(12, 16.5); c.lineTo(12, 20); c.stroke()
        } else if (kind === "document") {
            c.beginPath(); c.moveTo(14, 3.5); c.lineTo(7, 3.5); c.arcTo(5, 3.5, 5, 5.5, 2)
            c.lineTo(5, 18.5); c.arcTo(5, 20.5, 7, 20.5, 2); c.lineTo(17, 20.5)
            c.arcTo(19, 20.5, 19, 18.5, 2); c.lineTo(19, 8.5); c.closePath(); c.stroke()
            c.beginPath(); c.moveTo(14, 3.5); c.lineTo(14, 8.5); c.lineTo(19, 8.5); c.stroke()
        } else if (kind === "download") {
            c.beginPath(); c.moveTo(12, 3.5); c.lineTo(12, 15); c.stroke()
            c.beginPath(); c.moveTo(7, 10.5); c.lineTo(12, 15.5); c.lineTo(17, 10.5); c.stroke()
            c.beginPath(); c.moveTo(4.5, 19.5); c.lineTo(19.5, 19.5); c.stroke()
        } else if (kind === "picture") {
            box(3, 4.5, 18, 15, 2.5); c.stroke()
            c.beginPath(); c.arc(8.5, 9.5, 1.6, 0, Math.PI * 2); c.stroke()
            c.beginPath(); c.moveTo(3.5, 17); c.lineTo(9, 12.5); c.lineTo(13, 16)
            c.lineTo(16, 13.5); c.lineTo(20.5, 17.5); c.stroke()
        } else if (kind === "music") {
            c.beginPath(); c.moveTo(9, 17.5); c.lineTo(9, 5.5); c.lineTo(19, 3.8)
            c.lineTo(19, 15.5); c.stroke()
            c.beginPath(); c.arc(6.8, 17.5, 2.3, 0, Math.PI * 2); c.stroke()
            c.beginPath(); c.arc(16.8, 15.5, 2.3, 0, Math.PI * 2); c.stroke()
        } else if (kind === "video") {
            box(2.5, 6, 13.5, 12, 2.2); c.stroke()
            c.beginPath(); c.moveTo(16, 10.5); c.lineTo(21.5, 7.5); c.lineTo(21.5, 16.5)
            c.lineTo(16, 13.5); c.stroke()
        } else if (kind === "trash") {
            c.beginPath(); c.moveTo(4, 6.5); c.lineTo(20, 6.5); c.stroke()
            c.beginPath(); c.moveTo(9.5, 6.5); c.lineTo(9.5, 4); c.lineTo(14.5, 4)
            c.lineTo(14.5, 6.5); c.stroke()
            c.beginPath(); c.moveTo(6, 6.5); c.lineTo(7, 19); c.arcTo(7.2, 20.5, 9, 20.5, 1.6)
            c.lineTo(15, 20.5); c.arcTo(16.8, 20.5, 17, 19, 1.6); c.lineTo(18, 6.5); c.stroke()
            c.beginPath(); c.moveTo(10, 10); c.lineTo(10.3, 17); c.stroke()
            c.beginPath(); c.moveTo(14, 10); c.lineTo(13.7, 17); c.stroke()
        } else if (kind === "drive") {
            box(3, 8, 18, 9, 2.2); c.stroke()
            c.beginPath(); c.arc(16.8, 12.5, 1, 0, Math.PI * 2); c.fill()
            c.beginPath(); c.moveTo(6.5, 12.5); c.lineTo(11, 12.5); c.stroke()
        } else if (kind === "eject") {
            c.beginPath(); c.moveTo(12, 5); c.lineTo(19, 13); c.lineTo(5, 13); c.closePath()
            c.stroke()
            c.beginPath(); c.moveTo(5, 18); c.lineTo(19, 18); c.stroke()
        } else if (kind === "grid") {
            box(4, 4, 7, 7, 1.6); c.stroke(); box(13, 4, 7, 7, 1.6); c.stroke()
            box(4, 13, 7, 7, 1.6); c.stroke(); box(13, 13, 7, 7, 1.6); c.stroke()
        } else if (kind === "list") {
            for (var lr = 0; lr < 3; lr++) {
                c.beginPath(); c.arc(5, 6.5 + lr * 5.5, 1.1, 0, Math.PI * 2); c.fill()
                c.beginPath(); c.moveTo(9, 6.5 + lr * 5.5); c.lineTo(20, 6.5 + lr * 5.5); c.stroke()
            }
        } else if (kind === "more") {
            for (var md = 0; md < 3; md++) {
                c.beginPath(); c.arc(5.5 + md * 6.5, 12, 1.6, 0, Math.PI * 2); c.fill()
            }
        } else if (kind === "sort") {
            c.beginPath(); c.moveTo(4, 7); c.lineTo(20, 7); c.stroke()
            c.beginPath(); c.moveTo(4, 12); c.lineTo(15, 12); c.stroke()
            c.beginPath(); c.moveTo(4, 17); c.lineTo(10, 17); c.stroke()
        } else if (kind === "up") {
            c.lineWidth = 2
            c.beginPath(); c.moveTo(6, 14.5); c.lineTo(12, 8.5); c.lineTo(18, 14.5)
            c.stroke()
        }
        c.restore()
    }
}
