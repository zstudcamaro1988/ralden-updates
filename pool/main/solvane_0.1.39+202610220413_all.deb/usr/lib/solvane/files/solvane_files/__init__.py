# SPDX-License-Identifier: Solvane-Source
#
# Solvane OS - Files: the program behind /usr/share/solvane/files/Main.qml
