# SPDX-License-Identifier: Solvane-Source
#
# Solvane OS - Files: what the machine's own records say, read
#
# Plain Python, no Qt, so that tests/test_files.py can hold each of these to
# what the files and programs on the test machine actually contain:
#
#   user_dirs        ~/.config/user-dirs.dirs - where Desktop, Documents,
#                    Downloads... are, in this person's language
#   recent           ~/.local/share/recently-used.xbel - the files programs
#                    have opened lately (the freedesktop list KDE's and
#                    GTK's programs both write)
#   trash            ~/.local/share/Trash - what is in it, and where each
#                    thing came from (the freedesktop trash, Plasma's own)
#   drives           lsblk -J - the USB sticks and cards plugged in
#   when_words       "Just now", "2h ago", "Yesterday" - the picture's words
#   valid_name       a file name a person may give

import json
import os
import re
import time
import urllib.parse

# ---- the folders a person's things live in ------------------------------------

# The order the sidebar shows them in, and the words for each.
SPACES = (
    ("DESKTOP", "Desktop", "desktop"),
    ("DOCUMENTS", "Documents", "documents"),
    ("DOWNLOAD", "Downloads", "downloads"),
    ("PICTURES", "Pictures", "pictures"),
    ("MUSIC", "Music", "music"),
    ("VIDEOS", "Videos", "videos"),
)
USER_DIR_RE = re.compile(r'^XDG_([A-Z]+)_DIR="(.*)"\s*$')


def user_dirs(text, home):
    """{"DOCUMENTS": "/home/buu/Documents", ...} out of user-dirs.dirs.

    The file is the one xdg-user-dirs writes, in the person's language:
    `XDG_DOCUMENTS_DIR="$HOME/Documents"`. Only $HOME-relative and absolute
    paths are taken; a folder that is just $HOME means "not set".
    """
    out = {}
    for line in (text or "").splitlines():
        m = USER_DIR_RE.match(line.strip())
        if not m:
            continue
        value = m.group(2)
        if value.startswith("$HOME"):
            value = home + value[len("$HOME"):]
        elif not value.startswith("/"):
            continue
        value = os.path.normpath(value)
        if value != os.path.normpath(home):
            out[m.group(1)] = value
    return out


def spaces(dirs, home, exists=os.path.isdir):
    """The sidebar's Spaces: each of the usual folders this person has."""
    found = []
    for key, label, glyph in SPACES:
        path = dirs.get(key) or os.path.join(home, label)
        if exists(path):
            found.append({"key": key.lower(), "label": os.path.basename(path) or label,
                          "path": path, "glyph": glyph})
    return found


# ---- recently opened ----------------------------------------------------------------

BOOKMARK_RE = re.compile(r"<bookmark\b([^>]*)>", re.S)
ATTR_RE = re.compile(r'(\w+)="([^"]*)"')


def xbel_time(text):
    """2026-10-15T09:41:07.123456Z -> seconds since 1970, or 0."""
    m = re.match(r"^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)", text or "")
    if not m:
        return 0
    import calendar
    return calendar.timegm(tuple(int(x) for x in m.groups()) + (0, 0, 0))


def recent(text, limit=50, exists=os.path.exists):
    """[{"path", "when"}] out of recently-used.xbel, newest first.

    Read with a pattern, not an XML parser: the file is written by many
    programs and one of them leaving it half-written must not hide all of
    it. Only local files that are still there are kept.
    """
    found = {}
    for m in BOOKMARK_RE.finditer(text or ""):
        attrs = dict(ATTR_RE.findall(m.group(1)))
        href = attrs.get("href", "")
        if not href.startswith("file://"):
            continue
        path = urllib.parse.unquote(href[len("file://"):])
        if not path.startswith("/") or not exists(path):
            continue
        when = max(xbel_time(attrs.get(k)) for k in ("visited", "modified", "added"))
        if when > found.get(path, -1):
            found[path] = when
    ordered = sorted(found.items(), key=lambda kv: -kv[1])[:limit]
    return [{"path": p, "when": w} for p, w in ordered]


# ---- the trash -------------------------------------------------------------------------

def trash_info(text):
    """(original path, deletion time) out of a .trashinfo file, or None."""
    if not text or "[Trash Info]" not in text:
        return None
    path, when = None, 0
    for line in text.splitlines():
        if line.startswith("Path="):
            path = urllib.parse.unquote(line[5:].strip())
        elif line.startswith("DeletionDate="):
            try:
                when = int(time.mktime(time.strptime(line[13:].strip()[:19],
                                                     "%Y-%m-%dT%H:%M:%S")))
            except ValueError:
                when = 0
    if not path:
        return None
    return path, when


# ---- drives plugged in ---------------------------------------------------------------------

def drives(text):
    """The removable drives' filesystems, out of
    `lsblk -J -b -o NAME,PATH,TYPE,RM,HOTPLUG,TRAN,SIZE,LABEL,FSTYPE,MOUNTPOINT`.

    [{"device", "disk", "label", "size", "mountpoint", "fstype"}]. A disk
    with no partitions but a filesystem of its own (some sticks) is one
    entry. The internal drives, and anything with no filesystem, are not
    here: they are not something a person plugs in and opens.
    """
    try:
        data = json.loads(text)
    except ValueError:
        return []
    out = []
    for disk in (data.get("blockdevices") or []) if isinstance(data, dict) else []:
        if not isinstance(disk, dict) or disk.get("type") != "disk":
            continue
        removable = (disk.get("rm") in (True, 1, "1") or disk.get("hotplug") in (True, 1, "1")
                     or disk.get("tran") == "usb")
        if not removable:
            continue
        parts = [p for p in disk.get("children") or [] if isinstance(p, dict)]
        for node in parts or [disk]:
            fstype = node.get("fstype")
            if not fstype or fstype in ("swap", "crypto_LUKS", "LVM2_member"):
                continue
            try:
                size = int(node.get("size") or 0)
            except (TypeError, ValueError):
                size = 0
            out.append({"device": node.get("path") or "/dev/" + (node.get("name") or ""),
                        "disk": disk.get("path") or "/dev/" + (disk.get("name") or ""),
                        "label": node.get("label") or "",
                        "size": size,
                        "mountpoint": node.get("mountpoint") or "",
                        "fstype": fstype})
    return out


def size_words(n):
    """1536 -> "1.5 KB": what a size reads as, in powers of a thousand as a
    drive's maker counts them."""
    try:
        n = float(n)
    except (TypeError, ValueError):
        return ""
    if n < 1000:
        return "%d bytes" % n if n != 1 else "1 byte"
    for unit in ("KB", "MB", "GB", "TB"):
        n /= 1000.0
        if n < 1000 or unit == "TB":
            return ("%.1f %s" if n < 10 else "%.0f %s") % (n, unit)
    return ""


# ---- words for when ----------------------------------------------------------------------------

def when_words(then, now=None):
    """The picture's words: Just now, 5 min ago, 2h ago, Yesterday, Monday,
    12 Oct, 12 Oct 2025."""
    now = time.time() if now is None else now
    if not then:
        return ""
    ago = now - then
    if ago < 60:
        return "Just now"
    if ago < 3600:
        return "%d min ago" % (ago // 60)
    a, b = time.localtime(then), time.localtime(now)
    days = (time.mktime((b.tm_year, b.tm_mon, b.tm_mday, 0, 0, 0, 0, 0, -1))
            - time.mktime((a.tm_year, a.tm_mon, a.tm_mday, 0, 0, 0, 0, 0, -1))) // 86400
    if days <= 0:
        return "%dh ago" % (ago // 3600)
    if days == 1:
        return "Yesterday"
    if days < 7:
        return time.strftime("%A", a)
    if a.tm_year == b.tm_year:
        return "%d %s" % (a.tm_mday, time.strftime("%b", a))
    return "%d %s %d" % (a.tm_mday, time.strftime("%b", a), a.tm_year)


# ---- names -----------------------------------------------------------------------------------

def valid_name(name):
    """A name a file or folder may be given here: not empty, not . or ..,
    no slash, no NUL, at most 255 bytes."""
    if not isinstance(name, str):
        return False
    if name in ("", ".", "..") or "/" in name or "\0" in name:
        return False
    if name != name.strip() or len(name.encode("utf-8")) > 255:
        return False
    return True


def free_name(folder, wanted, exists=os.path.exists):
    """`wanted`, or "wanted 2", "wanted 3"... - the first not in `folder`."""
    if not exists(os.path.join(folder, wanted)):
        return wanted
    stem, ext = split_extension(wanted)
    for n in range(2, 1000):
        name = "%s %d%s" % (stem, n, ext)
        if not exists(os.path.join(folder, name)):
            return name
    return wanted


DOUBLE_EXTENSIONS = (".tar.gz", ".tar.xz", ".tar.bz2", ".tar.zst")


def split_extension(name):
    """("report", ".pdf"); ("backup", ".tar.gz"); (".bashrc", "")."""
    low = name.lower()
    for ext in DOUBLE_EXTENSIONS:
        if low.endswith(ext) and len(name) > len(ext):
            return name[:-len(ext)], name[-len(ext):]
    stem, dot, ext = name.rpartition(".")
    if not dot or not stem:
        return name, ""
    return stem, "." + ext


NUMBER_RE = re.compile(r"(\d+)")


def natural_key(name):
    """file2 before file10, and case not counted."""
    return [int(p) if p.isdigit() else p.casefold() for p in NUMBER_RE.split(name)]


def launcher(text, language=""):
    """A program's launcher file (.desktop) as a person knows it: its Name
    and its Icon, from the [Desktop Entry] group - the name in the
    person's language when the file has one ("Name[de]"). A file that is
    not a launcher gives None, and is shown by its file name."""
    if not isinstance(text, str) or "[Desktop Entry]" not in text:
        return None
    found, group = {}, None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("[") and line.endswith("]"):
            group = line[1:-1]
            continue
        if group != "Desktop Entry" or "=" not in line or line.startswith("#"):
            continue
        key, value = (part.strip() for part in line.split("=", 1))
        found.setdefault(key, value)
    lang = language.split(".")[0]
    name = (found.get("Name[%s]" % lang) or found.get("Name[%s]" % lang.split("_")[0])
            or found.get("Name"))
    if not name:
        return None
    return {"name": name, "icon": found.get("Icon", "")}


def plain(value):
    """What the window sent, as Python's own.

    A list or an object written in QML - `[path]`, `{"path": p, "name":
    n}` - reaches a slot declared to take a QVariant as a QJSValue, which
    is neither a list nor a dict until it is asked to be (seen on the test
    machine, 20 October 2026: Files' Copy, Rename and Move to Trash, and
    Settings' new shortcut key, were each handed one, and did nothing).
    Strings, numbers and true/false arrive as themselves."""
    if hasattr(value, "toVariant"):
        value = value.toVariant()
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value
