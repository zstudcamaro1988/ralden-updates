# SPDX-License-Identifier: Solvane-Source
#
# Solvane OS - Settings: one object per part of the machine
#
# Each page of Settings is drawn by QML and knows nothing about the machine.
# What it shows is one of these objects' `state` - a plain map of values -
# and what is pressed comes back as `act(verb, value)`. So a page can be
# photographed before a build with any state at all (tools/preview-events/
# settings.py hands it made-up objects with the same two things), and the
# checker can hold every verb a page sends to one this file answers.
#
# EVERYTHING IS ASKED WITHOUT WAITING. A program run to read the volume must
# not freeze the window while it starts - on the VAIO that is the difference
# between a window that answers and one that stutters. So programs are run
# by QProcess and answered when they finish.
#
# WHAT IS NOT KNOWN IS SAID TO BE NOT KNOWN. Each area marks what it has
# heard (`...Known`); until then a page draws nothing for it, and if the
# program fails the page says why the control is not there.

import json
import os

from PySide6.QtCore import (QObject, QProcess, QTimer, Property, Signal, Slot)

from . import commands, readers


class Runner(QObject):
    """Runs a program - a list, never a shell line - and calls back with
    (exit code, what it printed). -1 when it could not be started or took
    too long."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._running = set()

    def run(self, argv, done=None, seconds=15, merge=False, stdin=None):
        """`merge`: what it says when it fails (its errors) is handed back
        with what it printed - for a page that has to say why. `stdin`:
        text handed to it on standard input and nowhere else - a Wi-Fi
        password, which on the command line every program could read."""
        p = QProcess(self)
        p.setProgram(argv[0])
        p.setArguments(list(argv[1:]))
        p.setProcessChannelMode(QProcess.MergedChannels if merge
                                else QProcess.SeparateChannels)
        timer = QTimer(p)
        timer.setSingleShot(True)
        finished = {"done": False}

        def finish(code):
            if finished["done"]:
                return
            finished["done"] = True
            timer.stop()
            out = bytes(p.readAllStandardOutput()).decode("utf-8", "replace")
            self._running.discard(p)
            p.deleteLater()
            if done is not None:
                done(code, out)

        p.finished.connect(lambda code, status: finish(
            code if status == QProcess.NormalExit else -1))
        p.errorOccurred.connect(lambda error: finish(-1)
                                if error == QProcess.FailedToStart else None)

        def too_long():
            p.kill()
            finish(-1)
        timer.timeout.connect(too_long)
        self._running.add(p)
        timer.start(seconds * 1000)
        p.start()
        if stdin is not None:
            p.write(stdin.encode("utf-8"))
            p.closeWriteChannel()
        return p

    def launch(self, argv):
        """Starts a window of its own, and lets it go: it is not waited
        for, and closing Settings does not close it."""
        p = QProcess()
        p.setProgram(argv[0])
        p.setArguments(list(argv[1:]))
        # (bool, pid) from PySide6, as Files found; a bare bool elsewhere.
        result = p.startDetached()
        return bool(result[0] if isinstance(result, tuple) else result)


def read_file(path, limit=65536):
    try:
        with open(path, errors="replace") as f:
            return f.read(limit)
    except OSError:
        return ""


class Area(QObject):
    """A part of the machine: its state, and what can be done to it."""

    stateChanged = Signal()

    # verb -> method name. The checker holds every act("verb") a page sends
    # to one of these, for the area the page is given.
    ACTS = {}

    def __init__(self, runner, parent=None):
        super().__init__(parent)
        self.runner = runner
        self._state = {}
        self._watch = QTimer(self)
        self._watch.setInterval(4000)
        self._watch.timeout.connect(self.refresh)

    def _get_state(self):
        return self._state

    state = Property("QVariantMap", _get_state, notify=stateChanged)

    def update(self, **values):
        # Said to have changed only when it has: a page's lists are made
        # again at every change, and asked again every few seconds a list
        # would be pulled out from under the pointer for nothing.
        state = dict(self._state, **values)
        if state == self._state:
            return
        self._state = state
        self.stateChanged.emit()

    @Slot(str, "QVariant")
    def act(self, verb, value=None):
        name = self.ACTS.get(verb)
        if name is not None:
            getattr(self, name)(readers.plain(value))

    @Slot()
    def refresh(self):
        pass

    @Slot(bool)
    def watch(self, on):
        """Asked again every few seconds while its page is open, and not at
        all while it is not: nothing is polled for a page nobody sees."""
        if on:
            self.refresh()
            self._watch.start()
        else:
            self._watch.stop()

    def run(self, argv, done=None, seconds=15, merge=False, stdin=None):
        return self.runner.run(argv, done, seconds, merge, stdin)


# ---- Display ---------------------------------------------------------------------------

class DisplayArea(Area):
    ACTS = {
        "brightness": "set_brightness",
        "warmth": "set_warmth",
        "adaptive": "set_adaptive",
        "nightLight": "set_night_light",
        "resolution": "set_resolution",
        "rotation": "set_rotation",
        "keep": "keep",
        "revert": "revert",
    }

    # How long a new resolution waits to be kept before it is undone: a
    # screen that cannot show what was chosen goes black, and the person
    # cannot reach the button to undo it.
    KEEP_SECONDS = 15

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._screen = None
        self._undo = None
        self._countdown = QTimer(self)
        self._countdown.setInterval(1000)
        self._countdown.timeout.connect(self._tick)
        self.update(brightnessKnown=False, brightnessAvailable=False, brightness=0,
                    nightKnown=False, nightAvailable=False, warmth=0, adaptive=False,
                    adaptivePossible=False, screenKnown=False, screenName="",
                    resolutions=[], resolution="", resolutionLabel="",
                    rotation="none", asking=False, secondsLeft=0)

    @Slot()
    def refresh(self):
        self.run(commands.READ_BACKLIGHT, self._got_backlight)
        self.run(commands.READ_NIGHT, self._got_night)
        if not self._countdown.isActive():
            self.run(commands.READ_SCREENS, self._got_screens)

    def _got_backlight(self, code, out):
        light = readers.backlight(out) if code == 0 else None
        self.update(brightnessKnown=True, brightnessAvailable=light is not None,
                    brightness=light["percent"] if light else 0)

    def _got_night(self, code, out):
        try:
            data = json.loads(out) if code == 0 else None
        except ValueError:
            data = None
        if not isinstance(data, dict):
            self.update(nightKnown=True, nightAvailable=False)
            return
        warmth = data.get("warmth") if isinstance(data.get("warmth"), int) else 0
        self.update(nightKnown=True, nightAvailable=True,
                    warmth=warmth if data.get("active") else 0,
                    adaptive=data.get("adaptive") is True,
                    adaptivePossible=bool(data.get("place")))

    def _got_screens(self, code, out):
        found = readers.screens(out) if code == 0 else []
        shown = [s for s in found if s["enabled"]]
        if not shown:
            self._screen = None
            self.update(screenKnown=True, screenName="", resolutions=[])
            return
        screen = sorted(shown, key=lambda s: not s["primary"])[0]
        self._screen = screen
        current = readers.current_mode(screen)
        sizes = readers.resolutions(screen)
        preferred = {(m["width"], m["height"]) for m in screen["modes"]
                     if m["id"] in screen.get("preferred", [])}
        listed = []
        for m in sizes:
            label = "%d × %d" % (m["width"], m["height"])
            if (m["width"], m["height"]) in preferred:
                # What the screen itself says suits it best.
                label += "  (recommended)"
            listed.append({"key": m["id"], "label": label})
        current_key = ""
        current_label = ""
        if current:
            for m in sizes:
                if (m["width"], m["height"]) == (current["width"], current["height"]):
                    current_key = m["id"]
            current_label = "%d × %d" % (current["width"], current["height"])
        self.update(screenKnown=True, screenName=screen["name"],
                    resolutions=listed, resolution=current_key,
                    resolutionLabel=current_label, rotation=screen["rotation"])

    # -- what is pressed --

    def set_brightness(self, value):
        try:
            v = int(value)
        except (TypeError, ValueError):
            return
        self.run(commands.set_brightness(v))
        self.update(brightness=v)

    def set_warmth(self, value):
        try:
            w = int(value)
        except (TypeError, ValueError):
            return
        self.run(commands.set_night(w, self._state.get("adaptive")))
        self.update(warmth=w)

    def set_adaptive(self, value):
        on = bool(value) and bool(self._state.get("adaptivePossible"))
        # Switched on with the light off means "on": nobody asks for a
        # schedule for a light that is off. 50 is KWin's own 4,500 K.
        w = self._state.get("warmth") or (50 if on else 0)
        self.run(commands.set_night(w, on), lambda c, o: self.refresh())
        self.update(adaptive=on, warmth=w)

    def set_night_light(self, value):
        w = 50 if value else 0
        self.run(commands.set_night(w, self._state.get("adaptive")),
                 lambda c, o: self.refresh())
        self.update(warmth=w)

    def set_resolution(self, mode_id):
        screen = self._screen
        if not screen or not any(m["id"] == str(mode_id) for m in screen["modes"]):
            return
        before = screen.get("current")
        if str(mode_id) == before:
            return
        self._undo = commands.set_mode(screen["name"], before) if before else None
        self.run(commands.set_mode(screen["name"], str(mode_id)),
                 lambda c, o: self._ask_to_keep() if c == 0 else self._refused())

    def set_rotation(self, rotation):
        screen = self._screen
        if not screen or rotation not in commands.ROTATION_WORDS:
            return
        if rotation == screen["rotation"]:
            return
        self._undo = commands.set_rotation(screen["name"], screen["rotation"])
        self.run(commands.set_rotation(screen["name"], rotation),
                 lambda c, o: self._ask_to_keep() if c == 0 else self._refused())

    def _ask_to_keep(self):
        self.update(asking=True, secondsLeft=self.KEEP_SECONDS)
        self._countdown.start()
        self.run(commands.READ_SCREENS, self._got_screens)

    def _refused(self):
        self._undo = None
        self.update(asking=False, note="The screen would not change to that.")
        self.refresh()

    def _tick(self):
        left = int(self._state.get("secondsLeft", 0)) - 1
        if left <= 0:
            self.revert(None)
        else:
            self.update(secondsLeft=left)

    def keep(self, _value):
        self._countdown.stop()
        self._undo = None
        self.update(asking=False, secondsLeft=0)

    def revert(self, _value):
        self._countdown.stop()
        undo, self._undo = self._undo, None
        self.update(asking=False, secondsLeft=0)
        if undo:
            self.run(undo, lambda c, o: self.refresh())


# ---- Sound ------------------------------------------------------------------------------

class SoundArea(Area):
    ACTS = {
        "output": "set_output",
        "volume": "set_volume",
        "mute": "set_mute",
        "input": "set_input",
        "inputVolume": "set_input_volume",
        "inputMute": "set_input_mute",
    }

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._sinks = []
        self._sources = []
        self._defaults = ("", "")
        self.update(known=False, outputs=[], output="", volume=0, muted=False,
                    outputAvailable=False, inputs=[], input="", inputVolume=0,
                    inputMuted=False, inputAvailable=False)

    @Slot()
    def refresh(self):
        self.run(commands.READ_SOUND_DEFAULTS, self._got_defaults)

    def _got_defaults(self, code, out):
        if code != 0:
            self.update(known=True, outputAvailable=False, inputAvailable=False)
            return
        self._defaults = readers.defaults(out)
        self.run(commands.READ_SINKS, self._got_sinks)
        self.run(commands.READ_SOURCES, self._got_sources)

    def _got_sinks(self, code, out):
        self._sinks = readers.sinks(out) if code == 0 else []
        chosen = next((d for d in self._sinks if d["name"] == self._defaults[0]),
                      self._sinks[0] if self._sinks else None)
        self.update(known=True,
                    outputs=[{"key": d["name"], "label": d["label"]} for d in self._sinks],
                    output=chosen["name"] if chosen else "",
                    volume=chosen["volume"] if chosen and chosen["volume"] is not None else 0,
                    muted=bool(chosen and chosen["muted"]),
                    outputAvailable=chosen is not None)

    def _got_sources(self, code, out):
        self._sources = readers.sources(out) if code == 0 else []
        chosen = next((d for d in self._sources if d["name"] == self._defaults[1]),
                      self._sources[0] if self._sources else None)
        self.update(inputs=[{"key": d["name"], "label": d["label"]} for d in self._sources],
                    input=chosen["name"] if chosen else "",
                    inputVolume=chosen["volume"] if chosen and chosen["volume"] is not None else 0,
                    inputMuted=bool(chosen and chosen["muted"]),
                    inputAvailable=chosen is not None)

    def _known(self, devices, name):
        return isinstance(name, str) and any(d["name"] == name for d in devices)

    def set_output(self, name):
        if self._known(self._sinks, name):
            self.run(commands.set_default_sink(name), lambda c, o: self.refresh())
            self.update(output=name)

    def set_input(self, name):
        if self._known(self._sources, name):
            self.run(commands.set_default_source(name), lambda c, o: self.refresh())
            self.update(input=name)

    def set_volume(self, value):
        try:
            v = int(value)
        except (TypeError, ValueError):
            return
        # Any change unmutes: dragging the volume up on a muted machine
        # means "let me hear it".
        self.run(commands.set_sink_mute(False))
        self.run(commands.set_sink_volume(v))
        self.update(volume=v, muted=False)

    def set_input_volume(self, value):
        try:
            v = int(value)
        except (TypeError, ValueError):
            return
        self.run(commands.set_source_mute(False))
        self.run(commands.set_source_volume(v))
        self.update(inputVolume=v, inputMuted=False)

    def set_mute(self, value):
        self.run(commands.set_sink_mute(bool(value)))
        self.update(muted=bool(value))

    def set_input_mute(self, value):
        self.run(commands.set_source_mute(bool(value)))
        self.update(inputMuted=bool(value))


# ---- Power & Battery ---------------------------------------------------------------------

POWER_SUPPLY = os.environ.get("SOLVANE_POWER_SUPPLY", "/sys/class/power_supply")
# TLP, the image's power manager (config/package-lists): it changes how the
# machine saves power by itself, plugged in and on battery.
TLP = "/usr/sbin/tlp"


def read_power_supply(root=POWER_SUPPLY):
    entries = {}
    try:
        names = os.listdir(root)
    except OSError:
        return entries
    for name in names:
        d = os.path.join(root, name)
        entries[name] = {k: read_file(os.path.join(d, k), 64)
                         for k in ("type", "capacity", "status", "scope", "online")}
    return entries


class PowerArea(Area):
    ACTS = {"profile": "set_profile"}

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self.update(known=False, hasBattery=False, battery=0, charging=False,
                    full=False, onMains=False, profileKnown=False, profile="",
                    profiles=[], manager="tlp" if os.path.exists(TLP) else "")

    @Slot()
    def refresh(self):
        entries = read_power_supply()
        b = readers.battery(entries)
        mains = readers.on_mains(entries)
        self.update(known=True, hasBattery=b is not None,
                    battery=b["percent"] if b else 0,
                    charging=bool(b and b["charging"]), full=bool(b and b["full"]),
                    onMains=mains is not False)
        self.run(commands.READ_PROFILES, self._got_profiles)

    def _got_profiles(self, code, out):
        names, current, real = readers.profiles(out) if code == 0 else ([], "", False)
        if not real:
            # No power-profiles-daemon, or only its stand-in driver, which
            # remembers a choice and changes nothing on this machine. A
            # switch that does nothing is not drawn.
            names, current = [], ""
        self.update(profileKnown=True, profiles=names, profile=current)

    def set_profile(self, name):
        if name in self._state.get("profiles", []):
            self.run(commands.set_profile(name), lambda c, o: self.refresh())
            self.update(profile=name)


# ---- Multitasking --------------------------------------------------------------------------

class MultitaskingArea(Area):
    """KWin's: snapping windows to the edges, the workspaces, Alt+Tab, the
    overview. Each yes-or-no is a line of kwinrc that KWin is asked to read
    again; the workspaces are KWin's own, added and taken away through its
    D-Bus, which also writes them down."""

    ACTS = {
        "snapEdges": "set_snap_edges",
        "snapTop": "set_snap_top",
        "wrap": "set_wrap",
        "osd": "set_osd",
        "altTab": "set_alt_tab",
        "addDesktop": "add_desktop",
        "removeDesktop": "remove_desktop",
        "overview": "show_overview",
    }

    # name in the state -> (group, key, what KWin does with no line at all).
    # The defaults are kwin.kcfg's, read off the image (docs/settings.md);
    # /etc/xdg/kwinrc changes RollOverDesktops, and kreadconfig6 knows.
    SWITCHES = {
        "snapEdges": ("Windows", "ElectricBorderTiling", True),
        "snapTop": ("Windows", "ElectricBorderMaximize", True),
        "wrap": ("Windows", "RollOverDesktops", False),
        "osd": ("Plugins", "desktopchangeosdEnabled", False),
    }
    # [TabBox] DesktopMode: 1 the windows of this workspace, 0 of every one.
    ALT_TAB = {"this": 1, "all": 0}

    # KWin takes up to 25; more than this many is a dock nobody can read.
    MOST = 12

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._read = False
        self._desktops = []
        self.update(known=False, snapEdges=True, snapTop=True, wrap=False, osd=False,
                    altTab="this", desktopsKnown=False, desktops=[], count=0, most=self.MOST)

    @Slot(bool)
    def watch(self, on):
        # The switches are read once each time the page opens - nothing else
        # changes them while it is open - and the workspaces every few
        # seconds, since the dock can be at them too.
        if on:
            self._read = False
        super().watch(on)

    @Slot()
    def refresh(self):
        if not self._read:
            self._read = True
            for name, (group, key, default) in self.SWITCHES.items():
                self.run(commands.read_config("kwinrc", group, key, "true" if default else "false"),
                         lambda c, o, name=name, default=default: self.update(
                             **{name: readers.config_bool(o, default) if c == 0 else default}))
            self.run(commands.read_config("kwinrc", "TabBox", "DesktopMode", "1"),
                     lambda c, o: self.update(
                         known=True,
                         altTab="all" if c == 0 and readers.config_int(o, 1) == 0 else "this"))
        self.run(commands.READ_DESKTOPS, self._got_desktops)

    def _got_desktops(self, code, out):
        self._desktops = readers.desktops(out) if code == 0 else []
        self.update(desktopsKnown=True, desktops=[d["name"] for d in self._desktops],
                    count=len(self._desktops))

    def _set_switch(self, name, value):
        group, key, _default = self.SWITCHES[name]
        on = bool(value)
        self.run(commands.write_config("kwinrc", group, key, "true" if on else "false", "bool"),
                 lambda c, o: self.run(commands.KWIN_RECONFIGURE) if c == 0 else None)
        self.update(**{name: on})

    def set_snap_edges(self, value):
        self._set_switch("snapEdges", value)

    def set_snap_top(self, value):
        self._set_switch("snapTop", value)

    def set_wrap(self, value):
        self._set_switch("wrap", value)

    def set_osd(self, value):
        self._set_switch("osd", value)

    def set_alt_tab(self, value):
        if value not in self.ALT_TAB:
            return
        self.run(commands.write_config("kwinrc", "TabBox", "DesktopMode", str(self.ALT_TAB[value])),
                 lambda c, o: self.run(commands.KWIN_RECONFIGURE) if c == 0 else None)
        self.update(altTab=value)

    def add_desktop(self, _value):
        if not self._state.get("desktopsKnown") or len(self._desktops) >= self.MOST:
            return
        self.run(commands.add_desktop(len(self._desktops)),
                 lambda c, o: self.run(commands.READ_DESKTOPS, self._got_desktops))

    def remove_desktop(self, _value):
        # The last one, always: its windows go to the one before it.
        if len(self._desktops) <= 1:
            return
        self.run(commands.remove_desktop(self._desktops[-1]["id"]),
                 lambda c, o: self.run(commands.READ_DESKTOPS, self._got_desktops))

    def show_overview(self, _value):
        self.run(commands.SHOW_OVERVIEW)


# ---- Mouse & Touchpad --------------------------------------------------------------------------

class PointingArea(Area):
    """The mouse and the touchpad, as Plasma's own pages keep them on X11:
    the mouse in kcminputrc [Mouse], the touchpad in touchpadxlibinputrc,
    a group per touchpad by its name. Written there, and Plasma asked to
    set the devices from them again (MOUSE_APPLY, TOUCHPAD_APPLY)."""

    ACTS = {
        "mouseSpeed": "set_mouse_speed",
        "mouseAccel": "set_mouse_accel",
        "mouseNatural": "set_mouse_natural",
        "leftHanded": "set_left_handed",
        "touchpadSpeed": "set_touchpad_speed",
        "tap": "set_tap",
        "touchpadNatural": "set_touchpad_natural",
        "typingOff": "set_typing_off",
    }

    # kcminputrc [Mouse]: state name -> (key, default). kcm_mouse.so's own
    # names for X11's libinput (read off the test machine, 15 October 2026);
    # the defaults are libinput's.
    MOUSE_KEYS = {
        "mouseSpeed": ("XLbInptPointerAcceleration", 0.0),
        "mouseAccel": ("XLbInptAccelProfileFlat", False),
        "leftHanded": ("XLbInptLeftHanded", False),
        "mouseNatural": ("XLbInptNaturalScroll", False),
    }
    # touchpadxlibinputrc [<touchpad's name>]: kcm_touchpad.so's names for
    # the same. Libinput taps only when asked to, and leaves the pointer
    # alone while typing unless asked not to.
    TOUCHPAD_KEYS = {
        "touchpadSpeed": ("pointerAcceleration", 0.0),
        "tap": ("tapToClick", False),
        "touchpadNatural": ("naturalScroll", False),
        "typingOff": ("disableWhileTyping", True),
    }
    # Plasma's own start-up step for each, which sets the devices from the
    # files again. kcminit takes them by the path its --list prints, not by
    # name ("Could not find kcm_mouse"); seen working on the test machine on
    # 15 October 2026 - left-handed, written and applied, swapped the buttons.
    KCMS = "/usr/lib/x86_64-linux-gnu/qt6/plugins/plasma/kcms/systemsettings/"
    MOUSE_APPLY = ["kcminit", KCMS + "kcm_mouse.so"]
    TOUCHPAD_APPLY = ["kcminit", KCMS + "kcm_touchpad.so"]
    TOUCHPAD_FILE = "touchpadxlibinputrc"

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._read = False
        self._touchpads = []
        self.update(known=False, appliesNow=self.MOUSE_APPLY is not None,
                    mousePresent=False, touchpadPresent=False,
                    mouseSpeed=50, mouseAccel=True, mouseNatural=False, leftHanded=False,
                    touchpadSpeed=50, tap=False, touchpadNatural=False, typingOff=True)

    @Slot(bool)
    def watch(self, on):
        if on:
            self._read = False
        super().watch(on)

    @Slot()
    def refresh(self):
        devices = readers.input_devices(read_file(commands.INPUT_DEVICES, 1 << 20))
        touchpads = [d["name"] for d in devices if d["kind"] == "touchpad"]
        mice = [d["name"] for d in devices if d["kind"] == "mouse"]
        changed = touchpads != self._touchpads
        self._touchpads = touchpads
        self.update(known=True, mousePresent=bool(mice) and bool(self.MOUSE_KEYS),
                    touchpadPresent=bool(touchpads) and bool(self.TOUCHPAD_KEYS))
        if self._read and not changed:
            return
        self._read = True
        for name, (key, default) in self.MOUSE_KEYS.items():
            self.run(commands.read_config("kcminputrc", "Mouse", key, str(default).lower()),
                     lambda c, o, name=name, default=default: self._got(name, o if c == 0 else "", default))
        if touchpads:
            for name, (key, default) in self.TOUCHPAD_KEYS.items():
                self.run(commands.read_config(self.TOUCHPAD_FILE, touchpads[0], key, str(default).lower()),
                         lambda c, o, name=name, default=default: self._got(name, o if c == 0 else "", default))

    # Speeds are -1 to 1 in the files, 0 to 100 on the page.
    SPEEDS = ("mouseSpeed", "touchpadSpeed")

    def _got(self, name, text, default):
        if name in self.SPEEDS:
            try:
                v = max(-1.0, min(1.0, float(text.strip())))
            except ValueError:
                v = float(default)
            self.update(**{name: int(round((v + 1) * 50))})
        elif name == "mouseAccel":
            # Kept as "flat", which is its opposite.
            self.update(mouseAccel=not readers.config_bool(text, default))
        else:
            self.update(**{name: readers.config_bool(text, default)})

    def _write_mouse(self, name, value):
        key = self.MOUSE_KEYS.get(name, (None,))[0]
        if key is None:
            return
        steps = [commands.write_config("kcminputrc", "Mouse", key, value,
                                       None if name == "mouseSpeed" else "bool")]
        if self.MOUSE_APPLY:
            steps.append(self.MOUSE_APPLY)
        self._chain(steps)

    def _write_touchpad(self, name, value):
        key = self.TOUCHPAD_KEYS.get(name, (None,))[0]
        if key is None or not self._touchpads:
            return
        steps = [commands.write_config(self.TOUCHPAD_FILE, pad, key, value,
                                       None if name == "touchpadSpeed" else "bool")
                 for pad in self._touchpads]
        if self.TOUCHPAD_APPLY:
            steps.append(self.TOUCHPAD_APPLY)
        self._chain(steps)

    def _chain(self, steps):
        def next_step(code=0, out=""):
            if steps:
                self.run(steps.pop(0), next_step)
        next_step()

    @staticmethod
    def _speed(value):
        try:
            v = max(0, min(100, int(value)))
        except (TypeError, ValueError):
            return None
        return v, "%.2f" % (v / 50.0 - 1)

    def set_mouse_speed(self, value):
        s = self._speed(value)
        if s:
            self._write_mouse("mouseSpeed", s[1])
            self.update(mouseSpeed=s[0])

    def set_touchpad_speed(self, value):
        s = self._speed(value)
        if s:
            self._write_touchpad("touchpadSpeed", s[1])
            self.update(touchpadSpeed=s[0])

    def set_mouse_accel(self, value):
        self._write_mouse("mouseAccel", "false" if value else "true")
        self.update(mouseAccel=bool(value))

    def set_mouse_natural(self, value):
        self._write_mouse("mouseNatural", "true" if value else "false")
        self.update(mouseNatural=bool(value))

    def set_left_handed(self, value):
        self._write_mouse("leftHanded", "true" if value else "false")
        self.update(leftHanded=bool(value))

    def set_tap(self, value):
        self._write_touchpad("tap", "true" if value else "false")
        self.update(tap=bool(value))

    def set_touchpad_natural(self, value):
        self._write_touchpad("touchpadNatural", "true" if value else "false")
        self.update(touchpadNatural=bool(value))

    def set_typing_off(self, value):
        self._write_touchpad("typingOff", "true" if value else "false")
        self.update(typingOff=bool(value))


# ---- Keyboard -------------------------------------------------------------------------------

def key_text(keys):
    """A shortcut's key presses as Plasma writes them: "Meta+W"."""
    if not keys:
        return ""
    from PySide6.QtCore import QKeyCombination
    from PySide6.QtGui import QKeySequence
    try:
        seq = QKeySequence(*[QKeyCombination.fromCombined(int(k)) for k in keys[:4]])
    except (TypeError, ValueError):
        return ""
    return seq.toString(QKeySequence.PortableText)


# The layout switcher's own shortcut, as kglobalaccel names it.
LAYOUT_SWITCHER = ("KDE Keyboard Layout Switcher", "Switch to Next Keyboard Layout")


class KeyboardArea(Area):
    """Typing (kcminputrc [Keyboard]) and the layouts (kxkbrc [Layout]),
    Plasma's own files: written there so that Plasma sets the keyboard the
    same way at the next start, and set now with xset and setxkbmap."""

    ACTS = {
        "repeat": "set_repeat",
        "delay": "set_delay",
        "rate": "set_rate",
        "numLock": "set_num_lock",
        "addLayout": "add_layout",
        "removeLayout": "remove_layout",
        "firstLayout": "first_layout",
        "catalog": "load_catalog",
    }
    # kcminputrc [Keyboard] NumLock: 0 on, 1 off, 2 left as it was.
    NUM_LOCK = {"on": 0, "off": 1, "keep": 2}

    catalogChanged = Signal()

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._read = False
        self._xkb = {}
        self._labels = None
        self._catalog = []
        self._model = ""
        self.update(known=False, repeat=True, delay=600, rate=25, numLock="keep",
                    layouts=[], layoutsKnown=False, switchKeys="", catalogKnown=False)

    def _get_catalog(self):
        return self._catalog

    # Over a thousand lines: kept out of `state`, which is handed to the page
    # whole at every change.
    catalog = Property("QVariantList", _get_catalog, notify=catalogChanged)

    @Slot(bool)
    def watch(self, on):
        if on:
            self._read = False
        super().watch(on)

    def _names(self):
        if self._labels is None:
            self._labels = {e["key"]: e["label"] for e in
                            readers.xkb_layouts(read_file(readers.XKB_RULES, 4 << 20))}
        return self._labels

    @Slot()
    def refresh(self):
        if self._read:
            return
        self._read = True
        for key, default, name in (("KeyRepeat", "repeat", "repeat"), ("RepeatDelay", "600", "delay"),
                                   ("RepeatRate", "25", "rate"), ("NumLock", "2", "numLock")):
            self.run(commands.read_config("kcminputrc", "Keyboard", key, default),
                     lambda c, o, name=name, default=default: self._got_typing(name, o if c == 0 else default))
        self._xkb = {}
        for key, default in (("Use", "false"), ("LayoutList", ""), ("VariantList", "")):
            self.run(commands.read_config("kxkbrc", "Layout", key, default),
                     lambda c, o, key=key: self._got_xkb(key, o if c == 0 else ""))
        self.run(commands.READ_XKB, lambda c, o: self._got_xkb("query", o if c == 0 else ""))
        self.run(commands.READ_SHORTCUTS, self._got_shortcuts)

    def _got_typing(self, name, text):
        text = text.strip()
        if name == "repeat":
            self.update(repeat=text != "nothing")
        elif name == "delay":
            self.update(delay=readers.config_int(text, 600))
        elif name == "rate":
            try:
                self.update(rate=int(round(float(text))))
            except ValueError:
                self.update(rate=25)
        else:
            n = readers.config_int(text, 2)
            self.update(numLock={0: "on", 1: "off"}.get(n, "keep"), known=True)

    def _got_xkb(self, key, text):
        self._xkb[key] = text
        if len(self._xkb) < 4:
            return
        query = readers.xkb_query(self._xkb["query"])
        self._model = (query["model"] or [""])[0]
        layouts = readers.config_list(self._xkb["LayoutList"])
        variants = readers.config_list(self._xkb["VariantList"])
        if not readers.config_bool(self._xkb["Use"], False) or not layouts:
            # Plasma is not setting the keyboard: it is what X was started
            # with (/etc/default/keyboard), which setxkbmap says.
            layouts, variants = query["layout"], query["variant"]
        keys = []
        for i, layout in enumerate(layouts):
            key = readers.layout_key(layout, variants[i] if i < len(variants) else "")
            if readers.split_layout_key(key) and key not in keys:
                keys.append(key)
        self._show(keys)

    def _show(self, keys):
        names = self._names()
        self.update(layoutsKnown=True,
                    layouts=[{"key": k, "label": names.get(k, k)} for k in keys])

    def _got_shortcuts(self, code, out):
        for a in readers.shortcut_actions(out) if code == 0 else []:
            if (a["component"], a["action"]) == LAYOUT_SWITCHER:
                self.update(switchKeys=key_text(a["keys"]))
                return
        self.update(switchKeys="")

    # -- typing --

    def _write(self, key, value, kind=None):
        self.run(commands.write_config("kcminputrc", "Keyboard", key, value, kind))

    def set_repeat(self, value):
        on = bool(value)
        self._write("KeyRepeat", "repeat" if on else "nothing")
        self.run(commands.set_repeat(on))
        if on:
            self.run(commands.set_repeat_rate(self._state["delay"], self._state["rate"]))
        self.update(repeat=on)

    def set_delay(self, value):
        try:
            d = max(100, min(1000, int(value)))
        except (TypeError, ValueError):
            return
        self._write("RepeatDelay", str(d))
        self.run(commands.set_repeat_rate(d, self._state["rate"]))
        self.update(delay=d)

    def set_rate(self, value):
        try:
            r = max(1, min(100, int(value)))
        except (TypeError, ValueError):
            return
        self._write("RepeatRate", str(r))
        self.run(commands.set_repeat_rate(self._state["delay"], r))
        self.update(rate=r)

    def set_num_lock(self, value):
        if value in self.NUM_LOCK:
            self._write("NumLock", str(self.NUM_LOCK[value]))
            self.update(numLock=value)

    # -- layouts --

    def _keys(self):
        return [l["key"] for l in self._state.get("layouts", [])]

    def _set_layouts(self, keys):
        if not keys or any(readers.split_layout_key(k) is None for k in keys):
            return
        pairs = [readers.split_layout_key(k) for k in keys]
        names = self._names()
        write = commands.write_config
        steps = [write("kxkbrc", "Layout", "LayoutList", ",".join(p[0] for p in pairs)),
                 write("kxkbrc", "Layout", "VariantList", ",".join(p[1] for p in pairs)),
                 write("kxkbrc", "Layout", "DisplayNames", "," * (len(pairs) - 1)),
                 write("kxkbrc", "Layout", "Use", "true", "bool")]
        if self._model:
            # Plasma's own model is a US keyboard's, which has no key beside
            # the left Shift; the one X found is kept.
            steps.append(write("kxkbrc", "Layout", "Model", self._model))
        steps += [commands.set_layouts(keys), commands.KEYBOARD_RELOAD]

        def next_step(code=0, out=""):
            if steps:
                self.run(steps.pop(0), next_step)
        next_step()
        self.update(layouts=[{"key": k, "label": names.get(k, k)} for k in keys])

    def add_layout(self, key):
        keys = self._keys()
        if isinstance(key, str) and key in self._names() and key not in keys:
            self._set_layouts(keys + [key])

    def remove_layout(self, key):
        keys = self._keys()
        if key in keys and len(keys) > 1:
            self._set_layouts([k for k in keys if k != key])

    def first_layout(self, key):
        keys = self._keys()
        if key in keys and keys[0] != key:
            self._set_layouts([key] + [k for k in keys if k != key])

    def load_catalog(self, _value):
        if not self._catalog:
            self._catalog = readers.xkb_layouts(read_file(readers.XKB_RULES, 4 << 20))
            self.catalogChanged.emit()
        self.update(catalogKnown=True)


# ---- Keyboard shortcuts ----------------------------------------------------------------------

class ShortcutsArea(Area):
    """Plasma's global shortcuts, through kglobalaccel (global-shortcuts)."""

    ACTS = {"set": "set_key", "clear": "clear", "reset": "reset"}

    # Ctrl, Shift, Alt, Meta and the keypad: what a shortcut is made of.
    # Group-switch (the third level of some layouts) is not.
    MODIFIERS = 0x02000000 | 0x04000000 | 0x08000000 | 0x10000000 | 0x20000000

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._read = False
        self._actions = []
        self.update(known=False, available=True, actions=[], note="")

    @Slot(bool)
    def watch(self, on):
        if on:
            self._read = False
            # What went wrong last time the page was open is not news now.
            self.update(note="")
        super().watch(on)

    @Slot()
    def refresh(self):
        if not self._read:
            self._read = True
            self.run(commands.READ_SHORTCUTS, self._got)

    def _got(self, code, out):
        self._actions = readers.shortcut_actions(out) if code == 0 else []
        shown = []
        for a in sorted(self._actions, key=lambda a: (a["componentName"].lower(), a["name"].lower())):
            shown.append({"id": a["component"] + "\x1f" + a["action"], "name": a["name"],
                          "componentName": a["componentName"],
                          "keys": key_text(a["keys"]), "defaults": key_text(a["defaults"])})
        self.update(known=True, available=code == 0, actions=shown)

    def _find(self, ident):
        if not isinstance(ident, str) or "\x1f" not in ident:
            return None
        component, action = ident.split("\x1f", 1)
        return next((a for a in self._actions
                     if a["component"] == component and a["action"] == action), None)

    def _give(self, a, key):
        self.run(commands.set_shortcut(a["component"], a["action"], a["componentName"],
                                       a["name"], key),
                 lambda c, o: self._done(c))

    def _done(self, code):
        self.update(note="" if code == 0 else "Plasma's shortcut service would not change it.")
        self.run(commands.READ_SHORTCUTS, self._got)

    def set_key(self, value):
        if not isinstance(value, dict):
            return
        a = self._find(value.get("id"))
        try:
            key = int(value.get("key"))
            mods = int(value.get("modifiers") or 0) & self.MODIFIERS
        except (TypeError, ValueError):
            return
        if a is None or key <= 0 or key >= 0x02000000:
            return
        combined = mods | key
        for other in self._actions:
            if other is not a and other["keys"] == [combined]:
                self.update(note="%s is already %s, in %s. Clear that one first, or press another."
                            % (key_text([combined]), other["name"], other["componentName"]))
                return
        self._give(a, combined)

    def clear(self, ident):
        a = self._find(ident)
        if a is not None:
            self._give(a, None)

    def reset(self, ident):
        a = self._find(ident)
        if a is None:
            return
        if a["defaults"]:
            for other in self._actions:
                if other is not a and other["keys"] == a["defaults"][:1]:
                    self.update(note="%s is %s's now, in %s. Clear that one first."
                                % (key_text(a["defaults"][:1]), other["name"], other["componentName"]))
                    return
            self._give(a, a["defaults"][0])
        else:
            self._give(a, None)


# ---- Personalization ------------------------------------------------------------------------

APPLETSRC = os.path.expanduser("~/.config/plasma-org.kde.plasma.desktop-appletsrc")
IMAGE_APPLETSRC = "/etc/xdg/plasma-org.kde.plasma.desktop-appletsrc"
USER_DIRS = os.path.expanduser("~/.config/user-dirs.dirs")


class LookArea(Area):
    """The desktop's picture, and the lock screen's with it.

    Read from Plasma's own file for the desktop, and from the folders once a
    time the page is opened (and after a change): not every few seconds,
    which would read the Pictures folder over and over for nothing."""

    ACTS = {"picture": "set_picture"}

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._read = False
        self._busy = False
        self.update(known=False, current="", choices=[], folder="", busy=False, note="")

    @Slot(bool)
    def watch(self, on):
        if on:
            self._read = False
        super().watch(on)

    @Slot()
    def refresh(self):
        if self._read:
            return
        self._read = True
        home = os.path.expanduser("~")
        current = (readers.desktop_wallpaper(read_file(APPLETSRC, 1 << 20))
                   or readers.desktop_wallpaper(read_file(IMAGE_APPLETSRC, 1 << 20)))
        folder = readers.user_dirs(read_file(USER_DIRS), home).get(
            "PICTURES", os.path.join(home, "Pictures"))
        found = readers.pictures(folder) if os.path.isdir(folder) else []
        self.update(known=True, current=current, folder=os.path.basename(folder),
                    choices=readers.wallpaper_choices(current, found))

    def set_picture(self, value):
        offered = [c["path"] for c in self._state.get("choices", [])]
        if self._busy or not isinstance(value, str) or value not in offered \
                or value == self._state.get("current"):
            return
        self._busy = True
        self.update(busy=True, note="")

        def lock_too(code=0, out=""):
            self.run(commands.LOCK_PLUGIN)
            self.run(commands.set_lock_picture(value))

        def done(code, out):
            self._busy = False
            if code == 0:
                lock_too()
                # Plasma writes its file a moment after it changes the
                # desktop; read now, it would still say the picture before.
                # The tool said it was done, so the page says so.
                self.update(busy=False, current=value,
                            choices=[dict(c, chosen=c["path"] == value)
                                     for c in self._state.get("choices", [])])
            else:
                text = (out or "").strip().splitlines()
                self.update(busy=False, note="The picture was not put on the desktop%s"
                            % (": " + text[-1].strip().rstrip(".") + "." if text else "."))
        self.run(commands.set_wallpaper(value), done, 60, merge=True)


# ---- Apps -----------------------------------------------------------------------------------

APPLICATION_DIRS = [os.path.expanduser("~/.local/share/applications"),
                    "/usr/share/applications"]
MIMEAPPS_LISTS = [os.path.expanduser("~/.config/mimeapps.list"),
                  "/etc/xdg/mimeapps.list",
                  "/usr/share/applications/mimeapps.list",
                  "/usr/share/applications/defaults.list"]


class AppsArea(Area):
    """Which program opens each kind of file, and the programs there are.

    Read in Python from the desktop's own files, once each time the page is
    opened (a computer's programs do not change every few seconds), and
    again after a change."""

    ACTS = {
        "default": "set_default",
        "start": "start",
        "discover": "discover",
    }

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._read = False
        self._entries = {}
        self._busy = False
        self.update(known=False, kinds=[], programs=[], note="")

    @Slot(bool)
    def watch(self, on):
        if on:
            self._read = False
        super().watch(on)

    @Slot()
    def refresh(self):
        if self._read:
            return
        self._read = True
        self._entries = readers.desktop_entries(APPLICATION_DIRS)
        lists = [read_file(p, 1 << 20) for p in MIMEAPPS_LISTS]
        self.update(known=True, kinds=readers.app_kinds(self._entries, lists),
                    programs=readers.installed_programs(self._entries))

    def set_default(self, value):
        value = value if isinstance(value, dict) else {}
        found = readers.APP_KIND_KEYS.get(value.get("kind"))
        ident = value.get("app")
        if found is None or self._busy or not isinstance(ident, str):
            return
        kind = next((k for k in self._state.get("kinds", []) if k["key"] == found[0]), None)
        if kind is None or ident not in [o["key"] for o in kind["options"]] \
                or ident == kind["current"]:
            return
        steps = [commands.set_default_program(m, ident) for m in found[3]]
        steps.append(commands.REREAD_PROGRAMS)
        self._busy = True
        failed = []

        def next_step(code=0, out=""):
            if code != 0:
                failed.append(code)
            if steps:
                self.run(steps.pop(0), next_step, 60)
                return
            self._busy = False
            if failed:
                self.update(note="%s may not open in %s everywhere yet: a step "
                                 "did not finish." % (found[1], self._entries[ident]["name"]))
            self._read = False
            self.refresh()
        self.update(note="")
        next_step()

    def start(self, value):
        entry = self._entries.get(value) if isinstance(value, str) else None
        if entry is not None and not self.runner.launch(commands.start_program(entry["path"])):
            self.update(note="%s could not be started." % entry["name"])

    def discover(self, _value):
        if not self.runner.launch(commands.DISCOVER):
            self.update(note="Discover, where programs are added and removed, could not be opened.")


# ---- Updates --------------------------------------------------------------------------------

class UpdatesArea(Area):
    """What is waiting to be updated, and when the computer last looked;
    the installing itself is Discover's (it asks for the password, shows
    the progress, and says when a restart is wanted)."""

    ACTS = {"install": "install"}
    SHOWN = 40

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._read = False
        self.update(known=False, failed=False, count=0, security=0, waiting=[],
                    checked="", automatic=False, note="", live=os.path.isdir("/run/live"),
                    solvaneVersion="", solvaneBuilt="", solvaneFrom="", solvaneReached=False)

    @Slot(bool)
    def watch(self, on):
        if on:
            self._read = False
        super().watch(on)

    @Slot()
    def refresh(self):
        if self._read:
            return
        self._read = True
        self.run(commands.READ_PERIODIC, self._got_periodic)
        self.run(commands.READ_UPGRADABLE, self._got_upgradable, 60)
        self.run(commands.READ_SOLVANE_VERSION, self._got_solvane)
        # Where Solvane's own updates come from, and whether apt has ever
        # had an answer from there (the lists it keeps are named after it).
        address = readers.solvane_address(read_file(readers.SOLVANE_SOURCES))
        reached = False
        if address:
            start = readers.apt_list_name(address)
            try:
                reached = any(n.startswith(start) and n.endswith("InRelease")
                              for n in os.listdir(readers.APT_LISTS))
            except OSError:
                reached = False
        self.update(solvaneFrom=address, solvaneReached=reached)

    def _got_solvane(self, code, out):
        v = readers.solvane_version(out) if code == 0 else None
        built = ""
        if v and v["built"]:
            built = "%s %d, %d" % (readers.MONTH_NAMES[v["built"].month - 1], v["built"].day,
                                   v["built"].year)
        self.update(solvaneVersion=v["version"] if v else "", solvaneBuilt=built)

    def _got_periodic(self, code, out):
        periodic = readers.apt_periodic(out) if code == 0 else {}
        self.update(automatic=periodic.get("Unattended-Upgrade", "0") not in ("0", ""))

    def _got_upgradable(self, code, out):
        import datetime
        if code != 0:
            self.update(known=True, failed=True)
            return
        waiting = readers.apt_upgradable(out)
        try:
            stamp = datetime.datetime.fromtimestamp(os.path.getmtime(readers.UPDATE_STAMP))
        except OSError:
            stamp = None
        self.update(known=True, failed=False, count=len(waiting),
                    security=sum(1 for w in waiting if w["security"]),
                    waiting=waiting[:self.SHOWN],
                    checked=readers.when_words(stamp, datetime.datetime.now()))

    def install(self, _value):
        if not self.runner.launch(commands.DISCOVER_UPDATES):
            self.update(note="Discover, which installs updates, could not be opened.")
        else:
            # What is waiting will have changed by the time this page is
            # looked at again.
            self._read = False


# ---- Bluetooth ------------------------------------------------------------------------------

class BluetoothArea(Area):
    """The adapter and its devices, through Settings' bluetooth helper
    (BlueZ over D-Bus). Pairing is given minutes: a device may ask for a
    number to be confirmed, in Plasma's own window, and somebody has to
    look at both screens."""

    ACTS = {
        "power": "set_power",
        "look": "look",
        "pair": "pair",
        "connect": "connect",
        "disconnect": "disconnect",
        "forget": "forget",
        "more": "more",
    }

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._busy = False
        self.update(known=False, failed=False, adapter=False, powered=False, name="",
                    paired=[], found=[], looking=False, busy="", note="")

    @Slot()
    def refresh(self):
        if not self._busy:
            self.run(commands.READ_BLUETOOTH, self._got, 20)

    def _got(self, code, out):
        st = readers.bluetooth_state(out) if code == 0 else None
        if st is None:
            self.update(known=True, failed=True)
            return
        devices = st["devices"]
        self.update(known=True, failed=False, adapter=st["adapter"], powered=st["powered"],
                    name=st["name"],
                    paired=[d for d in devices if d["paired"]],
                    found=[d for d in devices if not d["paired"] and d["named"]])

    def _device(self, address):
        for d in self._state.get("paired", []) + self._state.get("found", []):
            if d["address"] == address:
                return d
        return None

    def _do(self, argv, failed, seconds, busy=""):
        self._busy = True
        self.update(busy=busy, note="")

        def done(code, out):
            self._busy = False
            self.update(busy="", looking=False, note=readers.bluetooth_outcome(out, failed))
            self.refresh()
        self.run(argv, done, seconds, merge=True)

    def set_power(self, value):
        if self._state.get("adapter") and not self._busy:
            self._do(commands.bluetooth_power(bool(value)),
                     "Bluetooth was not turned %s" % ("on" if value else "off"), 30)

    def look(self, _value):
        if not (self._state.get("adapter") and self._state.get("powered")) or self._busy:
            return
        self._busy = True
        self.update(looking=True, note="")

        def done(code, out):
            self._busy = False
            self.update(looking=False)
            self._got(code, out)
        self.run(commands.bluetooth_scan(12), done, 40)

    def _on_device(self, verb, value, failed, seconds, busy=""):
        d = self._device(value) if isinstance(value, str) else None
        if d is not None and not self._busy:
            self._do(commands.bluetooth_device(verb, d["address"]), failed % d["name"],
                     seconds, busy % d["name"] if busy else "")

    def pair(self, value):
        self._on_device("pair", value, "%s was not paired", 150, "Pairing with %s…")

    def connect(self, value):
        self._on_device("connect", value, "%s did not connect", 45, "Connecting to %s…")

    def disconnect(self, value):
        self._on_device("disconnect", value, "%s did not disconnect", 30)

    def forget(self, value):
        self._on_device("remove", value, "%s was not forgotten", 30)

    def more(self, _value):
        # What this page does not do yet - sending and receiving files, a
        # device's own details - in Plasma's own window for Bluetooth.
        if not self.runner.launch(commands.MORE_BLUETOOTH):
            self.update(note="Plasma's Bluetooth settings could not be opened.")


# ---- Accounts -------------------------------------------------------------------------------

AVATAR_DIRS = ["/usr/share/plasma/avatars"]


class AccountsArea(Area):
    """This account - its name, its picture, its password - and the other
    people who have one here, through AccountsService (busctl) and passwd
    (account-password); someone added or removed through Settings' people
    helper (AccountsService too, the new password on its standard input)."""

    ACTS = {
        "name": "set_name",
        "picture": "set_picture",
        "password": "set_password",
        "suggest": "suggest",
        "add": "add_person",
        "remove": "remove_person",
        "more": "more",
    }

    # polkit's window waits for a person, three times at the most (the
    # account, its shell, its password).
    PEOPLE_SECONDS = 960

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._read = False
        self._path = ""
        self._busy = False
        self._found = []
        self._signed = None
        # A disc's accounts are gone at the next restart: nobody is added
        # to one.
        self.update(known=False, failed=False, login="", name="", admin=False,
                    picture="", pictureUrl="", pictures=[], others=[], busy="", note="",
                    passwordNote="", passwordChanged=False, live=os.path.isdir("/run/live"),
                    suggestion="", peopleNote="", added="", addedLogin="")

    @Slot(bool)
    def watch(self, on):
        if on:
            self._read = False
        super().watch(on)

    @Slot()
    def refresh(self):
        if self._read:
            return
        self._read = True
        import getpass
        self.run(commands.find_account(getpass.getuser()), self._got_path)
        self.run(commands.READ_ACCOUNTS, self._got_paths)
        self.run(commands.READ_SIGNED_IN, self._got_signed)
        home = os.path.expanduser("~")
        folder = readers.user_dirs(read_file(USER_DIRS), home).get(
            "PICTURES", os.path.join(home, "Pictures"))
        found = []
        for d in AVATAR_DIRS:
            found += readers.pictures(d, 24)
        found += readers.pictures(folder, 12) if os.path.isdir(folder) else []
        from urllib.parse import quote
        self.update(pictures=[{"path": p["path"], "url": "file://" + quote(p["path"])}
                              for p in found])

    def _got_path(self, code, out):
        self._path = readers.busctl_path(out) if code == 0 else ""
        if not self._path:
            self.update(known=True, failed=True)
            return
        self.run(commands.read_account(self._path), self._got_me)

    def _got_me(self, code, out):
        me = readers.account(out) if code == 0 else None
        if me is None:
            self.update(known=True, failed=True)
            return
        from urllib.parse import quote
        url = "file://" + quote(me["picture"]) if me["picture"] and os.path.isfile(me["picture"]) else ""
        self.update(known=True, failed=False, login=me["login"], name=me["name"],
                    admin=me["admin"], picture=me["picture"], pictureUrl=url)

    def _got_paths(self, code, out):
        paths = readers.busctl_paths(out) if code == 0 else []
        found = []

        def one(path, code, out):
            a = readers.account(out) if code == 0 else None
            if a is not None and not a["system"]:
                found.append(a)
            if len(seen) == len(paths):
                import getpass
                me = getpass.getuser()
                self._found = [a for a in found if a["login"] != me]
                self._show_others()
        seen = []
        for path in paths:
            def done(c, o, path=path):
                seen.append(path)
                one(path, c, o)
            self.run(commands.read_account(path), done)
        if not paths:
            self._found = []
            self._show_others()

    def _got_signed(self, code, out):
        self._signed = readers.signed_in(out) if code == 0 else None
        self._show_others()

    def _show_others(self):
        # Removable: not signed in now, as far as logind says - and when it
        # has not said, nobody is (people says the same).
        signed = self._signed
        self.update(others=sorted(
            [{"login": a["login"], "name": a["name"] or a["login"], "admin": a["admin"],
              "home": a["home"], "signedIn": signed is not None and a["login"] in signed,
              "removable": signed is not None and a["login"] not in signed}
             for a in self._found],
            key=lambda a: a["name"].casefold()))

    def _change(self, argv, failed):
        self._busy = True
        self.update(busy="Making the change…", note="")

        def done(code, out):
            self._busy = False
            self.update(busy="", note="" if code == 0 else readers.nm_failure(out, failed))
            self._read = False
            self.refresh()
        self.run(argv, done, 300, merge=True)

    def set_name(self, value):
        name = readers.valid_real_name(value)
        if name is None:
            self.update(note="A name cannot have a colon or a comma in it, or be longer than 64 letters.")
            return
        if self._path and not self._busy and name != self._state.get("name"):
            self._change(commands.set_real_name(self._path, name), "Your name was not changed")

    def set_picture(self, value):
        offered = [p["path"] for p in self._state.get("pictures", [])]
        if self._path and not self._busy and value in offered:
            self._change(commands.set_picture(self._path, value), "Your picture was not changed")

    def set_password(self, value):
        value = value if isinstance(value, dict) else {}
        current, new, again = value.get("current"), value.get("new"), value.get("again")
        if self._busy or not all(isinstance(v, str) for v in (current, new, again)):
            return
        if new != again:
            self.update(passwordNote="The new password and its second typing are not the same.",
                        passwordChanged=False)
            return
        if not new:
            self.update(passwordNote="The new password is empty.", passwordChanged=False)
            return
        self._busy = True
        self.update(busy="Changing the password…", passwordNote="", passwordChanged=False)

        def done(code, out):
            self._busy = False
            said = readers.password_outcome(out)
            self.update(busy="", passwordNote=said, passwordChanged=said == "")
        self.run([commands.ACCOUNT_PASSWORD], done, 60, merge=True,
                 stdin=current + "\n" + new + "\n")

    def suggest(self, value):
        # The username the First Start would have offered for that name.
        self.update(suggestion=readers.suggest_login(value if isinstance(value, str) else ""))

    def add_person(self, value):
        value = value if isinstance(value, dict) else {}
        name, login = value.get("name"), value.get("login")
        password, again = value.get("password"), value.get("again")
        if self._busy or self._state.get("live") or not all(
                isinstance(v, str) for v in (name, login, password, again)):
            return
        shown = readers.valid_real_name(name) if name.strip() else login
        if shown is None:
            self.update(peopleNote="A name cannot have a colon or a comma in it, or be "
                                   "longer than 64 letters.", added="")
            return
        if not login:
            self.update(peopleNote="A username is needed: what they will sign in with.", added="")
            return
        if password != again:
            self.update(peopleNote="The password and its second typing are not the same.", added="")
            return
        if not password:
            self.update(peopleNote="A password is needed, so that nobody else can sign in "
                                   "as them.", added="")
            return
        self._busy = True
        self.update(busy="Adding %s…" % shown, peopleNote="", added="")

        def done(code, out):
            self._busy = False
            said = readers.people_outcome(out, "%s was not added" % shown)
            self.update(busy="", peopleNote=said, added=shown if said == "" else "",
                        addedLogin=login if said == "" else "")
            self._read = False
            self.refresh()
        self.run(commands.ADD_PERSON, done, self.PEOPLE_SECONDS, merge=True,
                 stdin=json.dumps({"login": login, "name": shown, "admin": value.get("admin") is True,
                                   "password": password}) + "\n")

    def remove_person(self, value):
        value = value if isinstance(value, dict) else {}
        login = value.get("login")
        who = [a for a in self._state.get("others", []) if a["login"] == login]
        if self._busy or self._state.get("live") or not who or not who[0]["removable"]:
            return
        shown = who[0]["name"]
        self._busy = True
        self.update(busy="Removing %s…" % shown, peopleNote="", added="")

        def done(code, out):
            self._busy = False
            said = readers.people_outcome(out, "%s was not removed" % shown)
            self.update(busy="", peopleNote=said or "%s's account has been removed." % shown)
            self._read = False
            self.refresh()
        self.run(commands.REMOVE_PERSON, done, self.PEOPLE_SECONDS, merge=True,
                 stdin=json.dumps({"login": login, "files": value.get("files") is True}) + "\n")

    def more(self, _value):
        if not self.runner.launch(commands.MORE_ACCOUNTS):
            self.update(note="Plasma's page for people's accounts could not be opened.")


# ---- Privacy --------------------------------------------------------------------------------

class PrivacyArea(Area):
    """The files opened lately, forgotten on request; and what this computer
    asks the internet, said (the page's own words, true of the image)."""

    ACTS = {"forget": "forget", "more": "more"}

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self.update(known=True, busy=False, forgotten=False, note="")

    def forget(self, _value):
        if self._state.get("busy"):
            return
        self.update(busy=True, forgotten=False, note="")
        # The freedesktop.org list first: a file of the person's own.
        path = os.path.expanduser(commands.RECENTLY_USED)
        listed = True
        if os.path.exists(path):
            try:
                with open(path, "w") as f:
                    f.write(commands.EMPTY_XBEL)
            except OSError:
                listed = False

        def done(code, out):
            ok = code == 0 and listed
            self.update(busy=False, forgotten=ok,
                        note="" if ok else "Not everything could be forgotten: "
                        + ("the activity manager did not answer." if code != 0
                           else "the list of recent files could not be written."))
        self.run(commands.FORGET_RECENT, done, 30, merge=True)

    def more(self, _value):
        if not self.runner.launch(commands.MORE_RECENT):
            self.update(note="Plasma's page for recent files could not be opened.")


# ---- Network --------------------------------------------------------------------------------

class NetworkArea(Area):
    """Wi-Fi and wired, through NetworkManager (nmcli), as the Control
    Center's tiles read it.

    A network with a password is joined by wifi-join, which takes the
    password on its standard input and hands it to NetworkManager over
    D-Bus: on a command line every program on the computer could read it.
    It waits to hear whether the password was right, and so does the page.

    Removing a remembered network, or joining one for everybody on the
    computer, may ask polkit for an administrator's password: those are
    given minutes, not seconds."""

    ACTS = {
        "wifi": "set_wifi",
        "join": "join",
        "password": "join_with_password",
        "cancel": "cancel",
        "disconnect": "disconnect",
        "forget": "forget",
        "more": "more",
    }
    ASKING_SECONDS = 300

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._saved = []
        self._busy = False
        # A look for networks can take longer than the few seconds between
        # askings; a second is not started while one is still out.
        self._looking = False
        self.update(known=False, failed=False, hasWifi=False, wifiDevice="",
                    switchOn=True, wifiOn=False, wifiState="", wifiConnection="",
                    networks=[], wired=[], asking="", askingKind="", joining="",
                    note="")

    @Slot()
    def refresh(self):
        self.run(commands.READ_NET_DEVICES, self._got_devices)

    def _got_devices(self, code, out):
        if code != 0:
            self.update(known=True, failed=True)
            return
        devices = readers.nm_devices(out)
        wifi = next((d for d in devices if d["type"] == "wifi"), None)
        wired = [d for d in devices if d["type"] == "ethernet"]
        old = {w["device"]: w.get("address", "") for w in self._state.get("wired", [])}
        self.update(known=True, failed=False, hasWifi=wifi is not None,
                    wifiDevice=wifi["device"] if wifi else "",
                    wifiState=wifi["state"] if wifi else "",
                    wifiConnection=wifi["connection"] if wifi else "",
                    wired=[{"device": w["device"], "state": w["state"],
                            "words": readers.wired_words(w["state"]),
                            "address": old.get(w["device"], "") if w["state"] == "connected" else ""}
                           for w in wired])
        for w in wired:
            if w["state"] == "connected":
                self.run(commands.read_address(w["device"]),
                         lambda c, o, d=w["device"]: self._got_address(d, o if c == 0 else ""))
        if wifi is None:
            self.update(networks=[], wifiOn=False)
        elif not self._looking:
            # What is remembered first: a network's row says whether it is.
            self._looking = True
            self.run(commands.READ_SAVED_NETWORKS,
                     lambda c, o: self._got_saved(o if c == 0 else ""))

    def _got_address(self, device, out):
        address = readers.nm_address(out)
        self.update(wired=[dict(w, address=address) if w["device"] == device else w
                           for w in self._state.get("wired", [])])

    def _got_radio(self, code, out):
        switch, on = readers.nm_radio(out) if code == 0 else (True, False)
        self.update(switchOn=switch, wifiOn=switch and on)
        if switch and on:
            self.run(commands.READ_NETWORKS, self._got_networks, 30)
        else:
            self._looking = False
            self.update(networks=[])

    def _got_saved(self, out):
        self._saved = readers.nm_saved(out)
        self.run(commands.READ_WIFI_RADIO, self._got_radio)

    def _got_networks(self, code, out):
        self._looking = False
        nets = readers.nm_wifi(out) if code == 0 else []
        shown = []
        for n in nets:
            words = []
            if n["active"]:
                words.append("Connected")
            words.append("Open" if n["join"] == "open" else "Secured")
            words.append(readers.signal_words(n["signal"]))
            shown.append({"ssid": n["ssid"], "join": n["join"], "active": n["active"],
                          "saved": n["ssid"] in self._saved, "words": " · ".join(words)})
        self.update(networks=shown)

    def _network(self, ssid):
        return next((n for n in self._state.get("networks", []) if n["ssid"] == ssid), None)

    def _changed(self, argv, failed, seconds=None, stdin=None, outcome=None):
        """Run a change; `failed` is the sentence for when it does not take
        ("HomeNet was not joined"), finished with nmcli's reason."""
        self._busy = True
        self.update(note="")

        def done(code, out):
            self._busy = False
            if outcome is not None:
                note = outcome(out)
            else:
                note = "" if code == 0 else readers.nm_failure(out, failed)
            self.update(joining="", note=note)
            self.refresh()
        self.run(argv, done, seconds or self.ASKING_SECONDS, merge=True, stdin=stdin)

    def set_wifi(self, value):
        if self._state.get("hasWifi") and self._state.get("switchOn"):
            self._changed(commands.set_wifi_radio(bool(value)),
                          "Wi-Fi was not turned %s" % ("on" if value else "off"), 30)

    def join(self, value):
        net = self._network(value)
        if net is None or net["active"] or self._busy:
            return
        ssid = net["ssid"]
        if net["saved"]:
            self.update(joining=ssid)
            self._changed(commands.join_saved(ssid), "%s was not joined" % ssid, 90)
        elif net["join"] == "open":
            self.update(joining=ssid)
            self._changed(commands.join_open(ssid), "%s was not joined" % ssid, 90)
        elif net["join"] in ("psk", "sae"):
            self.update(asking=ssid, askingKind=net["join"], note="")
        else:
            self.update(note="Settings cannot join %s yet: it needs WEP, which is no "
                             "longer safe, or a name as well as a password." % ssid)

    def join_with_password(self, value):
        value = value if isinstance(value, dict) else {}
        ssid, password = self._state.get("asking"), value.get("password")
        kind = self._state.get("askingKind")
        if not ssid or not isinstance(password, str) or kind not in ("psk", "sae") \
                or self._busy:
            return
        self.update(asking="", askingKind="", joining=ssid)
        self._changed(commands.join_secured(ssid, kind), "%s was not joined" % ssid, 90,
                      stdin=password + "\n",
                      outcome=lambda out: readers.join_outcome(out, ssid))

    def cancel(self, _value):
        self.update(asking="", askingKind="")

    def disconnect(self, _value):
        if self._state.get("wifiDevice") and not self._busy:
            self._changed(commands.disconnect_device(self._state["wifiDevice"]),
                          "Wi-Fi was not disconnected", 30)

    def more(self, _value):
        # The rare jobs this page does not do yet - a VPN, a hidden network,
        # a network that wants a name as well as a password - in Plasma's
        # own window for them, as Files has "Open in Dolphin".
        if not self.runner.launch(commands.MORE_NETWORK_SETTINGS):
            self.update(note="Plasma's network settings could not be opened.")

    def forget(self, value):
        net = self._network(value)
        if net is not None and net["saved"] and not self._busy:
            self._changed(commands.forget_network(net["ssid"]),
                          "%s was not forgotten" % net["ssid"])


# ---- Time & Language --------------------------------------------------------------------

class TimeArea(Area):
    """The clock: whether it sets itself, its time zone, and the time when it
    does not - systemd's timedated, through timedatectl, as the First Start
    and the live disc's live-zone set it.

    A change timedated wants an administrator for, it asks polkit about, and
    polkit asks the person, in Plasma's own password window. So a change is
    given minutes to finish, not seconds: somebody is typing.

    The time shown is worked out here, in the zone timedated says, each time
    the page asks again - not read from this program's own idea of the zone,
    which is the one it started with."""

    ACTS = {
        "auto": "set_auto",
        "zone": "set_zone",
        "find": "find",
        "setTime": "set_time",
    }
    # Long enough to type a password into the window polkit opens.
    ASKING_SECONDS = 300

    def __init__(self, runner, parent=None):
        super().__init__(runner, parent)
        self._zones = None
        self._query = ""
        self.update(known=False, failed=False, zone="", place="", where="",
                    offset="", now="", today="", clock="", canAuto=False,
                    auto=False, synced=False, busy=False, note="",
                    found=[], zonesKnown=False, anyZones=False)

    def _all_zones(self):
        if self._zones is None:
            self._zones = readers.time_zones()
        return self._zones

    @Slot()
    def refresh(self):
        self.run(commands.READ_TIMEDATE, self._got)

    def _got(self, code, out):
        said = readers.timedate(out) if code == 0 else None
        if said is None:
            self.update(known=True, failed=True)
            return
        zone = said["zone"]
        city, where = readers.zone_place(self._all_zones(), zone)
        now = readers.zone_now(zone) or {}
        self.update(known=True, failed=False, zone=zone, place=city, where=where,
                    offset=readers.zone_offset(zone), now=now.get("words", ""),
                    today=now.get("date", ""), clock=now.get("time", ""),
                    canAuto=said["canAuto"], auto=said["auto"],
                    synced=said["synced"])

    def _asked(self, argv, what):
        self.update(busy=True, note="")

        def done(code, out):
            self.update(busy=False,
                        note="" if code == 0 else readers.timedate_failure(out, what))
            self.refresh()
        self.run(argv, done, self.ASKING_SECONDS, merge=True)

    def set_auto(self, value):
        if self._state.get("busy") or not self._state.get("canAuto"):
            return
        self._asked(commands.set_auto_time(bool(value)), "The clock")

    def set_zone(self, value):
        zone = readers.known_zone(value)
        if zone is None or self._state.get("busy") or zone == self._state.get("zone"):
            return
        self._asked(commands.set_time_zone(zone), "The time zone")

    def set_time(self, value):
        if self._state.get("busy") or self._state.get("auto"):
            return
        value = value if isinstance(value, dict) else {}
        moment = readers.manual_time(value.get("date"), value.get("time"))
        if moment is None:
            self.update(note="That is not a date and time Settings can read. "
                             "Write the date as 2026-10-20 and the time as "
                             "7:05 PM or 19:05.")
            return
        self._asked(commands.set_time(moment), "The time")

    def find(self, value):
        self._query = value if isinstance(value, str) else ""
        zones = self._all_zones()
        self.update(zonesKnown=True,
                    found=[{"key": z["key"], "city": z["city"], "where": z["where"],
                            "offset": readers.zone_offset(z["key"])}
                           for z in readers.find_zones(zones, self._query)],
                    anyZones=bool(zones))


# ---- About -----------------------------------------------------------------------------------

class AboutArea(Area):
    ACTS = {"rename": "rename", "copy": "copy"}

    def __init__(self, runner, clipboard=None, parent=None):
        super().__init__(runner, parent)
        self._clipboard = clipboard
        self._asked = False
        self.update(known=False, live=os.path.isdir("/run/live"))

    @Slot()
    def refresh(self):
        if self._asked:
            return
        self._asked = True
        release = readers.os_release(read_file("/etc/os-release"))
        cpu, cores = readers.processor(read_file("/proc/cpuinfo", 1 << 20))
        mem = readers.memory(read_file("/proc/meminfo"))
        self.update(known=True,
                    system=release.get("NAME", "Solvane OS"),
                    version=release.get("VERSION", release.get("VERSION_ID", "")),
                    processor=cpu, cores=cores,
                    memory=readers.memory_size(mem) if mem else "")
        self.run(commands.READ_HOST, self._got_host)
        self.run(commands.READ_GRAPHICS, lambda c, o: self.update(
            graphics=", ".join(readers.graphics(o)) if c == 0 else ""))
        self.run(commands.READ_PLASMA, lambda c, o: self.update(
            plasma=readers.plasma_version(o) if c == 0 else ""))
        self.run(commands.READ_DISKS, self._got_disks)

    def _got_host(self, code, out):
        h = readers.hostname(out) if code == 0 else {}
        model = " ".join(x for x in (h.get("vendor", ""), h.get("model", "")) if x)
        self.update(name=h.get("name", ""), model=model, kernel=h.get("kernel", ""),
                    chassis=h.get("chassis", ""))

    def _got_disks(self, code, out):
        try:
            data = json.loads(out) if code == 0 else {}
        except ValueError:
            data = {}
        disks = []
        for d in data.get("blockdevices", []) if isinstance(data, dict) else []:
            if not isinstance(d, dict) or d.get("type") != "disk":
                continue
            if d.get("rm") in (True, "1", 1):
                continue
            size = d.get("size")
            if isinstance(size, int) and size > 0:
                disks.append(readers.human_bytes(size))
        self.update(storage=" + ".join(disks))

    def rename(self, name):
        name = (name or "").strip().lower() if isinstance(name, str) else ""
        if not readers.valid_hostname(name) or self._state.get("live"):
            self.update(renameNote="A name of letters, digits and hyphens, up to 63.")
            return
        self.run(commands.set_hostname(name), lambda c, o: (
            self.update(name=name, renameNote="") if c == 0 else
            self.update(renameNote="The name was not changed.")))

    def copy(self, _value):
        s = self._state
        lines = ["%s %s" % (s.get("system", ""), s.get("version", "")),
                 "Device: %s" % s.get("model", ""),
                 "Processor: %s (%s threads)" % (s.get("processor", ""), s.get("cores", "")),
                 "Memory: %s" % s.get("memory", ""),
                 "Graphics: %s" % s.get("graphics", ""),
                 "Storage: %s" % s.get("storage", ""),
                 "Kernel: Linux %s" % s.get("kernel", ""),
                 "Plasma: %s" % s.get("plasma", "")]
        if self._clipboard is not None:
            self._clipboard.setText("\n".join(lines))
            self.update(copied=True)
