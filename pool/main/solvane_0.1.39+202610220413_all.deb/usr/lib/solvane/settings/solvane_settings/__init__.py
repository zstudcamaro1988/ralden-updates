# SPDX-License-Identifier: Solvane-Source
#
# Solvane OS - Settings. readers and commands are plain Python; areas and
# app need PySide6.
