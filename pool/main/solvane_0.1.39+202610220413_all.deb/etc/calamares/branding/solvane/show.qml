/* SPDX-License-Identifier: Solvane-Source
 *
 * Solvane OS — what the installer shows while it works
 *
 * TWENTY MINUTES OF SOMEBODY'S ATTENTION, AND WHAT TO DO WITH IT.
 *
 * Most installers fill this with advertising for features the person has
 * already chosen to install. That is a strange thing to do to somebody who is
 * captive and slightly anxious, watching a progress bar decide the fate of
 * their disk.
 *
 * So these slides tell them things they will need afterwards and cannot find
 * out yet, because the machine is not installed: where the window controls
 * are, what the one keyboard shortcut is, how to check the machine is intact,
 * and what to do if the laptop feels slow. Four slides, no marketing, nothing
 * that will not still be true in a year.
 */

import QtQuick
import calamares.slideshow

Presentation {
    id: presentation

    /* THE WHITE PAGE BEHIND THE SLIDES.
     *
     * Seen on the first install that ever got this far, on 4 October: every
     * other page of the installer is dark, and this one draws the slide as a
     * dark card floating on a white sheet. The slides themselves each paint
     * their own background, so the white is not theirs - it is whatever is
     * behind them, which is Calamares' own Presentation backdrop plus the
     * margin it lays slides out with.
     *
     * This fills that backdrop. It is declared FIRST so the slides, declared
     * after it, paint on top; QML draws siblings in declaration order.
     *
     * HONESTY NOTE: this has not yet been seen working. It is the right
     * shape for the cause, and the next install will say whether the cause
     * was what I think it is. If the white survives, the backdrop is outside
     * this item and the answer is a stylesheet.qss in this directory
     * instead - which is a bigger hammer and would have to be aimed
     * carefully, because the other pages are already correct and a blanket
     * QWidget rule would restyle them too.
     */
    Rectangle {
        anchors.fill: parent
        color: "#141E2D"
    }

    function onActivate() { timer.running = true }
    function onLeave() { timer.running = false }

    Timer {
        id: timer
        interval: 9000
        running: false
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    Slide {
        Rectangle {
            anchors.fill: parent
            color: "#141E2D"

            Column {
                anchors.centerIn: parent
                width: parent.width * 0.78
                spacing: 18

                Text {
                    text: "Solvane"
                    color: "#ECF1F6"
                    font.family: "Inter"; font.weight: Font.Light
                    font.pixelSize: 40; font.letterSpacing: 3
                    anchors.horizontalCenter: parent.horizontalCenter
                }
                Text {
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    color: "#8C99B0"
                    font.family: "Inter"; font.pixelSize: 17
                    text: "Debian underneath, so every driver, every update " +
                          "and every program that runs on Linux runs here. " +
                          "The rest is ours."
                }
            }
        }
    }

    Slide {
        Rectangle {
            anchors.fill: parent
            color: "#141E2D"

            Column {
                anchors.centerIn: parent
                width: parent.width * 0.78
                spacing: 16

                Text {
                    text: "The window controls are on the right"
                    color: "#ECF1F6"
                    font.family: "Inter"; font.pixelSize: 26
                    anchors.horizontalCenter: parent.horizontalCenter
                }

                /* Drawn rather than described, because this is the one thing
                 * about Solvane a person notices in the first ten seconds and
                 * a sentence about it is worse than a picture of it. */
                Rectangle {
                    width: 320; height: 58
                    radius: 10
                    color: "#1E293B"
                    border.color: "#27354A"
                    anchors.horizontalCenter: parent.horizontalCenter

                    Row {
                        anchors.right: parent.right
                        anchors.rightMargin: 16
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 10
                        Rectangle { width: 12; height: 12; radius: 6; color: "#627086" }
                        Rectangle { width: 12; height: 12; radius: 6; color: "#627086" }
                        Rectangle { width: 12; height: 12; radius: 6; color: "#4A90E2" }
                    }
                }

                Text {
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    color: "#8C99B0"
                    font.family: "Inter"; font.pixelSize: 16
                    text: "Close is the outermost one, hard against the " +
                          "corner - the only target on a screen you can hit " +
                          "without aiming. If you would rather have them on " +
                          "the left, System Settings will move them."
                }
            }
        }
    }

    Slide {
        Rectangle {
            anchors.fill: parent
            color: "#141E2D"

            Column {
                anchors.centerIn: parent
                width: parent.width * 0.78
                spacing: 16

                Text {
                    text: "One shortcut worth knowing"
                    color: "#ECF1F6"
                    font.family: "Inter"; font.pixelSize: 26
                    anchors.horizontalCenter: parent.horizontalCenter
                }

                Rectangle {
                    width: 210; height: 44; radius: 8
                    color: "#27354A"
                    anchors.horizontalCenter: parent.horizontalCenter
                    Text {
                        anchors.centerIn: parent
                        text: "Meta  +  Space"
                        color: "#ECF1F6"
                        font.family: "Hack"; font.pixelSize: 17
                    }
                }

                Text {
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    color: "#8C99B0"
                    font.family: "Inter"; font.pixelSize: 16
                    text: "Opens search. Programs, files, settings and " +
                          "arithmetic, from wherever you are. It is the same " +
                          "field as the one on the dock."
                }
            }
        }
    }

    Slide {
        Rectangle {
            anchors.fill: parent
            color: "#141E2D"

            Column {
                anchors.centerIn: parent
                width: parent.width * 0.78
                spacing: 16

                Text {
                    text: "Shield is already installed"
                    color: "#ECF1F6"
                    font.family: "Inter"; font.pixelSize: 26
                    anchors.horizontalCenter: parent.horizontalCenter
                }

                Rectangle {
                    width: 330; height: 44; radius: 8
                    color: "#27354A"
                    anchors.horizontalCenter: parent.horizontalCenter
                    Text {
                        anchors.centerIn: parent
                        text: "solvane-shield scan"
                        color: "#ECF1F6"
                        font.family: "Hack"; font.pixelSize: 16
                    }
                }

                Text {
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    color: "#8C99B0"
                    font.family: "Inter"; font.pixelSize: 16
                    text: "It compares every program and library on this " +
                          "machine against the hash its package recorded, and " +
                          "tells you what has changed. It knows that the " +
                          "files you edited are supposed to have changed."
                }
            }
        }
    }
}
