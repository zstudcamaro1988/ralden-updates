/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS — the lock screen, as drawn
 *
 * WHAT THIS LOOKS LIKE, AND WHY (27 OCTOBER 2026).
 *
 * The login screen. Seen on the VAIO, the first real machine, the owner
 * said the lock screen "should look like the login screen": until then it
 * was the lock-screen picture of 7 October (reference/6-lock.png) - large
 * thin figures in the middle and a padlock at the foot that turned into a
 * password box. Every place and size below is now the login screen's
 * (usr/share/sddm/themes/ralden/Main.qml), a hundredth of the screen's
 * height (`u`): the time and the date at the top left, the owner's
 * "Ralden" at the top with the light behind it, the glass card with the
 * person, their name, the password box and a button - Unlock, where the
 * login screen's says Sign In - and at the foot, where the login screen
 * has Sleep, Restart and Shut Down, the one thing a locked screen offers:
 * letting somebody else sign in. What is playing, when something is, is a
 * small card at the bottom right.
 *
 * Where it is not the login screen: the glass. The login screen's is a
 * picture of its own background out of focus (glass.jpg). This photograph
 * is whatever the lock screen is set to show and may be the owner's own,
 * so the card is the same pale tint over it, without the blur.
 *
 * HOW THE PASSWORD IS CHECKED, AND WHY IT CHANGED.
 *
 * On the VAIO, after the lid was closed and opened, the password was
 * refused until the owner pressed the person at the foot and signed in
 * from the login screen. That is a known fault in Plasma's locker (KDE
 * bugs 519400, 521900, 481808): waking the computer reaches the password
 * check as if it were an attempt, the check fails, and the next one is
 * refused as "too soon" - round and round. This drawing used to start the
 * check the moment the screen was touched or a key pressed, which is
 * exactly what waking a computer does.
 *
 * So now nothing is checked until somebody asks: Unlock, or Enter, with a
 * password typed. Then the check is started, and the password handed over
 * when the locker asks for it - not before, when it would be dropped. If
 * nothing comes back in twelve seconds the box is given back, with a
 * line saying to try again, rather than "Checking..." for ever. A failure
 * nobody asked for (the locker's own, on waking) is not reported as a
 * wrong password.
 *
 * ONLY QtQuick IS IMPORTED HERE. Three things lean on pieces of Plasma that
 * an update may rename - who else may sign in, what is playing, Caps Lock -
 * and each is in a file of its own, loaded from here. One that will not
 * load takes itself away and nothing else.
 *
 * WHAT THE LOCKER GIVES IT: `authenticator` (it checks the password),
 * `kscreenlocker_userName`, and the photograph, which the locker puts
 * behind everything by itself.
 */

import QtQuick

Item {
    id: lock
    objectName: "raldenLock"

    readonly property real u: height / 100
    readonly property real hair: Math.max(1, Math.round(u * 0.12))
    readonly property string face: "Inter"
    readonly property color paper: "#FFFFFF"
    readonly property color soft: "#D6DEEC"
    readonly property color ink: "#22365C"
    readonly property color quiet: "#5A6C8C"
    readonly property color wrong: "#FFB3AB"

    /* ask: the password box. free: this account has no password. */
    property string mode: "ask"
    property bool busy: false
    property bool reveal: false
    property string said: ""
    /* This account needs no password: the locker said yes without asking. */
    property bool open: false
    /* Unlock was pressed: leave as soon as the locker says yes. */
    property bool wanted: false
    /* The locker has asked for the password and not been answered. */
    property bool asked: false
    /* Unlock was pressed before the locker asked: answer when it does. */
    property bool owed: false

    readonly property string who: kscreenlocker_userName

    /* Does this person have no password? Linux's check then lets in
     * whatever is typed - seen on the VAIO, 28 October 2026: the owner,
     * who has none, typed a made-up one and was let in. So such a person
     * gets no box, only Unlock.
     *
     * Only the locker can say, so it is asked once, as the screen is put
     * up (look(), below): an account with no password is let through
     * without being asked for one (onSucceeded, with hadPrompt false), and
     * the box goes; one with a password is asked for it, and the question
     * waits for Unlock (asked). Nothing else starts a check but Unlock or
     * Enter - not a touch, not a key (see the top of this file). */
    function look() {
        if (!lock.busy && !lock.asked && !lock.open)
            authenticator.startAuthenticating()
    }
    Keys.onReturnPressed: lock.answer()
    Keys.onEnterPressed: lock.answer()

    /* For the program that photographs this screen, which has no player to
     * ask and no session to ask who else may sign in: {track, artist,
     * playing}, and whether to draw the person at the foot. The locker
     * sets neither, and what they draw does nothing when pressed. */
    property var stagedMedia: null
    property bool stagedOther: false
    readonly property var playing: stagedMedia !== null ? stagedMedia
        : (media.item !== null && media.item.present ? media.item : null)

    /* ---- the three pieces that may not be there --------------------------- */

    Loader {
        id: switcher
        source: "Switch.qml"
        /* Off to one side: what it needs from Plasma may be slow to load,
         * and the screen is not kept waiting for it. */
        asynchronous: true
    }
    Connections {
        target: switcher.item
        ignoreUnknownSignals: true
        function onAsleep() { lock.settle() }
    }
    Loader {
        id: media
        source: "Media.qml"
        /* Off to one side: what it needs from Plasma may be slow to load,
         * and the screen is not kept waiting for it. */
        asynchronous: true
    }
    Loader {
        id: caps
        source: "Caps.qml"
        /* Off to one side: what it needs from Plasma may be slow to load,
         * and the screen is not kept waiting for it. */
        asynchronous: true
    }

    /* ---- locking and unlocking ------------------------------------------- */

    /* Back to an empty box: the screen went dark, or Escape. */
    function settle() {
        watchdog.stop()
        later.stop()
        lock.reveal = false
        lock.busy = false
        lock.owed = false
        lock.wanted = false
        if (!lock.open)
            lock.said = ""
        password.text = ""
        password.forceActiveFocus()
    }

    /* Unlock, or Enter. The only place a check is started. */
    function answer() {
        if (lock.open) {
            Qt.quit()
            return
        }
        if (lock.busy || grace.running)
            return
        lock.said = ""
        lock.busy = true
        watchdog.restart()
        if (authenticator.graceLocked) {
            /* The locker is still waiting out a failure - its own, on
             * waking, as often as not - and would refuse a check started
             * now as "too soon". Pressed then, Unlock used to do nothing
             * at all. Now it waits for the locker, and goes on by itself. */
            later.start()
            return
        }
        if (password.text === "") {
            /* Nothing typed: an account with no password is let in by
             * starting the check; one with a password is asked for it. */
            lock.wanted = true
            authenticator.startAuthenticating()
            return
        }
        if (lock.asked) {
            lock.asked = false
            authenticator.respond(password.text)
        } else {
            lock.owed = true
            authenticator.startAuthenticating()
        }
    }

    Connections {
        target: authenticator
        function onPromptForSecretChanged() {
            /* Drawn as having no password, and the locker asks for one:
             * it has one. The box comes back. */
            if (lock.mode === "free" && !lock.open) {
                lock.mode = "ask"
                lock.busy = false
                lock.wanted = false
                watchdog.stop()
                lock.said = "Enter your password, then Unlock."
                password.forceActiveFocus()
                return
            }
            if (lock.owed) {
                lock.owed = false
                lock.asked = false
                authenticator.respond(password.text)
            } else {
                lock.asked = true
                if (lock.busy && password.text === "") {
                    /* Unlock with nothing typed, and there is a password. */
                    lock.busy = false
                    lock.wanted = false
                    watchdog.stop()
                    lock.said = "Enter your password, then Unlock."
                }
            }
            password.forceActiveFocus()
        }
        function onFailed(kind) {
            lock.asked = false
            lock.owed = false
            /* A failure nobody asked for is the locker's own (waking the
             * computer reaches it as an attempt): not a wrong password. */
            if (!lock.busy)
                return
            /* Only the password's own failure: a fingerprint reader that
             * did not recognise a finger says so by another road. */
            if (kind !== 0)
                return
            watchdog.stop()
            lock.busy = false
            lock.wanted = false
            lock.said = "That is not the password."
            password.text = ""
            grace.restart()
        }
        function onSucceeded() {
            watchdog.stop()
            if (authenticator.hadPrompt) {
                Qt.quit()
                return
            }
            /* Nothing was asked: this account has no password. Whatever
             * was typed while finding that out is not a password. */
            lock.open = true
            lock.busy = false
            lock.mode = "free"
            password.text = ""
            if (lock.wanted)
                Qt.quit()
        }
        function onInfoMessageChanged() {
            if (authenticator.infoMessage !== "")
                lock.said = authenticator.infoMessage
        }
        function onErrorMessageChanged() {
            if (authenticator.errorMessage !== "" && lock.busy)
                lock.said = authenticator.errorMessage
        }
    }

    /* Unlock pressed while the locker was waiting out a failure: looked at
     * twice a second, and carried on as soon as it is ready. The watchdog
     * still gives up after twelve seconds. */
    Timer {
        id: later
        interval: 500
        repeat: true
        onTriggered: {
            if (!lock.busy) {
                stop()
            } else if (!authenticator.graceLocked) {
                stop()
                lock.busy = false
                lock.answer()
            }
        }
    }

    /* After a wrong password: three seconds, then it may be tried again. */
    Timer {
        id: grace
        interval: 3000
        onTriggered: {
            if (lock.said === "That is not the password.")
                lock.said = ""
            password.forceActiveFocus()
        }
    }

    /* Nothing back from the locker: give the box back rather than wait for
     * ever. The next Unlock starts a fresh check. */
    Timer {
        id: watchdog
        interval: 12000
        onTriggered: {
            later.stop()
            lock.busy = false
            lock.owed = false
            lock.asked = false
            lock.wanted = false
            lock.said = "That took too long. Try again."
            password.forceActiveFocus()
        }
    }

    Component.onCompleted: {
        password.forceActiveFocus()
        lock.look()
    }
    Keys.onEscapePressed: lock.settle()

    /* ---- the time ---------------------------------------------------------- */

    property date now: new Date()
    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: lock.now = new Date()
    }
    /* As the login screen writes it: this computer's own short form
     * (9:43 PM, or 21:43). */
    readonly property string time:
        Qt.formatTime(lock.now, Qt.locale().timeFormat(Locale.ShortFormat))

    /* A small drawing on a grid of 24. */
    component Glyph: Canvas {
        id: glyph
        property string kind: ""
        property color colour: lock.paper
        property real weight: 1.8
        property bool struck: false
        width: lock.u * 3
        height: width
        onKindChanged: requestPaint()
        onColourChanged: requestPaint()
        onWeightChanged: requestPaint()
        onStruckChanged: requestPaint()
        onWidthChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            var k = width / 24
            c.reset()
            c.scale(k, k)
            c.lineWidth = glyph.weight
            c.lineCap = "round"
            c.lineJoin = "round"
            c.strokeStyle = glyph.colour
            c.fillStyle = glyph.colour
            c.beginPath()
            if (kind === "padlock" || kind === "unlocked") {
                /* A solid body, as the picture's is, with its keyhole cut
                 * out; the shackle a thick line - let go on one side when
                 * there is nothing to ask. */
                c.lineWidth = 2.4
                if (kind === "padlock") {
                    c.moveTo(7.4, 11)
                    c.lineTo(7.4, 8.2)
                    c.arc(12, 8.2, 4.6, Math.PI, 0, false)
                    c.lineTo(16.6, 11)
                } else {
                    c.moveTo(7.4, 11)
                    c.lineTo(7.4, 7.4)
                    c.arc(12, 7.4, 4.6, Math.PI, Math.PI * 1.95, false)
                }
                c.stroke()
                c.beginPath()
                c.moveTo(6.6, 10.4)
                c.lineTo(17.4, 10.4)
                c.arcTo(19.2, 10.4, 19.2, 12.2, 1.8)
                c.lineTo(19.2, 19.4)
                c.arcTo(19.2, 21.2, 17.4, 21.2, 1.8)
                c.lineTo(6.6, 21.2)
                c.arcTo(4.8, 21.2, 4.8, 19.4, 1.8)
                c.lineTo(4.8, 12.2)
                c.arcTo(4.8, 10.4, 6.6, 10.4, 1.8)
                c.closePath()
                c.fill()
                c.globalCompositeOperation = "destination-out"
                c.beginPath()
                c.arc(12, 14.7, 1.5, 0, Math.PI * 2, false)
                c.fill()
                c.fillRect(11.3, 15.2, 1.4, 3.2)
                c.globalCompositeOperation = "source-over"
                return
            } else if (kind === "lock") {
                c.rect(6.2, 10.8, 11.6, 9)
                c.moveTo(8.6, 10.8)
                c.lineTo(8.6, 8.2)
                c.arc(12, 8.2, 3.4, Math.PI, 0, false)
                c.lineTo(15.4, 10.8)
                c.stroke()
                c.beginPath()
                c.arc(12, 15.3, 1.1, 0, Math.PI * 2, false)
                c.fill()
                return
            } else if (kind === "person") {
                /* A ring, a head, and shoulders that the ring cuts off. */
                c.arc(12, 12, 10, 0, Math.PI * 2, false)
                c.stroke()
                c.beginPath()
                c.arc(12, 9.4, 3.3, 0, Math.PI * 2, false)
                c.stroke()
                c.beginPath()
                c.arc(12, 21.4, 7.2, Math.PI * 1.17, Math.PI * 1.83, false)
                c.stroke()
                return
            } else if (kind === "eye") {
                c.moveTo(3.2, 12)
                c.bezierCurveTo(6.2, 6.6, 17.8, 6.6, 20.8, 12)
                c.bezierCurveTo(17.8, 17.4, 6.2, 17.4, 3.2, 12)
                c.moveTo(14.7, 12)
                c.arc(12, 12, 2.7, 0, Math.PI * 2, false)
                if (glyph.struck) {
                    c.moveTo(5.4, 4.8); c.lineTo(18.6, 19.2)
                }
            } else if (kind === "arrow") {
                c.moveTo(5, 12); c.lineTo(19, 12)
                c.moveTo(13.6, 6.6); c.lineTo(19, 12); c.lineTo(13.6, 17.4)
            } else if (kind === "pause") {
                c.fillRect(7, 5.5, 3.4, 13)
                c.fillRect(13.6, 5.5, 3.4, 13)
                return
            } else if (kind === "play") {
                c.moveTo(8, 5); c.lineTo(19, 12); c.lineTo(8, 19)
                c.closePath()
                c.fill()
                return
            } else if (kind === "previous" || kind === "next") {
                /* A bar and a triangle pointing at it. */
                var back = kind === "previous"
                c.fillRect(back ? 5 : 16.6, 6, 2.4, 12)
                c.beginPath()
                if (back) {
                    c.moveTo(19, 6); c.lineTo(9.4, 12); c.lineTo(19, 18)
                } else {
                    c.moveTo(5, 6); c.lineTo(14.6, 12); c.lineTo(5, 18)
                }
                c.closePath()
                c.fill()
                return
            }
            c.stroke()
        }
    }

    /* A button's face: rounded, lighter at the top. Drawn, because a
     * rounded Rectangle with a gradient in it comes out of the renderer a
     * computer falls back to with corners that do not match. */
    component Face: Canvas {
        id: face
        property real corner: 0
        property color light: "#000000"
        property color dark: "#000000"
        onCornerChanged: requestPaint()
        onLightChanged: requestPaint()
        onDarkChanged: requestPaint()
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            var w = width, h = height
            var r = Math.min(corner, w / 2, h / 2)
            c.reset()
            var shade = c.createLinearGradient(0, 0, 0, h)
            shade.addColorStop(0, face.light)
            shade.addColorStop(1, face.dark)
            c.fillStyle = shade
            c.beginPath()
            c.moveTo(r, 0)
            c.lineTo(w - r, 0)
            c.arcTo(w, 0, w, r, r)
            c.lineTo(w, h - r)
            c.arcTo(w, h, w - r, h, r)
            c.lineTo(r, h)
            c.arcTo(0, h, 0, h - r, r)
            c.lineTo(0, r)
            c.arcTo(0, 0, r, 0, r)
            c.closePath()
            c.fill()
        }
    }

    /* One of the three controls on the card for what is playing. */
    component Control: Item {
        id: control
        property string kind: ""
        property bool can: true
        signal pressed()
        width: lock.u * 4.6
        height: width
        opacity: can || lock.stagedMedia !== null ? 1 : 0.35
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: controlArea.pressed ? "#33223A66"
                 : controlArea.containsMouse ? "#1F223A66" : "transparent"
        }
        Glyph {
            anchors.centerIn: parent
            width: lock.u * 2.9
            kind: control.kind
            colour: lock.ink
        }
        MouseArea {
            id: controlArea
            anchors.fill: parent
            enabled: control.can
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: control.pressed()
        }
    }

    /* A round button with a word under it, as on the login screen. */
    component Round: Item {
        id: round
        property string kind: ""
        property string label: ""
        property bool can: true
        signal chosen()
        width: lock.u * 10
        height: lock.u * 11
        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: lock.u * 6.2
            height: width
            radius: width / 2
            color: roundArea.pressed ? "#8C223A66"
                 : roundArea.containsMouse ? "#66345690" : "#4D2A4474"
            border.width: lock.hair
            border.color: "#59FFFFFF"
            Glyph {
                anchors.centerIn: parent
                width: lock.u * 3.4
                kind: round.kind
                weight: 1.6
            }
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            y: lock.u * 7.6
            text: round.label
            color: lock.paper
            font.family: lock.face
            font.pixelSize: lock.u * 1.45
        }
        MouseArea {
            id: roundArea
            anchors.fill: parent
            enabled: round.can
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: round.chosen()
        }
    }

    /* ---- the photograph and the light ---------------------------------------
     *
     * The photograph is behind everything, put there by the locker. Over
     * it, the dusk's own navy, a little deeper at the foot; and at the top
     * the login screen's light behind the name. */
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#3D16305C" }
            GradientStop { position: 0.6; color: "#3316305C" }
            GradientStop { position: 1.0; color: "#6610244A" }
        }
    }
    Image {
        anchors.horizontalCenter: parent.horizontalCenter
        y: -lock.u * 13
        width: lock.u * 110
        height: lock.u * 60
        source: "glow.png"
        opacity: 0.5
        smooth: true
    }

    /* Anywhere on the screen: the keyboard goes to the box. Nothing is
     * checked by a touch (see the top of this file). */
    MouseArea {
        anchors.fill: parent
        onPressed: password.forceActiveFocus()
    }

    /* ---- top left: the time and the date ------------------------------------ */

    Text {
        id: clock
        x: lock.u * 4.4
        y: lock.u * 2.6
        text: lock.time
        color: lock.paper
        font.family: lock.face
        font.pixelSize: lock.u * 5.3
        font.weight: Font.Light
    }
    Text {
        x: clock.x + lock.u * 0.1
        y: lock.u * 8.6
        text: Qt.formatDateTime(lock.now, "dddd, MMMM d")
        color: lock.paper
        font.family: lock.face
        font.pixelSize: lock.u * 1.85
    }

    /* ---- the name ----------------------------------------------------------- */

    Image {
        anchors.horizontalCenter: parent.horizontalCenter
        y: lock.u * 10.5
        height: lock.u * 13.0
        width: height * 2112 / 579
        source: "wordmark.png"
        sourceSize.width: 1600
        smooth: true
        mipmap: true
    }

    /* ---- the card ------------------------------------------------------------ */

    Item {
        id: card
        x: Math.round((lock.width - width) / 2)
        y: Math.round(lock.u * 31.0)
        width: Math.round(lock.u * 50.8)
        height: Math.round(lock.u * 44.4)

        readonly property real corner: lock.u * 2.4
        readonly property real inset: lock.u * 6.2

        /* The glass: a pale tint over the photograph and a thin bright
         * rim (the login screen's, without the blur - see the top). */
        Canvas {
            anchors.fill: parent
            onWidthChanged: requestPaint()
            onHeightChanged: requestPaint()
            onPaint: {
                var c = getContext("2d")
                var w = width, h = height, r = card.corner
                c.reset()
                c.beginPath()
                c.moveTo(r, 0)
                c.lineTo(w - r, 0)
                c.arcTo(w, 0, w, r, r)
                c.lineTo(w, h - r)
                c.arcTo(w, h, w - r, h, r)
                c.lineTo(r, h)
                c.arcTo(0, h, 0, h - r, r)
                c.lineTo(0, r)
                c.arcTo(0, 0, r, 0, r)
                c.closePath()
                var tint = c.createLinearGradient(0, 0, 0, h)
                tint.addColorStop(0, "rgba(176, 200, 236, 0.34)")
                tint.addColorStop(1, "rgba(120, 152, 206, 0.26)")
                c.fillStyle = tint
                c.fill()
                c.lineWidth = Math.max(1, lock.hair)
                c.strokeStyle = "rgba(255, 255, 255, 0.42)"
                c.stroke()
            }
        }

        /* -- who it is ---------------------------------------------------- */

        Canvas {
            id: portrait
            anchors.horizontalCenter: parent.horizontalCenter
            y: lock.u * 4.0
            width: Math.round(lock.u * 12.1)
            height: width
            onWidthChanged: requestPaint()
            onPaint: {
                var c = getContext("2d")
                var d = width
                c.reset()
                var sky = c.createLinearGradient(0, 0, 0, d)
                sky.addColorStop(0, "#5E8FE2")
                sky.addColorStop(1, "#27488F")
                c.fillStyle = sky
                c.beginPath()
                c.arc(d / 2, d / 2, d / 2, 0, Math.PI * 2, false)
                c.fill()
                c.fillStyle = "#FFFFFF"
                c.beginPath()
                c.arc(d * 0.5, d * 0.385, d * 0.15, 0, Math.PI * 2, false)
                c.fill()
                c.save()
                c.translate(d * 0.5, d * 0.715)
                c.scale(1, 0.53)
                c.beginPath()
                c.arc(0, 0, d * 0.255, 0, Math.PI * 2, false)
                c.fill()
                c.restore()
            }
        }

        Text {
            id: name
            anchors.horizontalCenter: parent.horizontalCenter
            y: lock.u * 19.2 - height / 2
            text: lock.who
            textFormat: Text.PlainText
            color: lock.paper
            font.family: lock.face
            font.pixelSize: lock.u * 2.3
            font.weight: Font.Medium
        }

        /* -- the password --------------------------------------------------- */

        Rectangle {
            id: box
            x: Math.round(card.inset)
            y: Math.round(lock.u * 22.7)
            width: card.width - x * 2
            height: Math.round(lock.u * 5.5)
            radius: lock.u * 1.05
            visible: lock.mode !== "free"
            color: "#BF2C4A70"
            border.width: lock.hair
            border.color: password.activeFocus ? "#73FFFFFF" : "#26FFFFFF"

            Glyph {
                id: keyhole
                x: lock.u * 1.9
                anchors.verticalCenter: parent.verticalCenter
                width: lock.u * 2.9
                kind: "lock"
                weight: 2.0
                colour: "#E8EEF8"
            }
            Text {
                anchors.left: password.left
                anchors.verticalCenter: parent.verticalCenter
                visible: password.text === "" && password.preeditText === ""
                text: "Enter your password"
                color: "#C3CDE0"
                font.family: lock.face
                font.pixelSize: lock.u * 1.75
            }
            TextInput {
                id: password
                /* For the program that photographs this screen. */
                objectName: "password"
                anchors.left: keyhole.right
                anchors.leftMargin: lock.u * 1.4
                anchors.right: eye.left
                anchors.rightMargin: lock.u * 1.2
                anchors.verticalCenter: parent.verticalCenter
                height: parent.height
                verticalAlignment: TextInput.AlignVCenter
                clip: true
                focus: true
                readOnly: lock.busy || grace.running || lock.open
                cursorVisible: activeFocus && !readOnly
                color: lock.paper
                selectionColor: "#5B8FE6"
                selectedTextColor: "#FFFFFF"
                font.family: lock.face
                font.pixelSize: lock.reveal ? lock.u * 1.9 : lock.u * 1.5
                font.letterSpacing: lock.reveal ? 0 : lock.u * 0.22
                echoMode: lock.reveal ? TextInput.Normal : TextInput.Password
                maximumLength: 512
                inputMethodHints: Qt.ImhNoPredictiveText
                                  | Qt.ImhNoAutoUppercase
                                  | Qt.ImhSensitiveData
                onAccepted: lock.answer()
                onTextEdited: {
                    if (lock.said !== "" && !grace.running)
                        lock.said = ""
                }
            }
            Glyph {
                id: eye
                anchors.right: parent.right
                anchors.rightMargin: lock.u * 1.9
                anchors.verticalCenter: parent.verticalCenter
                width: lock.u * 2.8
                kind: "eye"
                weight: 2.0
                struck: !lock.reveal
                colour: eyeArea.containsMouse ? lock.paper : "#E8EEF8"
                MouseArea {
                    id: eyeArea
                    anchors.fill: parent
                    anchors.margins: -lock.u * 1.0
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        lock.reveal = !lock.reveal
                        password.forceActiveFocus()
                    }
                }
            }
        }

        /* -- Unlock --------------------------------------------------------- */

        Item {
            id: go
            x: box.x
            y: Math.round(lock.mode === "free" ? lock.u * 24.6 : lock.u * 30.6)
            width: box.width
            height: box.height
            scale: goArea.pressed ? 0.99 : 1
            Behavior on scale { NumberAnimation { duration: 90 } }
            Face {
                anchors.fill: parent
                corner: lock.u * 1.05
                light: lock.busy ? "#6E93CF"
                     : goArea.pressed ? "#3F7FE6"
                     : goArea.containsMouse ? "#63A5FB" : "#5398F7"
                dark: lock.busy ? "#5578B4"
                    : goArea.pressed ? "#2B5FCB"
                    : goArea.containsMouse ? "#3D7CEC" : "#3170E4"
            }
            Row {
                anchors.centerIn: parent
                spacing: lock.u * 1.0
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: lock.busy ? "Unlocking…" : "Unlock"
                    color: "#FFFFFF"
                    font.family: lock.face
                    font.pixelSize: lock.u * 1.85
                    font.weight: Font.Medium
                }
                Glyph {
                    anchors.verticalCenter: parent.verticalCenter
                    visible: !lock.busy
                    width: lock.u * 2.1
                    kind: "arrow"
                    weight: 2.0
                }
            }
            MouseArea {
                id: goArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    password.forceActiveFocus()
                    lock.answer()
                }
            }
        }

        /* What went wrong, or what is about to: said under the button. */
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            y: go.y + go.height + lock.u * 2.2
            width: box.width
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            textFormat: Text.PlainText
            /* 1 is the locker's number for a fingerprint reader it has
             * found and is listening to. */
            text: lock.said !== "" ? lock.said
                : lock.mode !== "ask" ? ""
                : caps.item !== null && caps.item.on ? "Caps Lock is on."
                : (authenticator.authenticatorTypes & 1)
                  ? "Or touch the fingerprint reader."
                : ""
            color: lock.said !== "" ? lock.wrong : lock.soft
            font.family: lock.face
            font.pixelSize: lock.u * 1.7
        }
    }

    /* ---- the foot: letting somebody else sign in ----------------------------- */

    Item {
        id: other
        readonly property bool real: switcher.item !== null
                                     && switcher.item.can
        visible: real || lock.stagedOther
        anchors.horizontalCenter: parent.horizontalCenter
        y: lock.u * 84.5
        width: lock.u * 12
        height: lock.u * 11
        Round {
            anchors.horizontalCenter: parent.horizontalCenter
            kind: "person"
            label: "Switch User"
            /* The photographer's stand-in is drawn, and cannot be pressed. */
            can: other.real
            onChosen: switcher.item.go()
        }
    }

    /* ---- what is playing: a small card at the bottom right ------------------- */

    Rectangle {
        id: tune
        visible: lock.playing !== null
        anchors.right: parent.right
        anchors.rightMargin: Math.round(lock.u * 3.8)
        y: Math.round(lock.u * 96 - height)
        width: Math.round(lock.u * 42)
        height: Math.round(lock.u * 9.4)
        radius: lock.u * 2.0
        color: "#8FFFFFFF"
        border.width: lock.hair
        border.color: "#99FFFFFF"

        /* The record's own picture, or a plain blue square with a note. */
        Rectangle {
            id: sleeve
            x: lock.u * 1.6
            anchors.verticalCenter: parent.verticalCenter
            width: Math.round(lock.u * 6.4)
            height: width
            radius: lock.u * 1.0
            color: "#3D5C92"
            clip: true
            Text {
                anchors.centerIn: parent
                visible: art.status !== Image.Ready
                text: "♪"
                color: "#D8E4F6"
                font.pixelSize: lock.u * 3.2
            }
            Image {
                id: art
                anchors.fill: parent
                source: lock.playing !== null && lock.playing.art
                        ? lock.playing.art : ""
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                sourceSize.width: 256
                sourceSize.height: 256
            }
        }
        Column {
            anchors.left: sleeve.right
            anchors.leftMargin: lock.u * 1.6
            anchors.right: controls.left
            anchors.rightMargin: lock.u * 1.0
            anchors.verticalCenter: parent.verticalCenter
            spacing: lock.u * 0.4
            Text {
                width: parent.width
                elide: Text.ElideRight
                text: lock.playing !== null && lock.playing.track
                      ? lock.playing.track : "Untitled"
                textFormat: Text.PlainText
                color: lock.ink
                font.family: lock.face
                font.pixelSize: lock.u * 2.0
                font.weight: Font.DemiBold
            }
            Text {
                width: parent.width
                elide: Text.ElideRight
                visible: text !== ""
                text: lock.playing !== null && lock.playing.artist
                      ? lock.playing.artist : ""
                textFormat: Text.PlainText
                color: lock.quiet
                font.family: lock.face
                font.pixelSize: lock.u * 1.7
            }
        }
        Row {
            id: controls
            anchors.right: parent.right
            anchors.rightMargin: lock.u * 1.6
            anchors.verticalCenter: parent.verticalCenter
            spacing: lock.u * 0.8
            /* A staged card has nothing behind its buttons, and is only
             * ever photographed. */
            readonly property bool live: lock.stagedMedia === null
                                         && lock.playing !== null
                                         && lock.playing.canControl
            Control {
                kind: "previous"
                can: controls.live && lock.playing.canPrevious
                onPressed: lock.playing.previous()
            }
            Control {
                kind: lock.playing !== null && lock.playing.playing
                      ? "pause" : "play"
                can: controls.live
                onPressed: lock.playing.toggle()
            }
            Control {
                kind: "next"
                can: controls.live && lock.playing.canNext
                onPressed: lock.playing.next()
            }
        }
    }
}
