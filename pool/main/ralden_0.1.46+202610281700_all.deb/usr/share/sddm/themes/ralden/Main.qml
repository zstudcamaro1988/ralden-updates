/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS — the login screen
 *
 * What SDDM draws when a computer with an account on it is switched on:
 * the mountains at dusk, the time, the mark, and a card of frosted glass
 * with a person on it, a box for their password and a blue Sign In.
 *
 * WHAT THIS IS A COPY OF, AND WHERE IT IS NOT.
 *
 * The first reference picture (reference/1-login.png; the design spec,
 * section 1), measured: every place and size below is a hundredth of the
 * screen's height (`u`), read off that picture, which is 941 pixels high.
 *
 * Where it differs, and why:
 *
 *   The weather, top left. Nothing on this computer knows the weather yet.
 *   It is not drawn until something does.
 *
 *   The clock says the time the way this computer's language does - on a
 *   computer set to American English, 5:28 PM and not 17:28.
 *
 *   The arrow beside the name is only there when there is somebody else to
 *   choose. A computer with one account has nobody to pick between.
 *
 *   An account with no password has no password box: there is nothing to
 *   type into it.
 *
 *   The photograph is Ralden's own, made dusk by tools/make-alpine-mist.py;
 *   over it, since 26 October 2026, the owner's "Ralden" in place of the
 *   mark and the typed name (tools/make-logo.py), lit from behind.
 *
 * THE GLASS IS A PHOTOGRAPH, NOT AN EFFECT. The card shows the part of
 * glass.jpg - the background, already out of focus - that is behind it.
 * tools/make-alpine-mist.py says why.
 *
 * ONLY QtQuick IS IMPORTED. Every drawing is a Canvas. This is the screen
 * between a person and their computer; a module that is missing on the day
 * is a computer nobody can sign in to.
 *
 * WHAT SDDM GIVES IT: `sddm` (sign in, restart, shut down, sleep), the
 * people (`userModel`), the sessions (`sessionModel`), what theme.conf says
 * (`config`), and the keyboard's lights (`keyboard`).
 */

import QtQuick

Item {
    id: root

    /* SDDM makes this the size of the screen. These are for when it is
     * loaded by anything else. */
    width: 1366
    height: 768

    readonly property real u: height / 100
    readonly property real hair: Math.max(1, Math.round(u * 0.12))
    readonly property string face: "Inter"
    readonly property color paper: "#FFFFFF"
    readonly property color soft: "#D6DEEC"
    readonly property color wrong: "#FFD2CC"

    /* ---- who ------------------------------------------------------------ */

    property int chosen: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
    readonly property var person: people.count > 0
                                  ? people.itemAt(Math.min(chosen,
                                                           people.count - 1))
                                  : null
    readonly property string login: person ? person.who : ""
    readonly property string called: person
                                     ? (person.called !== "" ? person.called
                                                             : person.who)
                                     : ""
    readonly property bool locked: person ? person.locked : true
    property bool picking: false
    property bool reveal: false
    property bool busy: false
    property string said: ""

    Repeater {
        id: people
        model: userModel
        delegate: Item {
            readonly property string who: model.name
            readonly property string called: model.realName
            /* SDDM says every account on Debian needs a password: it
             * looks where the password is not kept. Who has none is said
             * by ralden-ambient (the file below, "open"), which can read
             * where it is. Seen on the VAIO, 28 October 2026: the owner,
             * who has no password, typed a made-up one into the box and
             * was let in - a box that takes anything. */
            readonly property bool locked: model.needsPassword
                && !(Array.isArray(root.ambient.open)
                     && root.ambient.open.indexOf(model.name) >= 0)
        }
    }

    function signIn() {
        if (root.busy || root.login === "")
            return
        root.busy = true
        root.said = ""
        sddm.login(root.login, password.text, sessionModel.lastIndex)
    }

    Connections {
        target: sddm
        function onLoginFailed() {
            root.busy = false
            root.said = root.locked ? "That is not the password."
                                    : "Signing in did not work."
            password.text = ""
            password.forceActiveFocus()
        }
        function onLoginSucceeded() {
            root.said = ""
        }
    }

    /* The keyboard goes to the password box, or - for somebody who has no
     * password - to Sign In, so that Enter is enough. Asked again whenever
     * who it is changes: the people arrive a moment after the screen does. */
    function attend() {
        if (root.locked)
            password.forceActiveFocus()
        else
            go.forceActiveFocus()
    }
    Component.onCompleted: attend()
    onLockedChanged: attend()

    /* ---- the time -------------------------------------------------------- */

    property date now: new Date()
    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: {
            root.now = new Date()
            if (root.now.getSeconds() % 10 === 0)
                root.look()
        }
    }

    /* ---- the battery and the network -------------------------------------
     *
     * A small service (ralden-ambient) writes what it knows to one file a
     * few times a minute; this reads it. No file, nothing drawn. */

    property var ambient: ({})
    function look() {
        var path = config.ambient
        if (path === undefined || path === "")
            return
        var ask = new XMLHttpRequest()
        ask.onreadystatechange = function () {
            if (ask.readyState !== XMLHttpRequest.DONE)
                return
            try {
                var heard = JSON.parse(ask.responseText)
                root.ambient = heard && typeof heard === "object" ? heard : {}
            } catch (e) {
                root.ambient = {}
            }
        }
        ask.open("GET", "file://" + path)
        ask.send()
    }
    Timer {
        interval: 600
        running: true
        onTriggered: root.look()
    }

    /* ---- the pieces, declared once ---------------------------------------- */

    /* A small line drawing on a grid of 24. */
    component Glyph: Canvas {
        id: glyph
        property string kind: ""
        property color colour: root.paper
        property real weight: 1.8
        /* eye: a line through it. battery: how full, 0 to 100, and whether
         * it is being charged. wifi: how strong, 0 to 100. */
        property bool struck: false
        property real level: 100
        property bool charging: false
        width: root.u * 2.6
        height: width
        onKindChanged: requestPaint()
        onColourChanged: requestPaint()
        onWeightChanged: requestPaint()
        onStruckChanged: requestPaint()
        onLevelChanged: requestPaint()
        onChargingChanged: requestPaint()
        onWidthChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            var k = width / 24
            c.reset()
            c.scale(k, k)
            c.lineWidth = glyph.weight
            c.lineCap = "round"
            c.lineJoin = "round"
            c.strokeStyle = glyph.colour
            c.fillStyle = glyph.colour
            c.beginPath()
            if (kind === "lock") {
                c.rect(6.2, 10.8, 11.6, 9)
                c.moveTo(8.6, 10.8)
                c.lineTo(8.6, 8.2)
                c.arc(12, 8.2, 3.4, Math.PI, 0, false)
                c.lineTo(15.4, 10.8)
                c.stroke()
                c.beginPath()
                c.arc(12, 15.3, 1.1, 0, Math.PI * 2, false)
                c.fill()
                return
            } else if (kind === "eye") {
                c.moveTo(3.2, 12)
                c.bezierCurveTo(6.2, 6.6, 17.8, 6.6, 20.8, 12)
                c.bezierCurveTo(17.8, 17.4, 6.2, 17.4, 3.2, 12)
                c.moveTo(14.7, 12)
                c.arc(12, 12, 2.7, 0, Math.PI * 2, false)
                if (glyph.struck) {
                    c.moveTo(5.4, 4.8); c.lineTo(18.6, 19.2)
                }
            } else if (kind === "arrow") {
                c.moveTo(5, 12); c.lineTo(19, 12)
                c.moveTo(13.6, 6.6); c.lineTo(19, 12); c.lineTo(13.6, 17.4)
            } else if (kind === "down") {
                c.moveTo(6.5, 9.5); c.lineTo(12, 15); c.lineTo(17.5, 9.5)
            } else if (kind === "moon") {
                /* A disc with a smaller one taken out of its upper right. */
                c.arc(11.2, 12.8, 7.6, 0, Math.PI * 2, false)
                c.fill()
                c.globalCompositeOperation = "destination-out"
                c.beginPath()
                c.arc(15.6, 8.6, 6.6, 0, Math.PI * 2, false)
                c.fill()
                c.globalCompositeOperation = "source-over"
                return
            } else if (kind === "restart") {
                c.arc(12, 12, 6.8, Math.PI * 1.08, Math.PI * 1.92, false)
                c.moveTo(18.9, 5.6); c.lineTo(18.6, 9.6); c.lineTo(14.7, 9.0)
                c.moveTo(18.47, 14.1)
                c.arc(12, 12, 6.8, Math.PI * 0.08, Math.PI * 0.92, false)
                c.moveTo(5.1, 18.4); c.lineTo(5.4, 14.4); c.lineTo(9.3, 15.0)
            } else if (kind === "power") {
                c.moveTo(12, 4.4); c.lineTo(12, 11.6)
                c.moveTo(16.6, 7.3)
                c.arc(12, 12.6, 7, -Math.PI * 0.27, Math.PI * 1.27, false)
            } else if (kind === "wifi") {
                /* Three arcs and a dot; the arcs it has not the strength
                 * for are faint. */
                c.stroke()
                var reach = [[9.4, 67], [6.2, 34], [3.0, 1]]
                for (var i = 0; i < 3; i++) {
                    c.globalAlpha = glyph.level >= reach[i][1] ? 1 : 0.3
                    c.beginPath()
                    c.arc(12, 17.6, reach[i][0], -Math.PI * 0.76,
                          -Math.PI * 0.24, false)
                    c.stroke()
                }
                c.globalAlpha = 1
                c.beginPath()
                c.arc(12, 17.6, 1.2, 0, Math.PI * 2, false)
                c.fill()
                return
            } else if (kind === "wired") {
                c.rect(8.5, 4.5, 7, 5.5)
                c.moveTo(12, 10); c.lineTo(12, 14)
                c.moveTo(5.5, 19.5); c.lineTo(5.5, 14); c.lineTo(18.5, 14)
                c.lineTo(18.5, 19.5)
            } else if (kind === "battery") {
                c.stroke()
                c.lineWidth = 1.5
                c.beginPath()
                c.moveTo(4.9, 8.2)
                c.lineTo(17.3, 8.2)
                c.arcTo(18.6, 8.2, 18.6, 9.5, 1.3)
                c.lineTo(18.6, 14.5)
                c.arcTo(18.6, 15.8, 17.3, 15.8, 1.3)
                c.lineTo(4.9, 15.8)
                c.arcTo(3.6, 15.8, 3.6, 14.5, 1.3)
                c.lineTo(3.6, 9.5)
                c.arcTo(3.6, 8.2, 4.9, 8.2, 1.3)
                c.closePath()
                c.stroke()
                c.beginPath()
                c.moveTo(20.6, 10.6); c.lineTo(20.6, 13.4)
                c.stroke()
                var full = Math.max(0, Math.min(100, glyph.level)) / 100
                c.beginPath()
                c.rect(5.5, 10.1, 11.2 * full, 3.8)
                c.fill()
                return
            }
            c.stroke()
        }
    }

    /* A button's face: rounded, lighter at the top. Drawn, because a
     * rounded Rectangle with a gradient in it comes out of the renderer a
     * computer falls back to with corners that do not match. */
    component Face: Canvas {
        id: face
        property real corner: 0
        property color light: "#000000"
        property color dark: "#000000"
        onCornerChanged: requestPaint()
        onLightChanged: requestPaint()
        onDarkChanged: requestPaint()
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            var w = width, h = height
            var r = Math.min(corner, w / 2, h / 2)
            c.reset()
            var shade = c.createLinearGradient(0, 0, 0, h)
            shade.addColorStop(0, face.light)
            shade.addColorStop(1, face.dark)
            c.fillStyle = shade
            c.beginPath()
            c.moveTo(r, 0)
            c.lineTo(w - r, 0)
            c.arcTo(w, 0, w, r, r)
            c.lineTo(w, h - r)
            c.arcTo(w, h, w - r, h, r)
            c.lineTo(r, h)
            c.arcTo(0, h, 0, h - r, r)
            c.lineTo(0, r)
            c.arcTo(0, 0, r, 0, r)
            c.closePath()
            c.fill()
        }
    }

    /* One of the three round buttons at the foot of the screen. */
    component Round: Item {
        id: round
        property string kind: ""
        property string label: ""
        signal chosen()
        width: root.u * 10
        height: root.u * 11
        activeFocusOnTab: true
        Keys.onReturnPressed: round.chosen()
        Keys.onEnterPressed: round.chosen()
        Keys.onSpacePressed: round.chosen()
        Rectangle {
            id: disc
            anchors.horizontalCenter: parent.horizontalCenter
            width: root.u * 6.2
            height: width
            radius: width / 2
            /* A dark glass, as the reference's are: on a pale part of the
             * photograph a white one loses the drawing inside it. */
            color: roundArea.pressed ? "#8C223A66"
                 : roundArea.containsMouse ? "#66345690" : "#4D2A4474"
            border.width: round.activeFocus ? root.hair * 2 : root.hair
            border.color: round.activeFocus ? "#FFFFFF" : "#59FFFFFF"
            Glyph {
                anchors.centerIn: parent
                width: root.u * 3.0
                kind: round.kind
                weight: 2.3
            }
        }
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            y: root.u * 7.6
            text: round.label
            color: root.paper
            font.family: root.face
            font.pixelSize: root.u * 1.45
        }
        MouseArea {
            id: roundArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: round.chosen()
        }
    }

    /* ---- the mountains --------------------------------------------------- */

    Rectangle {
        anchors.fill: parent
        color: "#16305C"
    }
    Image {
        id: backdrop
        anchors.fill: parent
        source: Qt.resolvedUrl(config.background)
        fillMode: Image.PreserveAspectCrop
        asynchronous: false
        smooth: true
    }
    /* Light behind the name (26 October 2026): the owner's "Ralden" is deep
     * navy into cyan, and the sky here is dusk - without it the navy letters
     * sank into the sky in a mock-up of this screen. The boot screen's
     * glow.png, copied beside this file. */
    Image {
        anchors.horizontalCenter: parent.horizontalCenter
        y: -root.u * 13
        width: root.u * 110
        height: root.u * 60
        source: Qt.resolvedUrl("glow.png")
        opacity: 0.5
        smooth: true
    }

    /* ---- top left: the time ---------------------------------------------- */

    Text {
        id: clock
        x: root.u * 4.4
        y: root.u * 2.6
        text: Qt.formatTime(root.now, Qt.locale().timeFormat(Locale.ShortFormat))
        color: root.paper
        font.family: root.face
        font.pixelSize: root.u * 5.3
        font.weight: Font.Light
    }
    Text {
        x: clock.x + root.u * 0.1
        y: root.u * 8.6
        text: Qt.formatDateTime(root.now, "dddd, MMMM d")
        color: root.paper
        font.family: root.face
        font.pixelSize: root.u * 1.85
    }

    /* ---- top right: the network and the battery -------------------------- */

    Row {
        id: status
        anchors.right: parent.right
        anchors.rightMargin: root.u * 3.8
        y: root.u * 2.4
        spacing: root.u * 1.6

        /* What the file said, or nothing: a network that is "wifi" or
         * "wired", and a battery that has a number. */
        readonly property var net: root.ambient.network
        readonly property bool online: net !== undefined && net !== null
                                       && (net.kind === "wifi"
                                           || net.kind === "wired")
        readonly property var cell: root.ambient.battery
        readonly property bool powered: cell !== undefined && cell !== null
                                        && typeof cell.percent === "number"

        Glyph {
            anchors.verticalCenter: parent.verticalCenter
            visible: status.online
            kind: status.online ? status.net.kind : "wifi"
            level: status.online && typeof status.net.strength === "number"
                   ? status.net.strength : 100
            width: root.u * 2.7
        }
        Glyph {
            anchors.verticalCenter: parent.verticalCenter
            visible: status.powered
            kind: "battery"
            level: status.powered ? status.cell.percent : 0
            width: root.u * 3.0
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            visible: status.powered
            text: status.powered ? status.cell.percent + "%" : ""
            color: root.paper
            font.family: root.face
            font.pixelSize: root.u * 1.75
        }
    }

    /* ---- the mark ---------------------------------------------------------- */

    /* The name as the owner drew it (26 October 2026), where the mark
     * (10.6 to 19.8) and the typed name (19.8 to about 25) were. */
    Image {
        id: wordmark
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.u * 10.5
        height: root.u * 13.0
        width: height * 2112 / 579
        source: Qt.resolvedUrl("wordmark.png")
        sourceSize.width: 1600
        smooth: true
        mipmap: true
    }

    /* ---- the card ---------------------------------------------------------- */

    Item {
        id: card
        x: Math.round((root.width - width) / 2)
        y: Math.round(root.u * 31.0)
        width: Math.round(root.u * 50.8)
        height: Math.round(root.u * 44.4)

        readonly property real corner: root.u * 2.4
        readonly property real inset: root.u * 6.2

        /* The glass: the out-of-focus photograph behind this card, a pale
         * veil over it, and a thin bright rim. */
        Canvas {
            id: glass
            anchors.fill: parent
            readonly property url picture: Qt.resolvedUrl(config.glass)
            Component.onCompleted: loadImage(picture)
            onImageLoaded: requestPaint()
            onWidthChanged: requestPaint()
            onHeightChanged: requestPaint()
            onPaint: {
                var c = getContext("2d")
                var w = width, h = height, r = card.corner
                c.reset()
                c.beginPath()
                c.moveTo(r, 0)
                c.lineTo(w - r, 0)
                c.arcTo(w, 0, w, r, r)
                c.lineTo(w, h - r)
                c.arcTo(w, h, w - r, h, r)
                c.lineTo(r, h)
                c.arcTo(0, h, 0, h - r, r)
                c.lineTo(0, r)
                c.arcTo(0, 0, r, 0, r)
                c.closePath()
                c.save()
                c.clip()
                if (isImageLoaded(picture)) {
                    /* Where the background's 16 by 9 lands on this screen,
                     * cropped to cover it; and so which part of the same
                     * picture, out of focus, is behind the card. */
                    var cover = Math.max(root.width / 16, root.height / 9)
                    var seenW = 16 * cover, seenH = 9 * cover
                    var left = (root.width - seenW) / 2
                    var top = (root.height - seenH) / 2
                    c.drawImage(picture,
                                (card.x - left) / seenW * 960,
                                (card.y - top) / seenH * 540,
                                w / seenW * 960, h / seenH * 540,
                                0, 0, w, h)
                } else {
                    c.fillStyle = "#5A7FB8"
                    c.fillRect(0, 0, w, h)
                }
                var veil = c.createLinearGradient(0, 0, 0, h)
                veil.addColorStop(0, "rgba(255, 255, 255, 0.13)")
                veil.addColorStop(1, "rgba(255, 255, 255, 0.04)")
                c.fillStyle = veil
                c.fillRect(0, 0, w, h)
                c.restore()
                c.lineWidth = Math.max(1, root.hair)
                c.strokeStyle = "rgba(255, 255, 255, 0.42)"
                c.stroke()
            }
        }

        /* -- who it is ---------------------------------------------------- */

        Canvas {
            id: portrait
            anchors.horizontalCenter: parent.horizontalCenter
            y: root.u * 4.0
            width: Math.round(root.u * 12.1)
            height: width
            onWidthChanged: requestPaint()
            onPaint: {
                var c = getContext("2d")
                var d = width
                c.reset()
                var sky = c.createLinearGradient(0, 0, 0, d)
                sky.addColorStop(0, "#5E8FE2")
                sky.addColorStop(1, "#27488F")
                c.fillStyle = sky
                c.beginPath()
                c.arc(d / 2, d / 2, d / 2, 0, Math.PI * 2, false)
                c.fill()
                c.fillStyle = "#FFFFFF"
                c.beginPath()
                c.arc(d * 0.5, d * 0.385, d * 0.15, 0, Math.PI * 2, false)
                c.fill()
                /* The shoulders: a flattened circle. */
                c.save()
                c.translate(d * 0.5, d * 0.715)
                c.scale(1, 0.53)
                c.beginPath()
                c.arc(0, 0, d * 0.255, 0, Math.PI * 2, false)
                c.fill()
                c.restore()
            }
        }

        Row {
            id: nameRow
            anchors.horizontalCenter: parent.horizontalCenter
            y: root.u * 19.2 - height / 2
            spacing: root.u * 0.9
            Text {
                id: nameText
                text: root.called
                color: root.paper
                font.family: root.face
                font.pixelSize: root.u * 2.3
                font.weight: Font.Medium
            }
            Glyph {
                anchors.verticalCenter: parent.verticalCenter
                visible: people.count > 1
                width: root.u * 2.0
                kind: "down"
                weight: 2.2
            }
        }
        MouseArea {
            anchors.fill: nameRow
            anchors.margins: -root.u * 1.2
            enabled: people.count > 1
            cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
            onClicked: root.picking = !root.picking
        }

        /* -- the password --------------------------------------------------- */

        Rectangle {
            id: box
            x: Math.round(card.inset)
            y: Math.round(root.u * 22.7)
            width: card.width - x * 2
            height: Math.round(root.u * 5.5)
            radius: root.u * 1.05
            visible: root.locked
            color: "#BF2C4A70"
            border.width: root.hair
            border.color: password.activeFocus ? "#73FFFFFF" : "#26FFFFFF"

            Glyph {
                id: padlock
                x: root.u * 1.9
                anchors.verticalCenter: parent.verticalCenter
                width: root.u * 2.9
                kind: "lock"
                weight: 2.0
                colour: "#E8EEF8"
            }
            Text {
                anchors.left: password.left
                anchors.verticalCenter: parent.verticalCenter
                visible: password.text === "" && password.preeditText === ""
                text: "Enter your password"
                color: "#C3CDE0"
                font.family: root.face
                font.pixelSize: root.u * 1.75
            }
            TextInput {
                id: password
                /* For the program that photographs this screen. */
                objectName: "password"
                anchors.left: padlock.right
                anchors.leftMargin: root.u * 1.4
                anchors.right: eye.left
                anchors.rightMargin: root.u * 1.2
                anchors.verticalCenter: parent.verticalCenter
                height: parent.height
                verticalAlignment: TextInput.AlignVCenter
                clip: true
                enabled: !root.busy
                color: root.paper
                selectionColor: "#5B8FE6"
                selectedTextColor: "#FFFFFF"
                font.family: root.face
                font.pixelSize: root.reveal ? root.u * 1.9 : root.u * 1.5
                font.letterSpacing: root.reveal ? 0 : root.u * 0.22
                echoMode: root.reveal ? TextInput.Normal : TextInput.Password
                maximumLength: 512
                activeFocusOnTab: true
                inputMethodHints: Qt.ImhNoPredictiveText
                                  | Qt.ImhNoAutoUppercase
                                  | Qt.ImhSensitiveData
                onAccepted: root.signIn()
                onTextEdited: root.said = ""
            }
            Glyph {
                id: eye
                anchors.right: parent.right
                anchors.rightMargin: root.u * 1.9
                anchors.verticalCenter: parent.verticalCenter
                width: root.u * 2.8
                kind: "eye"
                weight: 2.0
                struck: !root.reveal
                colour: eyeArea.containsMouse ? root.paper : "#E8EEF8"
                MouseArea {
                    id: eyeArea
                    anchors.fill: parent
                    anchors.margins: -root.u * 1.0
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.reveal = !root.reveal
                }
            }
        }

        /* -- Sign In ------------------------------------------------------- */

        Item {
            id: go
            x: box.x
            y: Math.round(root.locked ? root.u * 30.6 : root.u * 24.6)
            width: box.width
            height: box.height
            activeFocusOnTab: true
            Keys.onReturnPressed: root.signIn()
            Keys.onEnterPressed: root.signIn()
            Keys.onSpacePressed: root.signIn()
            scale: goArea.pressed ? 0.99 : 1
            Behavior on scale { NumberAnimation { duration: 90 } }

            Face {
                anchors.fill: parent
                corner: root.u * 1.05
                light: root.busy ? "#6E93CF"
                     : goArea.pressed ? "#3F7FE6"
                     : goArea.containsMouse ? "#63A5FB" : "#5398F7"
                dark: root.busy ? "#5578B4"
                    : goArea.pressed ? "#2B5FCB"
                    : goArea.containsMouse ? "#3D7CEC" : "#3170E4"
            }
            Rectangle {
                anchors.fill: parent
                anchors.margins: -root.u * 0.5
                radius: root.u * 1.5
                color: "transparent"
                border.width: root.hair * 2
                border.color: "#FFFFFF"
                visible: go.activeFocus
            }
            Row {
                anchors.centerIn: parent
                spacing: root.u * 1.0
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.busy ? "Signing in…" : "Sign In"
                    color: "#FFFFFF"
                    font.family: root.face
                    font.pixelSize: root.u * 1.85
                    font.weight: Font.Medium
                }
                Glyph {
                    anchors.verticalCenter: parent.verticalCenter
                    visible: !root.busy
                    width: root.u * 2.1
                    kind: "arrow"
                    weight: 2.0
                }
            }
            MouseArea {
                id: goArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    go.forceActiveFocus()
                    root.signIn()
                }
            }
        }

        /* What went wrong, or what is about to: said under the button. */
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            y: go.y + go.height + root.u * 2.2
            width: box.width
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: root.said !== "" ? root.said
                : keyboard.capsLock && root.locked ? "Caps Lock is on."
                : ""
            color: root.said !== "" ? root.wrong : root.soft
            font.family: root.face
            font.pixelSize: root.u * 1.7
        }

        /* -- somebody else --------------------------------------------------
         *
         * Only on a computer with more than one account: the names, under
         * the one showing. */
        Rectangle {
            id: others
            visible: root.picking && people.count > 1
            anchors.horizontalCenter: parent.horizontalCenter
            y: root.u * 21.4
            width: box.width
            height: Math.min(people.count, 5) * root.u * 5.0 + root.u * 1.2
            radius: root.u * 1.2
            color: "#F2182848"
            border.width: root.hair
            border.color: "#59FFFFFF"
            z: 5
            ListView {
                anchors.fill: parent
                anchors.margins: root.u * 0.6
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: userModel
                delegate: Item {
                    id: other
                    readonly property string shown: model.realName !== ""
                                                    ? model.realName
                                                    : model.name
                    width: ListView.view.width
                    height: root.u * 5.0
                    Rectangle {
                        anchors.fill: parent
                        radius: root.u * 0.8
                        color: index === root.chosen ? "#405B8FE6"
                             : otherArea.containsMouse ? "#26FFFFFF"
                             : "transparent"
                    }
                    Text {
                        x: root.u * 1.6
                        anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - x * 2
                        elide: Text.ElideRight
                        text: other.shown
                        color: root.paper
                        font.family: root.face
                        font.pixelSize: root.u * 1.9
                    }
                    MouseArea {
                        id: otherArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            root.chosen = index
                            root.picking = false
                            root.said = ""
                            password.text = ""
                            if (root.locked)
                                password.forceActiveFocus()
                            else
                                go.forceActiveFocus()
                        }
                    }
                }
            }
        }
    }

    /* ---- the foot: sleep, restart, shut down ------------------------------
     *
     * Each is there only if this computer says it can do it. */

    Row {
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.u * 84.5
        spacing: root.u * 3.0
        Round {
            visible: sddm.canSuspend
            kind: "moon"
            label: "Sleep"
            onChosen: sddm.suspend()
        }
        Round {
            visible: sddm.canReboot
            kind: "restart"
            label: "Restart"
            onChosen: sddm.reboot()
        }
        Round {
            visible: sddm.canPowerOff
            kind: "power"
            label: "Shut Down"
            onChosen: sddm.powerOff()
        }
    }
}
