/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS — Shield's window
 *
 * Follows the from-scratch Ralden's Shield screen: the mark and a one-word
 * verdict, three cards of fact, one row of actions, and a panel that is
 * either a list of findings or a sentence saying there are none.
 *
 * WHAT IS NOT DRAWN, AND WHY THAT IS THE IMPORTANT PART.
 *
 * The original had "Accept 0 changes" and a line reading "Records are signed
 * - only your key can change what belongs on this machine". Both belonged to
 * a Shield that kept its own manifest. On Debian the manifest is dpkg's,
 * written by whoever built each package and verified by GPG on download —
 * there is nothing of ours to sign and nothing to accept. Drawing those
 * controls would be lying about where the trust in this machine comes from,
 * which is a worse lie than a fake weather readout.
 *
 * It also had no window decoration of its own, and still does not: KWin draws
 * the three dots, on the right, from kwinrc. One definition, not two.
 *
 * THE COLOURS ARE LITERAL ON PURPOSE.
 *
 * Every other QML file here takes its colours from Kirigami.Theme, which
 * reads the colour scheme. This one does not, because it is the same palette
 * arriving by a different route: these values are kernel/theme.c's, and this
 * window should look identical whether or not somebody has switched their
 * colour scheme. Shield saying "Protected" in somebody else's green is Shield
 * looking like it belongs to somebody else.
 */

import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as QQC2

QQC2.ApplicationWindow {
    id: root

    width: 980
    height: 720
    minimumWidth: 720
    minimumHeight: 560
    visible: true
    title: "Ralden Shield"

    readonly property color panel:  "#141E2D"
    readonly property color tile:   "#1E293B"
    readonly property color track:  "#27354A"
    readonly property color ink:    "#ECF1F6"
    readonly property color muted:  "#8C99B0"
    readonly property color faint:  "#627086"
    readonly property color accent: "#4A90E2"
    readonly property color warn:   "#E2A24A"

    color: panel

    /* The window is a view of a file the timer writes. Something else may
     * have written it since this window opened, so it is re-read whenever the
     * window is looked at again rather than only at startup. */
    onActiveChanged: if (active) shield.refresh()

    QQC2.Action {
        shortcut: "R"
        onTriggered: shield.scan()
    }
    QQC2.Action {
        shortcut: StandardKey.Refresh
        onTriggered: shield.scan()
    }
    QQC2.Action {
        shortcut: StandardKey.Cancel
        onTriggered: root.close()
    }

    /* AN INLINE COMPONENT, AND IT HAS TO BE HERE RATHER THAN WHERE IT IS
     * USED.
     *
     * This was declared inside the RowLayout that holds the three cards,
     * which is where it reads best and is not legal: Qt requires an inline
     * component to be a top-level member of the document, a direct child
     * of the root object. Nested any deeper the file does not load at all -
     * not a widget missing, the whole window failing to parse, with
     * `Inline component declaration must be a toplevel member` in a log.
     *
     * tests/check_tree.py now measures the brace depth of every `component`
     * declaration, because nothing about reading the file says this. */
    component Card: Rectangle {
        property string label: ""
        property string value: ""
        property string sub: ""
        property color valueColor: root.ink

        Layout.fillWidth: true
        Layout.preferredHeight: 84
        radius: 8
        color: root.tile

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 3

            Text {
                text: label
                color: root.muted
                font.family: "Inter"
                font.pixelSize: 11
                font.letterSpacing: 0.8
                font.capitalization: Font.AllUppercase
            }
            Text {
                text: value
                color: valueColor
                font.family: "Inter"
                font.pixelSize: 18
                font.weight: Font.DemiBold
                elide: Text.ElideRight
                Layout.fillWidth: true
            }
            Text {
                text: sub
                color: root.faint
                font.family: "Inter"
                font.pixelSize: 12
                elide: Text.ElideRight
                Layout.fillWidth: true
            }
        }
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 26
        spacing: 20

        // ---- the verdict ------------------------------------------------

        RowLayout {
            Layout.fillWidth: true
            spacing: 22

            Image {
                source: "mark.png"
                sourceSize.width: 84
                sourceSize.height: 84
                Layout.preferredWidth: 84
                Layout.preferredHeight: 84
                Layout.alignment: Qt.AlignTop
                fillMode: Image.PreserveAspectFit
                smooth: true
                mipmap: true
                opacity: shield.busy ? 0.55 : 1.0
                Behavior on opacity { NumberAnimation { duration: 300 } }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 6

                Text {
                    text: shield.verdict
                    /* "Protected" in white, a problem in amber. The colour is
                     * the part a person reads from across a room, before any
                     * of the words. Saying both in the same colour makes the
                     * window look identical whether the machine is fine or
                     * not, which wastes the one glance most people give it. */
                    color: shield.attention ? root.warn : root.ink
                    font.family: "Inter"
                    font.pixelSize: 34
                    font.weight: Font.DemiBold
                }
                Text {
                    Layout.fillWidth: true
                    text: shield.headline
                    color: root.muted
                    font.family: "Inter"
                    font.pixelSize: 15
                    wrapMode: Text.WordWrap
                }
                Text {
                    Layout.fillWidth: true
                    Layout.topMargin: 4
                    /* The faintest text on the window, saying what Shield
                     * cannot do. It is small because it is not the answer,
                     * and it is present because the answer is not complete
                     * without it. */
                    text: shield.caveat
                    color: root.faint
                    font.family: "Inter"
                    font.pixelSize: 12.5
                    wrapMode: Text.WordWrap
                }
            }
        }

        // ---- three facts -------------------------------------------------

        RowLayout {
            Layout.fillWidth: true
            spacing: 14

            Card {
                label: "Programs and libraries"
                value: shield.checkedCount
                sub: "checked against their packages"
            }
            Card {
                label: "Files no package owns"
                value: shield.unownedCount
                sub: "places to look, not problems"
                valueColor: shield.unownedCount === "none"
                            ? root.ink : root.warn
            }
            Card {
                label: "Last check"
                value: shield.lastCheck
                sub: "the next one happens by itself"
            }
        }

        // ---- what is watching, and the one control that changes it -------

        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Rectangle {
                width: 7; height: 7; radius: 3.5
                Layout.alignment: Qt.AlignVCenter
                color: shield.guardState === "enforcing" ? root.accent
                     : shield.guardState === "watching"  ? root.muted
                     : root.faint
            }

            Text {
                Layout.fillWidth: true
                color: root.muted
                font.family: "Inter"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
                text: shield.guardState === "enforcing"
                      ? "A program that is not what its package installed will not run."
                      : shield.guardState === "watching"
                      ? "Programs are checked as they run, and reported. Nothing is blocked."
                      : shield.guardState === "off"
                      ? "Programs are not being checked as they run."
                      : "Whether programs are checked as they run is not known."
            }

            Text {
                visible: !shield.canChangeGuard
                text: "needs pkexec"
                color: root.faint
                font.family: "Inter"
                font.pixelSize: 12
            }

            /* Two states, not three. Enforcement is turned on by editing the
             * unit, deliberately — it is the one thing here that can stop a
             * machine working, and it should not be one click away in a
             * window somebody opened to reassure themselves. */
            QQC2.Button {
                enabled: shield.canChangeGuard && shield.guardState !== "unknown"
                text: shield.guardState === "off" ? "Watch programs" : "Stop watching"
                onClicked: shield.setGuard(shield.guardState === "off" ? "on" : "off")

                contentItem: Text {
                    text: parent.text
                    color: parent.enabled ? root.ink : root.faint
                    font.family: "Inter"
                    font.pixelSize: 13
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                background: Rectangle {
                    implicitWidth: 138
                    implicitHeight: 32
                    radius: 6
                    color: parent.down ? root.track
                         : parent.hovered ? Qt.lighter(root.tile, 1.25)
                         : root.tile
                    border.width: 1
                    border.color: root.track
                }
            }
        }

        // ---- actions ------------------------------------------------------

        RowLayout {
            Layout.fillWidth: true
            spacing: 12

            QQC2.Button {
                enabled: !shield.busy
                text: shield.busy ? "Checking…" : "Check now"
                onClicked: shield.scan()

                contentItem: Text {
                    text: parent.text
                    color: "#FFFFFF"
                    font.family: "Inter"
                    font.pixelSize: 14
                    font.weight: Font.DemiBold
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                background: Rectangle {
                    implicitWidth: 150
                    implicitHeight: 38
                    radius: 7
                    color: !parent.enabled ? root.track
                         : parent.down ? Qt.darker(root.accent, 1.2)
                         : parent.hovered ? Qt.lighter(root.accent, 1.1)
                         : root.accent
                }
            }

            Text {
                visible: shield.note !== ""
                Layout.fillWidth: true
                text: shield.note
                color: root.warn
                font.family: "Inter"
                font.pixelSize: 13
                elide: Text.ElideRight
            }

            Item { Layout.fillWidth: shield.note === "" }
        }

        // ---- the findings, or the absence of them ------------------------

        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: 8
            color: "#18222F"

            ColumnLayout {
                anchors.centerIn: parent
                width: parent.width * 0.7
                spacing: 8
                visible: shield.findings.length === 0 && !shield.busy

                Text {
                    Layout.alignment: Qt.AlignHCenter
                    text: shield.checkedCount === "—"
                          ? "Nothing has been checked yet."
                          : "Everything is as it should be."
                    color: root.muted
                    font.family: "Inter"
                    font.pixelSize: 17
                    font.weight: Font.DemiBold
                }
                Text {
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignHCenter
                    text: shield.checkedCount === "—"
                          ? "Press Check now. It takes under a minute."
                          : "Every program and library is exactly what its package installed."
                    color: root.faint
                    font.family: "Inter"
                    font.pixelSize: 13.5
                    wrapMode: Text.WordWrap
                }
            }

            Text {
                anchors.centerIn: parent
                visible: shield.busy
                text: "Checking every program and library…"
                color: root.muted
                font.family: "Inter"
                font.pixelSize: 15
            }

            ListView {
                anchors.fill: parent
                anchors.margins: 8
                clip: true
                visible: shield.findings.length > 0 && !shield.busy
                model: shield.findings
                spacing: 2

                delegate: Rectangle {
                    width: ListView.view.width
                    height: 52
                    radius: 5
                    color: index % 2 === 0 ? "transparent" : "#1B2634"

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 12
                        anchors.rightMargin: 12
                        spacing: 12

                        Rectangle {
                            width: 6; height: 6; radius: 3
                            color: modelData.verdict === "unowned" ? root.warn
                                 : modelData.verdict === "missing" ? root.warn
                                 : root.accent
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 1
                            Text {
                                Layout.fillWidth: true
                                text: modelData.path
                                color: root.ink
                                font.family: "Hack"
                                font.pixelSize: 13
                                elide: Text.ElideMiddle
                            }
                            Text {
                                Layout.fillWidth: true
                                text: modelData.note !== "" ? modelData.note
                                    : modelData.package !== ""
                                      ? "from " + modelData.package
                                      : "no package owns this"
                                color: root.faint
                                font.family: "Inter"
                                font.pixelSize: 11.5
                                elide: Text.ElideRight
                            }
                        }

                        Text {
                            text: modelData.verdict === "changed" ? "changed"
                                : modelData.verdict === "missing" ? "gone"
                                : modelData.verdict === "unowned" ? "unowned"
                                : modelData.verdict
                            color: root.muted
                            font.family: "Inter"
                            font.pixelSize: 12
                        }
                    }
                }
            }
        }

        // ---- footer --------------------------------------------------------

        RowLayout {
            Layout.fillWidth: true

            Text {
                text: "R  check     Esc  close"
                color: root.faint
                font.family: "Inter"
                font.pixelSize: 11.5
            }
            Item { Layout.fillWidth: true }
            Text {
                text: "hashes recorded by the packages themselves"
                color: root.faint
                font.family: "Inter"
                font.pixelSize: 11.5
            }
        }
    }
}
