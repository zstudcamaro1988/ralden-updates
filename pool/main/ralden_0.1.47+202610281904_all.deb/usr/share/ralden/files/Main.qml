/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - Files
 *
 * The owner's picture (reference/2a-files.jpg): a sidebar - Home, Recents,
 * Starred, then the person's Spaces - and the place it opens beside it,
 * its name at the top and round buttons at the right. Home is the
 * picture's page: the pinned folders as large folders, and under them the
 * files opened lately, each with the folder it is in and when.
 *
 * In Alpine Mist's navy, as every Ralden window is, and measured in the
 * same units as Settings: the picture's 26-pixel sidebar words at Plasma's
 * own type size.
 *
 * THIS FILE ONLY DRAWS. What is where, and what pressing does, is the
 * `files` object (/usr/lib/ralden/files/ralden_files/files.py): its
 * `state`, its `entries` and `recent`, and `files.act(verb, value)`.
 */
import QtQuick
import QtQuick.Window
import org.kde.kirigami as Kirigami
import "../settings/parts"
import "parts"

Window {
    id: window

    required property var files

    readonly property var st: files.state
    readonly property var entries: files.entries || []
    readonly property var recent: files.recent || []
    function act(verb, value) { files.act(verb, value) }

    title: st.place === "folder" ? st.title + " - Files" : "Files"
    color: Style.window
    visible: true

    readonly property real body: Math.max(11, Math.round(Kirigami.Units.gridUnit * 0.72))
    Binding { target: Style; property: "body"; value: window.body }
    Binding { target: Style; property: "u"; value: window.body / 26 }

    // Nearer the picture's shape than Settings' window (whose cards needed
    // the width): side by side with the picture on 20 October 2026, a
    // window of 2200 left Home's folders and rows small in a lot of navy.
    // The picture is a crop, 1626 wide; this is a little more.
    width: Math.min(Screen.desktopAvailableWidth - 40, Math.round(1900 * body / 26))
    height: Math.min(Screen.desktopAvailableHeight - 40, Math.round(1150 * body / 26))
    minimumWidth: Math.round(1100 * body / 26)
    minimumHeight: Math.round(640 * body / 26)

    // ---- what is selected -------------------------------------------------------------
    property var selected: ({})
    property int anchorIndex: -1
    property string renaming: ""

    function isSelected(path) { return selected[path] === true }
    function selectedPaths() {
        var out = []
        for (var k in selected) if (selected[k]) out.push(k)
        return out
    }
    function selectOnly(path) { var s = {}; if (path) s[path] = true; selected = s }
    function pick(list, index, modifiers) {
        var path = list[index].path
        var s = Object.assign({}, selected)
        if (modifiers & Qt.ShiftModifier && anchorIndex >= 0) {
            s = {}
            var a = Math.min(anchorIndex, index), b = Math.max(anchorIndex, index)
            for (var i = a; i <= b && i < list.length; i++) s[list[i].path] = true
        } else if (modifiers & Qt.ControlModifier) {
            if (s[path]) delete s[path]; else s[path] = true
            anchorIndex = index
        } else {
            s = {}
            s[path] = true
            anchorIndex = index
        }
        selected = s
    }
    function urlsFor(entry) {
        var paths = isSelected(entry.path) ? selectedPaths() : [entry.path]
        var urls = []
        var all = entries.concat(recent)
        for (var i = 0; i < all.length; i++)
            if (paths.indexOf(all[i].path) >= 0 && urls.indexOf(all[i].url) < 0) urls.push(all[i].url)
        return urls
    }
    onEntriesChanged: {
        var s = {}
        for (var i = 0; i < entries.length; i++)
            if (selected[entries[i].path]) s[entries[i].path] = true
        selected = s
    }
    Connections {
        target: window.files
        function onStateChanged() {
            if (window.st.renaming && window.st.renaming !== window.renaming) {
                window.renaming = window.st.renaming
                window.selectOnly(window.renaming)
            }
        }
    }

    function openEntry(entry) { act("open", entry.path) }
    function goTo(where) { selectOnly(""); renaming = ""; filter.text = ""; act("go", where) }

    // ---- the keys ------------------------------------------------------------------------
    Shortcut { sequences: [StandardKey.Back, "Alt+Left"]; onActivated: window.act("back", true) }
    Shortcut { sequences: ["Alt+Up", "Backspace"]; enabled: window.renaming === ""; onActivated: window.act("up", true) }
    Shortcut { sequences: [StandardKey.Copy]; enabled: window.renaming === ""; onActivated: window.act("copy", window.selectedPaths()) }
    Shortcut { sequences: [StandardKey.Cut]; enabled: window.renaming === ""; onActivated: window.act("cut", window.selectedPaths()) }
    Shortcut { sequences: [StandardKey.Paste]; enabled: window.renaming === ""; onActivated: window.act("paste", true) }
    Shortcut { sequences: [StandardKey.Delete]; enabled: window.renaming === ""; onActivated: window.act("trash", window.selectedPaths()) }
    Shortcut { sequences: ["F2"]; onActivated: { var p = window.selectedPaths(); if (p.length === 1) window.renaming = p[0] } }
    Shortcut { sequences: ["Ctrl+Shift+N"]; onActivated: window.act("newFolder", true) }
    Shortcut { sequences: ["Ctrl+H"]; onActivated: window.act("hidden", !window.st.hidden) }
    Shortcut { sequences: [StandardKey.SelectAll]; enabled: window.renaming === ""
        onActivated: { var s = {}; for (var i = 0; i < window.entries.length; i++) s[window.entries[i].path] = true; window.selected = s } }
    Shortcut { sequences: ["Return", "Enter"]; enabled: window.renaming === ""
        onActivated: { var p = window.selectedPaths(); if (p.length === 1) window.act("open", p[0]) } }
    Shortcut { sequences: [StandardKey.Find]; onActivated: filter.focusIt() }
    Shortcut { sequences: [StandardKey.Close, StandardKey.Quit]; onActivated: window.close() }

    // ---- the menus -------------------------------------------------------------------------
    function thingMenu(entry) {
        var trash = st.place === "trash"
        var many = selectedPaths().length > 1
        var items = []
        if (trash) {
            items.push({ "key": "restore", "label": "Put back" })
            return items
        }
        items.push({ "key": "open", "label": "Open", "usable": !many })
        items.push({ "key": "cut", "label": "Cut", "line": true })
        items.push({ "key": "copy", "label": "Copy" })
        items.push({ "key": "rename", "label": "Rename", "usable": !many })
        items.push({ "key": "trash", "label": "Move to Trash" })
        items.push({ "key": "star", "label": entry.starred ? "Unstar" : "Star", "line": true })
        if (entry.isDir && !many) {
            items.push({ "key": "pin", "label": st.place === "home" ? "Unpin from Home" : "Pin to Home" })
            items.push({ "key": "dolphin", "label": "Open in Dolphin" })
        }
        // Where something is, from the places that are not its folder
        // (in its own folder the menu offered it anyway, build 31).
        if (!entry.isDir && !many && st.place !== "folder")
            items.push({ "key": "folder", "label": "Show in its folder" })
        return items
    }
    function placeMenu() {
        var items = []
        if (st.place === "folder") {
            items.push({ "key": "newFolder", "label": "New folder", "usable": st.canWrite === true })
            items.push({ "key": "paste", "label": "Paste", "usable": st.canPaste === true })
            items.push({ "key": "star", "label": st.starredHere ? "Unstar this folder" : "Star this folder", "line": true })
            items.push({ "key": "pin", "label": st.pinnedHere ? "Unpin from Home" : "Pin to Home" })
            items.push({ "key": "terminal", "label": "Open a terminal here", "line": true })
            items.push({ "key": "dolphin", "label": "Open in Dolphin" })
        }
        if (st.place === "trash")
            items.push({ "key": "emptyTrash", "label": "Empty the Trash", "usable": entries.length > 0 })
        items.push({ "key": "hidden", "label": "Show hidden files", "on": st.hidden === true, "line": items.length > 0 })
        return items
    }
    property var menuEntry: null
    Menu {
        id: menu
        onPicked: function(key) {
            var e = window.menuEntry
            var paths = window.selectedPaths()
            if (key === "open" && e) window.openEntry(e)
            else if (key === "rename" && e) window.renaming = e.path
            else if (key === "folder" && e) window.goTo(e.path.substring(0, e.path.lastIndexOf("/")) || "/")
            else if (key === "pin") window.act("pin", e ? e.path : window.st.path)
            else if (key === "star") window.act("star", e ? paths : window.st.path)
            else if (key === "dolphin") window.act("dolphin", e ? e.path : window.st.path)
            else if (key === "terminal") window.act("terminal", window.st.path)
            else if (key === "newFolder") window.act("newFolder", true)
            else if (key === "paste") window.act("paste", true)
            else if (key === "emptyTrash") window.act("emptyTrash", true)
            else if (key === "hidden") window.act("hidden", !window.st.hidden)
            else if (key === "cut") window.act("cut", paths)
            else if (key === "copy") window.act("copy", paths)
            else if (key === "trash") window.act("trash", paths)
            else if (key === "restore") window.act("restore", paths)
        }
    }
    Menu {
        id: sortMenu
        width: Style.s(320)
        items: [
            { "key": "name", "label": "By name", "on": window.st.sort === "name" },
            { "key": "date", "label": "By date", "on": window.st.sort === "date" },
            { "key": "size", "label": "By size", "on": window.st.sort === "size" }
        ]
        onPicked: function(key) { window.act("sort", key) }
    }

    // ---- the sidebar ------------------------------------------------------------------------
    Rectangle {
        id: sidebar
        width: Style.s(405)
        height: parent.height
        color: Style.sidebar

        Flickable {
            anchors.fill: parent
            anchors.topMargin: Style.s(37)
            contentHeight: sideColumn.implicitHeight + Style.s(40)
            clip: true
            boundsBehavior: Flickable.StopAtBounds

            Column {
                id: sideColumn
                x: Style.s(30)
                width: Style.s(353)
                spacing: Style.s(1)

                Place { glyph: "home"; label: "Home"; chosen: window.st.place === "home"; onPicked: window.goTo("home") }
                Place { glyph: "clock"; label: "Recents"; chosen: window.st.place === "recents"; onPicked: window.goTo("recents") }
                Place { glyph: "star"; label: "Starred"; chosen: window.st.place === "starred"; onPicked: window.goTo("starred") }

                SideHeading { text: "Spaces" }
                Place {
                    glyph: "folder"
                    label: "Home folder"
                    chosen: window.st.place === "folder" && window.st.path === window.st.home
                    dropFolder: window.st.home || ""
                    onPicked: window.goTo(window.st.home)
                    onDropped: function(urls, move) { window.act("drop", { "urls": urls, "folder": window.st.home, "move": move }) }
                }
                Repeater {
                    model: window.st.spaces || []
                    Place {
                        required property var modelData
                        glyph: ({ "desktop": "desktop", "documents": "document", "download": "download",
                                  "pictures": "picture", "music": "music", "videos": "video" })[modelData.key] || "folder"
                        label: modelData.label
                        chosen: window.st.place === "folder" && window.st.path === modelData.path
                        dropFolder: modelData.path
                        onPicked: window.goTo(modelData.path)
                        onDropped: function(urls, move) { window.act("drop", { "urls": urls, "folder": modelData.path, "move": move }) }
                    }
                }

                SideHeading { visible: (window.st.drives || []).length > 0; text: "Drives" }
                Repeater {
                    model: window.st.drives || []
                    Place {
                        required property var modelData
                        glyph: "drive"
                        label: modelData.name
                        ejectable: true
                        chosen: window.st.place === "folder" && modelData.mountpoint !== ""
                                && window.st.path.indexOf(modelData.mountpoint) === 0
                        dropFolder: modelData.mountpoint
                        onPicked: window.act("mount", modelData.device)
                        onEject: window.act("eject", modelData.device)
                        onDropped: function(urls, move) { window.act("drop", { "urls": urls, "folder": modelData.mountpoint, "move": move }) }
                    }
                }

                Item { width: 1; height: Style.s(20) }
                Place { glyph: "trash"; label: "Trash"; chosen: window.st.place === "trash"; onPicked: window.goTo("trash") }
            }
        }
    }
    component SideHeading: Text {
        width: Style.s(353)
        height: Style.s(78)
        leftPadding: Style.s(18)
        topPadding: Style.s(34)
        color: Style.inkFaint
        font.family: Style.family
        font.pixelSize: Style.detailSize + 1
        font.weight: Font.Medium
    }

    // ---- the page --------------------------------------------------------------------------
    Item {
        id: page
        anchors.left: sidebar.right
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.leftMargin: Style.s(40)
        anchors.rightMargin: Style.s(36)

        // The way back to where this folder is: small, over its name.
        Row {
            id: crumbs
            visible: (window.st.crumbs || []).length > 1
            y: Style.s(28)
            spacing: Style.s(4)
            Repeater {
                model: (window.st.crumbs || []).slice(0, -1)
                Row {
                    required property var modelData
                    spacing: Style.s(4)
                    Text {
                        text: modelData.label
                        color: crumbHit.containsMouse ? Style.ink : Style.inkSoft
                        font.family: Style.family
                        font.pixelSize: Style.detailSize
                        MouseArea {
                            id: crumbHit
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: window.goTo(modelData.path)
                        }
                    }
                    Text {
                        text: "›"
                        color: Style.inkFaint
                        font.family: Style.family
                        font.pixelSize: Style.detailSize
                    }
                }
            }
        }
        Text {
            id: heading
            y: Style.s(52)
            width: parent.width - tools.width - Style.s(20)
            text: window.st.title || ""
            elide: Text.ElideMiddle
            color: Style.ink
            font.family: Style.family
            font.pixelSize: Style.titleSize
            font.weight: Font.DemiBold
        }
        Row {
            id: tools
            anchors.right: parent.right
            anchors.verticalCenter: heading.verticalCenter
            spacing: Style.s(10)
            Tool { glyph: "back"; label: "Back"; usable: window.st.canGoBack === true; onPressed: window.act("back", true) }
            Tool { glyph: "up"; label: "The folder this is in"; visible: window.st.canGoUp === true; onPressed: window.act("up", true) }
            Tool { glyph: "folder-new"; label: "New folder"; visible: window.st.place === "folder"; usable: window.st.canWrite === true; onPressed: window.act("newFolder", true) }
            Tool {
                glyph: window.st.view === "grid" ? "list" : "grid"
                label: window.st.view === "grid" ? "Show as a list" : "Show as icons"
                visible: window.st.place !== "home" && window.st.place !== "recents"
                onPressed: window.act("view", window.st.view === "grid" ? "list" : "grid")
            }
            Tool {
                id: sortTool
                glyph: "sort"
                label: "Sort"
                visible: window.st.place === "folder" || window.st.place === "starred"
                onPressed: sortMenu.openAt(sortTool, 0, sortTool.height + Style.s(6))
            }
            Tool {
                id: moreTool
                glyph: "more"
                label: "More"
                onPressed: { window.menuEntry = null; menu.items = window.placeMenu(); menu.openAt(moreTool, moreTool.width - menu.width, moreTool.height + Style.s(6)) }
            }
        }
        Field {
            id: filter
            visible: window.st.place !== "home" && window.entries.length > 0 || text !== ""
            y: heading.y + heading.height + Style.s(22)
            width: Math.min(parent.width, Style.s(620))
            height: Style.s(64)
            glyph: "search"
            placeholder: window.st.place === "folder" ? "Find in this folder" : "Find here"
        }

        // What is shown, after the line to find something in it.
        readonly property var shown: {
            var words = filter.text.toLowerCase().split(/\s+/).filter(function(w) { return w !== "" })
            if (words.length === 0) return window.entries
            return window.entries.filter(function(e) {
                var n = (e.label || e.name).toLowerCase()
                for (var i = 0; i < words.length; i++) if (n.indexOf(words[i]) < 0) return false
                return true
            })
        }

        Item {
            // Not `body`: that is the window's type size, and an id wins over a
            // property of the same name - the first build's window was sized
            // by this Item instead, and opened 160 pixels square.
            id: shownArea
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: filter.visible ? filter.bottom : heading.bottom
            anchors.topMargin: Style.s(24)
            anchors.bottom: noteBar.visible ? noteBar.top : parent.bottom
            anchors.bottomMargin: Style.s(16)

            // Right-click or a press on nothing: the place's own menu, and
            // nothing selected.
            MouseArea {
                anchors.fill: parent
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                onClicked: function(mouse) {
                    window.selectOnly("")
                    if (mouse.button === Qt.RightButton) {
                        window.menuEntry = null
                        menu.items = window.placeMenu()
                        menu.openAt(shownArea, mouse.x, mouse.y)
                    }
                }
            }
            DropArea {
                anchors.fill: parent
                enabled: window.st.place === "folder" && window.st.canWrite === true
                onEntered: function(drag) { drag.accepted = drag.hasUrls }
                onDropped: function(drop) {
                    var urls = []
                    for (var i = 0; i < drop.urls.length; i++) urls.push(drop.urls[i].toString())
                    window.act("drop", { "urls": urls, "folder": window.st.path,
                                         "move": drop.proposedAction === Qt.MoveAction })
                    drop.acceptProposedAction()
                }
            }

            Loader {
                anchors.fill: parent
                sourceComponent: window.st.place === "home" ? homeView
                               : (window.st.place === "recents" || window.st.view === "list") ? listView
                               : gridView
            }

            Text {
                visible: window.st.place !== "home" && page.shown.length === 0
                anchors.centerIn: parent
                width: Math.min(parent.width, Style.s(800))
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
                text: filter.text !== "" ? "Nothing here is called that."
                    : window.st.place === "trash" ? "The Trash is empty."
                    : window.st.place === "recents" ? "Nothing has been opened lately."
                    : window.st.place === "starred" ? "Right-click a file or a folder and choose Star, and it is kept here."
                    : "This folder is empty."
                color: Style.inkSoft
                font.family: Style.family
                font.pixelSize: Style.cardSize
            }
        }

        // ---- a line from the machine: what went wrong, or that a stick can come out
        Rectangle {
            id: noteBar
            visible: (window.st.note || "") !== ""
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            anchors.bottomMargin: Style.s(24)
            height: noteText.implicitHeight + Style.s(36)
            radius: Style.s(18)
            color: Style.accentTint
            Text {
                id: noteText
                x: Style.s(24)
                anchors.verticalCenter: parent.verticalCenter
                width: parent.width - x - Style.s(110)
                text: window.st.note || ""
                wrapMode: Text.WordWrap
                color: Style.ink
                font.family: Style.family
                font.pixelSize: Style.detailSize + 1
            }
            Tool {
                anchors.right: parent.right
                anchors.rightMargin: Style.s(12)
                anchors.verticalCenter: parent.verticalCenter
                glyph: "check"
                label: "Done"
                onPressed: window.act("noted", true)
            }
        }
    }

    // ---- the three ways a place is laid out --------------------------------------------------
    function thingPressed(list, index, modifiers) { window.pick(list, index, modifiers) }
    function thingMenuAt(item, entry, x, y) {
        if (!window.isSelected(entry.path)) window.selectOnly(entry.path)
        window.menuEntry = entry
        menu.items = window.thingMenu(entry)
        menu.openAt(item, x, y)
    }
    function renamedTo(entry, name) {
        window.renaming = ""
        window.act("rename", { "path": entry.path, "name": name })
    }

    // Home: the picture's page.
    Component {
        id: homeView
        Flickable {
            contentHeight: homeColumn.implicitHeight + Style.s(40)
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            Column {
                id: homeColumn
                width: parent.width
                spacing: Style.s(14)
                Heading { text: "Pinned" }
                Text {
                    visible: window.entries.length === 0
                    text: "Right-click a folder and choose Pin to Home, and it is kept here."
                    color: Style.inkSoft
                    font.family: Style.family
                    font.pixelSize: Style.detailSize + 1
                }
                Flow {
                    width: parent.width
                    spacing: Style.s(8)
                    Repeater {
                        model: window.entries
                        Thing {
                            id: thing1
                            required property var modelData
                            required property int index
                            mode: "tile"
                            entry: modelData
                            selected: window.isSelected(modelData.path)
                            editing: window.renaming === modelData.path
                            dragUrls: window.urlsFor(modelData)
                            onClicked: function(mods) { window.thingPressed(window.entries, index, mods) }
                            onOpened: window.openEntry(modelData)
                            onMenu: function(x, y) { window.thingMenuAt(thing1, modelData, x, y) }
                            onRenamed: function(name) { window.renamedTo(modelData, name) }
                            onRenameDropped: window.renaming = ""
                            onDropped: function(urls, move) { window.act("drop", { "urls": urls, "folder": modelData.path, "move": move }) }
                        }
                    }
                }
                Item { width: 1; height: Style.s(16) }
                Heading { text: "Recent" }
                Text {
                    visible: window.recent.length === 0
                    text: "The files you open are kept here for a while."
                    color: Style.inkSoft
                    font.family: Style.family
                    font.pixelSize: Style.detailSize + 1
                }
                Repeater {
                    model: window.recent
                    Thing {
                        id: thing2
                        required property var modelData
                        required property int index
                        width: homeColumn.width
                        mode: "row"
                        entry: modelData
                        middleText: modelData.where
                        rightText: modelData.whenText
                        selected: window.isSelected(modelData.path)
                        dragUrls: window.urlsFor(modelData)
                        onClicked: function(mods) { window.thingPressed(window.recent, index, mods) }
                        onOpened: window.openEntry(modelData)
                        onMenu: function(x, y) { window.thingMenuAt(thing2, modelData, x, y) }
                    }
                }
            }
        }
    }

    // Icons: every folder, Starred and the Trash, unless a list was asked for.
    Component {
        id: gridView
        GridView {
            id: grid
            clip: true
            model: page.shown
            cellWidth: Math.floor(width / Math.max(1, Math.floor(width / Style.s(220))))
            cellHeight: Style.s(246)
            boundsBehavior: Flickable.StopAtBounds
            delegate: Thing {
                id: thing3
                required property var modelData
                required property int index
                width: grid.cellWidth
                height: grid.cellHeight
                mode: "tile"
                entry: modelData
                selected: window.isSelected(modelData.path)
                editing: window.renaming === modelData.path
                dragUrls: window.urlsFor(modelData)
                onClicked: function(mods) { window.thingPressed(page.shown, index, mods) }
                onOpened: window.openEntry(modelData)
                onMenu: function(x, y) { window.thingMenuAt(thing3, modelData, x, y) }
                onRenamed: function(name) { window.renamedTo(modelData, name) }
                onRenameDropped: window.renaming = ""
                onDropped: function(urls, move) { window.act("drop", { "urls": urls, "folder": modelData.path, "move": move }) }
            }
        }
    }

    // A list: the picture's Recent rows - name, where (or what), when.
    Component {
        id: listView
        ListView {
            id: list
            clip: true
            model: page.shown
            spacing: Style.s(2)
            boundsBehavior: Flickable.StopAtBounds
            delegate: Thing {
                id: thing4
                required property var modelData
                required property int index
                width: list.width
                mode: "row"
                entry: modelData
                middleText: window.st.place === "folder" ? (modelData.whenText) : modelData.where
                rightText: window.st.place === "folder" ? (modelData.isDir ? "Folder" : modelData.sizeText)
                     : modelData.whenText
                selected: window.isSelected(modelData.path)
                editing: window.renaming === modelData.path
                dragUrls: window.urlsFor(modelData)
                onClicked: function(mods) { window.thingPressed(page.shown, index, mods) }
                onOpened: window.openEntry(modelData)
                onMenu: function(x, y) { window.thingMenuAt(thing4, modelData, x, y) }
                onRenamed: function(name) { window.renamedTo(modelData, name) }
                onRenameDropped: window.renaming = ""
                onDropped: function(urls, move) { window.act("drop", { "urls": urls, "folder": modelData.path, "move": move }) }
            }
        }
    }
}
