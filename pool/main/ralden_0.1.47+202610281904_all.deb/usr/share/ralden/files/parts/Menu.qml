/* SPDX-License-Identifier: Ralden-Source
 *
 * The list that opens where something was right-clicked, or under a
 * toolbar button: a rounded card of lines, each a word, a tick on the ones
 * that are on, a hairline between groups.
 *
 *   items: [{ "key", "label", "on"?, "usable"?, "line"? }]  - "line": true
 *          draws a hairline above that item
 */
import QtQuick
import QtQuick.Templates as T
import "../../settings/parts"
import org.ralden.flowbar as Flow

T.Popup {
    id: menu

    property var items: []
    signal picked(string key)

    function openAt(item, x, y) {
        var p = item.mapToItem(menu.parent, x, y)
        menu.x = Math.max(0, Math.min(p.x, menu.parent.width - menu.width - Style.s(12)))
        menu.y = Math.max(0, Math.min(p.y, menu.parent.height - menu.implicitHeight - Style.s(12)))
        menu.open()
    }

    padding: Style.s(10)
    width: Style.s(420)
    implicitHeight: column.implicitHeight + padding * 2
    modal: false
    focus: true
    closePolicy: T.Popup.CloseOnEscape | T.Popup.CloseOnPressOutside

    background: Rectangle {
        radius: Style.s(18)
        color: "#162033"
        border.width: 1
        border.color: Style.edge
    }

    contentItem: Column {
        id: column
        Repeater {
            model: menu.items
            Item {
                required property var modelData
                width: column.width
                height: Style.s(58) + (modelData.line ? Style.s(11) : 0)
                Rectangle {
                    visible: modelData.line === true
                    x: Style.s(10)
                    y: Style.s(5)
                    width: parent.width - Style.s(20)
                    height: 1
                    color: Style.line
                }
                Rectangle {
                    y: modelData.line ? Style.s(11) : 0
                    width: parent.width
                    height: Style.s(58)
                    radius: Style.s(12)
                    color: hit.containsMouse && modelData.usable !== false ? Style.cardLit : "transparent"
                    opacity: modelData.usable === false ? 0.4 : 1
                    Text {
                        x: Style.s(18)
                        anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - x - Style.s(56)
                        text: modelData.label
                        elide: Text.ElideRight
                        color: Style.ink
                        font.family: Style.family
                        font.pixelSize: Style.cardSize
                    }
                    Flow.Glyph {
                        visible: modelData.on === true
                        anchors.right: parent.right
                        anchors.rightMargin: Style.s(16)
                        anchors.verticalCenter: parent.verticalCenter
                        width: Style.s(28)
                        height: width
                        kind: "check"
                        ink: Style.accentInk
                    }
                    MouseArea {
                        id: hit
                        anchors.fill: parent
                        hoverEnabled: true
                        enabled: modelData.usable !== false
                        cursorShape: Qt.PointingHandCursor
                        onClicked: { menu.close(); menu.picked(modelData.key) }
                    }
                }
            }
        }
    }
}
