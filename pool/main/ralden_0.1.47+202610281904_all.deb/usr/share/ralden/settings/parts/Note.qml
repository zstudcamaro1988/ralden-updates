/* SPDX-License-Identifier: Ralden-Source
 *
 * A sentence of explanation: why a control is not there, what a choice
 * will do. Soft, and wrapped to the width it is given.
 */
import QtQuick

Text {
    width: parent ? parent.width : implicitWidth
    wrapMode: Text.WordWrap
    color: Style.inkSoft
    font.family: Style.family
    font.pixelSize: Style.detailSize
    lineHeight: 1.15
}
