/* SPDX-License-Identifier: Ralden-Source
 *
 * A person's picture, round: the photograph itself cut to a circle, not a
 * square laid on one.
 *
 * Seen on the test machine, 21 October 2026: the Accounts page drew its
 * pictures in round frames with the photographs inside them square. Plasma's
 * own avatars are drawn on nothing, so they looked round; every photograph
 * stuck out at its corners, and so did the one chosen as the account's own.
 * `clip` cuts to the rectangle around a rounded Rectangle, never to its
 * curve. A mask does: MultiEffect, from QtQuick.Effects, which the image
 * has (read off the machine the same day).
 */
import QtQuick
import QtQuick.Effects

Item {
    id: portrait

    property url source
    // Pixels asked of the file: twice the size drawn, for a sharp edge.
    property size sourceSize: Qt.size(width * 2, height * 2)
    readonly property bool ready: photo.status === Image.Ready

    Image {
        id: photo
        anchors.fill: parent
        source: portrait.source
        sourceSize: portrait.sourceSize
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        visible: false
    }
    // The circle the photograph is cut to; drawn only as the mask.
    Item {
        id: circle
        anchors.fill: parent
        layer.enabled: true
        visible: false
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: "black"
        }
    }
    MultiEffect {
        anchors.fill: parent
        source: photo
        maskEnabled: true
        maskSource: circle
        // The circle's soft edge pixels, taken as half in: a smooth edge
        // rather than a stepped one.
        maskThresholdMin: 0.5
        maskSpreadAtMin: 1.0
    }
}
