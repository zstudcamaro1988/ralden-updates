/* SPDX-License-Identifier: Ralden-Source
 *
 * The title at the top of a page: the picture's "System", 38 of its pixels
 * tall. A page under another has a back mark before it, and its parent's
 * name over it, small.
 */
import QtQuick
import org.ralden.flowbar as Flow

Item {
    id: title

    property string text: ""
    property string parentName: ""     // "" for a page of the sidebar
    signal back()

    width: parent ? parent.width : implicitWidth
    implicitHeight: Style.s(72)

    Item {
        id: backMark
        visible: title.parentName !== ""
        width: visible ? Style.s(56) : 0
        height: Style.s(56)
        anchors.verticalCenter: parent.verticalCenter
        x: -Style.s(10)
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: backPress.pressed ? Style.cardPressed : backPress.containsMouse ? Style.cardLit : "transparent"
        }
        Flow.Glyph {
            anchors.centerIn: parent
            width: Style.s(34)
            height: width
            kind: "back"
            ink: Style.ink
        }
        MouseArea {
            id: backPress
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: title.back()
        }
        Accessible.role: Accessible.Button
        Accessible.name: "Back to " + title.parentName
    }
    Column {
        anchors.left: backMark.right
        anchors.leftMargin: backMark.visible ? Style.s(10) : 0
        anchors.verticalCenter: parent.verticalCenter
        Text {
            visible: title.parentName !== ""
            text: title.parentName
            color: Style.inkSoft
            font.family: Style.family
            font.pixelSize: Style.detailSize
        }
        Text {
            text: title.text
            color: Style.ink
            font.family: Style.family
            font.pixelSize: Style.titleSize
            font.weight: Font.DemiBold
        }
    }
}
