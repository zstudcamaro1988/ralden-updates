/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - Settings, measured
 *
 * Every length on every page is the picture's (reference/2d-settings.jpg,
 * 1729 of its pixels wide) times `u`. Main.qml sets `u` from the size of
 * Plasma's own type, so that the picture's 26-pixel sidebar labels are the
 * size Plasma writes everything else in: the window is as big, for the same
 * reader, as every other window on the machine.
 *
 * The colours are Alpine Mist's (the owner's choice, 13 October 2026): the
 * picture is drawn on white, Ralden's windows are its navy, and the type
 * and the glass are white over it - as the Control Center's are.
 */
pragma Singleton
import QtQuick

QtObject {
    property real u: 0.5
    property real body: 13

    function s(x) { return Math.round(x * u) }

    readonly property string family: "Inter"

    // The window: Alpine Mist's navy, the colour of the window frame.
    readonly property color window: "#1E293B"
    // The sidebar, a shade under it, as the picture's is a shade off white.
    readonly property color sidebar: Qt.rgba(13 / 255, 21 / 255, 38 / 255, 0.42)
    // Cards and rows: a little light laid on the navy.
    readonly property color card: Qt.rgba(1, 1, 1, 0.055)
    readonly property color cardLit: Qt.rgba(1, 1, 1, 0.09)
    readonly property color cardPressed: Qt.rgba(1, 1, 1, 0.035)
    readonly property color edge: Qt.rgba(1, 1, 1, 0.075)
    readonly property color line: Qt.rgba(1, 1, 1, 0.07)
    readonly property color tile: Qt.rgba(1, 1, 1, 0.07)

    readonly property color ink: "#FFFFFF"
    readonly property color inkSoft: Qt.rgba(1, 1, 1, 0.64)
    readonly property color inkFaint: Qt.rgba(1, 1, 1, 0.38)

    // kdeglobals' AccentColor: the blue the rest of Ralden is marked in.
    readonly property color accent: Qt.rgba(74 / 255, 144 / 255, 226 / 255, 1)
    readonly property color accentTint: Qt.rgba(74 / 255, 144 / 255, 226 / 255, 0.24)
    readonly property color accentInk: Qt.rgba(126 / 255, 182 / 255, 245 / 255, 1)
    readonly property color warning: Qt.rgba(246 / 255, 173 / 255, 85 / 255, 1)

    // Type: Plasma's size, in the picture's proportions.
    readonly property real sideSize: Math.round(body * 1.08)
    readonly property real titleSize: Math.round(body * 1.62)
    readonly property real cardSize: Math.round(body * 1.0)
    readonly property real detailSize: Math.round(body * 0.86)
    readonly property real headingSize: Math.round(body * 0.95)
}
