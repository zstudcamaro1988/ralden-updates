/* SPDX-License-Identifier: Ralden-Source
 *
 * A slider, the Control Center's: a thin rail, the part up to the knob in
 * the accent, and a round knob.
 *
 * THE DELAY IS THE DESIGN (the Control Center's Rail.qml says it at
 * length): the knob moves freely and the value is sent when the movement
 * settles, a fifth of a second of quiet, and again when the button is let
 * go - not a command a frame. While it is held, what the machine reports
 * does not move it.
 */
import QtQuick

Item {
    id: rail

    property int value: 0              // what the machine last said, 0-100
    property bool usable: true
    property string label: ""

    signal moving(int value)
    signal chosen(int value)

    readonly property real knob: Math.max(12, Style.s(28))
    readonly property real thick: Math.max(3, Style.s(6))
    property real shown: value
    property bool held: false

    implicitHeight: knob + Style.s(14)
    implicitWidth: Style.s(420)
    opacity: usable ? 1.0 : 0.4

    onValueChanged: if (!held) shown = value

    readonly property real span: width - knob
    function at(x) {
        return Math.max(0, Math.min(100, Math.round((x - knob / 2) / Math.max(1, span) * 100)))
    }

    Rectangle {
        id: track
        x: rail.knob / 2
        width: rail.span
        height: rail.thick
        radius: height / 2
        anchors.verticalCenter: parent.verticalCenter
        color: Qt.rgba(1, 1, 1, 0.18)
    }
    Rectangle {
        x: track.x
        width: rail.span * rail.shown / 100
        height: rail.thick
        radius: height / 2
        anchors.verticalCenter: parent.verticalCenter
        color: rail.usable ? Style.accent : Qt.rgba(1, 1, 1, 0.3)
    }
    Rectangle {
        width: rail.knob
        height: width
        radius: width / 2
        x: rail.span * rail.shown / 100
        anchors.verticalCenter: parent.verticalCenter
        color: rail.usable ? Qt.rgba(92 / 255, 158 / 255, 236 / 255, 1) : Qt.rgba(1, 1, 1, 0.45)
        border.width: Math.max(1, Style.s(2))
        border.color: Qt.rgba(1, 1, 1, rail.held ? 0.85 : 0.55)
    }

    MouseArea {
        anchors.fill: parent
        enabled: rail.usable
        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        preventStealing: true
        onPressed: function(mouse) {
            rail.held = true
            rail.shown = rail.at(mouse.x)
            rail.moving(rail.shown)
            settle.restart()
        }
        onPositionChanged: function(mouse) {
            if (!pressed) return
            rail.shown = rail.at(mouse.x)
            rail.moving(rail.shown)
            settle.restart()
        }
        onReleased: {
            settle.stop()
            rail.held = false
            rail.chosen(rail.shown)
        }
        onCanceled: {
            settle.stop()
            rail.held = false
            rail.shown = rail.value
        }
    }
    WheelHandler {
        enabled: rail.usable
        onWheel: function(event) {
            var step = event.angleDelta.y > 0 ? 5 : -5
            rail.shown = Math.max(0, Math.min(100, rail.shown + step))
            rail.moving(rail.shown)
            wheelSettle.restart()
        }
    }
    Keys.onLeftPressed: { rail.shown = Math.max(0, rail.shown - 5); rail.chosen(rail.shown) }
    Keys.onRightPressed: { rail.shown = Math.min(100, rail.shown + 5); rail.chosen(rail.shown) }
    activeFocusOnTab: usable

    Timer {
        id: settle
        interval: 200
        onTriggered: rail.chosen(rail.shown)
    }
    Timer {
        id: wheelSettle
        interval: 250
        onTriggered: rail.chosen(rail.shown)
    }
    Accessible.role: Accessible.Slider
    Accessible.name: rail.label
}
