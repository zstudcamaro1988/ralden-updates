/* SPDX-License-Identifier: Ralden-Source
 *
 * A number with a minus before it and a plus after it: how many of
 * something, one more or one fewer at a press. The number is what the
 * machine last said; a press asks, and the page shows the answer.
 */
import QtQuick

Row {
    id: stepper

    property int value: 0
    property int least: 0
    property int most: 99
    property bool usable: true
    property string label: ""

    signal fewer()
    signal more()

    spacing: Style.s(14)
    opacity: usable ? 1 : 0.45

    component Round: Item {
        id: round
        property string mark: ""
        property bool can: true
        property string name: ""
        signal pressed()
        width: Style.s(56)
        height: width
        opacity: can ? 1 : 0.35
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: press.pressed ? Style.cardPressed : press.containsMouse ? Style.cardLit : Style.card
            border.width: 1
            border.color: Style.edge
        }
        // Drawn, not typed: a hyphen and a plus in a font sit at different
        // heights and widths, and the two have to match.
        Rectangle {
            anchors.centerIn: parent
            width: Style.s(22)
            height: Math.max(2, Style.s(3))
            radius: height / 2
            color: Style.ink
        }
        Rectangle {
            visible: round.mark === "+"
            anchors.centerIn: parent
            width: Math.max(2, Style.s(3))
            height: Style.s(22)
            radius: width / 2
            color: Style.ink
        }
        MouseArea {
            id: press
            anchors.fill: parent
            enabled: stepper.usable && round.can
            hoverEnabled: true
            cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
            onClicked: round.pressed()
        }
        Accessible.role: Accessible.Button
        Accessible.name: round.name
    }

    Round {
        mark: "-"
        can: stepper.value > stepper.least
        name: "One fewer " + stepper.label
        onPressed: stepper.fewer()
    }
    Text {
        width: Style.s(52)
        height: Style.s(56)
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        text: stepper.value
        color: Style.ink
        font.family: Style.family
        font.pixelSize: Style.cardSize
        font.weight: Font.DemiBold
        font.features: { "tnum": 1 }
    }
    Round {
        mark: "+"
        can: stepper.value < stepper.most
        name: "One more " + stepper.label
        onPressed: stepper.more()
    }
}
