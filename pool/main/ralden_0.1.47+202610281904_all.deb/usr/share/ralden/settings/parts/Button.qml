/* SPDX-License-Identifier: Ralden-Source
 *
 * A button: a pill with a word on it; `strong` is the accent, for the one
 * thing a moment asks for.
 */
import QtQuick

Item {
    id: button

    property string text: ""
    property bool strong: false
    property bool usable: true
    signal pressed()

    implicitWidth: label.implicitWidth + Style.s(64)
    implicitHeight: Style.s(64)
    opacity: usable ? 1 : 0.45

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: button.strong ? (press.pressed ? Qt.darker(Style.accent, 1.15)
                                              : press.containsMouse ? Qt.lighter(Style.accent, 1.08) : Style.accent)
                             : (press.pressed ? Style.cardPressed : press.containsMouse ? Style.cardLit : Style.card)
        border.width: button.strong ? 0 : 1
        border.color: Style.edge
    }
    Text {
        id: label
        anchors.centerIn: parent
        text: button.text
        color: Style.ink
        font.family: Style.family
        font.pixelSize: Style.detailSize
        font.weight: Font.DemiBold
    }
    MouseArea {
        id: press
        anchors.fill: parent
        enabled: button.usable
        hoverEnabled: true
        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: button.pressed()
    }
    Accessible.role: Accessible.Button
    Accessible.name: button.text
}
