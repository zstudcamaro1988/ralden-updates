/* SPDX-License-Identifier: Ralden-Source
 *
 * A rounded card holding lines (Line.qml), under an optional heading.
 */
import QtQuick

Column {
    id: group

    property string heading: ""
    default property alias lines: inner.data

    width: parent ? parent.width : implicitWidth
    spacing: Style.s(16)

    Heading {
        visible: group.heading !== ""
        text: group.heading
    }
    Rectangle {
        width: group.width
        height: inner.implicitHeight
        radius: Style.s(22)
        color: Style.card
        border.width: 1
        border.color: Style.edge
        Column {
            id: inner
            width: parent.width
        }
    }
}
