/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - Privacy
 *
 *   Recent files     forget the files opened lately - both places they are
 *                    remembered (areas.py) - and Plasma's own page for
 *                    choosing what is remembered at all.
 *   The internet     what this computer asks, of whom, and how often, said
 *                    plainly. Each line is true of the image as it is built
 *                    (the weather's timer, apt's, fwupd's; no usage
 *                    reporting installed) - read off the test machine on 21
 *                    October 2026.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.privacy : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle { text: "Privacy" }

        Group {
            heading: "Recent files"
            Line {
                title: "Forget the files opened lately"
                detail: page.st.forgotten === true
                        ? "Forgotten. The search panel and Files start their lists again from now."
                        : "The search panel and Files list them, to open again quickly."
                Button {
                    text: "Forget"
                    usable: page.st.busy !== true
                    onPressed: page.act("forget", true)
                }
            }
        }
        Note {
            visible: (page.st.note || "") !== ""
            text: page.st.note || ""
        }
        LinkRow {
            width: parent.width
            glyph: "document"
            title: "Choose what is remembered"
            detail: "Which programs' files are kept in the list, and for how long, in Plasma's own page for it"
            onPicked: page.act("more", true)
        }

        Group {
            heading: "What this computer asks the internet"
            Line {
                title: "Where it is"
                detail: "The town its internet connection is in, from KDE's lookup service (geoip.kde.org) - for the weather, and for the clock when it is first set up. Nothing is sent with the question."
            }
            Line {
                title: "The weather"
                detail: "From Open-Meteo, every half hour, for that town's position to about a kilometre. No account, nothing else sent."
            }
            // The clock's: systemd-timesyncd, Debian's servers (timedatectl
            // show-timesync, read off the installed test machine on 21
            // October 2026: 0-3.debian.pool.ntp.org, at most 34 minutes apart).
            Line {
                title: "The time"
                detail: "From Debian's time servers (debian.pool.ntp.org), about every half hour once the clock is right. Nothing is sent but the question."
            }
            // Discover's notifier runs from the start of every session
            // (DiscoverNotifier --check-delay 20, seen running the same day),
            // not only when Discover is opened.
            Line {
                title: "Updates"
                detail: "Debian's lists of updates, every day; and, in the background, Discover's notifier looks for updates from Debian and Flathub, to say when some are waiting."
            }
            Line {
                title: "Firmware"
                detail: "The list of firmware updates for this computer's parts, from the Linux Vendor Firmware Service (fwupd), every day."
            }
            Line {
                title: "How it is used"
                detail: "Nothing. Ralden has no usage reporting, and Plasma's own (KDE User Feedback) is off unless someone turns it on."
            }
        }
    }
}
