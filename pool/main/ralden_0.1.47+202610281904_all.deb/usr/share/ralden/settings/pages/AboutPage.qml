/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - About
 *
 * What this computer is and what it runs, read off the machine:
 * hostnamectl (its name, its maker and model, the kernel), /proc (the
 * processor and the memory), lspci (the graphics), lsblk (the drives),
 * /etc/os-release and Plasma's own version. And a button to copy all of
 * it, for whoever is asked for help.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.about : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle { text: "About" }

        // The logo and what this is, as large as the picture's cards.
        Item {
            width: parent.width
            height: Style.s(150)
            Image {
                id: mark
                source: "../mark.png"
                width: Style.s(150)
                height: width
                sourceSize.width: 256
                sourceSize.height: 256
                smooth: true
                mipmap: true
            }
            Column {
                anchors.left: mark.right
                anchors.leftMargin: Style.s(24)
                anchors.verticalCenter: parent.verticalCenter
                spacing: Style.s(8)
                Text {
                    text: page.st.system || "Ralden OS"
                    color: Style.ink
                    font.family: Style.family
                    font.pixelSize: Style.titleSize
                    font.weight: Font.DemiBold
                }
                Text {
                    text: page.st.version ? "Version " + page.st.version : ""
                    color: Style.inkSoft
                    font.family: Style.family
                    font.pixelSize: Style.detailSize
                }
                Text {
                    visible: page.st.live === true
                    text: "Running from the Ralden OS disk"
                    color: Style.accentInk
                    font.family: Style.family
                    font.pixelSize: Style.detailSize
                }
            }
        }

        Group {
            heading: "This computer"
            Line { title: "Name"; detail: page.st.name || "" }
            Line { visible: (page.st.model || "") !== ""; title: "Made by"; detail: page.st.model || "" }
            Line {
                title: "Processor"
                detail: (page.st.processor || "") + (page.st.cores ? "  ·  " + page.st.cores + (page.st.cores === 1 ? " thread" : " threads") : "")
            }
            Line { title: "Memory"; detail: page.st.memory || "" }
            Line { visible: (page.st.graphics || "") !== ""; title: "Graphics"; detail: page.st.graphics || "" }
            Line { visible: (page.st.storage || "") !== ""; title: "Storage"; detail: page.st.storage || "" }
        }

        Group {
            heading: "Software"
            Line { title: "Ralden OS"; detail: page.st.version || "" }
            Line { visible: (page.st.plasma || "") !== ""; title: "Desktop"; detail: "KDE Plasma " + (page.st.plasma || "") }
            Line { visible: (page.st.kernel || "") !== ""; title: "Kernel"; detail: "Linux " + (page.st.kernel || "") }
        }

        Row {
            spacing: Style.s(20)
            Button {
                text: "Copy these details"
                onPressed: page.act("copy", true)
            }
            Text {
                visible: page.st.copied === true
                anchors.verticalCenter: parent.verticalCenter
                text: "Copied."
                color: Style.inkSoft
                font.family: Style.family
                font.pixelSize: Style.detailSize
            }
        }
    }
}
