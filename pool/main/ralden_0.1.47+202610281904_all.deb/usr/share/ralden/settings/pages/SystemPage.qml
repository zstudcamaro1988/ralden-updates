/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - System, the picture's page: three cards across the top
 * (Display, Sound, Notifications) and long rows under them, each opening
 * its own page.
 *
 * THE LINES UNDER THE TITLES SAY WHAT IS ON THE PAGE BEHIND THEM. The
 * picture's "Brightness, HDR, night mode" and "Output, input, spatial
 * audio" name things a 2009 laptop and an X11 desktop do not have (HDR,
 * spatial audio); these name what the pages behind them hold.
 *
 * Every row of the picture's System page is here. The picture's "Snap
 * layouts" under Multitasking is Windows' name; KWin snaps by dragging.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)

    readonly property var power: areas ? areas.power : null
    readonly property var ps: power ? power.state : ({})

    readonly property string powerDetail: {
        if (!ps.known) return ""
        var profile = ""
        var names = { "power-saver": "Power saver", "balanced": "Balanced", "performance": "Performance" }
        if (ps.profile) profile = names[ps.profile] || ""
        var b = ""
        if (ps.hasBattery)
            b = ps.charging ? ps.battery + "%, charging"
              : ps.full ? "Fully charged" : ps.battery + "% left"
        else
            b = "Plugged in"
        return profile !== "" ? profile + " · " + b : b
    }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(29)

        PageTitle { text: "System" }

        Row {
            id: cards
            width: parent.width
            spacing: Style.s(29)
            readonly property real cardWidth: Math.floor((width - spacing * 2) / 3)
            Card {
                width: cards.cardWidth
                glyph: "monitor"
                title: "Display"
                detail: "Brightness, Night Light, resolution"
                onPicked: page.open("display")
            }
            Card {
                width: cards.cardWidth
                glyph: "volume"
                level: 3
                title: "Sound"
                detail: "Output, input, volume"
                onPicked: page.open("sound")
            }
            Card {
                width: cards.cardWidth
                glyph: "bell"
                title: "Notifications"
                detail: "Banners, sounds, Do Not Disturb"
                onPicked: page.open("notifications")
            }
        }

        Column {
            width: parent.width
            spacing: Style.s(8)
            LinkRow {
                width: parent.width
                glyph: "power"
                title: "Power & Battery"
                detail: page.powerDetail
                onPicked: page.open("power")
            }
            LinkRow {
                width: parent.width
                glyph: "multitask"
                title: "Multitasking"
                detail: "Snapping windows, overview, workspaces"
                onPicked: page.open("multitasking")
            }
            LinkRow {
                width: parent.width
                glyph: "keyboard"
                title: "Keyboard"
                detail: "Shortcuts, typing, layouts"
                onPicked: page.open("keyboard")
            }
            LinkRow {
                width: parent.width
                glyph: "mouse"
                title: "Mouse & Touchpad"
                detail: "Pointer speed, tapping, scrolling"
                onPicked: page.open("pointing")
            }
        }
    }
}
