/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - Bluetooth
 *
 *   Bluetooth      on or off; a computer without it is told so.
 *   Your devices   the paired ones, each Connected or not, with Connect or
 *                  Disconnect, and Forget.
 *   Add a device   Look (twelve seconds of listening), then each device
 *                  that gave its name, with Pair. A device that wants a
 *                  number confirmed is asked about by Plasma's own
 *                  Bluetooth window, on the screen.
 *   More           Plasma's own Bluetooth window, for what this page does
 *                  not do yet (sending and receiving files).
 *
 * Through Settings' own helper, BlueZ over D-Bus (areas.py says why not
 * bluetoothctl).
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.bluetooth : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property bool readable: st.known === true && st.failed !== true
    readonly property bool working: (st.busy || "") !== "" || st.looking === true
    readonly property var paired: st.paired || []
    readonly property var found: st.found || []

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle { text: "Bluetooth" }

        Note {
            visible: page.st.known === true && page.st.failed === true
            text: "Bluetooth did not answer, so its devices cannot be shown."
        }

        Group {
            visible: page.readable
            heading: "Bluetooth"
            Line {
                visible: page.st.adapter !== true
                title: "No Bluetooth"
                detail: "This computer has no Bluetooth that Ralden can use."
            }
            Line {
                visible: page.st.adapter === true
                title: "Bluetooth"
                detail: page.st.powered === true
                        ? ((page.st.name || "") !== "" ? "On · This computer's Bluetooth name is " + page.st.name : "On")
                        : "Off"
                Switch {
                    on: page.st.powered === true
                    usable: !page.working
                    label: "Bluetooth"
                    onFlipped: page.act("power", !on)
                }
            }
        }

        Note {
            visible: (page.st.busy || "") !== ""
            text: page.st.busy || ""
        }
        Note {
            visible: (page.st.note || "") !== ""
            text: page.st.note || ""
        }

        Group {
            visible: page.readable && page.st.powered === true && page.paired.length > 0
            heading: "Your devices"
            Repeater {
                model: page.paired
                Line {
                    required property var modelData
                    title: modelData.name
                    detail: modelData.kind + " · " + (modelData.connected ? "Connected" : "Not connected")
                    Row {
                        spacing: Style.s(12)
                        Button {
                            text: "Forget"
                            usable: !page.working
                            onPressed: page.act("forget", modelData.address)
                        }
                        Button {
                            text: modelData.connected ? "Disconnect" : "Connect"
                            usable: !page.working
                            onPressed: modelData.connected
                                       ? page.act("disconnect", modelData.address)
                                       : page.act("connect", modelData.address)
                        }
                    }
                }
            }
        }

        Group {
            visible: page.readable && page.st.powered === true
            heading: "Add a device"
            Line {
                title: page.st.looking === true ? "Looking for devices…" : "Look for devices"
                detail: "Put the device in pairing mode first; its instructions say how."
                Button {
                    text: "Look"
                    usable: !page.working
                    onPressed: page.act("look", true)
                }
            }
            Repeater {
                model: page.found
                Line {
                    required property var modelData
                    title: modelData.name
                    detail: modelData.kind
                    Button {
                        text: "Pair"
                        strong: true
                        usable: !page.working
                        onPressed: page.act("pair", modelData.address)
                    }
                }
            }
        }

        Column {
            visible: page.readable && page.st.adapter === true
            width: parent.width
            spacing: Style.s(16)
            Heading { text: "More" }
            LinkRow {
                width: parent.width
                glyph: "bluetooth"
                title: "Other Bluetooth settings"
                detail: "Sending and receiving files, and each device's own details"
                onPicked: page.act("more", true)
            }
        }
    }
}
