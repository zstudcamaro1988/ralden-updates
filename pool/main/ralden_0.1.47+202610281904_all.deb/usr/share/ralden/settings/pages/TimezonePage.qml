/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - Time & Language - Time zone
 *
 * Every place the clock can be set to, found by city, country or the few
 * words the tables give a country with more than one zone ("Central"):
 * the First Start's list, read the same way (readers.time_zones). Each says
 * how far its clock is from the world's. Choosing one asks timedated for it
 * and goes back to Time & Language, which says when it has been made.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.time : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property var found: st.found || []
    // As many as the area hands back at most (readers.ZONES_SHOWN).
    readonly property int shownMost: 60

    // In the page, not the row's handler: going back destroys the row.
    function choose(key) {
        page.act("zone", key)
        page.open("time")
    }

    implicitHeight: column.implicitHeight
    Component.onCompleted: { page.act("find", ""); search.focusIt() }

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Time zone"
            parentName: "Time & Language"
            onBack: page.open("time")
        }

        Field {
            id: search
            width: parent.width
            glyph: "search"
            placeholder: "Find a city or a country"
            onTextChanged: page.act("find", text)
        }

        Group {
            visible: page.found.length > 0
            Repeater {
                model: page.found
                Line {
                    required property var modelData
                    readonly property bool isHere: modelData.key === page.st.zone
                    title: modelData.city
                    detail: [modelData.where, modelData.offset].filter(function(p) { return p !== "" }).join(" · ")
                    Button {
                        text: isHere ? "Chosen" : "Choose"
                        usable: !isHere && page.st.busy !== true
                        onPressed: page.choose(modelData.key)
                    }
                }
            }
        }

        Note {
            visible: page.st.zonesKnown === true && page.found.length === 0
            text: page.st.anyZones === true
                  ? "No place is called that."
                  : "The list of places could not be read."
        }
        Note {
            visible: page.found.length >= page.shownMost
            text: "Only the first " + page.shownMost + " are shown. Type more of the name to find the rest."
        }
    }
}
