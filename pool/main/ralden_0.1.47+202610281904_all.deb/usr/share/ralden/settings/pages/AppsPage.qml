/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - Apps
 *
 *   Default programs   which program opens each kind of file - web pages,
 *                      email, folders, music, videos, pictures, text, PDF -
 *                      written where every desktop reads it
 *                      (~/.config/mimeapps.list), out of the programs that
 *                      say they can open that kind.
 *   Installed          the programs the menu shows, each with Open; and a way
 *                      to Discover, where programs are added and removed.
 *
 * Read from the desktop's own files (readers.desktop_entries and the
 * mimeapps.list rule); nothing here guesses.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.apps : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property var kinds: st.kinds || []
    readonly property var programs: st.programs || []

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle { text: "Apps" }

        Group {
            visible: page.st.known === true
            heading: "Default programs"
            Repeater {
                model: page.kinds
                Line {
                    required property var modelData
                    title: modelData.label
                    detail: modelData.options.length === 0
                            ? "Nothing on this computer opens these yet."
                            : modelData.current === ""
                              ? "None is chosen yet, so the computer picks one."
                              : ""
                    Choice {
                        visible: modelData.options.length > 0
                        options: modelData.options
                        chosen: modelData.current
                        label: modelData.label
                        onPicked: function(key) {
                            page.act("default", { "kind": modelData.key, "app": key })
                        }
                    }
                }
            }
        }

        Note {
            visible: (page.st.note || "") !== ""
            text: page.st.note || ""
        }

        Column {
            visible: page.st.known === true
            width: parent.width
            spacing: Style.s(16)
            Heading { text: "Programs" }
            LinkRow {
                width: parent.width
                glyph: "download"
                title: "Get more programs, or remove one"
                detail: "In Discover, which finds them in Debian's archive and on Flathub"
                onPicked: page.act("discover", true)
            }
        }

        Group {
            visible: page.st.known === true && page.programs.length > 0
            Repeater {
                model: page.programs
                Line {
                    required property var modelData
                    title: modelData.label
                    Button {
                        text: "Open"
                        onPressed: page.act("start", modelData.key)
                    }
                }
            }
        }
    }
}
