/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - Network
 *
 *   Wi-Fi    on or off (NetworkManager's switch; the computer's own switch
 *            or key, where it has one, is said to be off when it is), the
 *            networks that can be seen, the one joined first, and each one's
 *            Connect, Disconnect and Forget. A network with a password asks
 *            for it here, in a box of its own above the list - the list is
 *            looked at again every few seconds, and a box inside it would be
 *            made again under the person typing.
 *   Wired    each socket, whether a cable is in it, and the address it has.
 *
 * Read with nmcli, as the Control Center's tiles are; a password goes to
 * NetworkManager by wifi-join, on its standard input, never on a command
 * line (areas.py).
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.network : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property bool readable: st.known === true && st.failed !== true
    readonly property var networks: st.networks || []
    readonly property var wired: st.wired || []
    readonly property bool joining: (st.joining || "") !== ""

    readonly property string wifiDetail: {
        if (st.switchOn !== true)
            return "The Wi-Fi switch or key on the computer itself is off."
        if (st.wifiOn !== true)
            return "Off"
        if (joining)
            return "Joining " + st.joining + "…"
        if ((st.wifiConnection || "") !== "" && st.wifiState === "connected")
            return "Connected to " + st.wifiConnection
        return "Not connected"
    }

    // In the page, not the box's own handler: the box goes when it is sent.
    function sendPassword() {
        page.act("password", { "password": password.text })
        password.text = ""
    }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle { text: "Network" }

        Note {
            visible: page.st.known === true && page.st.failed === true
            text: "NetworkManager did not answer, so this computer's networks cannot be shown."
        }

        Group {
            visible: page.readable
            heading: "Wi-Fi"
            Line {
                visible: page.st.hasWifi !== true
                title: "No Wi-Fi"
                detail: "This computer has no Wi-Fi that Ralden can use."
            }
            Line {
                visible: page.st.hasWifi === true
                title: "Wi-Fi"
                detail: page.wifiDetail
                usable: page.st.switchOn === true
                Switch {
                    on: page.st.wifiOn === true
                    usable: page.st.switchOn === true && !page.joining
                    label: "Wi-Fi"
                    onFlipped: page.act("wifi", !on)
                }
            }
        }

        Group {
            visible: page.readable && (page.st.asking || "") !== ""
            heading: "Join " + (page.st.asking || "")
            Line {
                title: "Password"
                detail: "The network's password, as its owner set it. It is kept on this computer, for next time."
                wide: true
                Row {
                    spacing: Style.s(16)
                    Field {
                        id: password
                        width: Style.s(520)
                        secret: true
                        placeholder: "Password"
                        onAccepted: page.sendPassword()
                    }
                    Button {
                        text: "Join"
                        strong: true
                        usable: password.text.length >= 8
                        onPressed: page.sendPassword()
                    }
                    Button {
                        text: "Cancel"
                        onPressed: { password.text = ""; page.act("cancel", true) }
                    }
                }
            }
        }

        Note {
            visible: (page.st.note || "") !== ""
            text: page.st.note || ""
        }

        Group {
            visible: page.readable && page.st.wifiOn === true && page.networks.length > 0
            heading: "Networks"
            Repeater {
                model: page.networks
                Line {
                    required property var modelData
                    title: modelData.ssid
                    detail: modelData.words
                    Row {
                        spacing: Style.s(12)
                        Button {
                            visible: modelData.saved === true && modelData.active !== true
                            text: "Forget"
                            usable: !page.joining
                            onPressed: page.act("forget", modelData.ssid)
                        }
                        Button {
                            text: modelData.active === true ? "Disconnect" : "Connect"
                            usable: !page.joining
                            onPressed: modelData.active === true
                                       ? page.act("disconnect", true)
                                       : page.act("join", modelData.ssid)
                        }
                    }
                }
            }
        }
        Note {
            visible: page.readable && page.st.wifiOn === true && page.networks.length === 0
            text: "No Wi-Fi networks can be seen from here."
        }

        Group {
            visible: page.readable && page.wired.length > 0
            heading: "Wired"
            Repeater {
                model: page.wired
                Line {
                    required property var modelData
                    title: page.wired.length > 1 ? "Wired (" + modelData.device + ")" : "Wired"
                    detail: modelData.address !== ""
                            ? modelData.words + " · This computer's address is " + modelData.address
                            : modelData.words
                }
            }
        }

        // What this page does not do yet, in Plasma's own window for it.
        Column {
            visible: page.readable
            width: parent.width
            spacing: Style.s(16)
            Heading { text: "More" }
            LinkRow {
                width: parent.width
                glyph: "gear"
                title: "Other network settings"
                detail: "A VPN, a hidden network, a network that asks for a name as well as a password"
                onPicked: page.act("more", true)
            }
        }
    }
}
