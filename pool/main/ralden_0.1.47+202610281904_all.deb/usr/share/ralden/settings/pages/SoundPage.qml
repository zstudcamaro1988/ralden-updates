/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - System - Sound
 *
 * What plays the sound and how loud, and what listens and how much: the
 * sound server's own devices, asked and set through pactl (PipeWire's
 * PulseAudio side). A device is chosen by the name the server gave it, and
 * only from the list the server gave - nothing typed reaches it.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.sound : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Sound"
            parentName: "System"
            onBack: page.back()
        }

        Note {
            visible: page.st.known === true && !page.st.outputAvailable && !page.st.inputAvailable
            text: "No sound device was found on this computer."
        }

        Group {
            heading: "Output"
            visible: page.st.outputAvailable === true

            Line {
                title: "Play sound through"
                Choice {
                    options: page.st.outputs || []
                    chosen: page.st.output || ""
                    label: "Play sound through"
                    onPicked: function(key) { page.act("output", key) }
                }
            }
            Line {
                title: "Volume"
                detail: page.st.muted ? "Muted" : (page.st.volume || 0) + "%"
                wide: true
                Rail {
                    width: parent ? parent.width : implicitWidth
                    value: page.st.volume || 0
                    label: "Volume"
                    onChosen: function(v) { page.act("volume", v) }
                }
            }
            Line {
                title: "Mute"
                Switch {
                    on: page.st.muted === true
                    label: "Mute"
                    onFlipped: page.act("mute", !on)
                }
            }
        }

        Group {
            heading: "Input"
            visible: page.st.inputAvailable === true

            Line {
                title: "Listen through"
                Choice {
                    options: page.st.inputs || []
                    chosen: page.st.input || ""
                    label: "Listen through"
                    onPicked: function(key) { page.act("input", key) }
                }
            }
            Line {
                title: "Input level"
                detail: page.st.inputMuted ? "Muted" : (page.st.inputVolume || 0) + "%"
                wide: true
                Rail {
                    width: parent ? parent.width : implicitWidth
                    value: page.st.inputVolume || 0
                    label: "Input level"
                    onChosen: function(v) { page.act("inputVolume", v) }
                }
            }
            Line {
                title: "Mute the microphone"
                Switch {
                    on: page.st.inputMuted === true
                    label: "Mute the microphone"
                    onFlipped: page.act("inputMute", !on)
                }
            }
        }
    }
}
