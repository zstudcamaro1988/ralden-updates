/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - System - Multitasking ("Snap layouts, overview, virtual
 * desktops" in the picture), all of it KWin's:
 *
 *   Snapping       a window dragged to a side fills that half, to a
 *                  corner a quarter, to the top the whole screen (kwinrc
 *                  [Windows] ElectricBorderTiling, ElectricBorderMaximize).
 *   Overview       every window side by side, with the workspaces over
 *                  them; shown from here by its own shortcut's action.
 *   Workspaces     KWin's virtual desktops, the numbers in the dock's
 *                  workspaces pane: how many, whether moving on from the
 *                  last comes round to the first, whether the name is
 *                  shown on the way, and what Alt+Tab lists.
 *
 * The picture's "Snap layouts" are Windows' name for a menu of layouts on
 * the maximise button. KWin snaps by dragging, and this page says that.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.multitasking : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    readonly property var altTabOptions: [
        { "key": "this", "label": "Windows on this workspace" },
        { "key": "all", "label": "Windows on every workspace" }
    ]

    implicitHeight: column.implicitHeight

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Multitasking"
            parentName: "System"
            onBack: page.back()
        }

        Group {
            heading: "Snapping windows"
            Line {
                title: "Snap to the sides"
                detail: "Drag a window against the left or right edge to fill that half of the screen, or into a corner to fill a quarter."
                Switch {
                    on: page.st.snapEdges === true
                    label: "Snap to the sides"
                    onFlipped: page.act("snapEdges", !on)
                }
            }
            Line {
                title: "Fill the screen from the top"
                detail: "Drag a window against the top edge to make it fill the screen."
                Switch {
                    on: page.st.snapTop === true
                    label: "Fill the screen from the top"
                    onFlipped: page.act("snapTop", !on)
                }
            }
        }

        Group {
            heading: "Overview"
            Line {
                title: "Overview"
                detail: "Every open window side by side, with your workspaces above them. Pick one to go to it."
                Button {
                    text: "Show"
                    onPressed: page.act("overview", true)
                }
            }
        }

        Group {
            heading: "Workspaces"
            Line {
                title: "Workspaces"
                detail: !page.st.desktopsKnown ? ""
                      : page.st.count === 0 ? "The window manager did not say how many there are."
                      : "Separate desktops for separate jobs. The dock shows a number for each."
                usable: (page.st.count || 0) > 0
                Stepper {
                    visible: (page.st.count || 0) > 0
                    value: page.st.count || 0
                    least: 1
                    most: page.st.most || 12
                    label: "workspace"
                    onFewer: page.act("removeDesktop", true)
                    onMore: page.act("addDesktop", true)
                }
            }
            Line {
                title: "Go round from the last to the first"
                detail: "Moving on from the last workspace comes back to the first, and back from the first to the last."
                Switch {
                    on: page.st.wrap === true
                    label: "Go round from the last to the first"
                    onFlipped: page.act("wrap", !on)
                }
            }
            Line {
                title: "Show the workspace's name on the way"
                detail: "For a moment, in the middle of the screen, when you move to another."
                Switch {
                    on: page.st.osd === true
                    label: "Show the workspace's name on the way"
                    onFlipped: page.act("osd", !on)
                }
            }
            Line {
                title: "Alt+Tab shows"
                Choice {
                    options: page.altTabOptions
                    chosen: page.st.altTab || "this"
                    label: "Alt+Tab shows"
                    onPicked: function(key) { page.act("altTab", key) }
                }
            }
        }
    }
}
