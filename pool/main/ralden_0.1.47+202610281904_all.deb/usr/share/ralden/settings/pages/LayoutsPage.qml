/* SPDX-License-Identifier: Ralden-Source
 *
 * Settings - System - Keyboard - Add a layout
 *
 * Every layout the X keyboard database knows, and every variant of each
 * (/usr/share/X11/xkb/rules/evdev.xml, read by readers.xkb_layouts), with a
 * line to find one by name. Picking one adds it after the ones there are
 * and goes back to the Keyboard page.
 */
import QtQuick
import "../parts"

Item {
    id: page

    property var areas: null
    signal open(string page)
    signal back()

    readonly property var area: areas ? areas.keyboard : null
    readonly property var st: area ? area.state : ({})
    function act(verb, value) { if (area) area.act(verb, value) }

    property string wanted: ""
    // At most this many drawn at once: the whole database is over a
    // thousand lines, and nobody reads past the first screens of it.
    readonly property int shownMost: 60
    // The database is the area's `catalog`, kept apart from its state.
    readonly property var catalog: area && area.catalog ? area.catalog : []
    readonly property var found: {
        var all = catalog
        var have = {}
        var mine = st.layouts || []
        for (var i = 0; i < mine.length; i++) have[mine[i].key] = true
        var words = wanted.toLowerCase().split(/\s+/).filter(function(w) { return w !== "" })
        var out = []
        for (var j = 0; j < all.length && out.length < shownMost; j++) {
            var item = all[j]
            if (have[item.key]) continue
            var text = (item.label + " " + item.key).toLowerCase()
            var ok = true
            for (var k = 0; k < words.length; k++)
                if (text.indexOf(words[k]) < 0) { ok = false; break }
            if (ok) out.push(item)
        }
        return out
    }

    // In the page, not the row's own handler. Seen on the test machine on
    // 15 October 2026: adding a layout takes it off this list, which
    // destroys the row whose button was pressed, and the rest of the row's
    // handler - going back to Keyboard - never ran.
    function addAndGoBack(key) {
        page.act("addLayout", key)
        page.open("keyboard")
    }

    implicitHeight: column.implicitHeight
    Component.onCompleted: { page.act("catalog", true); search.focusIt() }

    Column {
        id: column
        width: parent.width
        spacing: Style.s(36)

        PageTitle {
            text: "Add a layout"
            parentName: "Keyboard"
            onBack: page.open("keyboard")
        }

        Field {
            id: search
            width: parent.width
            glyph: "search"
            placeholder: "Find a language or a country"
            onTextChanged: page.wanted = text
        }

        Group {
            visible: page.found.length > 0
            Repeater {
                model: page.found
                Line {
                    required property var modelData
                    title: modelData.label
                    Button {
                        text: "Add"
                        onPressed: page.addAndGoBack(modelData.key)
                    }
                }
            }
        }

        Note {
            visible: page.st.catalogKnown === true && page.found.length === 0
            text: page.catalog.length === 0
                  ? "The list of keyboard layouts could not be read."
                  : "No layout is called that."
        }
        Note {
            visible: page.found.length >= page.shownMost
            text: "Only the first " + page.shownMost + " are shown. Type more of the name to find the rest."
        }
    }
}
