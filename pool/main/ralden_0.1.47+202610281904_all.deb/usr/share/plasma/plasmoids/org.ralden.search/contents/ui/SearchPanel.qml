/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the search panel, as it is drawn
 *
 * The owner's picture (reference/2c-search.jpg), in Alpine Mist's dark
 * glass: a search field with a button at its end; a row of chips to say
 * what to search; the results in rounded cards, in groups under headings;
 * and at the foot, "Show more results".
 *
 * THIS FILE ONLY DRAWS, as the Control Center's Panel.qml only draws. What
 * is found is handed to it as a model, what is typed and pressed is said as
 * a signal, and main.qml does the finding (through KRunner, the search
 * Plasma already has - see main.qml) and the opening. So the panel can be
 * photographed before a build, with made-up results that say they are, by
 * tools/preview-events/search.py.
 *
 * EVERY LENGTH IS THE PICTURE'S, TIMES `u`.
 *
 * The picture is 1136 of its pixels by 1219; `u` is how many of the
 * screen's pixels one of the picture's is (main.qml chooses it from the
 * screen's height, so that the whole panel fits above the bar). The writing
 * is Plasma's own size, `body`, with the picture's proportions between
 * sizes kept.
 */
import QtQuick
import QtQuick.Controls as QQC2
import org.kde.kirigami as Kirigami
import org.ralden.flowbar as Flow

Item {
    id: panel

    property real u: 0.5
    property real body: 13
    // The popup glass keeps 10 pixels of its own; this is the rest of the
    // picture's 40.
    property real edge: Math.max(4, Math.round(40 * u) - 10)

    // ---- what it shows ---------------------------------------------------
    property string query: ""
    property string placeholder: "Search anything…"
    // The chips: [{ "key": "apps", "name": "Apps" }, ...], "all" first.
    property var filters: []
    property string filter: "all"
    // What was found: a model with Qt's display and decoration roles and
    // KRunner's `subtext` and `category`, drawn in groups by category.
    property var results: null
    property int count: 0
    property bool busy: false
    // Whether asking for more could find more: the foot is drawn only then.
    property bool more: false
    // Before anything is typed: what was used lately, with the same roles.
    property var recent: null
    property int recentCount: 0
    property int currentIndex: 0

    property string moreText: "Show more results"
    property string nothingText: "Nothing found"
    property string nothingDetail: ""  // a line under it, when there is something to say
    property string hintTitle: "Type to search"
    property var hints: []            // lines under the hint, when nothing is typed and nothing is recent

    // ---- what is pressed ---------------------------------------------------
    signal queryEdited(string text)
    signal indexMoved(int index)      // the keys or the pointer moved to another row
    signal filterChosen(string key)
    signal resultChosen(int index)
    signal recentChosen(int index)
    signal moreChosen()
    signal settingsChosen()
    signal closeRequested()

    function s(x) { return Math.round(x * u) }
    function takeFocus() { field.forceActiveFocus() }

    readonly property real inner: s(1052)
    readonly property bool typing: query.length > 0
    readonly property var shown: typing ? results : recent
    readonly property int shownCount: typing ? count : recentCount

    implicitWidth: inner + edge * 2
    implicitHeight: s(1219) - s(40) * 2 + edge * 2

    readonly property color detailInk: Qt.rgba(1, 1, 1, 0.62)
    readonly property color cardFill: Qt.rgba(1, 1, 1, 0.065)
    readonly property color accentInk: Qt.rgba(110 / 255, 172 / 255, 242 / 255, 1)

    // ---- the field -----------------------------------------------------------
    Item {
        id: top
        x: panel.edge
        y: panel.edge
        width: panel.inner
        height: panel.s(100)

        Rectangle {
            anchors.fill: parent
            radius: height / 2
            color: field.activeFocus ? Qt.rgba(1, 1, 1, 0.10) : panel.cardFill
            border.width: 1
            border.color: field.activeFocus ? Qt.rgba(110 / 255, 172 / 255, 242 / 255, 0.55)
                                            : Qt.rgba(1, 1, 1, 0.08)
        }
        Flow.Glyph {
            id: magnifier
            x: panel.s(30)
            anchors.verticalCenter: parent.verticalCenter
            width: panel.s(44)
            height: width
            kind: "search"
            ink: Flow.Look.inkSoft
        }
        QQC2.TextField {
            id: field
            anchors.left: magnifier.right
            anchors.leftMargin: panel.s(18)
            anchors.right: tune.left
            anchors.rightMargin: panel.s(16)
            anchors.verticalCenter: parent.verticalCenter
            text: panel.query
            placeholderText: panel.placeholder
            placeholderTextColor: Flow.Look.inkFaint
            color: Flow.Look.ink
            selectionColor: Flow.Look.accent
            selectedTextColor: "#FFFFFF"
            font.family: Flow.Look.family
            font.pixelSize: Math.round(panel.body * 1.18)
            background: Item { }
            onTextEdited: panel.queryEdited(text)
            Keys.onDownPressed: panel.indexMoved(Math.min(panel.shownCount - 1, panel.currentIndex + 1))
            Keys.onUpPressed: panel.indexMoved(Math.max(0, panel.currentIndex - 1))
            Keys.onReturnPressed: panel.choose(panel.currentIndex)
            Keys.onEnterPressed: panel.choose(panel.currentIndex)
            Keys.onEscapePressed: {
                if (text.length > 0) panel.queryEdited("")
                else panel.closeRequested()
            }
            Keys.onTabPressed: panel.nextFilter(1)
            Keys.onBacktabPressed: panel.nextFilter(-1)
        }
        // The button at the end of the field: which kinds of thing search
        // looks through - Plasma's own search settings.
        Item {
            id: tune
            anchors.right: parent.right
            anchors.rightMargin: panel.s(12)
            anchors.verticalCenter: parent.verticalCenter
            width: panel.s(80)
            height: width
            Rectangle {
                anchors.fill: parent
                radius: width / 2
                color: Qt.rgba(1, 1, 1, tunePress.containsMouse ? 0.14 : 0.07)
                border.width: 1
                border.color: Qt.rgba(1, 1, 1, 0.08)
            }
            Flow.Glyph {
                anchors.centerIn: parent
                width: panel.s(40)
                height: width
                kind: "tune"
                ink: Flow.Look.inkSoft
            }
            MouseArea {
                id: tunePress
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: panel.settingsChosen()
            }
        }
    }

    function choose(i) {
        if (i < 0 || i >= panel.shownCount) return
        if (panel.typing) panel.resultChosen(i)
        else panel.recentChosen(i)
    }
    function nextFilter(step) {
        var keys = []
        for (var i = 0; i < panel.filters.length; i++) keys.push(panel.filters[i].key)
        var at = keys.indexOf(panel.filter)
        if (keys.length > 0)
            panel.filterChosen(keys[(at + step + keys.length) % keys.length])
    }

    // ---- the chips -------------------------------------------------------------
    Row {
        id: chips
        x: panel.edge
        y: top.y + top.height + panel.s(45)
        height: panel.s(62)
        spacing: panel.s(16)
        Repeater {
            model: panel.filters
            Item {
                id: chip
                required property var modelData
                readonly property bool chosen: modelData.key === panel.filter
                width: label.implicitWidth + panel.s(60)
                height: chips.height
                Rectangle {
                    anchors.fill: parent
                    radius: height / 2
                    color: chip.chosen ? Flow.Look.accent
                         : chipPress.containsMouse ? Qt.rgba(1, 1, 1, 0.12) : panel.cardFill
                    border.width: 1
                    border.color: chip.chosen ? Qt.rgba(1, 1, 1, 0.16) : Qt.rgba(1, 1, 1, 0.08)
                }
                Text {
                    id: label
                    anchors.centerIn: parent
                    text: chip.modelData.name
                    color: Flow.Look.ink
                    font.family: Flow.Look.family
                    font.pixelSize: Math.round(panel.body * 0.92)
                    font.weight: chip.chosen ? Font.DemiBold : Font.Medium
                }
                MouseArea {
                    id: chipPress
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: panel.filterChosen(chip.modelData.key)
                }
            }
        }
    }

    // ---- what was found ------------------------------------------------------------
    ListView {
        id: list
        x: panel.edge
        y: chips.y + chips.height + panel.s(34)
        width: panel.inner
        height: (foot.visible ? foot.y - panel.s(14) : panel.implicitHeight - panel.edge) - y
        clip: true
        model: panel.shown
        currentIndex: panel.currentIndex
        // The row the keys are on is always in sight.
        onCurrentIndexChanged: if (currentIndex >= 0) positionViewAtIndex(currentIndex, ListView.Contain)
        boundsBehavior: Flickable.StopAtBounds
        highlightMoveDuration: 0
        visible: panel.shownCount > 0
        section.property: "category"
        section.delegate: Item {
            required property string section
            width: list.width
            height: panel.s(72)
            Text {
                x: panel.s(18)
                anchors.bottom: parent.bottom
                anchors.bottomMargin: panel.s(16)
                text: parent.section
                color: Flow.Look.ink
                font.family: Flow.Look.family
                font.pixelSize: Math.round(panel.body * 0.95)
                font.weight: Font.DemiBold
            }
        }

        delegate: Item {
            id: row
            required property int index
            required property var model
            // Whether this row starts or ends its group, so that the group's
            // card is rounded at its own top and bottom only.
            readonly property bool first: index === 0 || ListView.previousSection !== ListView.section
            readonly property bool last: index === panel.shownCount - 1 || ListView.nextSection !== ListView.section
            readonly property bool current: index === panel.currentIndex
            width: list.width
            height: panel.s(115) + (first ? panel.s(14) : 0) + (last ? panel.s(14) : 0)

            // The group's card, drawn a row at a time: rounded at the top of
            // its first row and the foot of its last, square where it goes
            // on, and never two layers of it over one pixel. (The first
            // photograph drew the square parts over the round ones, and the
            // glass was darker in a band between every two rows.)
            Rectangle {
                anchors.fill: parent
                color: panel.cardFill
                topLeftRadius: row.first ? panel.s(26) : 0
                topRightRadius: row.first ? panel.s(26) : 0
                bottomLeftRadius: row.last ? panel.s(26) : 0
                bottomRightRadius: row.last ? panel.s(26) : 0
            }
            // The one under the pointer or the keys.
            Rectangle {
                x: panel.s(10)
                y: (row.first ? panel.s(14) : 0) + panel.s(4)
                width: parent.width - panel.s(20)
                height: panel.s(107)
                radius: panel.s(20)
                color: row.current ? Qt.rgba(74 / 255, 144 / 255, 226 / 255, 0.22)
                     : hover.containsMouse ? Qt.rgba(1, 1, 1, 0.07) : "transparent"
                border.width: row.current ? 1 : 0
                border.color: Qt.rgba(110 / 255, 172 / 255, 242 / 255, 0.45)
            }
            Item {
                y: row.first ? panel.s(14) : 0
                width: parent.width
                height: panel.s(115)
                Rectangle {
                    id: tile
                    x: panel.s(67) - width / 2
                    anchors.verticalCenter: parent.verticalCenter
                    width: panel.s(66)
                    height: width
                    radius: panel.s(16)
                    color: Qt.rgba(1, 1, 1, 0.08)
                    Kirigami.Icon {
                        anchors.centerIn: parent
                        width: panel.s(44)
                        height: width
                        source: row.model.decoration || "application-x-executable"
                    }
                }
                Column {
                    x: panel.s(136)
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - x - panel.s(30)
                    spacing: Math.round(panel.body * 0.18)
                    Text {
                        width: parent.width
                        text: row.model.display || ""
                        textFormat: Text.PlainText
                        elide: Text.ElideRight
                        color: Flow.Look.ink
                        font.family: Flow.Look.family
                        font.pixelSize: panel.body
                        font.weight: Font.DemiBold
                    }
                    Text {
                        width: parent.width
                        visible: text !== ""
                        text: row.model.subtext || ""
                        textFormat: Text.PlainText
                        elide: Text.ElideRight
                        color: panel.detailInk
                        font.family: Flow.Look.family
                        font.pixelSize: Math.round(panel.body * 0.86)
                    }
                }
            }
            MouseArea {
                id: hover
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onEntered: panel.indexMoved(row.index)
                onClicked: panel.choose(row.index)
            }
        }
    }

    // ---- nothing yet, or nothing at all ------------------------------------------------
    Column {
        visible: panel.shownCount === 0
        x: panel.edge + panel.s(18)
        y: list.y + panel.s(40)
        width: panel.inner - panel.s(36)
        spacing: Math.round(panel.body * 0.6)
        Text {
            text: panel.typing ? (panel.busy ? "" : panel.nothingText) : panel.hintTitle
            color: Flow.Look.ink
            font.family: Flow.Look.family
            font.pixelSize: Math.round(panel.body * 1.05)
            font.weight: Font.DemiBold
        }
        Repeater {
            model: panel.typing ? (panel.busy || panel.nothingDetail === "" ? [] : [panel.nothingDetail])
                                : panel.hints
            Text {
                required property var modelData
                width: parent.width
                text: modelData
                wrapMode: Text.WordWrap
                color: panel.detailInk
                font.family: Flow.Look.family
                font.pixelSize: Math.round(panel.body * 0.9)
            }
        }
    }

    // ---- the foot -----------------------------------------------------------------------
    Item {
        id: foot
        x: panel.edge
        y: panel.implicitHeight - panel.edge - height
        width: panel.inner
        height: panel.s(64)
        visible: panel.typing && panel.more
        Row {
            x: panel.s(18)
            anchors.verticalCenter: parent.verticalCenter
            spacing: panel.s(14)
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: panel.moreText
                color: morePress.containsMouse ? Flow.Look.ink : Flow.Look.inkSoft
                font.family: Flow.Look.family
                font.pixelSize: Math.round(panel.body * 0.92)
                font.weight: Font.Medium
            }
            Rectangle {
                anchors.verticalCenter: parent.verticalCenter
                width: panel.s(52)
                height: width
                radius: width / 2
                color: Qt.rgba(1, 1, 1, morePress.containsMouse ? 0.14 : 0.07)
                Flow.Glyph {
                    anchors.centerIn: parent
                    width: panel.s(30)
                    height: width
                    kind: "next"
                    ink: Flow.Look.inkSoft
                }
            }
        }
        MouseArea {
            id: morePress
            width: panel.s(380)
            height: parent.height
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: panel.moreChosen()
        }
    }
}
