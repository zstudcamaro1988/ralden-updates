/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - what was used lately, for the search panel before anything
 * is typed
 *
 * The picture fills the empty panel with "Top Results" and "Suggestions".
 * Nothing on this machine can suggest anything honestly, so the empty panel
 * shows what it can know: the programs and the files used lately, as
 * Plasma's own menu (Kickoff) knows them - through Kicker's RecentUsageModel,
 * which reads Plasma's activity manager. On a fresh machine both lists are
 * empty and the panel says what search can find instead.
 *
 * READ OFF THE MACHINE, 14 OCTOBER 2026: Kickoff's main.qml makes two
 * Kicker.RecentUsageModel objects; the Kicker plugin itself names the
 * properties shownItems (AppsAndDocs, OnlyApps, OnlyDocs) and ordering;
 * Kickoff's delegates read the roles display, decoration and description,
 * and open an entry with trigger(row, "", null).
 *
 * KEPT APART for the same reason as Results.qml: Kicker is a private part
 * of Plasma, free to change between releases. If it does, this file fails
 * to load and the panel is empty with its hint, not broken.
 */
import QtQuick
import QtQml.Models
import org.kde.plasma.private.kicker as Kicker

Item {
    id: recent

    property string appsTitle: "Programs used lately"
    property string filesTitle: "Files opened lately"
    // How many of each; the panel has room for about six rows.
    property int most: 3

    // One list for the panel, in two groups: display, decoration, subtext
    // and category, as KRunner's are - so the panel draws both alike.
    readonly property alias model: rows
    readonly property int count: rows.count

    function open(row) {
        if (row < 0 || row >= rows.count)
            return false
        var r = rows.get(row)
        var from = r.from === "apps" ? apps : files
        return from.trigger(r.row, "", null)
    }

    function refresh() {
        rows.clear()
        take(appRows, recent.appsTitle, "apps")
        take(fileRows, recent.filesTitle, "files")
    }

    function take(list, title, from) {
        for (var i = 0; i < Math.min(recent.most, list.count); i++) {
            var o = list.objectAt(i)
            if (!o || o.name === "")
                continue
            rows.append({
                "display": o.name,
                "decoration": o.icon,
                // The same words twice is no detail.
                "subtext": o.detail !== o.name ? o.detail : "",
                "category": title,
                "from": from,
                "row": i
            })
        }
    }

    ListModel {
        id: rows
        // A program's icon is a QIcon, which only a list with dynamic roles
        // keeps as it is.
        dynamicRoles: true
    }

    Kicker.RecentUsageModel {
        id: apps
        shownItems: Kicker.RecentUsageModel.OnlyApps
    }
    Kicker.RecentUsageModel {
        id: files
        shownItems: Kicker.RecentUsageModel.OnlyDocs
    }

    component Entry: QtObject {
        required property var model
        readonly property string name: model.display ? String(model.display) : ""
        readonly property var icon: model.decoration
        readonly property string detail: model.description ? String(model.description) : ""
    }

    Instantiator {
        id: appRows
        model: apps
        delegate: Entry { }
        onObjectAdded: settle.restart()
        onObjectRemoved: settle.restart()
    }
    Instantiator {
        id: fileRows
        model: files
        delegate: Entry { }
        onObjectAdded: settle.restart()
        onObjectRemoved: settle.restart()
    }

    // The models fill a row at a time; the list is made once they stop.
    Timer {
        id: settle
        interval: 60
        onTriggered: recent.refresh()
    }
}
