/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - what search finds, from KRunner
 *
 * The finding is Plasma's own: Milou's ResultsModel, the model KRunner's
 * window and Plasma's search widget are drawn from, asking every runner
 * Plasma has installed - programs, settings, files opened lately, places,
 * sums, unit conversions, the web. Ralden draws the answers (SearchPanel)
 * and finds none of them itself.
 *
 * WHAT IS USED HERE IS READ OFF THE MACHINE, NOT REMEMBERED.
 *
 * Milou ships no description of its model for tools to read (its .qmltypes
 * is empty), so its own ResultsView.qml, read off the test machine on
 * 14 October 2026, is the description: queryString, singleRunner, limit and
 * querying; run(index); the roles display, decoration, subtext and
 * category. Nothing else of it is touched here.
 *
 * KEPT APART, as the Control Center keeps Plasma's music and session
 * pieces: if a Plasma release moves Milou, this file fails to load, main.qml
 * sees that, and the panel says that search is not available - instead of
 * the whole widget failing to load and leaving a hole in the dock.
 */
import QtQuick
import org.kde.milou as Milou

Item {
    id: results

    // What is typed, and which one runner to ask ("" asks all of them).
    property string query: ""
    property string runner: ""
    // How many to fetch at most; "Show more results" raises it.
    property int limit: 8

    // A result asking for the words to be changed: KRunner's helpers do,
    // to finish a command for the person typing it.
    signal wantsQuery(string text)

    readonly property var model: found
    readonly property bool busy: found.querying
    property int count: 0

    // Opens the one at `row`; true when it was opened.
    function run(row) {
        if (row < 0 || row >= count)
            return false
        return found.run(found.index(row, 0))
    }

    function recount() { results.count = found.rowCount() }

    // ASKED AGAIN WHEN THE CHIP CHANGES, NOT ONLY WHEN THE WORDS DO.
    //
    // KRunner reads which runner to ask when the words change, and at no
    // other time. Seen in the first photographs of the panel (14 October
    // 2026): with the words typed first and the chip chosen after, the
    // Settings chip went on showing the Software Center's answers. So the
    // runner is set first, and the question asked afresh - emptied, then
    // asked - whenever either changes.
    function ask() {
        found.singleRunner = results.runner
        found.queryString = ""
        found.queryString = results.query
    }
    onQueryChanged: ask()
    onRunnerChanged: ask()
    Component.onCompleted: ask()

    Milou.ResultsModel {
        id: found
        limit: results.limit
        onRowsInserted: results.recount()
        onRowsRemoved: results.recount()
        onModelReset: results.recount()
        onQueryStringChangeRequested: (text, position) => results.wantsQuery(text)
    }
}
