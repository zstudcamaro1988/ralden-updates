/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the search field, as drawn
 *
 * The second pane of the flow bar in the picture: a magnifier, the words,
 * and a keycap at the far end. Drawn here from the words it is given;
 * main.qml decides what pressing it does (it opens the search panel).
 */
import QtQuick
import org.ralden.flowbar as Flow

Item {
    id: field

    property string placeholder: ""
    property string shortcutHint: ""
    // Lit while the panel it opens is open, as the Control Center's pane is.
    property bool open: false

    signal pressed()

    readonly property real h: Math.round(height * Flow.Look.share)
    readonly property real gap: Math.round(h * Flow.Look.gap)
    readonly property real paneWidth: Math.max(h * 3, width - gap)

    implicitWidth: gap + Math.round(h * Flow.Look.searchWidth)

    // Open, this pane is drawn pressed; Plasma's own line over an open
    // widget is hidden (QuietOpenLine.qml says why).
    Flow.QuietOpenLine { }

    Flow.Pill {
        id: pane
        x: field.gap
        width: field.paneWidth
        height: field.h
        lit: area.containsMouse
        pressed: area.pressed || field.open

        Flow.Glyph {
            id: magnifier
            x: Math.round(field.h * 0.33)
            anchors.verticalCenter: parent.verticalCenter
            width: Math.round(field.h * 0.42)
            height: width
            kind: "search"
        }

        Text {
            anchors.left: magnifier.right
            anchors.leftMargin: Math.round(field.h * 0.24)
            anchors.right: keycap.visible ? keycap.left : parent.right
            anchors.rightMargin: Math.round(field.h * 0.25)
            anchors.verticalCenter: parent.verticalCenter
            text: field.placeholder
            elide: Text.ElideRight
            color: Flow.Look.inkSoft
            font.family: Flow.Look.family
            font.pixelSize: Math.round(field.h * Flow.Look.textSize)
        }

        // A key to press, so a chip: raised, rounded, the key's name on it.
        Rectangle {
            id: keycap
            visible: field.shortcutHint.length > 0
            anchors.right: parent.right
            anchors.rightMargin: Math.round(field.h * 0.25)
            anchors.verticalCenter: parent.verticalCenter
            height: Math.round(field.h * 0.5)
            width: hint.implicitWidth + Math.round(field.h * 0.36)
            radius: Math.round(field.h * 0.12)
            color: Qt.rgba(1, 1, 1, 0.14)
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.16)

            Text {
                id: hint
                anchors.centerIn: parent
                text: field.shortcutHint
                color: Flow.Look.inkSoft
                font.family: Flow.Look.family
                font.pixelSize: Math.round(field.h * 0.19)
            }
        }

        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: field.pressed()
        }
    }
}
