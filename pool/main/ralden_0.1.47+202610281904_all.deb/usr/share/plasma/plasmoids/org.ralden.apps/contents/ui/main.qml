/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the programs on the flow bar
 *
 * WHY RALDEN HAS ITS OWN, WHEN PLASMA HAS A GOOD ONE.
 *
 * Plasma's list of running programs is excellent and draws its icons
 * straight onto the dock. The picture puts them on a pane of glass of
 * their own, and a Plasma panel draws no background behind one widget and
 * not the next. So the pane has to be drawn by the widget holding the
 * icons, which means the widget has to be Ralden's.
 *
 * What it does NOT do is find the programs itself. Which windows exist,
 * which program each belongs to, which are kept on the bar, starting one
 * and switching to one - all of that is Plasma's TasksModel
 * (org.kde.taskmanager), the same model Plasma's own list is built on.
 * Ralden draws; Plasma knows.
 *
 * WHAT A PRESS DOES.
 *
 *   a kept program that is not running   starts it
 *   a program with one window            brings it forward, or tucks it
 *                                        away if it is already in front -
 *                                        as Windows does
 *   a program with several windows       the most recent one; pressed
 *                                        again, the next
 *   the middle button                    a new window of it
 *   the right button                     a short menu: new window, keep on
 *                                        the bar or stop keeping it, close
 *
 * WHAT IT DOES NOT DO YET, SAID SO.
 *
 * Icons cannot be dragged into a different order, and hovering shows the
 * program's name, not a picture of its windows. Plasma's own list does both.
 */
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.extras as PlasmaExtras
import org.kde.taskmanager as TaskManager

PlasmoidItem {
    id: root

    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation

    readonly property real drawn: pane.implicitWidth
    Layout.minimumWidth: drawn
    Layout.preferredWidth: drawn
    Layout.maximumWidth: drawn
    Layout.fillWidth: false

    TaskManager.VirtualDesktopInfo {
        id: desktops
    }

    TaskManager.ActivityInfo {
        id: activities
    }

    TaskManager.TasksModel {
        id: tasks

        virtualDesktop: desktops.currentDesktop
        activity: activities.currentActivity
        screenGeometry: Plasmoid.containment.screenGeometry

        // Every window on every workspace: the workspaces pane says where
        // a person is, and a program does not vanish from the bar because
        // its window is on workspace 3.
        filterByVirtualDesktop: false
        filterByScreen: false
        filterByActivity: true

        // A kept program that starts takes the kept icon's place, so each
        // program is on the bar once.
        launchInPlace: true
        separateLaunchers: false
        hideActivatedLaunchers: true

        groupMode: TaskManager.TasksModel.GroupApplications
        groupInline: false
        sortMode: TaskManager.TasksModel.SortManual

        // The kept programs are this widget's own setting, written back
        // whenever the list changes - which is what "keep on the bar" does.
        onLauncherListChanged: {
            if (String(launcherList) !== String(Plasmoid.configuration.launchers))
                Plasmoid.configuration.launchers = launcherList
        }
        Component.onCompleted: launcherList = Plasmoid.configuration.launchers
    }

    function role(row, child, which) {
        return tasks.data(tasks.makeModelIndex(row, child), which)
    }

    function activate(row) {
        var index = tasks.makeModelIndex(row)
        var isLauncher = tasks.data(index, TaskManager.AbstractTasksModel.IsLauncher)
        var isGroup = tasks.data(index, TaskManager.AbstractTasksModel.IsGroupParent)

        if (isLauncher) {
            tasks.requestActivate(index)
            return
        }
        if (!isGroup) {
            if (tasks.data(index, TaskManager.AbstractTasksModel.IsActive))
                tasks.requestToggleMinimized(index)
            else
                tasks.requestActivate(index)
            return
        }

        // Several windows. If one of them is in front, the next one;
        // otherwise the one used last.
        var n = tasks.data(index, TaskManager.AbstractTasksModel.ChildCount) || 0
        var inFront = -1
        var latest = 0
        var latestWhen = 0
        for (var c = 0; c < n; c++) {
            if (role(row, c, TaskManager.AbstractTasksModel.IsActive))
                inFront = c
            var when = role(row, c, TaskManager.AbstractTasksModel.LastActivated)
            var t = when ? new Date(when).getTime() : 0
            if (t > latestWhen) {
                latestWhen = t
                latest = c
            }
        }
        var pick = inFront >= 0 ? (inFront + 1) % n : latest
        tasks.requestActivate(tasks.makeModelIndex(row, pick))
    }

    // ---------------------------------------------------- the short menu

    property int asking: -1
    readonly property url askingLauncher: asking >= 0
        ? (tasks.data(tasks.makeModelIndex(asking),
                      TaskManager.AbstractTasksModel.LauncherUrlWithoutIcon) || "")
        : ""
    readonly property bool askingKept: asking >= 0
        && String(askingLauncher) !== ""
        && tasks.launcherPosition(askingLauncher) >= 0

    PlasmaExtras.Menu {
        id: menu
        placement: PlasmaExtras.Menu.TopPosedLeftAlignedPopup

        PlasmaExtras.MenuItem {
            text: i18n("New window")
            icon: "window-new"
            visible: root.asking >= 0
                && tasks.data(tasks.makeModelIndex(root.asking),
                              TaskManager.AbstractTasksModel.CanLaunchNewInstance) === true
            onClicked: tasks.requestNewInstance(tasks.makeModelIndex(root.asking))
        }
        PlasmaExtras.MenuItem {
            text: i18n("Keep on the bar")
            icon: "window-pin"
            visible: root.asking >= 0 && String(root.askingLauncher) !== ""
                     && !root.askingKept
            onClicked: tasks.requestAddLauncher(root.askingLauncher)
        }
        PlasmaExtras.MenuItem {
            text: i18n("Stop keeping on the bar")
            icon: "window-unpin"
            visible: root.askingKept
            onClicked: tasks.requestRemoveLauncher(root.askingLauncher)
        }
        PlasmaExtras.MenuItem {
            text: tasks.data(tasks.makeModelIndex(root.asking >= 0 ? root.asking : 0),
                             TaskManager.AbstractTasksModel.IsGroupParent) === true
                  ? i18n("Close all windows") : i18n("Close")
            icon: "window-close"
            visible: root.asking >= 0
                && tasks.data(tasks.makeModelIndex(root.asking),
                              TaskManager.AbstractTasksModel.IsLauncher) !== true
            onClicked: tasks.requestClose(tasks.makeModelIndex(root.asking))
        }
    }

    // DRAWN AS THE WIDGET'S OWN CHILD, NOT AS A fullRepresentation.
    //
    // That is how Plasma's own task list does it. Drawn as a
    // fullRepresentation, with the widget's width read back through
    // fullRepresentationItem, the first build on the machine (8 October
    // 2026) came up with all four panes nought pixels wide: Plasma sized
    // each widget before that item existed and never asked again.
    Programs {
        id: pane
        anchors.fill: parent
        model: tasks
        count: tasks.count
        onActivated: function(index) { root.activate(index) }
        onNewInstance: function(index) {
            tasks.requestNewInstance(tasks.makeModelIndex(index))
        }
        onAsked: function(index, where) {
            root.asking = index
            menu.visualParent = where
            menu.openRelative()
        }
    }
}
