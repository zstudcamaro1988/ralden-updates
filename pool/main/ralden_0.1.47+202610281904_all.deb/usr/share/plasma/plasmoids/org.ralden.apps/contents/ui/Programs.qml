/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the programs pane, as drawn
 *
 * One pane of glass with a row of icons on it: the programs kept on the bar
 * and the ones running, in one list, each once. From the picture, plus two
 * things it does not show and a person needs:
 *
 *   a small dot under a program that is open, so a kept program that is not
 *   running can be told from one that is - longer under the window in use,
 *   amber under one asking for attention;
 *
 *   a lighter square behind the window in use, and behind whatever the
 *   pointer is over.
 *
 * This file draws and says what was pressed. main.qml is what knows which
 * programs there are and does the opening, switching and closing, so this
 * can be photographed from a list written by hand.
 *
 * The model's rows are read by the names Plasma's task list gives them:
 * decoration, display, IsLauncher, IsActive, IsStartup,
 * IsDemandingAttention.
 */
import QtQuick
import org.kde.kirigami as Kirigami
import org.kde.plasma.core as PlasmaCore
import org.ralden.flowbar as Flow

Item {
    id: programs

    property var model: null
    property int count: 0

    signal activated(int index)
    signal newInstance(int index)
    signal asked(int index, Item where)

    readonly property real h: Math.round(height * Flow.Look.share)
    readonly property real gap: Math.round(h * Flow.Look.gap)
    readonly property real icon: Math.round(h * Flow.Look.icon)
    readonly property real slot: h * Flow.Look.slot
    readonly property real inset: h * Flow.Look.inset
    readonly property real paneWidth: count > 0
        ? Math.round(inset * 2 + icon + (count - 1) * slot) : 0

    implicitWidth: count > 0 ? gap + paneWidth : 0

    Flow.Pill {
        id: pane
        x: programs.gap
        width: programs.paneWidth
        height: programs.h
        visible: programs.count > 0

        Repeater {
            model: programs.model

            delegate: PlasmaCore.ToolTipArea {
                id: task

                required property int index
                required property var model

                readonly property bool open: !task.model.IsLauncher
                readonly property bool inUse: task.model.IsActive === true
                readonly property bool calling: task.model.IsDemandingAttention === true
                readonly property bool starting: task.model.IsStartup === true

                x: programs.inset + index * programs.slot
                   - (programs.slot - programs.icon) / 2
                width: programs.slot
                height: programs.h

                mainText: task.model.display || ""
                active: !press.pressed

                Rectangle {
                    anchors.centerIn: parent
                    width: programs.icon * 1.24
                    height: width
                    radius: width * 0.22
                    color: task.inUse ? Flow.Look.lit
                         : press.containsMouse ? Qt.rgba(1, 1, 1, 0.10)
                         : "transparent"
                    Behavior on color {
                        ColorAnimation { duration: 120 }
                    }
                }

                Kirigami.Icon {
                    id: picture
                    anchors.centerIn: parent
                    width: programs.icon
                    height: programs.icon
                    roundToIconSize: false
                    source: task.model.decoration
                    scale: press.pressed ? 0.92 : 1.0
                    Behavior on scale {
                        NumberAnimation { duration: 90 }
                    }

                    // Something was asked to start and has not shown a
                    // window yet: the icon breathes until it does.
                    SequentialAnimation on opacity {
                        running: task.starting
                        loops: Animation.Infinite
                        alwaysRunToEnd: true
                        NumberAnimation { to: 0.45; duration: 450 }
                        NumberAnimation { to: 1.0; duration: 450 }
                    }
                }

                Rectangle {
                    anchors.horizontalCenter: parent.horizontalCenter
                    y: programs.h - height - programs.h * 0.045
                    visible: task.open
                    height: Math.max(2, Math.round(programs.h * 0.06))
                    width: task.inUse ? programs.h * 0.22 : height
                    radius: height / 2
                    color: task.calling ? "#F5A623" : Flow.Look.ink
                    opacity: task.inUse || task.calling ? 1.0 : 0.75
                    Behavior on width {
                        NumberAnimation { duration: 120 }
                    }
                }

                MouseArea {
                    id: press
                    anchors.fill: parent
                    hoverEnabled: true
                    acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
                    cursorShape: Qt.PointingHandCursor
                    onClicked: function(mouse) {
                        if (mouse.button === Qt.MiddleButton)
                            programs.newInstance(task.index)
                        else if (mouse.button === Qt.RightButton)
                            programs.asked(task.index, task)
                        else
                            programs.activated(task.index)
                    }
                }
            }
        }
    }
}
