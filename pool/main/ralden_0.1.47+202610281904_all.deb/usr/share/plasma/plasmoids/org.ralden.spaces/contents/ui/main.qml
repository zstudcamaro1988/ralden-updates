/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the workspaces on the flow bar
 *
 * The drawing is Spaces.qml. This is what it is connected to:
 *
 *   how many workspaces, and which is in use - KWin's own answer, through
 *   the same piece of Plasma its list of running programs uses
 *   (org.kde.taskmanager's VirtualDesktopInfo), so the pane and the rest
 *   of the desktop never disagree about where a person is;
 *
 *   moving to one - KWin's own "Switch to Desktop N" shortcut, invoked by
 *   name. Plasma 6.3's VirtualDesktopInfo can say where a person is and
 *   has no way to move them (its .qmltypes lists no methods at all, read
 *   out of the image on 8 October 2026), and the shortcuts are what the
 *   keyboard uses, so the pane and Ctrl+F1..F4 do exactly the same thing;
 *
 *   the overview - KWin's, opened by its own shortcut's name, which is
 *   exactly what pressing Meta+W does. If the overview is turned off in
 *   KWin, the shortcut does nothing and so does the button; it is not
 *   drawn as something else.
 *
 * Ralden sets four workspaces in a row (/etc/xdg/kwinrc). A person who
 * makes six gets six numbers; one who removes all but one gets a pane with
 * one number in it, which is what the machine has.
 */
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.plasma5support as Plasma5Support
import org.kde.taskmanager as TaskManager

PlasmoidItem {
    id: root

    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
    preferredRepresentation: fullRepresentation
    toolTipMainText: i18n("Workspaces")
    toolTipSubText: i18n("Workspace %1 of %2", root.current + 1, root.count)

    readonly property real drawn: pane.implicitWidth
    Layout.minimumWidth: drawn
    Layout.preferredWidth: drawn
    Layout.maximumWidth: drawn
    Layout.fillWidth: false

    TaskManager.VirtualDesktopInfo {
        id: desktops
    }

    // HOW MANY IS numberOfDesktops, NOT THE LENGTH OF desktopIds. Seen on
    // the test machine on 15 October 2026: a fifth workspace made through
    // KWin (Settings' plus) was KWin's at once - _NET_NUMBER_OF_DESKTOPS 5,
    // kwinrc Number=5 - and the pane went on drawing four. On X11 the list
    // of ids is not said to have changed when the number does; the number
    // is (both are in the module's .qmltypes, each with its own signal).
    readonly property var ids: desktops.desktopIds
    readonly property int count: desktops.numberOfDesktops > 0 ? desktops.numberOfDesktops
                                                              : (ids ? ids.length : 0)
    readonly property int current: {
        if (ids) {
            for (var i = 0; i < ids.length; i++) {
                if (String(ids[i]) === String(desktops.currentDesktop))
                    return i
            }
        }
        // X11 numbers its workspaces from 1, and the number is the id.
        var n = Number(desktops.currentDesktop)
        return isNaN(n) || n < 1 || n > count ? -1 : n - 1
    }

    function go(index) {
        if (index >= 0 && index < count)
            run(kwin + "string:'Switch to Desktop " + (index + 1) + "'")
    }

    function run(command) {
        runner.disconnectSource(command)
        runner.connectSource(command)
    }

    Plasma5Support.DataSource {
        id: runner
        engine: "executable"
        connectedSources: []
        onNewData: function(source) { disconnectSource(source) }
    }

    // invokeShortcut on KWin's component, by the shortcut's name. The
    // names are KWin's ("Overview", "Switch to Desktop 2") and are the ones
    // its own shortcuts page lists.
    readonly property string kwin:
        "dbus-send --session --type=method_call --dest=org.kde.kglobalaccel "
        + "/component/kwin org.kde.kglobalaccel.Component.invokeShortcut "

    // DRAWN AS THE WIDGET'S OWN CHILD, NOT AS A fullRepresentation.
    //
    // That is how Plasma's own task list does it. Drawn as a
    // fullRepresentation, with the widget's width read back through
    // fullRepresentationItem, the first build on the machine (8 October
    // 2026) came up with all four panes nought pixels wide: Plasma sized
    // each widget before that item existed and never asked again.
    Spaces {
        id: pane
        anchors.fill: parent
        count: root.count
        current: root.current

        onOverview: root.run(root.kwin + "string:Overview")
        onGo: function(index) { root.go(index) }
        onNext: root.go(root.current + 1)
    }
}
