/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the workspaces pane, as drawn
 *
 * From the picture: the overview's mark, one number for each workspace with
 * the one in use ringed in blue, and a chevron to the next. This file only
 * draws that and says what was pressed; main.qml is what asks Plasma how
 * many workspaces there are and moves between them, so the drawing can be
 * photographed with nothing behind it.
 */
import QtQuick
import org.ralden.flowbar as Flow

Item {
    id: spaces

    // What is true of the machine.
    property int count: 4
    property int current: 0              // 0-based; -1 when nobody knows

    signal overview()
    signal go(int index)
    signal next()

    // The pane is a share of how tall this widget is; what is left below
    // it is where its shadow falls.
    readonly property real h: Math.round(height * Flow.Look.share)
    readonly property real gap: Math.round(h * Flow.Look.gap)
    readonly property real slot: h * Flow.Look.space
    readonly property real side: h * 0.06
    readonly property bool atEnd: current >= count - 1

    implicitWidth: gap + paneWidth
    readonly property real paneWidth: Math.round(side * 2 + slot * (count + 2))

    Flow.Pill {
        id: pane
        x: spaces.gap
        width: spaces.paneWidth
        height: spaces.h

        Row {
            x: spaces.side
            height: parent.height

            Item {
                width: spaces.slot
                height: parent.height
                Flow.Glyph {
                    anchors.centerIn: parent
                    width: spaces.h * 0.42
                    height: width
                    kind: "overview"
                    ink: overviewArea.containsMouse ? Flow.Look.ink : Flow.Look.inkSoft
                }
                MouseArea {
                    id: overviewArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: spaces.overview()
                }
            }

            Repeater {
                model: spaces.count
                Item {
                    id: one
                    required property int index
                    readonly property bool here: index === spaces.current
                    width: spaces.slot
                    height: parent.height

                    // The ring round the workspace in use: a pale blue
                    // pane with a blue edge, and the number on a small
                    // blue square inside it.
                    Rectangle {
                        anchors.centerIn: parent
                        width: spaces.h * 0.725
                        height: spaces.h * 0.65
                        radius: spaces.h * 0.16
                        visible: one.here || numberArea.containsMouse
                        color: one.here ? Flow.Look.accentTint : Flow.Look.lit
                        border.width: one.here ? Math.max(1, spaces.h * 0.035) : 0
                        border.color: Flow.Look.accent
                    }
                    Rectangle {
                        anchors.centerIn: parent
                        width: spaces.h * 0.34
                        height: width
                        radius: width * 0.22
                        visible: one.here
                        color: Flow.Look.accent
                    }
                    Text {
                        anchors.centerIn: parent
                        text: String(one.index + 1)
                        color: Flow.Look.ink
                        opacity: one.here || numberArea.containsMouse ? 1 : 0.85
                        font.family: Flow.Look.family
                        font.pixelSize: Math.round(spaces.h * (one.here ? 0.2 : Flow.Look.numberSize))
                        font.weight: one.here ? Font.DemiBold : Font.Normal
                    }
                    MouseArea {
                        id: numberArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: spaces.go(one.index)
                    }
                }
            }

            Item {
                width: spaces.slot
                height: parent.height
                Flow.Glyph {
                    anchors.centerIn: parent
                    width: spaces.h * 0.36
                    height: width
                    kind: "next"
                    // Nothing after the last one, and it says so.
                    ink: spaces.atEnd ? Flow.Look.inkFaint
                       : nextArea.containsMouse ? Flow.Look.ink : Flow.Look.inkSoft
                }
                MouseArea {
                    id: nextArea
                    anchors.fill: parent
                    enabled: !spaces.atEnd
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: spaces.next()
                }
            }
        }
    }

    WheelHandler {
        acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
        onWheel: function(event) {
            if (event.angleDelta.y < 0 && !spaces.atEnd)
                spaces.go(spaces.current + 1)
            else if (event.angleDelta.y > 0 && spaces.current > 0)
                spaces.go(spaces.current - 1)
        }
    }
}
