/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS — the clock's settings page, such as it is.
 */

import org.kde.plasma.configuration

ConfigModel {
    ConfigCategory {
        name: i18n("Appearance")
        icon: "preferences-desktop-color"
        source: "configGeneral.qml"
    }
}
