/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS — the clock's three switches.
 *
 * Kirigami's form layout rather than a hand-placed grid, because it is what
 * every other settings page in the system uses and a page that lines its
 * labels up differently from the rest is a page that looks like it came from
 * somewhere else.
 */

import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as QQC2
import org.kde.kirigami as Kirigami

Kirigami.FormLayout {
    id: page

    /* The names Plasma binds to. `cfg_` plus the entry name in main.xml is
     * the contract; a typo here is a switch that moves and changes nothing. */
    property alias cfg_use24Hour: use24Hour.checked
    property alias cfg_showSeconds: showSeconds.checked
    property alias cfg_showDate: showDate.checked

    QQC2.CheckBox {
        id: use24Hour
        Kirigami.FormData.label: i18n("Time:")
        text: i18n("Use a 24-hour clock")
    }

    QQC2.CheckBox {
        id: showSeconds
        text: i18n("Show seconds")
    }

    QQC2.Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        font: Kirigami.Theme.smallFont
        opacity: 0.7
        text: i18n("Showing seconds wakes the processor once a second rather "
                 + "than once a minute, which is noticeable on a laptop "
                 + "running from its battery.")
    }

    Item { Kirigami.FormData.isSection: true }

    QQC2.CheckBox {
        id: showDate
        Kirigami.FormData.label: i18n("Date:")
        text: i18n("Show the date under the time")
    }
}
