/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the state of the machine, on the flow bar
 *
 * NOT CALLED State.qml, THOUGH THAT IS WHAT IT IS.
 *
 * It was, on 8 October 2026, and on the machine Plasma refused to load the
 * widget: "Cannot assign to non-existent property onPressed". QtQuick has
 * a type called State - the one used for an item's states - and a type
 * imported by name wins over a file of the same name beside it. So the
 * widget was asking QtQuick's State to be the pane.
 *
 * The last pane in the picture: the weather, Wi-Fi, the volume, the battery
 * and the time, all on one piece of glass, and pressing it opens the
 * Control Center. This file draws it from what it is told; main.qml is
 * what asks the machine.
 *
 * WHAT IS LEFT OUT, AND WHEN.
 *
 *   The battery, on a computer with none - a desktop.
 *   The network, until something has answered the question.
 *   The weather, until /usr/lib/ralden/weather has found it, and again
 *   whenever what it found is more than three hours old (Flow.Weather).
 */
import QtQuick
import org.ralden.flowbar as Flow

Item {
    id: machine

    // The weather's drawing and temperature, or "" while nothing is known.
    property string sky: ""
    property string temperature: ""

    // "wifi", "wired", "offline", or "" while nobody has said
    property string network: ""
    property int strength: 0             // 1-4, Wi-Fi only
    property bool soundKnown: false
    property int volume: 0               // 0-100
    property bool muted: false
    property int battery: -1             // -1: there is no battery
    property bool charging: false
    property string time: ""
    property bool lit: false
    property bool open: false

    signal pressed()

    readonly property real h: Math.round(height * Flow.Look.share)
    readonly property real gap: Math.round(h * Flow.Look.gap)
    readonly property real glyph: Math.round(h * 0.36)
    readonly property real side: Math.round(h * Flow.Look.stateInset)

    implicitWidth: gap + paneWidth
    readonly property real paneWidth: Math.round(row.implicitWidth + side * 2)

    // Open, this pane is drawn pressed; Plasma's own line over an open
    // widget is hidden (QuietOpenLine.qml says why).
    Flow.QuietOpenLine { }

    Flow.Pill {
        id: pane
        x: machine.gap
        width: machine.paneWidth
        height: machine.h
        lit: machine.lit || area.containsMouse
        pressed: area.pressed || machine.open

        Row {
            id: row
            x: machine.side
            height: parent.height
            spacing: Math.round(machine.h * Flow.Look.stateGap)

            // The weather first, as in the picture: the sky's drawing and
            // the temperature beside it.
            Row {
                anchors.verticalCenter: parent.verticalCenter
                visible: machine.sky !== "" && machine.temperature !== ""
                spacing: Math.round(machine.h * 0.1)
                Flow.Glyph {
                    anchors.verticalCenter: parent.verticalCenter
                    width: Math.round(machine.h * 0.42)
                    height: width
                    kind: machine.sky
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: machine.temperature
                    color: Flow.Look.ink
                    font.family: Flow.Look.family
                    font.pixelSize: Math.round(machine.h * Flow.Look.textSize)
                }
            }

            Flow.Glyph {
                anchors.verticalCenter: parent.verticalCenter
                visible: machine.network !== ""
                width: machine.glyph
                height: width
                kind: machine.network
                level: machine.strength
            }

            Flow.Glyph {
                anchors.verticalCenter: parent.verticalCenter
                visible: machine.soundKnown
                width: machine.glyph
                height: width
                kind: "volume"
                muted: machine.muted || machine.volume === 0
                level: machine.volume === 0 ? 0 : (machine.volume < 50 ? 1 : 2)
            }

            Row {
                anchors.verticalCenter: parent.verticalCenter
                visible: machine.battery >= 0
                spacing: Math.round(machine.h * 0.06)
                Flow.Glyph {
                    anchors.verticalCenter: parent.verticalCenter
                    width: machine.glyph
                    height: width
                    kind: "battery"
                    level: machine.battery
                    charging: machine.charging
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: machine.battery + "%"
                    color: Flow.Look.ink
                    font.family: Flow.Look.family
                    font.pixelSize: Math.round(machine.h * Flow.Look.textSize)
                }
            }

            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: machine.time
                color: Flow.Look.ink
                font.family: Flow.Look.family
                font.pixelSize: Math.round(machine.h * Flow.Look.timeSize)
            }
        }

        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: machine.pressed()
        }
    }
}
