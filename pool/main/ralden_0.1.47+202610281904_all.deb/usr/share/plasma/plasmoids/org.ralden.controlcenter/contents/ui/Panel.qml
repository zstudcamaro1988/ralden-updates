/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the Control Center, as it is drawn
 *
 * The owner's picture (reference/2b-control-center.jpg), in Alpine Mist's
 * dark glass: a header with a gear; three tiles - Wi-Fi, Bluetooth, Focus;
 * a card with Adaptive Mode and Night Light; a card with the screen and
 * the sound; what is playing; and at the foot the battery and four round
 * buttons.
 *
 * THIS FILE ONLY DRAWS.
 *
 * Everything it shows is handed to it, and everything pressed is said as a
 * signal; main.qml does the asking and the doing. That split is so the
 * panel can be photographed with any state at all - on, off, unknown, a
 * laptop on its battery, a desktop with no Bluetooth - before a build, by
 * tools/preview-events/controlcenter.py, which loads this file alone.
 *
 * EVERY LENGTH IS THE PICTURE'S, TIMES `u`.
 *
 * The picture is 786 of its pixels wide. The numbers below are read off
 * it - the tiles 214 tall with 28 between them, the cards 26 round, the
 * sliders' knobs 26 across - and `u` is how many of the screen's pixels
 * one of the picture's is. main.qml chooses u so that the whole panel fits
 * above the bar on the screen it is on: about 0.55 on a 1920 screen, a
 * little less on the VAIO's 768 lines. The writing is not scaled with it:
 * it is Plasma's own size (`body`), so that it is as readable here as
 * everywhere else, and the picture's proportions between the sizes are
 * kept.
 */
import QtQuick
import org.ralden.flowbar as Flow

Item {
    id: panel

    // ---- how big -------------------------------------------------------
    property real u: 0.55
    property real body: 13
    // How far the cards are from the glass's edge. The glass (the Plasma
    // theme's popup) keeps its own 10 pixels; this is the rest of the
    // picture's 46.
    property real edge: Math.round(46 * u) - 10

    // ---- what it shows ---------------------------------------------------
    // The first tile: Wi-Fi where there is Wi-Fi, the network where there
    // is only a cable.
    property bool wifiPresent: true
    property bool wifiOn: false
    property bool wifiKnown: false
    property string wifiDetail: ""
    property int wifiLevel: 4
    property string wiredDetail: ""
    property bool wiredConnected: false

    property bool btPresent: true
    property bool btOn: false
    property bool btKnown: false
    property string btDetail: ""

    property bool focusOn: false
    property bool focusKnown: false
    property string focusDetail: ""

    property bool nightAvailable: true
    property bool nightKnown: false
    property int warmth: 0              // 0 is off
    property bool adaptive: false
    property bool adaptivePossible: true
    property string adaptiveDetail: ""

    property int brightness: 0
    property bool brightnessAvailable: false
    property string brightnessDetail: ""
    property int volume: 0
    property bool volumeAvailable: false
    property bool muted: false
    property string volumeDetail: ""

    property bool hasMedia: false
    property string track: ""
    property string artist: ""
    property string art: ""
    property bool playing: false
    property bool canPrevious: false
    property bool canNext: false
    property bool canControl: false

    property int battery: -1            // -1: no battery
    property bool charging: false
    property bool canSleep: false
    property bool canLock: false
    property bool canStop: false

    // ---- what is pressed ------------------------------------------------
    signal settingsChosen()
    signal wifiToggled()
    signal wifiMore()
    signal btToggled()
    signal btMore()
    signal focusToggled()
    signal adaptiveToggled()
    signal warmthMoving(int value)
    signal warmthChosen(int value)
    signal brightnessChosen(int value)
    signal volumeChosen(int value)
    signal muteToggled()
    signal previousChosen()
    signal playChosen()
    signal nextChosen()
    signal screenshotChosen()
    signal sleepChosen()
    signal lockChosen()
    signal stopChosen()

    // In the person's language where Plasma can say it; the preview has no
    // Plasma, and shows the English.
    function say(text, a) {
        if (typeof i18n === "function")
            return a === undefined ? i18n(text) : i18n(text, a)
        return a === undefined ? text : text.replace("%1", a)
    }

    function s(x) { return Math.round(x * u) }

    readonly property real inner: s(694)       // 786 less 46 each side
    implicitWidth: inner + edge * 2
    implicitHeight: column.implicitHeight + edge * 2

    readonly property color detailInk: Qt.rgba(1, 1, 1, 0.62)
    readonly property color line: Qt.rgba(1, 1, 1, 0.08)

    Column {
        id: column
        x: panel.edge
        y: panel.edge
        width: panel.inner
        spacing: 0

        // ---- the header ---------------------------------------------------
        Item {
            width: parent.width
            height: panel.s(56)

            Text {
                anchors.verticalCenter: parent.verticalCenter
                x: panel.s(6)
                text: panel.say("Control Center")
                color: Flow.Look.ink
                font.family: Flow.Look.family
                font.pixelSize: Math.round(panel.body * 1.3)
                font.weight: Font.DemiBold
            }
            Item {
                width: panel.s(64)
                height: width
                anchors.right: parent.right
                anchors.rightMargin: 0
                anchors.verticalCenter: parent.verticalCenter
                Rectangle {
                    anchors.fill: parent
                    radius: width / 2
                    color: Qt.rgba(1, 1, 1, gear.containsMouse ? 0.12 : 0.0)
                }
                Flow.Glyph {
                    anchors.centerIn: parent
                    width: panel.s(40)
                    height: width
                    kind: "gear"
                    ink: Flow.Look.inkSoft
                }
                MouseArea {
                    id: gear
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: panel.settingsChosen()
                }
            }
        }

        Item { width: 1; height: panel.s(39) }

        // ---- the tiles -----------------------------------------------------
        Row {
            spacing: panel.s(28)
            readonly property real tileWidth: Math.floor((panel.inner - spacing * 2) / 3)

            Tile {
                width: parent.tileWidth
                height: panel.s(214)
                u: panel.u
                body: panel.body
                checking: panel.say("Checking…")
                glyph: panel.wifiPresent ? (panel.wifiOn ? "wifi" : "offline")
                                         : (panel.wiredDetail !== "" ? "wired" : "offline")
                level: panel.wifiLevel
                label: panel.wifiPresent ? panel.say("Wi-Fi") : panel.say("Network")
                detail: panel.wifiPresent ? panel.wifiDetail : panel.wiredDetail
                // Lit when the machine is on a network at all: a cable that
                // is connected is as "on" as a radio that is.
                on: panel.wifiPresent ? panel.wifiOn : panel.wiredConnected
                known: panel.wifiKnown
                more: true
                onToggled: panel.wifiPresent ? panel.wifiToggled() : panel.wifiMore()
                onMoreChosen: panel.wifiMore()
            }
            Tile {
                width: parent.tileWidth
                height: panel.s(214)
                u: panel.u
                body: panel.body
                checking: panel.say("Checking…")
                glyph: "bluetooth"
                label: panel.say("Bluetooth")
                detail: panel.btDetail
                on: panel.btOn
                known: panel.btKnown
                present: panel.btPresent
                more: true
                onToggled: panel.btToggled()
                onMoreChosen: panel.btMore()
            }
            Tile {
                width: parent.tileWidth
                height: panel.s(214)
                u: panel.u
                body: panel.body
                checking: panel.say("Checking…")
                glyph: "focus"
                label: panel.say("Focus")
                detail: panel.focusDetail
                on: panel.focusOn
                known: panel.focusKnown
                onToggled: panel.focusToggled()
            }
        }

        Item { width: 1; height: panel.s(34) }

        // ---- Adaptive Mode and Night Light ------------------------------------
        Card {
            width: panel.inner
            height: panel.s(246)
            radius: panel.s(26)

            // Adaptive Mode
            Item {
                width: parent.width
                height: panel.s(122)
                Flow.Glyph {
                    x: panel.s(53) - width / 2
                    anchors.verticalCenter: parent.verticalCenter
                    width: panel.s(40)
                    height: width
                    kind: "adaptive"
                    ink: panel.adaptive && panel.warmth > 0
                         ? Qt.rgba(110 / 255, 172 / 255, 242 / 255, 1) : Flow.Look.inkSoft
                }
                Column {
                    x: panel.s(106)
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - x - panel.s(150)
                    spacing: Math.round(panel.body * 0.12)
                    Text {
                        width: parent.width
                        text: panel.say("Adaptive Mode")
                        elide: Text.ElideRight
                        color: Flow.Look.ink
                        font.family: Flow.Look.family
                        font.pixelSize: panel.body
                        font.weight: Font.DemiBold
                    }
                    Text {
                        width: parent.width
                        visible: text !== ""
                        text: panel.adaptiveDetail
                        elide: Text.ElideRight
                        color: panel.detailInk
                        font.family: Flow.Look.family
                        font.pixelSize: Math.round(panel.body * 0.82)
                    }
                }
                Toggle {
                    u: panel.u
                    anchors.right: parent.right
                    anchors.rightMargin: panel.s(41)
                    anchors.verticalCenter: parent.verticalCenter
                    on: panel.adaptive
                    usable: panel.nightKnown && panel.nightAvailable && panel.adaptivePossible
                    onFlipped: panel.adaptiveToggled()
                }
            }
            Rectangle {
                x: panel.s(26)
                y: panel.s(122)
                width: parent.width - panel.s(52)
                height: 1
                color: panel.line
            }
            // Night Light
            Item {
                y: panel.s(124)
                width: parent.width
                height: panel.s(122)
                Flow.Glyph {
                    x: panel.s(53) - width / 2
                    anchors.verticalCenter: parent.verticalCenter
                    width: panel.s(40)
                    height: width
                    kind: "sun-low"
                    ink: Flow.Look.inkSoft
                }
                Text {
                    x: panel.s(106)
                    anchors.verticalCenter: parent.verticalCenter
                    width: panel.s(290)
                    text: panel.say("Night Light")
                    elide: Text.ElideRight
                    color: Flow.Look.ink
                    font.family: Flow.Look.family
                    font.pixelSize: panel.body
                    font.weight: Font.DemiBold
                }
                Rail {
                    u: panel.u
                    x: panel.s(406) - knob / 2
                    width: parent.width - panel.s(90) - x + knob / 2
                    anchors.verticalCenter: parent.verticalCenter
                    value: panel.warmth
                    usable: panel.nightKnown && panel.nightAvailable
                    onMoving: function(v) { panel.warmthMoving(v) }
                    onChosen: function(v) { panel.warmthChosen(v) }
                }
                Flow.Glyph {
                    x: parent.width - panel.s(51) - width / 2
                    anchors.verticalCenter: parent.verticalCenter
                    width: panel.s(40)
                    height: width
                    kind: "sun-high"
                    ink: Flow.Look.inkSoft
                }
            }
        }

        Item { width: 1; height: panel.s(33) }

        // ---- the screen and the sound -----------------------------------------
        Card {
            width: panel.inner
            height: panel.s(322)
            radius: panel.s(26)

            Repeater {
                model: [
                    { "top": 0, "name": "Display", "low": "sun-low", "high": "sun-high" },
                    { "top": 159, "name": "Volume", "low": "volume", "high": "volume" }
                ]
                Item {
                    required property var modelData
                    required property int index
                    readonly property bool sound: index === 1
                    y: panel.s(modelData.top)
                    width: parent.width
                    height: panel.s(163)

                    Text {
                        x: panel.s(32)
                        y: panel.s(51) - height / 2
                        text: panel.say(modelData.name)
                        color: Flow.Look.ink
                        font.family: Flow.Look.family
                        font.pixelSize: panel.body
                        font.weight: Font.Medium
                    }
                    Text {
                        anchors.right: parent.right
                        anchors.rightMargin: panel.s(37)
                        y: panel.s(51) - height / 2
                        text: sound ? panel.volumeDetail : panel.brightnessDetail
                        color: panel.detailInk
                        font.family: Flow.Look.family
                        font.pixelSize: Math.round(panel.body * 0.85)
                    }
                    Item {
                        x: panel.s(51) - width / 2
                        y: panel.s(107) - height / 2
                        width: panel.s(52)
                        height: width
                        Flow.Glyph {
                            anchors.centerIn: parent
                            width: panel.s(40)
                            height: width
                            kind: modelData.low
                            level: 0
                            muted: sound && panel.muted
                            ink: Flow.Look.inkSoft
                        }
                        // Pressing the speaker mutes, as on every system.
                        MouseArea {
                            anchors.fill: parent
                            enabled: sound && panel.volumeAvailable
                            cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                            onClicked: panel.muteToggled()
                        }
                    }
                    Rail {
                        u: panel.u
                        x: panel.s(90) - knob / 2
                        width: parent.width - panel.s(89) - x + knob / 2
                        y: panel.s(107) - height / 2
                        value: sound ? (panel.muted ? 0 : panel.volume) : panel.brightness
                        usable: sound ? panel.volumeAvailable : panel.brightnessAvailable
                        onChosen: function(v) {
                            if (sound) panel.volumeChosen(v)
                            else panel.brightnessChosen(v)
                        }
                    }
                    Flow.Glyph {
                        x: parent.width - panel.s(49) - width / 2
                        y: panel.s(107) - height / 2
                        width: panel.s(40)
                        height: width
                        kind: modelData.high
                        level: 3
                        ink: Flow.Look.inkSoft
                    }
                }
            }
            Rectangle {
                x: panel.s(26)
                y: panel.s(168)
                width: parent.width - panel.s(52)
                height: 1
                color: panel.line
            }
        }

        // ---- what is playing ------------------------------------------------------
        Item {
            width: 1
            height: panel.s(23)
            visible: panel.hasMedia
        }
        Card {
            visible: panel.hasMedia
            width: panel.inner
            height: panel.s(157)
            radius: panel.s(26)

            Rectangle {
                id: cover
                x: panel.s(26)
                anchors.verticalCenter: parent.verticalCenter
                width: panel.s(98)
                height: width
                radius: panel.s(12)
                color: Qt.rgba(1, 1, 1, 0.08)
                clip: true
                Image {
                    id: artwork
                    anchors.fill: parent
                    source: panel.art
                    fillMode: Image.PreserveAspectCrop
                    sourceSize.width: width * 2
                    sourceSize.height: height * 2
                    asynchronous: true
                    visible: status === Image.Ready
                }
                Flow.Glyph {
                    anchors.centerIn: parent
                    visible: !artwork.visible
                    width: parent.width * 0.42
                    height: width
                    kind: "note"
                    ink: Flow.Look.inkFaint
                }
            }
            Column {
                x: panel.s(156)
                anchors.verticalCenter: parent.verticalCenter
                width: parent.width - x - panel.s(290)
                spacing: Math.round(panel.body * 0.2)
                Text {
                    width: parent.width
                    text: panel.track
                    elide: Text.ElideRight
                    color: Flow.Look.ink
                    font.family: Flow.Look.family
                    font.pixelSize: Math.round(panel.body * 1.08)
                    font.weight: Font.DemiBold
                    textFormat: Text.PlainText
                }
                Text {
                    width: parent.width
                    visible: text !== ""
                    text: panel.artist
                    elide: Text.ElideRight
                    color: panel.detailInk
                    font.family: Flow.Look.family
                    font.pixelSize: Math.round(panel.body * 0.9)
                    textFormat: Text.PlainText
                }
            }
            Repeater {
                model: [
                    { "from": 246, "kind": "previous" },
                    { "from": 152, "kind": "play" },
                    { "from": 58, "kind": "next-track" }
                ]
                Item {
                    required property var modelData
                    readonly property bool usable: !panel.canControl ? false
                        : modelData.kind === "previous" ? panel.canPrevious
                        : modelData.kind === "next-track" ? panel.canNext : true
                    x: parent.width - panel.s(modelData.from) - width / 2
                    anchors.verticalCenter: parent.verticalCenter
                    width: panel.s(64)
                    height: width
                    opacity: usable ? 1.0 : 0.35
                    Rectangle {
                        anchors.fill: parent
                        radius: width / 2
                        color: Qt.rgba(1, 1, 1, mediaPress.containsMouse && parent.usable ? 0.12 : 0.0)
                    }
                    Flow.Glyph {
                        anchors.centerIn: parent
                        width: panel.s(modelData.kind === "play" ? 40 : 34)
                        height: width
                        kind: modelData.kind === "play" ? (panel.playing ? "pause" : "play")
                                                        : modelData.kind
                        ink: Flow.Look.ink
                    }
                    MouseArea {
                        id: mediaPress
                        anchors.fill: parent
                        hoverEnabled: true
                        enabled: parent.usable
                        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                        onClicked: {
                            if (modelData.kind === "previous") panel.previousChosen()
                            else if (modelData.kind === "play") panel.playChosen()
                            else panel.nextChosen()
                        }
                    }
                }
            }
        }

        Item { width: 1; height: panel.s(35) }

        // ---- the foot ----------------------------------------------------------------
        Row {
            id: foot
            spacing: panel.s(18)
            readonly property bool hasBattery: panel.battery >= 0
            readonly property real pill: hasBattery ? panel.s(229) : 0
            readonly property real key: Math.floor((panel.inner - pill
                                         - spacing * (hasBattery ? 4 : 3)) / 4)

            Card {
                visible: foot.hasBattery
                width: foot.pill
                height: panel.s(85)
                radius: height / 2
                Row {
                    anchors.centerIn: parent
                    spacing: panel.s(14)
                    Flow.Glyph {
                        anchors.verticalCenter: parent.verticalCenter
                        width: panel.s(44)
                        height: width
                        kind: "battery"
                        level: Math.max(0, panel.battery)
                        charging: panel.charging
                        ink: Flow.Look.inkSoft
                    }
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: panel.say("%1%", panel.battery)
                        color: Flow.Look.ink
                        font.family: Flow.Look.family
                        font.pixelSize: Math.round(panel.body * 0.95)
                        font.weight: Font.Medium
                    }
                }
            }
            Repeater {
                model: [
                    { "kind": "screenshot", "name": "Take a screenshot" },
                    { "kind": "sleep", "name": "Sleep" },
                    { "kind": "lock", "name": "Lock" },
                    { "kind": "power", "name": "Shut down or restart" }
                ]
                Card {
                    id: key
                    required property var modelData
                    readonly property bool usable: modelData.kind === "screenshot" ? true
                        : modelData.kind === "sleep" ? panel.canSleep
                        : modelData.kind === "lock" ? panel.canLock : panel.canStop
                    width: foot.key
                    height: panel.s(85)
                    radius: height / 2
                    lit: keyPress.containsMouse && usable
                    pressed: keyPress.pressed
                    opacity: usable ? 1.0 : 0.4
                    Flow.Glyph {
                        anchors.centerIn: parent
                        width: panel.s(40)
                        height: width
                        kind: key.modelData.kind
                        ink: Flow.Look.ink
                    }
                    MouseArea {
                        id: keyPress
                        anchors.fill: parent
                        hoverEnabled: true
                        enabled: key.usable
                        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                        onClicked: {
                            var k = key.modelData.kind
                            if (k === "screenshot") panel.screenshotChosen()
                            else if (k === "sleep") panel.sleepChosen()
                            else if (k === "lock") panel.lockChosen()
                            else panel.stopChosen()
                        }
                    }
                    Accessible.name: panel.say(key.modelData.name)
                }
            }
        }
    }
}
