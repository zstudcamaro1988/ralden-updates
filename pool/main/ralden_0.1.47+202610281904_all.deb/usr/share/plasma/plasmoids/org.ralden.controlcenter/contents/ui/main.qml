/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the Control Center
 *
 * Two things in one widget: the last pane of the flow bar (Readings.qml),
 * which is always on the screen, and the panel it opens (Panel.qml), drawn
 * from the owner's picture (reference/2b-control-center.jpg). This file
 * asks the machine what is so, hands it to both, and does what is pressed.
 *
 * EVERY CONTROL MOVES SOMETHING REAL, AND HERE IS WHAT.
 *
 *   Wi-Fi            NetworkManager's radio (nmcli). A computer with no
 *                    Wi-Fi gets a Network tile that says how it is
 *                    connected, and opens the network settings.
 *   Bluetooth        BlueZ (bluetoothctl). No adapter: a grey tile that
 *                    says so.
 *   Focus            Plasma's Do Not Disturb, through the same object as
 *                    Plasma's own bell (Focus.qml).
 *   Adaptive Mode,   KWin's Night Light: the slider is how warm (at its
 *   Night Light      left end, off); the switch is whether only from
 *                    sunset to sunrise where you are, or all day.
 *                    /usr/lib/ralden/night-light writes it; KWin's own
 *                    preview shows the warmth while the slider moves.
 *   Display          the screen's backlight (brightnessctl). A screen with
 *                    none - a desktop monitor, the test machine - is grey.
 *   Volume           WirePlumber (wpctl); the speaker mutes.
 *   The media card   whatever is playing, through Plasma's MPRIS piece
 *                    (Media.qml); drawn only while something is.
 *   The foot         the battery, if there is one; Spectacle; and sleep,
 *                    lock and shut down through Plasma's session piece
 *                    (Session.qml).
 *   The gear         Ralden's Settings (ralden-settings); the Wi-Fi and
 *                    Bluetooth tiles' arrows open its Network and Bluetooth
 *                    pages, each of which has Plasma's own window one link
 *                    further on.
 *
 * Seen on the test machine before any of this was written, 14 October
 * 2026: every interface above was asked for and answered, and what each
 * said is in docs/desktop.md, section 4.
 *
 * A NON-ZERO EXIT MEANS THE CONTROL IS NOT AVAILABLE.
 *
 * This is the rule that keeps the panel honest on machines nobody has
 * tried it on. brightnessctl finds no backlight on a desktop; there is no
 * Bluetooth adapter; a Plasma release moves something. In each case the
 * command fails, the control greys out and says why, and the panel has
 * told the truth. Assuming a sensible default instead would be a switch
 * that says "Off" for hardware that is not there.
 *
 * LITTLE IS ASKED WHILE THE PANEL IS SHUT.
 *
 * The bar's pane is always on the screen and needs the network, the
 * volume and the battery, so those are asked every five seconds. The rest
 * is asked only while the panel is open: a control panel that wakes a
 * 2009 laptop's processor to read things nobody is looking at costs more
 * battery than it reports on.
 */

import QtQuick
import QtQuick.Window
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.kirigami as Kirigami
import org.ralden.flowbar as Flow

PlasmoidItem {
    id: root

    preferredRepresentation: compactRepresentation

    toolTipMainText: i18n("Control Center")
    toolTipSubText: i18n("Network, sound, display and battery")

    /* ----------------------------------------------------------- the state
     *
     * `*Known` says whether anybody has told us yet, which is a different
     * thing from the value being false - see Tile.qml. */
    property bool wifiOn: false
    property bool wifiKnown: false
    property string wifiName: ""
    property bool wifiPresent: false

    property bool btOn: false
    property bool btKnown: false
    property bool btPresent: true

    property bool nightKnown: false
    property bool nightAvailable: false
    property int warmth: 0
    property bool adaptive: false
    property bool placeKnown: false

    property int volume: 0
    property bool muted: false
    property bool volumeAvailable: false

    property int brightness: 0
    property bool brightnessAvailable: false

    property int battery: -1
    property bool charging: false

    property string network: ""
    property int strength: 0

    // On the live disc the Lock button is grey. Seen on the test machine,
    // 14 October 2026: pressed there, it locked the live session behind a
    // password nobody using a live disc has been told. (The live session
    // already never locks by itself - kscreenlockerrc, Autolock=false and
    // LockOnResume=false - so sleep is safe; only Lock is not.)
    property bool live: false

    Shell {
        id: shell
        onFinished: function(command, code, out) {
            var ok = (code === 0)

            if (command === root.cmdWifiRadio) {
                root.wifiKnown = ok
                root.wifiOn = ok && (out === "enabled")
            } else if (command === root.cmdWifiName) {
                // nmcli prints one line per active connection; the
                // wireless one is marked by its type. Empty means
                // associated with nothing, a real and common answer.
                root.wifiName = out
            } else if (command === root.cmdBt) {
                // "No default controller available" is an exit of 1: no
                // adapter. That is an answer, not a failure to answer.
                // Seen on the test machine: with no adapter it can also say
                // "No default controller available" and exit 0. An adapter
                // is there when it names one.
                root.btKnown = true
                root.btPresent = ok && out.indexOf("Controller ") >= 0
                root.btOn = root.btPresent && (out.indexOf("Powered: yes") >= 0)
            } else if (command === root.cmdNightAvailable) {
                root.nightAvailable = ok && (out.indexOf("true") >= 0)
            } else if (command === root.cmdNight
                       || command.indexOf(root.cmdNightSet) === 0) {
                var s = null
                try { s = JSON.parse(out) } catch (e) { s = null }
                root.nightKnown = ok && s !== null
                if (s !== null) {
                    root.warmth = s.warmth
                    root.adaptive = s.adaptive
                    root.placeKnown = s.place
                }
            } else if (command === root.cmdVolume) {
                // wpctl prints "Volume: 0.42" and adds " [MUTED]" when muted.
                var m = ok ? out.match(/([0-9]*\.?[0-9]+)/) : null
                root.volumeAvailable = (m !== null)
                root.muted = out.indexOf("MUTED") >= 0
                if (m) root.volume = Math.round(parseFloat(m[1]) * 100)
            } else if (command === root.cmdBrightness) {
                var n = ok ? parseInt(out) : NaN
                root.brightnessAvailable = !isNaN(n)
                if (!isNaN(n)) root.brightness = n
            } else if (command === root.cmdBattery) {
                var b = ok ? parseInt(out) : NaN
                root.battery = isNaN(b) ? -1 : b
            } else if (command === root.cmdCharging) {
                root.charging = (out === "Charging" || out === "Full")
            } else if (command === root.cmdLive) {
                root.live = ok
            } else if (command === root.cmdNetwork) {
                if (!ok) {
                    root.network = ""
                    return
                }
                // Wired first: a laptop on a cable with its radio also
                // connected is on the cable.
                var lines = out.split("\n")
                var wired = false, wireless = false, radio = false
                for (var i = 0; i < lines.length; i++) {
                    var parts = lines[i].split(":")
                    if (parts.length < 2)
                        continue
                    if (parts[0] === "wifi") radio = true
                    if (parts[1] !== "connected")
                        continue
                    if (parts[0] === "ethernet") wired = true
                    if (parts[0] === "wifi") wireless = true
                }
                root.wifiPresent = radio
                root.network = wired ? "wired" : wireless ? "wifi" : "offline"
            } else if (command === root.cmdSignal) {
                var rows = ok ? out.split("\n") : []
                var best = -1
                for (var j = 0; j < rows.length; j++) {
                    var cells = rows[j].split(":")
                    if (cells.length >= 2 && cells[0] === "yes")
                        best = Math.max(best, parseInt(cells[1]))
                }
                root.strength = best < 0 || isNaN(best) ? 0
                              : best >= 75 ? 4 : best >= 50 ? 3 : best >= 25 ? 2 : 1
            }
        }
    }

    /* The commands, named once. The reply is matched by comparing against
     * the command that produced it, so two spellings of one command are two
     * things that never match.
     *
     * busctl rather than qdbus: qdbus is qdbus, qdbus-qt6 or qdbus6
     * depending on the distribution; busctl comes with systemd and has had
     * one name for a decade. */
    readonly property string cmdWifiRadio:  "nmcli radio wifi"
    readonly property string cmdWifiName:   "nmcli -t -f NAME,TYPE connection show --active"
    // --timeout 2: with no adapter, `bluetoothctl show` waits for a daemon
    // that is never going to answer (the first machine to say so took
    // eight seconds and the tile never came alive).
    readonly property string cmdBt:         "bluetoothctl --timeout 2 show"
    readonly property string cmdNightAvailable: "busctl --user get-property org.kde.KWin /org/kde/KWin/NightLight org.kde.KWin.NightLight available"
    readonly property string cmdNight:      "/usr/lib/ralden/night-light show"
    readonly property string cmdNightSet:   "/usr/lib/ralden/night-light set "
    readonly property string cmdVolume:     "wpctl get-volume @DEFAULT_AUDIO_SINK@"
    // -c backlight, NOT -d '*': the first machine to report on itself had
    // a keyboard LED first in brightnessctl's list, and -d '*' would have
    // made this the scroll-lock light.
    readonly property string cmdBrightness: "brightnessctl -m -c backlight | cut -d, -f4 | tr -d '%'"
    readonly property string cmdBattery:    "cat /sys/class/power_supply/BAT*/capacity 2>/dev/null | head -1"
    readonly property string cmdCharging:   "cat /sys/class/power_supply/BAT*/status 2>/dev/null | head -1"
    readonly property string cmdLive:       "test -d /run/live"
    readonly property string cmdNetwork:    "nmcli -t -f TYPE,STATE device"
    readonly property string cmdSignal:     "nmcli -t -f ACTIVE,SIGNAL device wifi list --rescan no"
    readonly property string cmdPreview:    "busctl --user call org.kde.KWin /org/kde/KWin/NightLight org.kde.KWin.NightLight preview u "
    readonly property string cmdStopPreview: "busctl --user call org.kde.KWin /org/kde/KWin/NightLight org.kde.KWin.NightLight stopPreview"

    function refresh() {
        shell.run(cmdWifiRadio)
        shell.run(cmdWifiName)
        shell.run(cmdBt)
        shell.run(cmdNightAvailable)
        shell.run(cmdNight)
        shell.run(cmdBrightness)
        glance()
    }

    function glance() {
        shell.run(cmdNetwork)
        shell.run(cmdSignal)
        shell.run(cmdVolume)
        shell.run(cmdBattery)
        shell.run(cmdCharging)
    }

    // The panel's questions, only while somebody is looking.
    Timer {
        interval: 4000
        repeat: true
        running: root.expanded
        triggeredOnStart: true
        onTriggered: root.refresh()
    }
    // The bar's, always.
    Timer {
        interval: 5000
        repeat: true
        running: !root.expanded
        triggeredOnStart: true
        onTriggered: root.glance()
    }
    // After a switch is thrown the machine needs a moment before it will
    // report the new state; asking at once gets the old answer and makes
    // the tile flicker back before it corrects itself.
    Timer {
        id: refreshSoon
        interval: 700
        onTriggered: root.refresh()
    }

    /* ------------------------------------------------- the pieces loaded apart
     *
     * Each leans on a part of Plasma with no promise across releases, so
     * each is its own file behind a Loader: if one fails, its controls grey
     * and the rest of the panel is as it was. */
    // NOT `focus`, `media` or `session`: seen on the machine, 14 October
    // 2026, a handler inside the panel read `focus` as the panel's own
    // `focus` property - every Item has one - and pressing the Focus tile
    // was "Cannot call method 'set' of undefined". So the three are named
    // for what they are, as nothing else in QtQuick is.
    Loader { id: mediaPiece; source: "Media.qml" }
    Loader { id: sessionPiece; source: "Session.qml" }
    Loader { id: focusPiece; source: "Focus.qml" }

    readonly property bool hasMedia: mediaPiece.status === Loader.Ready && mediaPiece.item.present
    readonly property bool focusKnown: focusPiece.status === Loader.Ready
    readonly property bool focusOn: focusKnown && focusPiece.item.on

    /* ------------------------------------------------------ what is said
     *
     * Each second line answers the question the panel was opened to ask:
     * which network, whether notifications are held and until when, why a
     * slider is grey. */
    readonly property string wifiDetail: {
        if (!wifiOn) return i18n("Off")
        var lines = wifiName.split("\n")
        for (var i = 0; i < lines.length; i++) {
            var parts = lines[i].split(":")
            if (parts.length >= 2 && parts[1] === "802-11-wireless")
                return parts[0]
        }
        return i18n("Not connected")
    }
    readonly property string wiredDetail: network === "wired" ? i18n("Wired")
                                        : network === "offline" ? i18n("Offline") : ""
    // "None here", not "Not on this computer": a tile is 120 pixels wide
    // on a 1920 screen and the longer one was cut short in the first
    // photograph.
    readonly property string btDetail: !btPresent ? i18n("None here")
                                     : btOn ? i18n("On") : i18n("Off")
    readonly property string focusDetail: {
        if (!focusOn) return i18n("Off")
        var f = focusPiece.item
        if (f.held && !f.timed) {
            var who = f.holders && f.holders.length > 0 ? f.holders[0] : ""
            return who !== "" ? i18n("Held by %1", who) : i18n("On")
        }
        // "On" for "until I turn it off" (a year away, as Plasma's own bell
        // writes it); a time when it ends today or tomorrow.
        if (f.until - f.now < 24 * 3600 * 1000)
            return i18n("Until %1", Qt.formatTime(f.until, Qt.locale().timeFormat(Locale.ShortFormat)))
        return i18n("On")
    }
    readonly property string adaptiveDetail: {
        if (!nightKnown) return ""
        if (!nightAvailable) return i18n("Not available on this screen")
        if (!placeKnown) return i18n("Needs to know where you are first")
        if (warmth === 0) return i18n("Night Light is off")
        return adaptive ? i18n("Warmer from sunset to sunrise") : i18n("Warm all day")
    }

    function collapseThen(command) {
        root.expanded = false
        if (command) shell.run(command)
    }

    /* ---------------------------------------------------- Night Light's preview
     *
     * While the slider moves, KWin is asked to show that warmth for a moment
     * without anything being saved - its own preview, which is what Plasma's
     * Night Light page does too. The latest position only, five times a
     * second at most. */
    property int previewWanted: -1
    Timer {
        id: previewPace
        interval: 200
        onTriggered: {
            if (root.previewWanted >= 0) {
                shell.run(root.cmdPreview + Math.round(6500 - 40 * root.previewWanted))
                root.previewWanted = -1
            }
        }
    }

    /* ---------------------------------------------------------- the button
     *
     * The last pane of the flow bar: what the machine is doing, and
     * pressing it opens the panel. */
    property string time: ""
    function tick() {
        // As the wallpaper clock does: the zone can change under a running
        // desktop (the live disc learns it a moment after starting), and
        // QML's Date keeps the old one until it is told.
        Date.timeZoneUpdated()
        var now = new Date()
        root.time = Qt.formatTime(now, Qt.locale().timeFormat(Locale.ShortFormat))
        minute.interval = Math.max(1000, (60 - now.getSeconds()) * 1000 - now.getMilliseconds() + 50)
        minute.restart()
    }
    Timer {
        id: minute
        repeat: false
        onTriggered: root.tick()
    }
    Component.onCompleted: {
        tick()
        shell.run(cmdLive)
    }

    // The weather, read from the file the weather service writes. Shared
    // with the clock on the wallpaper, so the two say the same thing.
    Flow.Weather {
        id: weather
    }

    compactRepresentation: Readings {
        sky: weather.known ? weather.kind : ""
        temperature: weather.temperature
        network: root.network
        strength: root.strength
        soundKnown: root.volumeAvailable
        volume: root.volume
        muted: root.muted || root.volume === 0
        battery: root.battery
        charging: root.charging
        time: root.time
        open: root.expanded

        Layout.minimumWidth: implicitWidth
        Layout.preferredWidth: implicitWidth
        Layout.maximumWidth: implicitWidth
        Layout.fillWidth: false
        Layout.fillHeight: true

        onPressed: root.expanded = !root.expanded
    }

    /* ----------------------------------------------------------- the panel
     *
     * Sized so that the whole of it fits above the bar on the screen it is
     * on: the picture is 1330 of its pixels tall with everything in it, and
     * u is the share of the screen's height that leaves, up to 0.58 - the
     * picture's proportions at about 450 pixels across on a 1920 screen. */
    fullRepresentation: Item {
        readonly property real u: Math.min(0.58, Math.max(0.42, Screen.height * 0.86 / 1330))
        Layout.minimumWidth: panel.implicitWidth
        Layout.preferredWidth: panel.implicitWidth
        Layout.maximumWidth: panel.implicitWidth
        Layout.minimumHeight: panel.implicitHeight
        Layout.preferredHeight: panel.implicitHeight
        Layout.maximumHeight: panel.implicitHeight

        Panel {
            id: panel
            width: implicitWidth
            height: implicitHeight
            u: parent.u
            body: Math.round(Kirigami.Units.gridUnit * 0.72)

            wifiPresent: root.wifiPresent
            wifiOn: root.wifiOn
            wifiKnown: root.wifiKnown && root.network !== ""
            wifiDetail: root.wifiDetail
            wifiLevel: root.strength
            wiredDetail: root.wiredDetail
            wiredConnected: root.network === "wired"
            btPresent: root.btPresent
            btOn: root.btOn
            btKnown: root.btKnown
            btDetail: root.btDetail
            focusOn: root.focusOn
            focusKnown: root.focusKnown
            focusDetail: root.focusDetail
            nightAvailable: root.nightAvailable
            nightKnown: root.nightKnown
            warmth: root.warmth
            adaptive: root.adaptive && root.placeKnown
            adaptivePossible: root.placeKnown
            adaptiveDetail: root.adaptiveDetail
            brightness: root.brightness
            brightnessAvailable: root.brightnessAvailable
            brightnessDetail: root.brightnessAvailable ? i18n("%1%", root.brightness)
                                                       : i18n("Not adjustable here")
            volume: root.volume
            volumeAvailable: root.volumeAvailable
            muted: root.muted
            volumeDetail: !root.volumeAvailable ? i18n("No sound device")
                        : root.muted ? i18n("Muted") : i18n("%1%", root.volume)
            hasMedia: root.hasMedia
            track: root.hasMedia ? mediaPiece.item.track : ""
            artist: root.hasMedia ? mediaPiece.item.artist : ""
            art: root.hasMedia ? mediaPiece.item.art : ""
            playing: root.hasMedia && mediaPiece.item.playing
            canPrevious: root.hasMedia && mediaPiece.item.canPrevious
            canNext: root.hasMedia && mediaPiece.item.canNext
            canControl: root.hasMedia && mediaPiece.item.canControl
            battery: root.battery
            charging: root.charging
            canSleep: sessionPiece.status === Loader.Ready && sessionPiece.item.canSleep
            canLock: !root.live && sessionPiece.status === Loader.Ready && sessionPiece.item.canLock
            canStop: sessionPiece.status === Loader.Ready && sessionPiece.item.canStop

            onSettingsChosen: root.collapseThen("ralden-settings")
            onWifiToggled: {
                shell.run("nmcli radio wifi " + (root.wifiOn ? "off" : "on"))
                root.wifiKnown = false
                refreshSoon.restart()
            }
            onWifiMore: root.collapseThen("ralden-settings network")
            onBtToggled: {
                shell.run("bluetoothctl power " + (root.btOn ? "off" : "on"))
                root.btKnown = false
                refreshSoon.restart()
            }
            onBtMore: root.collapseThen("ralden-settings bluetooth")
            onFocusToggled: focusPiece.item.set(!root.focusOn)
            onAdaptiveToggled: {
                // Switched on with the light off means "on": nobody turns
                // on a schedule for a light that is off. 50 is 4500 K,
                // KWin's own default (night-light's DEFAULT_WARMTH).
                var turningOn = !(root.adaptive && root.placeKnown)
                var w = turningOn && root.warmth === 0 ? 50 : root.warmth
                shell.run(root.cmdNightSet + w + " " + (turningOn ? 1 : 0))
                root.nightKnown = false
            }
            onWarmthMoving: function(v) {
                root.previewWanted = v
                if (!previewPace.running) previewPace.start()
            }
            onWarmthChosen: function(v) {
                previewPace.stop()
                root.previewWanted = -1
                shell.run(root.cmdNightSet + v + " " + (root.adaptive && root.placeKnown ? 1 : 0))
                shell.run(root.cmdStopPreview)
                root.warmth = v
            }
            onBrightnessChosen: function(v) {
                // Never to nothing: a screen turned fully off by a slider
                // is a machine a person cannot find the slider on again.
                shell.run("brightnessctl -c backlight set " + Math.max(v, 3) + "%")
                root.brightness = v
            }
            onVolumeChosen: function(v) {
                // Unmuted by any change: dragging the volume up on a muted
                // machine means "let me hear it".
                shell.run("wpctl set-mute @DEFAULT_AUDIO_SINK@ 0")
                shell.run("wpctl set-volume @DEFAULT_AUDIO_SINK@ " + v + "%")
                root.volume = v
                root.muted = false
            }
            onMuteToggled: {
                shell.run("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle")
                root.muted = !root.muted
                refreshSoon.restart()
            }
            onPreviousChosen: mediaPiece.item.previous()
            onPlayChosen: mediaPiece.item.toggle()
            onNextChosen: mediaPiece.item.next()
            // A moment after the panel has gone, so that it is not in the
            // picture.
            onScreenshotChosen: {
                root.expanded = false
                shot.restart()
            }
            onSleepChosen: { root.expanded = false; sessionPiece.item.sleep() }
            onLockChosen: { root.expanded = false; sessionPiece.item.lock() }
            onStopChosen: { root.expanded = false; sessionPiece.item.stop() }
        }
    }

    Timer {
        id: shot
        interval: 450
        onTriggered: shell.run("spectacle --region")
    }
}
