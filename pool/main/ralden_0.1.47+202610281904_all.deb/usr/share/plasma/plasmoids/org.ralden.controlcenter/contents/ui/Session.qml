/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - sleep, lock and switch off, for the Control Center's foot
 *
 * LOADED APART, AND WHY: org.kde.plasma.private.sessions is the only way
 * to ask Plasma itself to lock the screen, put the computer to sleep or
 * show its "shut down" screen (the menu does it through the same piece),
 * and it is private. So it is here alone and loaded through a Loader: if
 * an update renames it, the three buttons grey and nothing else changes.
 * The lock screen's "switch user" is loaded the same way.
 */
import QtQuick
import org.kde.plasma.private.sessions as Sessions

Item {
    readonly property bool canSleep: sessions.canSuspend
    readonly property bool canLock: sessions.canLock
    readonly property bool canStop: sessions.canShutdown

    function sleep() { sessions.suspend() }
    function lock() { sessions.lock() }
    // Plasma's own "shut down" screen, which also offers restart, sleep
    // and log out, and asks before anything is lost.
    function stop() { sessions.requestShutdown() }

    Sessions.SessionManagement {
        id: sessions
    }
}
