/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - one of the three tiles across the top of the Control Center
 *
 * A drawing, a name, and a line underneath saying what it is doing now.
 * That third line is the whole reason these are tiles rather than
 * switches: "Wi-Fi" tells a person nothing they did not know, and
 * "Wi-Fi / Ralden_5G" answers the question they opened the panel to ask.
 *
 * Measured off the picture, where a tile is 219 by 214 of its pixels: the
 * drawing's middle 58 in and 59 down, 44 across; the name's middle 129
 * down, the line under it 171 down, both 33 in. `u` turns those into the
 * screen's pixels.
 *
 * THREE STATES, NOT TWO.
 *
 * Off is "this is off". Unknown is "nobody has said yet" - the first paint
 * happens before any command has come back, and a tile that reads "Off"
 * for a quarter of a second before correcting itself has told a lie that
 * somebody may act on. And absent is "there is none here": a desktop with
 * no Bluetooth gets a grey tile that says so, not a switch that does
 * nothing.
 */
import QtQuick
import org.ralden.flowbar as Flow

Card {
    id: tile

    property real u: 0.55
    property real body: 13
    property string glyph: ""
    property int level: 4
    property string label: ""
    property string detail: ""
    property bool known: false
    property bool present: true
    // The small arrow at the top right, to the page in Settings where the
    // choices are (which network, which device). Only where there are any.
    property bool more: false
    // What the second line says before anything is known, in the
    // person's language (the panel translates; this only shows it).
    property string checking: "Checking…"

    signal toggled()
    signal moreChosen()

    radius: Math.round(26 * u)
    lit: press.containsMouse && press.enabled
    pressed: press.pressed

    readonly property color mark: !present || !known ? Flow.Look.inkFaint
                                : on ? Qt.rgba(110 / 255, 172 / 255, 242 / 255, 1)
                                : Flow.Look.inkSoft

    MouseArea {
        id: press
        anchors.fill: parent
        hoverEnabled: true
        // Nothing to press until the state is known, or where there is
        // nothing to switch: pressing either would send a guess.
        enabled: tile.known && tile.present
        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
        onClicked: tile.toggled()
    }

    Flow.Glyph {
        x: Math.round(58 * tile.u - width / 2)
        y: Math.round(59 * tile.u - height / 2)
        width: Math.round(44 * tile.u)
        height: width
        kind: tile.glyph
        level: tile.level
        ink: tile.mark
    }

    Text {
        x: Math.round(33 * tile.u)
        width: tile.width - x - Math.round(16 * tile.u)
        y: Math.round(129 * tile.u - height / 2)
        text: tile.label
        elide: Text.ElideRight
        color: tile.present ? Flow.Look.ink : Flow.Look.inkSoft
        font.family: Flow.Look.family
        font.pixelSize: tile.body
        font.weight: Font.DemiBold
    }

    Text {
        x: Math.round(33 * tile.u)
        width: tile.width - x - Math.round(16 * tile.u)
        y: Math.round(171 * tile.u - height / 2)
        text: !tile.present || tile.known ? tile.detail : tile.checking
        elide: Text.ElideRight
        color: Qt.rgba(1, 1, 1, 0.62)
        font.family: Flow.Look.family
        font.pixelSize: Math.round(tile.body * 0.86)
    }

    Item {
        visible: tile.more && tile.present
        width: Math.round(56 * tile.u)
        height: width
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.rightMargin: Math.round(8 * tile.u)
        anchors.topMargin: Math.round(31 * tile.u)

        Rectangle {
            anchors.centerIn: parent
            width: parent.width
            height: width
            radius: width / 2
            color: Qt.rgba(1, 1, 1, morePress.containsMouse ? 0.12 : 0.0)
        }
        Flow.Glyph {
            anchors.centerIn: parent
            width: Math.round(30 * tile.u)
            height: width
            kind: "next"
            ink: Flow.Look.inkSoft
        }
        MouseArea {
            id: morePress
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: tile.moreChosen()
        }
    }
}
