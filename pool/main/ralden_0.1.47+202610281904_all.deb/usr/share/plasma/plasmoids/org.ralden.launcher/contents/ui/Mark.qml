/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS - the first pane of the flow bar, as drawn
 *
 * A square of lighter glass with Ralden's R on it - the start button the
 * owner drew when the system was renamed Ralden OS, 26 October 2026, in
 * place of the white S of 13 October. The R is a picture in its own blues
 * (tools/make-logo.py); the glass is the same pane every other part of the
 * bar is drawn on.
 */
import QtQuick
import org.ralden.flowbar as Flow

Item {
    id: mark

    property bool open: false
    // Where the silver mark is on the image; a photograph of the drawing
    // taken anywhere else says where it put it.
    property url picture: "file:///usr/share/ralden/flowbar/mark.png"
    signal pressed()

    readonly property real h: Math.round(height * Flow.Look.share)
    implicitWidth: Math.round(h * Flow.Look.launcherWidth)

    Flow.Pill {
        width: parent.width
        height: mark.h
        fill: Flow.Look.launcherGlass
        lit: area.containsMouse
        pressed: area.pressed || mark.open

        // The R is wider than it is tall (1243 by 905).
        Image {
            anchors.centerIn: parent
            height: Math.round(mark.h * 0.56)
            width: Math.round(height * 1243 / 905)
            source: mark.picture
            sourceSize.height: 256
            fillMode: Image.PreserveAspectFit
            smooth: true
            mipmap: true
        }

        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: mark.pressed()
        }
    }
}
