// SPDX-License-Identifier: Ralden-Source
//
// Ralden OS — the desktop, laid out
//
// WHY THIS FILE EXISTS, AND WHAT ITS ABSENCE COST.
//
// The first Ralden ISO booted on 2026-09-25 and came up with Plasma's
// default purple wallpaper and Plasma's default bottom panel. No dock, no
// clock, no photograph. Everything else had worked: the palette was
// Ralden's, the global theme was org.ralden.desktop, the window buttons
// were on the right, Inter was installed, all three widgets were on the
// image. The desktop simply was not the one that had been designed.
//
// The reason is that settings and LAYOUT come from different places, and
// only one of them cascades.
//
// /etc/xdg/kdeglobals and /etc/xdg/kwinrc are read through KConfig's
// cascade, so a fresh account picks them up - which is why the colours and
// the title bars were right. The desktop's shape does not work that way.
// plasmashell builds a new profile's desktop by RUNNING A SCRIPT:
//
//     script = m_lookAndFeelPackage.filePath("layouts",
//                                            shell() + "-layout.js");
//     if (script.isEmpty()) {
//         script = kPackage().filePath("defaultlayout");
//     }
//
// - shellcorona.cpp, loadDefaultLayout()
//
// There was no such file in this package, so the second line ran, and
// Plasma laid out Plasma's desktop. No error, no warning: a fallback doing
// exactly what a fallback is for.
//
// plasma-org.kde.plasma.desktop-appletsrc in /etc/xdg is NOT what a new
// profile reads. It describes the same desktop this script builds, and it
// is still worth having - it is what an existing profile uses and what
// tests/check_tree.py validates - but on a live stick, where every account
// is new, this file is the one that decides.

var gridUnit = 18;

// ---- the desktop ----------------------------------------------------------
//
// The photograph, and the clock sitting directly on it.
var allDesktops = desktops();
for (var i = 0; i < allDesktops.length; i++) {
    var d = allDesktops[i];

    d.wallpaperPlugin = "org.kde.image";
    d.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    d.writeConfig("Image", "/usr/share/wallpapers/Ralden");
    // 2 is PreserveAspectCrop: fill the screen, crop the overflow, never
    // letterbox. A photograph with black bars down the side is not the
    // design.
    d.writeConfig("FillMode", 2);

    // PLACED WHERE IT IS CREATED, NOT ONLY WHERE IT IS CONFIGURED.
    //
    //     Q_INVOKABLE QJSValue addWidget(const QJSValue &v = QJSValue(),
    //         qreal x = -1, qreal y = -1, qreal w = -1, qreal h = -1, ...);
    //
    // - plasma-workspace, shell/scripting/containment.h
    //
    // The ItemGeometries keys below are written and they are correct, and
    // the clock still came up in the middle of the screen. The layout that
    // reads those keys does so when the containment's QML loads, which can
    // be before this script has written them - so the widget is placed by
    // default first, and our geometry describes a position nothing ever
    // used.
    //
    // Geometry passed to addWidget has no such race: it is the position the
    // widget is created at.
    //
    // WHICH OF THE TWO LAYOUTS THIS SCREEN GETS.
    //
    // There are two: a small one, drawn for the VAIO's 1366x768 and used on
    // every screen narrower than 1920, and a large one for 1920 and up. The
    // screen is asked how wide it is - guarded twice over, because a script
    // that throws here builds no desktop at all and Plasma's own appears
    // instead. If the question cannot be asked, the answer is the small
    // layout, which fits anything.
    var here = null;
    var wide = false;
    try {
        if (typeof screenGeometry === "function" && d.screen >= 0) {
            here = screenGeometry(d.screen);
            wide = !!here && here.width >= 1920;
        }
    } catch (e) {
        here = null;
        wide = false;
    }

    // Multiples of 16, all four. Plasma snaps a desktop widget to a grid
    // that wide; given 32,40,330,140 it kept 32,48,336,144, and the clock
    // moved eight pixels the first time Plasma saved where it was.
    //
    // And the same numbers as the lines written further down, so that
    // where the clock is created is where Plasma will put it at every
    // login after this one.
    var clock = wide
        ? d.addWidget("org.ralden.clock", 48, 48, 368, 352)
        : d.addWidget("org.ralden.clock", 32, 48, 336, 256);

    // WHERE THE CLOCK SITS, WRITTEN THE WAY PLASMA STORES IT.
    //
    // Desktop widget positions are per screen size, one line each, and the
    // format is Applet-<id>:x,y,w,h,z. These are the same resolutions and
    // the same coordinates as the appletsrc in /etc/xdg - 1920x1080 for the
    // desktop, 1366x768 for the VAIO's panel - and the applet id has to come
    // from the widget that was just created rather than be guessed.
    //
    // AND THE THIRD LINE, WHICH IS THE ONE THAT USUALLY RUNS.
    //
    // Two named resolutions cover two screens. Every other screen reads a
    // fallback key, and the fallback is ours to set:
    //
    //     configKey: "ItemGeometries-" + width + "x" + height
    //     fallbackConfigKey: landscape ? "ItemGeometriesHorizontal"
    //                                  : "ItemGeometriesVertical"
    //
    // - plasma-desktop, containments/desktop/.../main.qml
    //
    //     if (!config().readEntry(m_configKey, "").isEmpty()) { ...that... }
    //     else { parseLayout(config().readEntry(m_fallbackConfigKey, "")); }
    //
    // - plasma-workspace, appletslayout.cpp
    //
    // Read verbatim, no scaling. The VirtualBox machine boots at 1280x800,
    // which is neither size above, so without this line the clock landed
    // wherever Plasma chose on the only machine this has ever run on. The
    // fallback carries the smaller layout deliberately: it has to fit a
    // screen whose size is unknown, and too small on a big screen is untidy
    // where too big on a small screen is off the edge.
    //
    // tests/check_tree.py checks all three against the appletsrc, so the two
    // files cannot drift.
    d.currentConfigGroup = ["General"];

    // THE ICONS GO TO THE RIGHT, SO THE CLOCK CAN KEEP THE CORNER.
    //
    // This is a Folder View desktop, so it has icons on it - on the live
    // medium always three: Install Ralden, READ ME FIRST, and the report
    // the first boot leaves. Folder View stacks them from the top LEFT by
    // default, which is where the clock is placed three lines below. The
    // first Ralden desktop to appear put both in the same corner.
    //
    //     "alignment" (Int) - default: 0 (Left vs. Right)
    //
    // - plasma-desktop, containments/desktop/.../config/main.xml
    d.writeConfig("alignment", 1);

    // IN THE CONTAINMENT'S OWN GROUP, WHICH IS WHERE PLASMA LOOKS.
    //
    // Until 6 October 2026 the three lines below were written under
    // ["General"], with the alignment above. Plasma does not keep widget
    // positions there: it keeps them in the containment's own group, one
    // level up. So they were never read. The clock was in its place at the
    // first login because addWidget puts it there - and at the SECOND login
    // Plasma looked in its own group, found nothing for this widget, and
    // put it in the top corner at 96 pixels square, with the first digit of
    // the time off the edge of the screen. Seen on a machine, and read out
    // of the file Plasma had written:
    //
    //     [Containments][1]
    //     ItemGeometries-1280x800=Applet-2:0,0,96,96,0;
    //
    //     [Containments][1][General]
    //     ItemGeometriesHorizontal=Applet-2:32,40,330,140,0;    <- unread
    //
    // An empty list is the containment's own group.
    d.currentConfigGroup = [];
    d.writeConfig("ItemGeometries-1920x1080",
                  "Applet-" + clock.id + ":48,48,368,352,0;");
    d.writeConfig("ItemGeometries-1366x768",
                  "Applet-" + clock.id + ":32,48,336,256,0;");
    d.writeConfig("ItemGeometriesHorizontal",
                  "Applet-" + clock.id + ":32,48,336,256,0;");

    // AND FOR THE SCREEN THAT IS ACTUALLY THERE.
    //
    // Plasma reads the line named for the screen in front of it first, and
    // the fallback only when there is none. On that same machine it had
    // written the fallback itself during the first session - as an empty
    // line - which is one more reason not to rest on it alone. So a screen
    // that is neither of the two named above is given a line of its own,
    // from the size it gave earlier.
    if (here && here.width > 0 && here.height > 0) {
        var named = "ItemGeometries-" + Math.round(here.width)
                  + "x" + Math.round(here.height);
        if (named !== "ItemGeometries-1920x1080"
                && named !== "ItemGeometries-1366x768") {
            d.writeConfig(named, wide
                ? "Applet-" + clock.id + ":48,48,368,352,0;"
                : "Applet-" + clock.id + ":32,48,336,256,0;");
        }
    }
}

// ---- the dock -------------------------------------------------------------
//
// THE FLOW BAR, FROM THE OWNER'S PICTURE OF THE DESKTOP.
//
// Until 8 October 2026 this was one floating bar with Plasma's own widgets
// on it. The picture (reference/2-desktop.png) has five panes of glass in a
// row with the wallpaper showing between them: the mark, the search field,
// the programs, the workspaces, the state of the machine. A Plasma panel
// draws one background for all its widgets or none, so the panel is told
// to draw none - Ralden's Plasma theme gives it a background with nothing
// in it - and each pane is drawn by the widget on it. Every length on them
// is a share of the dock's thickness (org/ralden/flowbar/Look.qml).
//
// HOW THICK, ON THIS SCREEN.
//
// The picture's panes, measured against its screen, are as tall as 84
// pixels of dock are on a screen 1920 wide. The dock is that share of
// whatever screen it is on: 60 on the VAIO's 1366, 56 on the test
// machine's 1280. Asked of the screen the same guarded way as above, and if
// the question cannot be asked, the VAIO's.
var thickAt1920 = 84;
var screenWide = 1366;
try {
    if (typeof screenGeometry === "function") {
        var first = screenGeometry(0);
        if (first && first.width > 0)
            screenWide = first.width;
    }
} catch (e) {
    screenWide = 1366;
}
var thick = Math.max(48, Math.round(thickAt1920 * screenWide / 1920));

var dock = new Panel;
dock.location = "bottom";
dock.height = thick;
dock.floating = true;
dock.alignment = "center";
dock.lengthMode = "fit";
dock.opacity = "translucent";
dock.hiding = "none";

// Order matters and is the order in the picture: the mark, the search
// field, the programs, the workspaces, the state of the machine - and then
// Plasma's tray, which the picture has no place for (see below).
dock.addWidget("org.ralden.launcher");

// THE MENU, BESIDE THE MARK AND NO WIDER THAN NOTHING.
//
// Kickoff is the menu the mark opens. It is as wide as the picture on its
// button, and a picture that is not square is drawn at its own shape - so
// its picture is one transparent pixel wide, and it takes no room. The
// mark's pane (org.ralden.launcher) is the button.
//
// NOT AN EMPTY ICON, WHICH WAS TRIED.
//
// The first build wrote the icon as "", meaning none. Plasma reads an empty
// setting as no setting and used its own default, and the first photograph
// of the bar had Plasma's white logo on the white snow beside the mark,
// invisible and pressable.
//
// The mark opens the menu by asking Plasma for "the launcher menu", which
// is the first menu widget with a global shortcut: so it is given Plasma's
// own, Alt+F1. That is also what the Meta key opens; without a shortcut
// the Meta key had nothing to open.
var kickoff = dock.addWidget("org.kde.plasma.kickoff");
kickoff.currentConfigGroup = ["Shortcuts"];
kickoff.writeConfig("global", "Alt+F1");
kickoff.currentConfigGroup = ["General"];
kickoff.writeConfig("icon", "/usr/share/ralden/flowbar/nothing.png");

// The favourites, named rather than asked for by role. Kickoff's own
// default is Konqueror (via preferred://browser), Kontact (not installed
// on this image), System Settings, Dolphin and Discover - which is what
// the first Ralden menu came up with. Menu ids, no prefix; the launchers
// below use `applications:` and the two syntaxes are not interchangeable.
// Kickoff has moved its own defaults into the activity manager before this
// line runs; /usr/lib/ralden/settle-desktop puts this list there instead
// (found on 21 October 2026).
kickoff.writeConfig("favorites",
                    "firefox-esr.desktop," +
                    "org.ralden.files.desktop," +
                    "org.kde.konsole.desktop," +
                    "libreoffice-startcenter.desktop," +
                    "org.kde.discover.desktop," +
                    // Ralden's own Settings: every section is a Ralden
                    // page from build 36 (docs/settings.md).
                    "org.ralden.settings.desktop");

// THE SEARCH FIELD, AND THE KEY ITS KEYCAP NAMES.
//
// Plasma gives every widget a shortcut of its own that opens it; this is
// the search panel's, and Meta+Space is the key the keycap on the field
// says (the widget's own settings, contents/config/main.xml). It used to be
// KRunner's, when pressing the field opened KRunner's window; KRunner keeps
// Plasma's own Alt+Space and Alt+F2.
var search = dock.addWidget("org.ralden.search");
search.currentConfigGroup = ["Shortcuts"];
search.writeConfig("global", "Meta+Space");

var programs = dock.addWidget("org.ralden.apps");
programs.currentConfigGroup = ["General"];
// EVERY ONE OF THESE IS A DEBIAN FILENAME, AND ONE OF THEM WAS NOT.
//
// A launcher is the id of a .desktop file. Plasma does not complain about
// one it cannot find: it draws a blank placeholder in the right place, in
// the right order, which does nothing when clicked. Five icons where one is
// a hole, on the first screen anybody sees, reported nowhere.
//
// The fourth used to read `startcenter.desktop`, which is the name
// LibreOffice uses upstream and Fedora keeps. Debian ships the same program
// as `libreoffice-startcenter.desktop`, and the first photograph of a real
// Ralden dock has a blank page icon between Konsole and System Settings
// where the office suite should be.
//
// 0200-verify.hook.chroot now checks every id in this list against what is
// actually installed, inside the chroot, where the answer is a fact rather
// than a recollection - and prints the near misses when one is wrong.
//
// The last is Ralden's own Settings since 14 October 2026
// (org.ralden.settings.desktop, /usr/bin/ralden-settings). Plasma's own
// System Settings stays on the menu's favourites while Ralden's is being
// built a section at a time, so that nothing is out of reach meanwhile.
//
// The first is Ralden's own Files since 20 October 2026
// (org.ralden.files.desktop, /usr/bin/ralden-files). Dolphin stays on the
// image, on the menu and on every folder's own menu, for what Files does not
// do.
programs.writeConfig("launchers",
                     "applications:org.ralden.files.desktop," +
                     "applications:firefox-esr.desktop," +
                     "applications:org.kde.konsole.desktop," +
                     "applications:libreoffice-startcenter.desktop," +
                     "applications:org.kde.discover.desktop," +
                     "applications:org.ralden.settings.desktop");

dock.addWidget("org.ralden.spaces");
dock.addWidget("org.ralden.controlcenter");

// PLASMA'S TRAY, KEPT, AND WHY THE PICTURE DOES NOT HAVE IT.
//
// The picture has nowhere for two things a computer needs: notifications,
// and programs that live in the background - Steam, Discord, a download
// manager - whose only window is an icon in the tray. Plasma's
// notifications are served by the notifications widget inside the tray, so
// with no tray there would be no notifications at all.
//
// So it stays, at the end of the bar, showing only the bell and whatever
// asks to be seen. What the last pane already shows - network, sound,
// battery, brightness - is put behind its arrow, where it is still one
// press away for choosing a Wi-Fi network or a sound output.
//
// WRITTEN TO THE TRAY'S INSIDE, WHICH IS A CONTAINMENT OF ITS OWN.
//
// The first build wrote these to the tray widget, and the tray came up
// showing everything: the tray widget is a wrapper, and the list of what
// it shows belongs to a containment it makes for itself, whose number it
// keeps as SystrayContainmentId. Guarded, because a layout script that
// throws builds no desktop at all.
var tray = dock.addWidget("org.kde.plasma.systemtray");
var trayInside = null;
try {
    trayInside = desktopById(tray.readConfig("SystrayContainmentId"));
    if (trayInside) {
        trayInside.currentConfigGroup = ["General"];
        trayInside.writeConfig("shownItems", "org.kde.plasma.notifications");
        trayInside.writeConfig("hiddenItems",
                               "org.kde.plasma.networkmanagement," +
                               "org.kde.plasma.volume," +
                               "org.kde.plasma.battery," +
                               "org.kde.plasma.brightness," +
                               "org.kde.plasma.bluetooth," +
                               "org.kde.plasma.clipboard," +
                               "org.kde.plasma.keyboardlayout," +
                               "org.kde.plasma.mediacontroller," +
                               "org.kde.kscreen");
        // AND TOLD TO READ THEM NOW.
        //
        // Seen on the test machine, 13 October 2026: both lists were in
        // the file exactly as written here, and the tray showed five icons
        // anyway. It had read its settings when it was made, a moment
        // before this wrote them, and in the first session - which on the
        // live disk is the only one - nothing made it read them again.
        trayInside.reloadConfig();
    }
} catch (e) {
    trayInside = null;
}
