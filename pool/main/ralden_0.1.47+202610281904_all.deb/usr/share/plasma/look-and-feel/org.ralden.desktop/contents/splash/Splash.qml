/* SPDX-License-Identifier: Ralden-Source
 *
 * Ralden OS — the splash screen
 *
 * WHAT THIS IS AND WHAT IT IS NOT ALLOWED TO BE.
 *
 * It is the six or seven seconds between the boot messages stopping and the
 * desktop appearing. Nothing can be done in it and nothing can be read in it,
 * so the only question is what a person is looking at while they wait.
 *
 * What it must not be is a lie about progress. Plasma hands a splash screen
 * six `stage` changes as the session starts, and they are real: each one is
 * something that finished. So the bar below moves in six steps and stops
 * where it has got to. It does not creep forward on a timer to look busy,
 * and it does not sit at 99% waiting — both of which are the same trick, and
 * both of which teach people that progress bars are decoration.
 *
 * THE MARK IS A FILE, NOT AN ICON NAME.
 *
 * The splash runs before the icon theme is necessarily loaded, and asking for
 * a named icon this early is how a splash ends up showing a grey question
 * mark on somebody else's hardware. images/wordmark.png is beside this file:
 * since 26 October 2026 the owner's "Ralden" (tools/make-logo.py), in place
 * of the white S and the typed name, with a pale blue light behind it
 * (images/glow.png) because its navy letters barely show on this dark
 * background alone - the same as the boot splash before it.
 */

import QtQuick

Rectangle {
    id: root

    /* Set by KSplash as the session comes up. Six is the desktop. */
    property int stage: 0

    /* Ralden panel. The same value as theme.c in the from-scratch kernel and
     * as Ralden.colors - this is the first surface of the machine a person
     * sees and it has to be the same colour as the last one. */
    color: "#141E2D"

    onStageChanged: {
        if (stage >= 1 && !mark.shown)
            mark.shown = true
    }

    /* FLAT, AND THAT IS A DECISION RATHER THAN A DEFAULT.
     *
     * This was a three-stop vertical gradient, #16212F to #141E2D to
     * #101927, to stop a large dark screen reading as a dead panel. A render
     * of it at 1366x768 showed why that does not work: the whole gradient
     * spans about six values of red, green and blue, so across 768 rows it
     * is not a gradient at all - it is six wide bands with hard edges
     * between them.
     *
     * A GPU can hide that by dithering. The machine this is aimed at has
     * Intel graphics from 2009, and the first thing a person would see of
     * Ralden would be three visible stripes across the screen.
     *
     * So the background is one colour, and the composition carries the
     * screen instead.
     */

    /* The light behind the name. Outside the block, so that it does not
     * count towards the block's height and move the composition. */
    Image {
        x: block.x + (block.width - width) / 2
        y: block.y + wordmark.y + (wordmark.height - height) / 2
        width: wordmark.width * 1.7
        height: wordmark.height * 3.2
        source: "images/glow.png"
        smooth: true
        opacity: mark.shown ? 0.3 : 0.0
        Behavior on opacity { NumberAnimation { duration: 420; easing.type: Easing.OutCubic } }
    }

    Item {
        id: block
        anchors.centerIn: parent
        /* Measured against the short side, so the composition is the same on
         * the VAIO's 1366x768 as on a 1920x1080 desktop. A splash laid out in
         * fixed pixels is a splash designed for one screen. */
        width: Math.round(Math.min(root.width, root.height) * 0.42)
        height: childrenRect.height

        Image {
            id: wordmark

            source: "images/wordmark.png"
            smooth: true
            mipmap: true
            fillMode: Image.PreserveAspectFit

            width: block.width
            height: Math.round(width * 579 / 2112)
            anchors.horizontalCenter: parent.horizontalCenter

            opacity: mark.shown ? 1.0 : 0.0
            scale: mark.shown ? 1.0 : 0.94
            Behavior on opacity { NumberAnimation { duration: 420; easing.type: Easing.OutCubic } }
            Behavior on scale { NumberAnimation { duration: 420; easing.type: Easing.OutCubic } }
        }
        /* Whether the name has been shown yet: set once, at the first stage. */
        QtObject {
            id: mark
            property bool shown: false
        }

        /* The progress track. Two pixels of it, narrower than the name above
         * it, because a bar wider than the thing it belongs to reads as a
         * separate object. */
        Rectangle {
            id: track
            anchors.top: wordmark.bottom
            anchors.topMargin: Math.round(block.width * 0.13)
            anchors.horizontalCenter: parent.horizontalCenter

            width: block.width * 0.62
            height: Math.max(2, Math.round(block.width * 0.006))
            radius: height / 2
            color: "#27354A"

            opacity: mark.shown ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 420 } }

            Rectangle {
                height: parent.height
                radius: parent.radius
                color: "#4A90E2"

                /* Six stages, and the bar is wherever those have got to.
                 * Clamped, because a stage count that ever exceeds six on
                 * some future Plasma should overflow into "done" rather than
                 * out of the track. */
                width: parent.width * Math.min(root.stage / 6.0, 1.0)
                Behavior on width {
                    NumberAnimation { duration: 340; easing.type: Easing.OutCubic }
                }
            }
        }
    }
}
