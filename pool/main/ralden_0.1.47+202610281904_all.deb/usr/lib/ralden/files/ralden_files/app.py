# SPDX-License-Identifier: Ralden-Source
#
# Ralden OS - Files: the window
#
# One object (files.py) and one window (/usr/share/ralden/files/Main.qml),
# drawn from the owner's picture (reference/2a-files.jpg). Every start opens
# a window of its own - a person with two folders open side by side is how
# files are moved - at the folder asked for, or at Home.
#
#   ralden-files [folder]

import os
import sys

QML = "/usr/share/ralden/files/Main.qml"


def find_qml():
    if os.path.exists(QML):
        return QML
    here = os.path.dirname(os.path.abspath(__file__))
    candidate = os.path.normpath(os.path.join(
        here, "..", "..", "..", "..", "share", "ralden", "files", "Main.qml"))
    return candidate if os.path.exists(candidate) else QML


def start_place(argv):
    """The folder asked for: a path, or a file:// address as the desktop
    hands one over (Exec=ralden-files %U). Anything else is Home."""
    if not argv:
        return None
    wanted = argv[0]
    if wanted.startswith("file://"):
        from urllib.parse import unquote
        wanted = unquote(wanted[len("file://"):])
    if wanted.startswith("/") and os.path.isdir(wanted):
        return os.path.normpath(wanted)
    return None


def main(argv):
    try:
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QGuiApplication, QIcon
        from PySide6.QtQml import QQmlApplicationEngine
    except ImportError:
        sys.stderr.write("Files needs PySide6 (python3-pyside6.qtquick).\n")
        return 2
    from . import files

    app = QGuiApplication(sys.argv[:1])
    app.setApplicationName("ralden-files")
    app.setApplicationDisplayName("Files")
    app.setOrganizationName("Ralden")
    app.setDesktopFileName("org.ralden.files")
    app.setWindowIcon(QIcon.fromTheme("system-file-manager"))

    backend = files.Files(clipboard=app.clipboard())
    app.aboutToQuit.connect(backend.runner.stop)
    first = start_place(argv)
    if first:
        backend.go(first)

    engine = QQmlApplicationEngine()
    engine.setInitialProperties({"files": backend})
    engine.load(QUrl.fromLocalFile(find_qml()))
    if not engine.rootObjects():
        sys.stderr.write("Files: the window did not load.\n")
        return 1
    return app.exec()
