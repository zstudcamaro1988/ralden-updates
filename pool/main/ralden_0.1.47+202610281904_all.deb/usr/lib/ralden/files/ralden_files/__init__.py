# SPDX-License-Identifier: Ralden-Source
#
# Ralden OS - Files: the program behind /usr/share/ralden/files/Main.qml
