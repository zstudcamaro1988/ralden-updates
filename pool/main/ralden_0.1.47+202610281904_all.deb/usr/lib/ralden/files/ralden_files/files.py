# SPDX-License-Identifier: Ralden-Source
#
# Ralden OS - Files: the one object the window is drawn from
#
# Main.qml draws; this decides. What the window shows is `state` (where it
# is, how it is laid out, the sidebar's places) and `entries` (what is in
# the place it is showing); what is pressed comes back as act(verb, value).
# So the window can be photographed with this very object pointed at a
# made-up home folder, and a `runner` that answers instead of running
# (tools/preview-events/files.py), and the tree checker holds every verb
# the window sends to an entry in ACTS.
#
# NOTHING A PERSON NAMED GOES NEAR A SHELL. Programs are run with QProcess,
# a list of arguments, never waited for; renaming and making a folder are
# Python's own calls, on a path checked to be the one shown.

import json
import os
import re
import shutil
import stat

from PySide6.QtCore import (QFileSystemWatcher, QMimeData, QMimeDatabase, QObject,
                            QProcess, QTimer, QUrl, Property, Signal, Slot)

from . import commands, readers

ENTRIES_MOST = 5000
THUMB_TYPES = ("image/png", "image/jpeg", "image/gif", "image/webp", "image/bmp",
               "image/svg+xml")
THUMB_BYTES = 25 * 1000 * 1000
CUT_FORMAT = "application/x-kde-cutselection"

# The usual folders' own pictures in the icon theme.
SPACE_ICONS = {"desktop": "user-desktop", "documents": "folder-documents",
               "download": "folder-download", "pictures": "folder-pictures",
               "music": "folder-music", "videos": "folder-videos"}


class Runner(QObject):
    """Runs a program - a list - and calls back with (exit code, output)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._running = set()

    def run(self, argv, done=None, seconds=0):
        p = QProcess(self)
        p.setProgram(argv[0])
        p.setArguments(list(argv[1:]))
        p.setProcessChannelMode(QProcess.MergedChannels)
        state = {"over": False}

        def finish(code):
            if state["over"]:
                return
            state["over"] = True
            try:
                out = bytes(p.readAllStandardOutput()).decode("utf-8", "replace")
            except RuntimeError:
                # Qt has already let go of it: the window is closing.
                return
            self._running.discard(p)
            p.deleteLater()
            if done is not None:
                done(code, out)
        p.finished.connect(lambda code, status: finish(
            code if status == QProcess.NormalExit else -1))
        p.errorOccurred.connect(lambda error: finish(-1)
                                if error == QProcess.FailedToStart else None)
        if seconds:
            QTimer.singleShot(seconds * 1000, lambda: (p.kill(), finish(-1))
                              if not state["over"] else None)
        self._running.add(p)
        p.start()
        return p

    def launch(self, argv):
        """Starts a program that is not Files' to keep - Dolphin, a
        terminal, the program a file opens in, a copy KDE does - on its
        own, so that it outlives this window. (A QProcess that is still
        running when Files closes is killed with it: a Dolphin opened from
        here would have gone when Files did.)"""
        p = QProcess()
        p.setProgram(argv[0])
        p.setArguments(list(argv[1:]))
        result = p.startDetached()
        return bool(result[0] if isinstance(result, tuple) else result)

    def stop(self):
        """On the way out: what is still running - the drives being read,
        a stick being ejected - is no longer listened to, and is given a
        moment to finish rather than killed half-way. (Without this, the
        first build printed a traceback on every close: Qt finished each
        process as it destroyed it, and told a window that was no longer
        there.)"""
        for p in list(self._running):
            try:
                p.finished.disconnect()
                p.errorOccurred.disconnect()
                if p.state() != QProcess.NotRunning:
                    p.waitForFinished(3000)
            except (RuntimeError, TypeError):
                pass
        self._running.clear()


def read_file(path, limit=4 << 20):
    try:
        with open(path, errors="replace") as f:
            return f.read(limit)
    except OSError:
        return ""


class Files(QObject):
    stateChanged = Signal()
    entriesChanged = Signal()
    recentChanged = Signal()

    ACTS = {
        "go": "go",
        "back": "back",
        "up": "up",
        "open": "open",
        "newFolder": "new_folder",
        "rename": "rename",
        "trash": "trash",
        "copy": "copy",
        "cut": "cut",
        "paste": "paste",
        "drop": "drop",
        "star": "star",
        "pin": "pin",
        "view": "set_view",
        "sort": "set_sort",
        "hidden": "set_hidden",
        "mount": "mount",
        "eject": "eject",
        "restore": "restore",
        "emptyTrash": "empty_trash",
        "dolphin": "dolphin",
        "terminal": "terminal",
        "noted": "noted",
    }

    def __init__(self, home=None, clipboard=None, runner=None, parent=None):
        super().__init__(parent)
        self.home = os.path.normpath(home or os.path.expanduser("~"))
        self.clipboard = clipboard
        self.runner = runner or Runner(self)
        config = os.environ.get("XDG_CONFIG_HOME") or os.path.join(self.home, ".config")
        data = os.environ.get("XDG_DATA_HOME") or os.path.join(self.home, ".local", "share")
        self.dirs = readers.user_dirs(read_file(os.path.join(config, "user-dirs.dirs")),
                                      self.home)
        self.store = os.path.join(data, "ralden", "files")
        self.recent_file = os.path.join(data, "recently-used.xbel")
        self.trash_dir = os.path.join(data, "Trash")
        self.kio = commands.kioclient()
        self.mimes = QMimeDatabase()
        saved = self._load("settings.json", {})
        self._view = saved.get("view") if saved.get("view") in ("grid", "list") else "grid"
        self._sort = saved.get("sort") if saved.get("sort") in ("name", "date", "size") else "name"
        self._hidden = saved.get("hidden") is True
        self._starred = [p for p in self._load("starred.json", []) if isinstance(p, str)]
        pinned = self._load("pinned.json", None)
        self._pinned = ([p for p in pinned if isinstance(p, str)] if isinstance(pinned, list)
                        else self._default_pinned())
        self._place = "home"
        self._path = self.home
        self._history = []
        self._state = {}
        self._entries = []
        self._recent = []
        self._drives = []
        self._note = ""
        self._renaming = ""
        self.watcher = QFileSystemWatcher(self)
        self.watcher.directoryChanged.connect(lambda _p: self._soon.start())
        self._soon = QTimer(self)
        self._soon.setSingleShot(True)
        self._soon.setInterval(300)
        self._soon.timeout.connect(self.refresh)
        self._drive_timer = QTimer(self)
        self._drive_timer.setInterval(3000)
        self._drive_timer.timeout.connect(self.read_drives)
        self._drive_timer.start()
        self.read_drives()
        self.refresh()

    # ---- what the window reads ---------------------------------------------------

    def _get_state(self):
        return self._state

    def _get_entries(self):
        return self._entries

    def _get_recent(self):
        return self._recent

    state = Property("QVariantMap", _get_state, notify=stateChanged)
    entries = Property("QVariantList", _get_entries, notify=entriesChanged)
    recent = Property("QVariantList", _get_recent, notify=recentChanged)

    def _publish(self):
        spaces = readers.spaces(self.dirs, self.home)
        for s in spaces:
            s["icon"] = SPACE_ICONS.get(s["key"], "folder")
        crumbs = []
        if self._place == "folder":
            crumbs = self._crumbs(self._path)
        self._state = {
            "place": self._place,
            "path": self._path if self._place == "folder" else "",
            "title": self._title(),
            "crumbs": crumbs,
            "canGoBack": bool(self._history),
            "canGoUp": self._place == "folder" and self._path != "/",
            "view": self._view,
            "sort": self._sort,
            "hidden": self._hidden,
            "spaces": spaces,
            "drives": self._drives,
            "home": self.home,
            "note": self._note,
            "renaming": self._renaming,
            "canPaste": self._clip_urls() != [] and self._place == "folder",
            "canWrite": self._place == "folder" and os.access(self._path, os.W_OK),
            "starredHere": self._path in self._starred,
            "pinnedHere": self._path in self._pinned,
            "copier": "kde" if self.kio else "",
            "count": len(self._entries),
        }
        self.stateChanged.emit()

    def _title(self):
        if self._place == "home":
            return "Home"
        if self._place == "recents":
            return "Recents"
        if self._place == "starred":
            return "Starred"
        if self._place == "trash":
            return "Trash"
        if self._path == self.home:
            return "Home folder"
        for d in self._drives:
            if d["mountpoint"] == self._path:
                return d["name"]
        return os.path.basename(self._path) or "This computer"

    def _crumbs(self, path):
        """The folders from the home folder (or the drive, or /) down."""
        roots = [(d["mountpoint"], d["name"]) for d in self._drives if d["mountpoint"]]
        roots.append((self.home, "Home folder"))
        for root, label in roots:
            if commands.in_folder(path, root):
                rest = os.path.relpath(path, root)
                crumbs = [{"label": label, "path": root}]
                at = root
                for part in ([] if rest == "." else rest.split(os.sep)):
                    at = os.path.join(at, part)
                    crumbs.append({"label": part, "path": at})
                return crumbs
        crumbs = [{"label": "This computer", "path": "/"}]
        at = "/"
        for part in [p for p in path.split(os.sep) if p]:
            at = os.path.join(at, part)
            crumbs.append({"label": part, "path": at})
        return crumbs

    # ---- what is in a place ---------------------------------------------------------

    def entry(self, path, info=None, when=None, where=None, trashed=None):
        try:
            st = info or os.stat(path)
        except OSError:
            return None
        name = os.path.basename(path.rstrip("/")) or path
        is_dir = stat.S_ISDIR(st.st_mode)
        if is_dir:
            mime = "inode/directory"
            icon = "folder"
            for key, folder in self.dirs.items():
                if folder == path:
                    icon = SPACE_ICONS.get(key.lower(), "folder")
        else:
            m = self.mimes.mimeTypeForFile(path, QMimeDatabase.MatchExtension)
            mime = m.name()
            icon = m.iconName() or m.genericIconName() or "unknown"
        size = 0 if is_dir else st.st_size
        mtime = when if when is not None else st.st_mtime
        # A launcher is shown by the program's name and picture, as the
        # desktop shows it ("Install Ralden OS", not install-ralden.desktop);
        # renaming it still renames the file.
        label = trashed or name
        if not is_dir and name.endswith(".desktop") and size < 65536:
            known = readers.launcher(read_file(path, 65536), os.environ.get("LANG", ""))
            if known:
                label = known["name"]
                icon = known["icon"] or icon
        return {
            "path": path,
            "url": QUrl.fromLocalFile(path).toString(),
            "name": trashed or name,
            "label": label,
            "isDir": is_dir,
            "mime": mime,
            "icon": icon,
            "kind": "Folder" if is_dir else self.mimes.mimeTypeForName(mime).comment(),
            "size": size,
            "sizeText": "" if is_dir else readers.size_words(size),
            "when": int(mtime),
            "whenText": readers.when_words(mtime),
            "where": where if where is not None else self._where(os.path.dirname(path)),
            "starred": path in self._starred,
            "thumb": (not is_dir and mime in THUMB_TYPES and size < THUMB_BYTES),
            "hidden": name.startswith("."),
        }

    def _where(self, folder):
        """The picture's middle column: the folder something is in, in words."""
        if folder == self.home:
            return "Home folder"
        return os.path.basename(folder) or folder

    def _list_folder(self, path):
        out = []
        try:
            with os.scandir(path) as it:
                for d in it:
                    if not self._hidden and d.name.startswith("."):
                        continue
                    try:
                        st = d.stat()
                    except OSError:
                        continue
                    e = self.entry(d.path, st, where="")
                    if e:
                        out.append(e)
                    if len(out) >= ENTRIES_MOST:
                        self._note = ("This folder has more than %d things in it; the "
                                      "first %d are shown." % (ENTRIES_MOST, ENTRIES_MOST))
                        break
        except OSError as e:
            self._note = "This folder could not be opened: %s." % (e.strerror or "refused")
        return self._sorted(out)

    def _sorted(self, items):
        if self._sort == "date":
            key = lambda e: (not e["isDir"], -e["when"])
        elif self._sort == "size":
            key = lambda e: (not e["isDir"], -e["size"], readers.natural_key(e["name"]))
        else:
            key = lambda e: (not e["isDir"], readers.natural_key(e["name"]))
        return sorted(items, key=key)

    def _recent_entries(self, limit):
        found = []
        for r in readers.recent(read_file(self.recent_file), limit=limit * 2):
            if os.path.isdir(r["path"]):
                continue
            e = self.entry(r["path"], when=r["when"])
            if e:
                found.append(e)
            if len(found) >= limit:
                break
        return found

    def _trash_entries(self):
        out = []
        files = os.path.join(self.trash_dir, "files")
        info = os.path.join(self.trash_dir, "info")
        try:
            names = os.listdir(files)
        except OSError:
            return out
        for name in names:
            meta = readers.trash_info(read_file(os.path.join(info, name + ".trashinfo"), 65536))
            original, when = meta if meta else ("", 0)
            path = os.path.join(files, name)
            try:
                st = os.lstat(path)
            except OSError:
                continue
            e = self.entry(path, st, when=when or st.st_mtime,
                           where=self._where(os.path.dirname(original)) if original else "",
                           trashed=os.path.basename(original) if original else name)
            if e:
                e["original"] = original
                out.append(e)
        return sorted(out, key=lambda e: -e["when"])

    def _default_pinned(self):
        keys = ("DOCUMENTS", "DOWNLOAD", "PICTURES", "MUSIC", "VIDEOS")
        return [self.dirs.get(k) or os.path.join(self.home, label)
                for k, label in zip(keys, ("Documents", "Downloads", "Pictures",
                                           "Music", "Videos"))]

    @Slot()
    def refresh(self):
        for watched in self.watcher.directories():
            self.watcher.removePath(watched)
        if self._place == "home":
            self._entries = [e for e in (self.entry(p) for p in self._pinned
                                         if os.path.isdir(p)) if e]
            self._recent = self._recent_entries(8)
            self.recentChanged.emit()
        elif self._place == "recents":
            self._entries = self._recent_entries(50)
        elif self._place == "starred":
            self._entries = self._sorted([e for e in (self.entry(p) for p in self._starred) if e])
        elif self._place == "trash":
            self._entries = self._trash_entries()
            if os.path.isdir(os.path.join(self.trash_dir, "files")):
                self.watcher.addPath(os.path.join(self.trash_dir, "files"))
        else:
            self._entries = self._list_folder(self._path)
            self.watcher.addPath(self._path)
        self.entriesChanged.emit()
        self._publish()

    # ---- moving about -------------------------------------------------------------------

    def _go(self, place, path=None, remember=True):
        if remember:
            self._history.append((self._place, self._path))
            del self._history[:-50]
        self._place = place
        if path:
            self._path = path
        self._renaming = ""
        # A note is about the place it was said in - except that a stick
        # can come out, which is worth saying until it is read. (Not in
        # refresh(): a copy finishing in the background must not wipe out
        # what went wrong a moment ago.)
        self._note = self._note if self._note.startswith("You can take") else ""
        self.refresh()

    def go(self, where):
        if where in ("home", "recents", "starred", "trash"):
            self._go(where)
        elif isinstance(where, str) and where.startswith("/") and os.path.isdir(where):
            self._go("folder", os.path.normpath(where))
        else:
            self._say("That folder is not there any more.")

    def back(self, _value=None):
        if self._history:
            place, path = self._history.pop()
            self._go(place, path, remember=False)

    def up(self, _value=None):
        if self._place == "folder" and self._path != "/":
            self._go("folder", os.path.dirname(self._path))

    def open(self, path):
        if not isinstance(path, str) or not os.path.lexists(path):
            self._say("That is not there any more.")
            return
        if self._place == "trash" and commands.in_folder(path, self.trash_dir):
            self._say("Restore it first to open it.")
            return
        if os.path.isdir(path):
            self._go("folder", os.path.normpath(path))
        else:
            if not self.runner.launch(commands.open_file(path)):
                self._say("Nothing on this computer opens %s." % os.path.basename(path))

    # ---- changing things ------------------------------------------------------------------

    def _say(self, words):
        self._note = words
        self._publish()

    def noted(self, _value=None):
        self._note = ""
        self._publish()

    def _here(self):
        return self._path if self._place == "folder" else None

    def _shown(self, paths):
        """Of the paths given, the ones this window is showing now."""
        shown = {e["path"] for e in self._entries} | {e["path"] for e in self._recent}
        if not isinstance(paths, (list, tuple)):
            paths = [paths]
        return [p for p in paths if isinstance(p, str) and p in shown]

    def new_folder(self, _value=None):
        here = self._here()
        if not here:
            return
        name = readers.free_name(here, "New folder")
        try:
            os.mkdir(os.path.join(here, name))
        except OSError as e:
            self._say("A folder could not be made here: %s." % (e.strerror or "refused"))
            return
        # The window starts renaming it straight away, as every file
        # manager since the first does.
        self._renaming = os.path.join(here, name)
        self.refresh()

    def rename(self, value):
        if not isinstance(value, dict):
            return
        path, name = value.get("path"), value.get("name")
        self._renaming = ""
        if not self._shown([path]):
            self.refresh()
            return
        name = name.strip() if isinstance(name, str) else ""
        if name == os.path.basename(path):
            self.refresh()
            return
        if not readers.valid_name(name):
            self._say("A name cannot be empty, or have a / in it.")
            return
        target = os.path.join(os.path.dirname(path), name)
        if os.path.lexists(target):
            self._say("Something called %s is already here." % name)
            return
        try:
            os.rename(path, target)
        except OSError as e:
            self._say("It could not be renamed: %s." % (e.strerror or "refused"))
            return
        for store in (self._starred, self._pinned):
            if path in store:
                store[store.index(path)] = target
        self._save_lists()
        self.refresh()

    def trash(self, paths):
        paths = self._shown(paths)
        if not paths or self._place == "trash":
            return
        self.runner.run(commands.trash(paths), lambda c, o: (
            self.refresh() if c == 0 else self._say(
                "It could not be moved to the Trash. %s" % o.strip()[-200:])))

    def _set_clip(self, paths, cut):
        if self.clipboard is None:
            return
        data = QMimeData()
        data.setUrls([QUrl.fromLocalFile(p) for p in paths])
        if cut:
            data.setData(CUT_FORMAT, b"1")
        self.clipboard.setMimeData(data)
        self._publish()

    def _clip_urls(self):
        if self.clipboard is None:
            return []
        data = self.clipboard.mimeData()
        if data is None or not data.hasUrls():
            return []
        return [u.toLocalFile() for u in data.urls() if u.isLocalFile()]

    def copy(self, paths):
        paths = self._shown(paths)
        if paths:
            self._set_clip(paths, False)

    def cut(self, paths):
        paths = self._shown(paths)
        if paths and self._place != "trash":
            self._set_clip(paths, True)

    def paste(self, _value=None):
        here = self._here()
        sources = [p for p in self._clip_urls() if os.path.lexists(p)]
        if not here or not sources:
            return
        data = self.clipboard.mimeData()
        cut = data is not None and bytes(data.data(CUT_FORMAT)) == b"1"
        self._transfer(sources, here, cut)
        if cut:
            self.clipboard.clear()

    def drop(self, value):
        if not isinstance(value, dict):
            return
        folder = value.get("folder") or self._here()
        urls = value.get("urls") or []
        sources = []
        for u in urls:
            url = QUrl(u) if isinstance(u, str) else u
            if isinstance(url, QUrl) and url.isLocalFile() and os.path.lexists(url.toLocalFile()):
                sources.append(url.toLocalFile())
        if not folder or not os.path.isdir(folder) or not sources:
            return
        # Nothing into itself, and nothing onto the folder it is already in.
        sources = [s for s in sources if not commands.in_folder(folder, s)
                   and os.path.dirname(s) != os.path.normpath(folder)]
        if sources:
            self._transfer(sources, folder, bool(value.get("move")))

    def _transfer(self, sources, folder, move):
        folder = os.path.normpath(folder)
        # A folder is never copied into itself (that copy never ends), and
        # what is moved to where it already is stays as it is.
        inside = [s for s in sources if commands.in_folder(folder, s)]
        sources = [s for s in sources if s not in inside
                   and not (move and os.path.dirname(s) == folder)]
        if inside:
            self._say("%s cannot go inside itself." % os.path.basename(inside[0]))
        if not sources:
            return
        if self.kio:
            argv = (commands.move if move else commands.copy)(sources, folder, self.kio)
            # KDE shows the copy's progress and asks about a name already
            # taken; the folder shown refreshes itself as things arrive
            # (the watcher), so nothing here waits for it.
            if not self.runner.launch(argv):
                self._say("The copy could not be started.")
            return
        # No KDE file layer on this machine: Python's own, without the
        # question KDE asks about a name already taken - so a name already
        # taken is given a free one instead.
        for s in sources:
            target = os.path.join(folder, readers.free_name(folder, os.path.basename(s)))
            try:
                if move:
                    shutil.move(s, target)
                elif os.path.isdir(s) and not os.path.islink(s):
                    shutil.copytree(s, target, symlinks=True)
                else:
                    shutil.copy2(s, target)
            except OSError as e:
                self._say("%s could not be %s: %s." % (os.path.basename(s),
                                                       "moved" if move else "copied",
                                                       e.strerror or "refused"))
                break
        self.refresh()

    def star(self, paths):
        paths = self._shown(paths) or ([self._path] if paths == self._path else [])
        if not paths:
            return
        on = not all(p in self._starred for p in paths)
        for p in paths:
            if on and p not in self._starred:
                self._starred.append(p)
            elif not on and p in self._starred:
                self._starred.remove(p)
        self._save_lists()
        self.refresh()

    def pin(self, path):
        if not isinstance(path, str) or not os.path.isdir(path):
            return
        if path in self._pinned:
            self._pinned.remove(path)
        else:
            self._pinned.append(path)
        self._save_lists()
        self.refresh()

    def set_view(self, mode):
        if mode in ("grid", "list"):
            self._view = mode
            self._save_settings()
            self._publish()

    def set_sort(self, key):
        if key in ("name", "date", "size"):
            self._sort = key
            self._save_settings()
            self.refresh()

    def set_hidden(self, on):
        self._hidden = bool(on)
        self._save_settings()
        self.refresh()

    # ---- the Trash ------------------------------------------------------------------------

    def restore(self, paths):
        if self._place != "trash":
            return
        paths = self._shown(paths)
        back = 0
        for p in paths:
            e = next((x for x in self._entries if x["path"] == p), None)
            original = e.get("original") if e else ""
            if not original:
                continue
            if os.path.lexists(original):
                self._say("%s is already back where it was; this one was left in the "
                          "Trash." % os.path.basename(original))
                continue
            try:
                os.makedirs(os.path.dirname(original), exist_ok=True)
                shutil.move(p, original)
                os.unlink(os.path.join(self.trash_dir, "info",
                                       os.path.basename(p) + ".trashinfo"))
                back += 1
            except OSError as e2:
                self._say("It could not be put back: %s." % (e2.strerror or "refused"))
                break
        self.refresh()

    def empty_trash(self, _value=None):
        self.runner.run(commands.EMPTY_TRASH, lambda c, o: self.refresh())

    # ---- drives plugged in -------------------------------------------------------------------

    @Slot()
    def read_drives(self):
        self.runner.run(commands.READ_DRIVES, self._got_drives, seconds=10)

    def _got_drives(self, code, out):
        found = readers.drives(out) if code == 0 else []
        for d in found:
            d["name"] = d["label"] or ("%s drive" % readers.size_words(d["size"])
                                       if d["size"] else "Drive")
            d["sizeText"] = readers.size_words(d["size"])
        if found != self._drives:
            gone = self._place == "folder" and any(
                d["mountpoint"] and commands.in_folder(self._path, d["mountpoint"])
                for d in self._drives) and not any(
                d["mountpoint"] and commands.in_folder(self._path, d["mountpoint"])
                for d in found)
            self._drives = found
            if gone:
                self._go("home", remember=False)
            else:
                self._publish()

    def _drive(self, device):
        return next((d for d in self._drives if d["device"] == device), None)

    def mount(self, device):
        d = self._drive(device)
        if not d:
            return
        if d["mountpoint"]:
            self._go("folder", d["mountpoint"])
            return

        def done(code, out):
            m = re.search(r" at (/.+?)\.?\s*$", out.strip())
            if code == 0 and m and os.path.isdir(m.group(1)):
                self._go("folder", m.group(1))
            else:
                self._say("The drive could not be opened. %s" % out.strip()[-200:])
            self.read_drives()
        self.runner.run(commands.mount(device), done, seconds=60)

    def eject(self, device):
        d = self._drive(device)
        if not d:
            return
        if self._place == "folder" and d["mountpoint"] and commands.in_folder(
                self._path, d["mountpoint"]):
            self._go("home", remember=False)

        def off(code, out):
            if code == 0:
                self._say("You can take out the %s now." % d["name"])
            else:
                self._say("It is safe to take the drive out now.")
            self.read_drives()

        def unmounted(code, out):
            if code != 0 and d["mountpoint"]:
                self._say("The drive is still in use - close anything with its files "
                          "open, and try again.")
                self.read_drives()
                return
            self.runner.run(commands.power_off(d["disk"]), off, seconds=30)
        if d["mountpoint"]:
            self.runner.run(commands.unmount(device), unmounted, seconds=60)
        else:
            unmounted(0, "")

    # ---- the rare jobs -------------------------------------------------------------------------

    def dolphin(self, path):
        path = path if isinstance(path, str) and os.path.isdir(path) else self._here() or self.home
        self.runner.launch(commands.dolphin(path))

    def terminal(self, path):
        path = path if isinstance(path, str) and os.path.isdir(path) else self._here() or self.home
        self.runner.launch(commands.terminal(path))

    # ---- the window's verbs --------------------------------------------------------------------

    @Slot(str, "QVariant")
    def act(self, verb, value=None):
        name = self.ACTS.get(verb)
        if name is not None:
            getattr(self, name)(readers.plain(value))

    # ---- kept between runs -----------------------------------------------------------------------

    def _load(self, name, default):
        try:
            with open(os.path.join(self.store, name)) as f:
                return json.load(f)
        except (OSError, ValueError):
            return default

    def _save(self, name, value):
        try:
            os.makedirs(self.store, exist_ok=True)
            fresh = os.path.join(self.store, name + ".new")
            with open(fresh, "w") as f:
                json.dump(value, f, indent=1)
            os.replace(fresh, os.path.join(self.store, name))
        except OSError:
            pass

    def _save_lists(self):
        self._save("starred.json", self._starred)
        self._save("pinned.json", self._pinned)

    def _save_settings(self):
        self._save("settings.json", {"view": self._view, "sort": self._sort,
                                     "hidden": self._hidden})

