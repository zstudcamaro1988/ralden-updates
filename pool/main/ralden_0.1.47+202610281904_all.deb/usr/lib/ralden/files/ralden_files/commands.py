# SPDX-License-Identifier: Ralden-Source
#
# Ralden OS - Files: what is run to do something
#
# Every program Files runs is one of these: a list, run directly, never a
# line handed to a shell. A file's name - which can be anything at all,
# "$(reboot)" included - goes in as one argument and stays one. Written here
# once so tests/test_files.py can say exactly what each button runs.
#
# Copying and moving are KDE's own (kioclient): its progress is the one in
# Plasma's notifications, and a name that is already taken gets KDE's own
# question - replace, skip or rename - rather than one of ours.

import os
import shutil

READ_DRIVES = ["lsblk", "-J", "-b", "-o",
               "NAME,PATH,TYPE,RM,HOTPLUG,TRAN,SIZE,LABEL,FSTYPE,MOUNTPOINT"]


def kioclient(which=shutil.which):
    """KDE's file layer on the command line, by whichever name it has."""
    for name in ("kioclient", "kioclient6", "kioclient5"):
        path = which(name)
        if path:
            return path
    return None


def _paths(paths):
    paths = [p for p in paths if isinstance(p, str) and p.startswith("/")]
    if not paths:
        raise ValueError("no paths")
    return paths


def copy(sources, folder, kio):
    return [kio, "copy"] + _paths(sources) + [_paths([folder])[0]]


def move(sources, folder, kio):
    return [kio, "move"] + _paths(sources) + [_paths([folder])[0]]


def open_file(path):
    # xdg-open on Plasma is kde-open: the program the person chose for this
    # kind of file (mimeapps.list), as everywhere else on the desktop.
    return ["xdg-open", _paths([path])[0]]


def trash(paths):
    # The freedesktop trash in the home folder, which is Plasma's own: what
    # goes in from here comes out of Dolphin's, and the other way round.
    return ["gio", "trash", "--"] + _paths(paths)


EMPTY_TRASH = ["gio", "trash", "--empty"]


def mount(device):
    return ["udisksctl", "mount", "--no-user-interaction", "-b", _paths([device])[0]]


def unmount(device):
    return ["udisksctl", "unmount", "--no-user-interaction", "-b", _paths([device])[0]]


def power_off(disk):
    return ["udisksctl", "power-off", "--no-user-interaction", "-b", _paths([disk])[0]]


def dolphin(path):
    return ["dolphin", "--new-window", _paths([path])[0]]


def terminal(path):
    return ["konsole", "--workdir", _paths([path])[0]]


def in_folder(path, folder):
    """Is `path` inside `folder` (or `folder` itself)?"""
    path, folder = os.path.realpath(path), os.path.realpath(folder)
    return path == folder or path.startswith(folder.rstrip("/") + "/")
