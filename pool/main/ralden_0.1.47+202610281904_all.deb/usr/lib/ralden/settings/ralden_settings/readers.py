# SPDX-License-Identifier: Ralden-Source
#
# Ralden OS - Settings: reading what the machine says
#
# Every page of Settings shows what the machine reports, and this is where
# what it reports is read. Each function takes the text a program printed
# (or a file held) and returns plain Python values - no Qt here, so that
# every one of them is tested where the tree is written, against what the
# programs were seen to print on the test machine (tests/test_settings.py).
#
# THE RULE THE WHOLE PROGRAM KEEPS: an answer that cannot be read is
# "not known", never a guess. A page with nothing known says so; it does not
# draw a slider at fifty per cent for hardware that is not there.

import datetime as _datetime
import json
import os as _os
import re
import unicodedata as _unicodedata

# ---- small things -----------------------------------------------------------


def human_bytes(n):
    """4015464 kB of memory -> "3.8 GB". Decimal, as disks are sold."""
    try:
        n = float(n)
    except (TypeError, ValueError):
        return ""
    if n < 0:
        return ""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1000 or unit == "TB":
            if unit in ("B", "KB"):
                return "%d %s" % (round(n), unit)
            return ("%.1f %s" % (n, unit)).replace(".0 ", " ")
        n /= 1000.0
    return ""


def memory_size(n):
    """Memory is sold in binary sizes: 4015464 kB -> "4 GB"."""
    try:
        gib = float(n) / (1024 ** 3)
    except (TypeError, ValueError):
        return ""
    if gib <= 0:
        return ""
    # The kernel keeps a little for itself, so 3.83 GiB of 4 GiB is "4 GB".
    for size in (0.5, 1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256):
        if gib <= size and gib >= size * 0.88:
            return ("%g GB" % size)
    return "%.1f GB" % gib


def percent(text):
    """ "40%" -> 40, or None."""
    m = re.search(r"(-?\d+(?:\.\d+)?)\s*%", text or "")
    if not m:
        return None
    return max(0, min(150, int(round(float(m.group(1))))))


# ---- sound (pactl -f json) -------------------------------------------------------
#
# Read off the test machine, 14 October 2026: `pactl -f json list sinks` is a
# list of objects with "name", "description", "mute", "volume" (a map of
# channels, each with "value_percent"), "properties" and "ports"; sources
# include each output's ".monitor", which is not a microphone; `pactl -f json
# info` names the default sink and source.


def _devices(text, monitors=False):
    try:
        data = json.loads(text or "[]")
    except ValueError:
        return []
    if not isinstance(data, list):
        return []
    found = []
    for d in data:
        if not isinstance(d, dict) or not isinstance(d.get("name"), str):
            continue
        props = d.get("properties") if isinstance(d.get("properties"), dict) else {}
        if not monitors and (props.get("device.class") == "monitor"
                             or d["name"].endswith(".monitor")):
            continue
        volumes = []
        vol = d.get("volume")
        if isinstance(vol, dict):
            for channel in vol.values():
                if isinstance(channel, dict):
                    p = percent(str(channel.get("value_percent", "")))
                    if p is not None:
                        volumes.append(p)
        description = d.get("description") if isinstance(d.get("description"), str) else ""
        found.append({
            "name": d["name"],
            "label": description or props.get("device.description") or d["name"],
            "muted": d.get("mute") is True,
            "volume": round(sum(volumes) / len(volumes)) if volumes else None,
            "icon": props.get("device.icon_name", ""),
        })
    return found


def sinks(text):
    return _devices(text)


def sources(text):
    return _devices(text)


def defaults(text):
    """ (default sink name, default source name) from `pactl -f json info`."""
    try:
        data = json.loads(text or "{}")
    except ValueError:
        return "", ""
    if not isinstance(data, dict):
        return "", ""
    sink = data.get("default_sink_name")
    source = data.get("default_source_name")
    return (sink if isinstance(sink, str) else "",
            source if isinstance(source, str) else "")


# ---- the screen (kscreen-doctor -j) -----------------------------------------------
#
# Read off the test machine: {"outputs": [{"id": 70, "connected": true,
# "enabled": true, "currentModeId": "78", "modes": [{"id": "100",
# "refreshRate": 59.78, "size": {"width": 1366, "height": 768}}, ...], ...}]}

ROTATIONS = {1: "none", 2: "left", 4: "inverted", 8: "right"}


def screens(text):
    try:
        data = json.loads(text or "{}")
    except ValueError:
        return []
    outputs = data.get("outputs") if isinstance(data, dict) else None
    if not isinstance(outputs, list):
        return []
    found = []
    for o in outputs:
        if not isinstance(o, dict) or o.get("connected") is not True:
            continue
        modes = []
        for m in o.get("modes") or []:
            if not isinstance(m, dict):
                continue
            size = m.get("size") if isinstance(m.get("size"), dict) else {}
            w, h = size.get("width"), size.get("height")
            rate = m.get("refreshRate")
            if not (isinstance(w, int) and isinstance(h, int) and w > 0 and h > 0):
                continue
            modes.append({"id": str(m.get("id")), "width": w, "height": h,
                          "rate": float(rate) if isinstance(rate, (int, float)) else 0.0})
        name = o.get("name") if isinstance(o.get("name"), str) else str(o.get("id"))
        found.append({
            "id": o.get("id"),
            "name": name,
            "enabled": o.get("enabled") is True,
            "current": str(o.get("currentModeId", "")),
            "modes": modes,
            "scale": o.get("scale") if isinstance(o.get("scale"), (int, float)) else 1,
            "rotation": ROTATIONS.get(o.get("rotation"), "none"),
            "primary": o.get("priority") == 1,
            "preferred": [str(x) for x in (o.get("preferredModes") or [])
                          if isinstance(x, (str, int))],
        })
    return found


def resolutions(screen):
    """Each size the screen can show, once, largest first, with the best
    refresh rate for it - the mode to ask for when that size is chosen."""
    best = {}
    for m in screen.get("modes", []):
        key = (m["width"], m["height"])
        if key not in best or m["rate"] > best[key]["rate"]:
            best[key] = m
    return sorted(best.values(), key=lambda m: (m["width"] * m["height"], m["width"]),
                  reverse=True)


def current_mode(screen):
    for m in screen.get("modes", []):
        if m["id"] == screen.get("current"):
            return m
    return None


def aspect(w, h):
    """ (16, 10) for 1280x800; None for an odd one."""
    known = {(16, 9): 16 / 9, (16, 10): 16 / 10, (4, 3): 4 / 3, (5, 4): 5 / 4,
             (21, 9): 64 / 27, (3, 2): 3 / 2}
    r = w / float(h)
    for name, value in known.items():
        if abs(r - value) < 0.02:
            return name
    return None


# ---- the backlight (brightnessctl -m -c backlight) ---------------------------------
#
# "intel_backlight,backlight,4882,51%,9600" - device, class, value, percent,
# maximum. The Control Center reads the same thing the same way.


def backlight(text):
    for line in (text or "").splitlines():
        parts = line.strip().split(",")
        if len(parts) >= 5 and parts[1] == "backlight":
            p = percent(parts[3])
            if p is not None:
                return {"device": parts[0], "percent": p}
    return None


# ---- the battery (/sys/class/power_supply) ----------------------------------------


def battery(entries):
    """entries: {name: {"type": ..., "capacity": ..., "status": ...,
    "scope": ...}} as read from /sys/class/power_supply. A mouse's or a
    phone's battery is not the computer's: scope "Device" is left out."""
    for name in sorted(entries):
        e = entries[name]
        if (e.get("type") or "").strip() != "Battery":
            continue
        if (e.get("scope") or "").strip() == "Device":
            continue
        try:
            capacity = int((e.get("capacity") or "").strip())
        except ValueError:
            continue
        status = (e.get("status") or "").strip()
        return {"percent": max(0, min(100, capacity)), "status": status,
                "charging": status == "Charging",
                "full": status == "Full"}
    return None


def on_mains(entries):
    """True when a mains supply says it is online; None when there is none."""
    seen = False
    for e in entries.values():
        if (e.get("type") or "").strip() == "Mains":
            seen = True
            if (e.get("online") or "").strip() == "1":
                return True
    return False if seen else None


# ---- about this computer ----------------------------------------------------------


def os_release(text):
    found = {}
    for line in (text or "").splitlines():
        m = re.match(r'^([A-Z_]+)=(.*)$', line.strip())
        if m:
            value = m.group(2).strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                value = value[1:-1]
            found[m.group(1)] = value
    return found


def processor(text):
    """ ("AMD Ryzen 5 3600 6-Core Processor", 4) from /proc/cpuinfo."""
    name, count = "", 0
    for line in (text or "").splitlines():
        if line.startswith("processor"):
            count += 1
        elif line.startswith("model name") and not name:
            name = line.split(":", 1)[1].strip()
    name = re.sub(r"\(R\)|\(TM\)|\(tm\)|\(r\)", "", name)
    name = re.sub(r"\s+CPU\b", "", name)
    return " ".join(name.split()), count


def memory(text):
    """Bytes of memory from /proc/meminfo, or None."""
    m = re.search(r"^MemTotal:\s+(\d+)\s*kB", text or "", re.M)
    return int(m.group(1)) * 1024 if m else None


def graphics(text):
    """The display controllers in `lspci -mm`, by vendor and name."""
    found = []
    for line in (text or "").splitlines():
        fields = re.findall(r'"([^"]*)"', line)
        if len(fields) >= 3 and re.search(r"VGA|3D|Display", fields[0]):
            vendor = fields[1].replace(" Corporation", "").replace(", Inc.", "") \
                .replace(" Inc.", "").replace("Advanced Micro Devices, Inc. ", "AMD ")
            found.append(("%s %s" % (vendor, fields[2])).strip())
    return found


def hostname(text):
    """ {"name", "pretty", "chassis", "vendor", "model"} from
    `hostnamectl --json=short`."""
    try:
        data = json.loads(text or "{}")
    except ValueError:
        return {}
    if not isinstance(data, dict):
        return {}

    def s(key):
        v = data.get(key)
        return v if isinstance(v, str) else ""
    return {"name": s("StaticHostname") or s("Hostname"), "pretty": s("PrettyHostname"),
            "chassis": s("Chassis"), "vendor": s("HardwareVendor"),
            "model": s("HardwareModel"), "kernel": s("KernelRelease")}


HOSTNAME_RE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\Z")


def valid_hostname(name):
    """What a computer may be called on a network: lowercase letters, digits
    and hyphens, not starting or ending with a hyphen, at most 63."""
    return isinstance(name, str) and bool(HOSTNAME_RE.match(name))


def plasma_version(text):
    m = re.search(r"plasmashell\s+(\d+(?:\.\d+)+)", text or "")
    return m.group(1) if m else ""


def disk(total, free):
    """ "25.8 GB, 18.2 GB free" """
    if not total:
        return ""
    if free is None:
        return human_bytes(total)
    return "%s, %s free" % (human_bytes(total), human_bytes(free))


# ---- power profiles (powerprofilesctl list) ------------------------------------------
#
#     performance:
#       CpuDriver:      amd_pstate
#       PlatformDriver: placeholder
#     * balanced:
#     ...
# The daemon's "placeholder" driver remembers a choice and changes nothing.
# A machine where every driver is that one has no power modes to offer.

PROFILE_NAMES = ("power-saver", "balanced", "performance")


def profiles(text):
    """ (names, current, real) """
    names, current, drivers = [], "", []
    for line in (text or "").splitlines():
        m = re.match(r"^\s*(\*?)\s*([a-z-]+):\s*$", line)
        if m and m.group(2) in PROFILE_NAMES:
            names.append(m.group(2))
            if m.group(1):
                current = m.group(2)
            continue
        d = re.match(r"^\s*(?:Cpu|Platform)?Driver:\s*(\S+)", line)
        if d:
            drivers.append(d.group(1))
    real = any(v != "placeholder" for v in drivers)
    return names, current, real


# ---- KWin's workspaces ------------------------------------------------------------

def desktops(text):
    """busctl --json=short get-property ... desktops: KWin's workspaces, in
    order, as [{"id", "name"}]. [] when it is not that."""
    try:
        data = json.loads(text)
    except ValueError:
        return []
    rows = data.get("data") if isinstance(data, dict) else None
    if not isinstance(rows, list):
        return []
    found = []
    for row in rows:
        if (isinstance(row, list) and len(row) == 3 and isinstance(row[0], int)
                and isinstance(row[1], str) and isinstance(row[2], str) and row[1]):
            found.append((row[0], row[1], row[2]))
    return [{"id": i, "name": n} for _, i, n in sorted(found)]


def config_bool(text, default):
    """What kreadconfig6 printed for a yes-or-no setting."""
    word = text.strip().lower()
    if word in ("true", "1", "yes", "on"):
        return True
    if word in ("false", "0", "no", "off"):
        return False
    return default


def config_int(text, default):
    try:
        return int(text.strip())
    except ValueError:
        return default


# ---- the keyboard ---------------------------------------------------------------------

XKB_RULES = "/usr/share/X11/xkb/rules/evdev.xml"
LAYOUT_RE = re.compile(r"^[a-z][a-z0-9_-]{0,31}(\([a-zA-Z0-9_-]{1,48}\))?$")


def layout_key(layout, variant=""):
    """"us", or "de(nodeadkeys)": the one word Settings names a layout by."""
    return "%s(%s)" % (layout, variant) if variant else layout


def split_layout_key(key):
    """("de", "nodeadkeys") for "de(nodeadkeys)"; None for anything that is
    not a layout's name."""
    if not isinstance(key, str) or not LAYOUT_RE.match(key):
        return None
    if "(" in key:
        layout, variant = key[:-1].split("(", 1)
        return layout, variant
    return key, ""


def xkb_layouts(text):
    """Every layout and variant in the X keyboard database (evdev.xml), as
    [{"key", "label"}], layouts by name with each one's variants after it."""
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return []
    found = []
    for layout in root.iter("layout"):
        item = layout.find("configItem")
        if item is None:
            continue
        name = (item.findtext("name") or "").strip()
        label = (item.findtext("description") or "").strip()
        if not name or not label or not LAYOUT_RE.match(name):
            continue
        if name == "custom":
            # "A user-defined custom Layout": a name for a file a person
            # writes by hand, empty until they do.
            continue
        entry = [{"key": name, "label": label}]
        for variant in layout.iter("variant"):
            vitem = variant.find("configItem")
            if vitem is None:
                continue
            vname = (vitem.findtext("name") or "").strip()
            vlabel = (vitem.findtext("description") or "").strip()
            key = layout_key(name, vname)
            if vname and vlabel and LAYOUT_RE.match(key):
                entry.append({"key": key, "label": vlabel})
        found.append(entry)
    found.sort(key=lambda e: e[0]["label"].lower())
    return [x for entry in found for x in entry]


def config_list(text):
    """A KConfig list as kreadconfig6 prints it: "us,de" -> ["us", "de"]."""
    return [x.strip() for x in text.strip().split(",")] if text.strip() else []


def xkb_query(text):
    """What `setxkbmap -query` printed: {"model": [...], "layout": [...],
    "variant": [...], "options": [...]}."""
    out = {"model": [], "layout": [], "variant": [], "options": []}
    for line in text.splitlines():
        if ":" not in line:
            continue
        name, value = line.split(":", 1)
        name = name.strip()
        if name in out:
            out[name] = [x.strip() for x in value.strip().split(",")]
    return out


# ---- what points --------------------------------------------------------------------

TOUCHPAD_WORDS = re.compile(r"touch ?pad|synaptics|alps|elan|glidepoint|trackpad|cyapa", re.I)


def input_devices(text):
    """/proc/bus/input/devices, as [{"name", "kind"}] for whatever moves the
    pointer: "touchpad" or "mouse". A tablet - which is what a virtual
    machine's pointer is - is neither, and is left out."""
    found = []
    for block in text.split("\n\n"):
        name, handlers, bits = "", "", {}
        for line in block.splitlines():
            if line.startswith("N: Name="):
                name = line[len("N: Name="):].strip().strip('"')
            elif line.startswith("H: Handlers="):
                handlers = line[len("H: Handlers="):]
            elif line.startswith("B: ") and "=" in line:
                k, v = line[3:].split("=", 1)
                bits[k.strip()] = v.strip()
        if not re.search(r"\bmouse\d+\b", handlers):
            continue
        try:
            prop = int(bits.get("PROP", "0").split()[-1] or "0", 16)
        except ValueError:
            prop = 0
        try:
            rel = int(bits.get("REL", "0").split()[-1] or "0", 16)
        except ValueError:
            rel = 0
        if "ABS" in bits and (prop & 1 or TOUCHPAD_WORDS.search(name)):
            found.append({"name": name, "kind": "touchpad"})
        elif rel & 3 == 3:
            # Moves by so much left and right, up and down (REL_X, REL_Y):
            # a mouse, a trackball, a TrackPoint. A tablet's wheel alone is not.
            found.append({"name": name, "kind": "mouse"})
    return found


# ---- global shortcuts -------------------------------------------------------------------

def shortcut_actions(text):
    """What /usr/lib/ralden/settings/global-shortcuts list printed, as
    [{"component", "componentName", "action", "name", "keys", "defaults"}]
    with each "keys" a list of key presses (numbers) - the first shortcut
    of each, which is the one Plasma shows. Actions with no name are
    Plasma's own bookkeeping and are left out."""
    try:
        data = json.loads(text)
    except ValueError:
        return []
    out = []
    for a in data if isinstance(data, list) else []:
        if not isinstance(a, dict):
            continue
        fields = [a.get(k) for k in ("component", "componentName", "action", "name")]
        if not all(isinstance(f, str) for f in fields) or not fields[0] or not fields[2]:
            continue
        if not fields[3].strip() or fields[2].startswith("_k_"):
            continue

        def first(v):
            if isinstance(v, list) and v and isinstance(v[0], list):
                return [k for k in v[0] if isinstance(k, int) and k > 0]
            return []
        out.append({"component": fields[0], "componentName": fields[1] or fields[0],
                    "action": fields[2], "name": fields[3].strip(),
                    "keys": first(a.get("keys")), "defaults": first(a.get("defaults"))})
    return out


def plain(value):
    """What the window sent, as Python's own.

    A list or an object written in QML - `[path]`, `{"path": p, "name":
    n}` - reaches a slot declared to take a QVariant as a QJSValue, which
    is neither a list nor a dict until it is asked to be (seen on the test
    machine, 20 October 2026: Files' Copy, Rename and Move to Trash, and
    Settings' new shortcut key, were each handed one, and did nothing).
    Strings, numbers and true/false arrive as themselves."""
    if hasattr(value, "toVariant"):
        value = value.toVariant()
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value


# ---- the clock: timedated, and the time zone tables -----------------------------
#
# `timedatectl show` prints one name=value a line (systemd's own names):
# Timezone, LocalRTC, CanNTP, NTP, NTPSynchronized, TimeUSec... Only the
# first five are read; the time itself is worked out here from the zone,
# so it is the time in the zone the machine says, at this moment.


ZONEINFO = _os.environ.get("RALDEN_ZONEINFO", "/usr/share/zoneinfo")
ZONE_RE = re.compile(r"^[A-Za-z0-9_+-]+(/[A-Za-z0-9_+-]+){0,2}\Z")
# What the clock says on a computer nobody has told where it is: the world's
# time, which every image is built with (the First Start's own list).
NO_ZONE = ("UTC", "Etc/UTC", "Etc/UCT", "Etc/Universal", "Etc/Zulu",
           "Etc/GMT", "Universal", "Zulu", "UCT", "GMT")
ZONES_SHOWN = 60

DAY_NAMES = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
             "Saturday", "Sunday")
MONTH_NAMES = ("January", "February", "March", "April", "May", "June", "July",
               "August", "September", "October", "November", "December")


def timedate(text):
    """`timedatectl show` -> {"zone", "canAuto", "auto", "synced", "localRtc"}.

    None when it says nothing a clock is made of (no Timezone line).
    """
    values = {}
    for line in (text or "").splitlines():
        name, sep, value = line.partition("=")
        if sep:
            values[name.strip()] = value.strip()
    if "Timezone" not in values:
        return None

    def yes(name):
        return values.get(name, "").lower() in ("yes", "true", "1")
    return {"zone": values["Timezone"], "canAuto": yes("CanNTP"),
            "auto": yes("NTP"), "synced": yes("NTPSynchronized"),
            "localRtc": yes("LocalRTC")}


def known_zone(zone, zoneinfo=None):
    """`zone` if it is the name of a time zone this system has, else None.

    The same test as the First Start's: a name of the right shape, with a
    file of that name under /usr/share/zoneinfo. Nothing else is handed to
    timedatectl.
    """
    if not isinstance(zone, str) or not ZONE_RE.match(zone):
        return None
    if not _os.path.isfile(_os.path.join(zoneinfo or ZONEINFO, zone)):
        return None
    return zone


def fold(text):
    """Text as a search compares it: no capitals, no accents, no _ or /."""
    plain_text = _unicodedata.normalize("NFKD", text or "")
    plain_text = "".join(ch for ch in plain_text if not _unicodedata.combining(ch))
    return " ".join(plain_text.replace("_", " ").replace("/", " ").casefold().split())


def time_zones(zoneinfo=None):
    """Every place the clock can be set to, in the order of their names.

    The First Start's list (ralden-first-start's read_zones), read the same
    way from the same two tables: zone1970.tab (the countries a zone is used
    in, its name, a few words for countries with more than one) and
    iso3166.tab (what the countries' letters stand for). Each is
    {"key", "city", "where", "find"}. No tables, no list.
    """
    zoneinfo = zoneinfo or ZONEINFO
    countries = {}
    try:
        with open(_os.path.join(zoneinfo, "iso3166.tab"),
                  encoding="utf-8", errors="replace") as f:
            for line in f:
                if line.startswith("#") or "\t" not in line:
                    continue
                code, name = line.rstrip("\n").split("\t")[:2]
                countries[code] = name
    except OSError:
        pass
    try:
        with open(_os.path.join(zoneinfo, "zone1970.tab"),
                  encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError:
        return []
    zones = []
    for line in lines:
        if line.startswith("#"):
            continue
        parts = line.rstrip("\n").split("\t")
        if len(parts) < 3:
            continue
        key = known_zone(parts[2], zoneinfo)
        if not key:
            continue
        city = key.rsplit("/", 1)[-1].replace("_", " ")
        names = [countries.get(code, code) for code in parts[0].split(",")]
        where = names[0] if names else ""
        note = parts[3].strip() if len(parts) > 3 else ""
        if note:
            where = "%s · %s" % (where, note) if where else note
        zones.append({"key": key, "city": city, "where": where,
                      "find": fold(" ".join([key, city, " ".join(names), note]))})
    zones.sort(key=lambda z: (fold(z["city"]), z["key"]))
    return zones


def find_zones(zones, query, limit=ZONES_SHOWN):
    """The places a search finds: every word typed has to be in the place,
    and places whose city starts with it come first ("lon": London before
    Ceylon). Nothing typed finds everything, up to `limit`."""
    words = fold(query).split()
    first, rest = [], []
    for z in zones:
        if all(w in z["find"] for w in words):
            if words and fold(z["city"]).startswith(words[0]):
                first.append(z)
            else:
                rest.append(z)
    return (first + rest)[:limit]


def _zone(zone, zoneinfo=None):
    import zoneinfo as zones
    if zoneinfo:
        with open(_os.path.join(zoneinfo, zone), "rb") as f:
            return zones.ZoneInfo.from_file(f, key=zone)
    return zones.ZoneInfo(zone)


def _moment(zone, now=None, zoneinfo=None):
    """`now` (or this moment) as the clock in `zone` says it, or None."""
    try:
        tz = _zone(zone, zoneinfo)
        moment = now or _datetime.datetime.now(_datetime.timezone.utc)
        return moment.astimezone(tz)
    except Exception:
        return None


def clock_text(moment):
    """7:05 PM. Twelve hours, as every clock on Ralden's screen says it."""
    hour = moment.hour % 12 or 12
    return "%d:%02d %s" % (hour, moment.minute, "AM" if moment.hour < 12 else "PM")


def zone_now(zone, now=None, zoneinfo=None):
    """{"words": "Tuesday, October 20, 7:05 PM", "date": "2026-10-20",
    "time": "7:05 PM"} in `zone`, or None when it cannot be worked out.

    Day and month names written here, not by strftime: Qt sets the C
    library's locale to the person's, and the names would then be in a
    language the rest of the page is not.
    """
    moment = _moment(zone, now, zoneinfo)
    if moment is None:
        return None
    return {"words": "%s, %s %d, %s" % (DAY_NAMES[moment.weekday()],
                                        MONTH_NAMES[moment.month - 1],
                                        moment.day, clock_text(moment)),
            "date": "%04d-%02d-%02d" % (moment.year, moment.month, moment.day),
            "time": clock_text(moment)}


def zone_offset(zone, now=None, zoneinfo=None):
    """How far the clock in `zone` is from the world's: "UTC−5", "UTC+5:30",
    "UTC". "" when it cannot be worked out."""
    moment = _moment(zone, now, zoneinfo)
    if moment is None or moment.utcoffset() is None:
        return ""
    minutes = int(moment.utcoffset().total_seconds() // 60)
    if minutes == 0:
        return "UTC"
    hours, rest = divmod(abs(minutes), 60)
    return "UTC%s%d%s" % ("+" if minutes > 0 else "−", hours,
                          ":%02d" % rest if rest else "")


def zone_place(zones, zone):
    """(city, where) for the zone the clock is in. The world's own time (what
    every image is built with) is "Coordinated Universal Time"; a zone the
    tables do not list is called by its own name, which is still true."""
    if zone in NO_ZONE:
        return ("Coordinated Universal Time", "The world's own time, not a place's")
    for z in zones:
        if z["key"] == zone:
            return (z["city"], z["where"])
    if not zone:
        return ("", "")
    return (zone.rsplit("/", 1)[-1].replace("_", " "), zone)


TIME_RE = re.compile(r"^\s*(\d{1,2})(?:[:.](\d{2}))?\s*([AaPp]\.?\s*[Mm]\.?)?\s*$")
DATE_RE = re.compile(r"^\s*(\d{4})-(\d{1,2})-(\d{1,2})\s*$")


def manual_time(date_text, time_text):
    """"2026-10-20" and "7:05 PM" (or "19:05", or "7 pm") -> what
    `timedatectl set-time` takes, "2026-10-20 19:05:00"; None for anything
    that is not a real date and time."""
    d = DATE_RE.match(date_text or "")
    t = TIME_RE.match(time_text or "")
    if not d or not t:
        return None
    year, month, day = (int(x) for x in d.groups())
    hour, minute = int(t.group(1)), int(t.group(2) or 0)
    half = (t.group(3) or "").lower()
    if half:
        if not 1 <= hour <= 12:
            return None
        hour = hour % 12 + (12 if half.startswith("p") else 0)
    try:
        moment = _datetime.datetime(year, month, day, hour, minute)
    except ValueError:
        return None
    if not 2000 <= moment.year <= 2099:
        return None
    return moment.strftime("%Y-%m-%d %H:%M:%S")


def timedate_failure(out, what):
    """What to say when timedatectl would not change something. `what` is
    "The time zone" or "The time"; `out` is what it printed."""
    text = (out or "").strip()
    lowered = text.lower()
    if "automatic time synchronization is enabled" in lowered \
            or "ntp is enabled" in lowered:
        return ("%s was not changed: the clock is setting itself. Turn off "
                "Set the time automatically first." % what)
    if ("access denied" in lowered or "authentication" in lowered
            or "not authorized" in lowered or "permission denied" in lowered):
        return ("%s was not changed. Changing it needs the password of an "
                "administrator of this computer." % what)
    last = text.splitlines()[-1].strip() if text else ""
    if ":" in last:
        last = last.split(":", 1)[1].strip()
    if last:
        return "%s was not changed: %s" % (what, last.rstrip(".") + ".")
    return "%s was not changed." % what


# ---- the network: NetworkManager, through nmcli ----------------------------------
#
# `nmcli -t` prints one record a line, its fields split by ":", and a ":" or
# a "\" inside a field written "\:" and "\\" - a Wi-Fi network's name can be
# anything at all, colons included.

def nm_fields(line):
    """One line of `nmcli -t` -> its fields, the escapes undone."""
    out, cur, i = [], [], 0
    while i < len(line):
        ch = line[i]
        if ch == "\\" and i + 1 < len(line):
            cur.append(line[i + 1])
            i += 2
            continue
        if ch == ":":
            out.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
        i += 1
    out.append("".join(cur))
    return out


def nm_devices(text):
    """`nmcli -t -f DEVICE,TYPE,STATE,CONNECTION device` -> the network
    devices a person has: Wi-Fi and wired, not the loopback or a bridge."""
    out = []
    for line in (text or "").splitlines():
        f = nm_fields(line)
        if len(f) < 4 or f[1] not in ("wifi", "ethernet"):
            continue
        state = f[2].split(" ", 1)[0]
        out.append({"device": f[0], "type": f[1], "state": state,
                    "connection": f[3] if f[3] != "--" else ""})
    return out


def signal_words(signal):
    """How strong, in words a person uses, from nmcli's 0-100."""
    if signal >= 70:
        return "Strong signal"
    if signal >= 45:
        return "Good signal"
    if signal >= 25:
        return "Weak signal"
    return "Very weak signal"


def nm_security(security):
    """nmcli's SECURITY ("WPA1 WPA2", "WPA3", "WEP", "WPA2 802.1X", "") ->
    how Settings joins it: "open", "psk" (a password, WPA or WPA2), "sae"
    (a password, WPA3 only), or "" for what it does not offer yet (WEP,
    which is broken, and 802.1X, which wants a name as well)."""
    words = (security or "").replace("--", "").split()
    if not words:
        return "open"
    if "802.1X" in words or "WEP" in words:
        return ""
    if any(w in ("WPA1", "WPA2", "WPA") for w in words):
        return "psk"
    if "WPA3" in words or "OWE" in words:
        return "sae" if "WPA3" in words else "open"
    return ""


def nm_wifi(text):
    """`nmcli -t -f IN-USE,SSID,SECURITY,SIGNAL device wifi list` -> one
    entry a network name (a house's two access points are one network): its
    strongest signal, and in use if either is. The one in use first, then by
    strength. Networks that hide their name are left out: there is nothing
    to show for them."""
    nets = {}
    for line in (text or "").splitlines():
        f = nm_fields(line)
        if len(f) < 4 or not f[1]:
            continue
        try:
            signal = max(0, min(100, int(f[3])))
        except ValueError:
            signal = 0
        security = f[2] if f[2] != "--" else ""
        net = nets.setdefault(f[1], {"ssid": f[1], "security": security,
                                     "join": nm_security(security),
                                     "signal": -1, "active": False})
        if signal > net["signal"]:
            net.update(signal=signal, security=security, join=nm_security(security))
        net["active"] = net["active"] or f[0].strip() == "*"
    out = list(nets.values())
    out.sort(key=lambda n: (not n["active"], -n["signal"], n["ssid"].casefold()))
    return out


def nm_saved(text):
    """`nmcli -t -f NAME,TYPE connection show` -> the names of the Wi-Fi
    networks this computer remembers (NetworkManager names a connection after
    its network when it makes one)."""
    out = []
    for line in (text or "").splitlines():
        f = nm_fields(line)
        if len(f) >= 2 and f[1] in ("802-11-wireless", "wifi"):
            out.append(f[0])
    return out


def nm_address(text):
    """`nmcli -t -f IP4.ADDRESS device show DEV` -> "10.0.2.15", or ""."""
    for line in (text or "").splitlines():
        f = nm_fields(line)
        if len(f) >= 2 and f[0].startswith("IP4.ADDRESS") and f[1]:
            return f[1].split("/", 1)[0]
    return ""


def nm_radio(text):
    """`nmcli -t -f WIFI-HW,WIFI radio` -> (the computer's own switch on,
    NetworkManager's on).

    The switch is off only when it says "disabled". With no Wi-Fi at all it
    says "missing" (seen on the test machine, 21 October 2026), which is
    not a switch turned off."""
    f = nm_fields((text or "").strip())
    if len(f) < 2:
        return (False, False)
    return (f[0] != "disabled", f[1] == "enabled")


def wired_words(state):
    """What a wired connection's state is, in words."""
    return {"connected": "Connected",
            "connecting": "Connecting…",
            "disconnected": "Not connected",
            "unavailable": "No cable plugged in",
            "unmanaged": "Not looked after by NetworkManager"}.get(state, state.capitalize())


JOIN_OUTCOMES = {
    "joined": "",
    "wrong-password": "That is not the password for %s.",
    "not-a-password": "A Wi-Fi password is 8 to 63 characters.",
    "refused": "This account may not add a Wi-Fi network; an administrator of this computer can.",
    "no-wifi": "This computer has no Wi-Fi.",
}


def join_outcome(out, ssid):
    """What wifi-join printed -> what the page says ("" when it joined)."""
    line = (out or "").strip().splitlines()
    first = line[-1].strip() if line else ""
    word, _, rest = first.partition(" ")
    if word in JOIN_OUTCOMES:
        said = JOIN_OUTCOMES[word]
        return said % ssid if "%s" in said else said
    if word == "failed" and rest:
        return "%s was not joined: %s." % (ssid, rest.rstrip("."))
    return "%s was not joined." % ssid


def nm_failure(out, failed):
    """What to say when nmcli would not do something. `failed` is the
    sentence so far ("HomeNet was not joined"); nmcli's reason finishes it."""
    text = (out or "").strip()
    lowered = text.lower()
    if ("not authorized" in lowered or "permission denied" in lowered
            or "insufficient privileges" in lowered or "access denied" in lowered):
        return ("%s. That needs the password of an administrator of this "
                "computer." % failed)
    last = text.splitlines()[-1].strip() if text else ""
    if last.lower().startswith("error:"):
        last = last[6:].strip()
    if last:
        return "%s: %s" % (failed, last.rstrip(".") + ".")
    return failed + "."


# ---- Personalization: the wallpaper ---------------------------------------------------
#
# The desktop's picture is in Plasma's own file for the desktop
# (plasma-org.kde.plasma.desktop-appletsrc), in the first containment's
# [Wallpaper][org.kde.image][General] Image. Read from the file, not asked
# of plasmashell: evaluateScript hands back a script's errors and never its
# answer (ralden-selftest found that out three times).

RALDEN_WALLPAPER = "/usr/share/wallpapers/Ralden"
PICTURE_KINDS = (".jpg", ".jpeg", ".png", ".webp")
PICTURES_SHOWN = 23
USER_DIR_RE = re.compile(r'^XDG_([A-Z]+)_DIR="(.*)"\s*$')
WALLPAPER_GROUP_RE = re.compile(r"^\[Containments\]\[\d+\]\[Wallpaper\]\[org\.kde\.image\]\[General\]$")


def user_dirs(text, home):
    """{"PICTURES": "/home/buu/Pictures", ...} out of user-dirs.dirs - the
    same reading as Files'. A folder that is just $HOME means "not set"."""
    out = {}
    for line in (text or "").splitlines():
        m = USER_DIR_RE.match(line.strip())
        if not m:
            continue
        value = m.group(2)
        if value.startswith("$HOME"):
            value = home + value[len("$HOME"):]
        elif not value.startswith("/"):
            continue
        value = _os.path.normpath(value)
        if value != _os.path.normpath(home):
            out[m.group(1)] = value
    return out


def picture_path(value):
    """An Image= value ("file:///home/buu/Pictures/a%20b.jpg", or a plain
    path, or a wallpaper package's folder) -> a plain path."""
    from urllib.parse import unquote
    value = (value or "").strip()
    if value.startswith("file://"):
        value = unquote(value[len("file://"):])
    return value.rstrip("/") if len(value) > 1 else value


def desktop_wallpaper(text):
    """The picture of the first desktop in plasma-org.kde.plasma.desktop-
    appletsrc, as a plain path; "" when it does not say."""
    group = None
    for line in (text or "").splitlines():
        line = line.strip()
        if line.startswith("["):
            group = line
        elif group and WALLPAPER_GROUP_RE.match(group) and line.startswith("Image="):
            return picture_path(line[len("Image="):])
    return ""


def wallpaper_preview(path):
    """What to draw for a choice: a picture is itself; Ralden's own is a
    folder of sizes (a wallpaper package), drawn by its largest."""
    if _os.path.isdir(path):
        images = _os.path.join(path, "contents", "images")
        def width(name):
            m = re.match(r"(\d+)", name)
            return int(m.group(1)) if m else 0
        try:
            sizes = sorted((f for f in _os.listdir(images)
                            if f.lower().endswith(PICTURE_KINDS)), key=width)
        except OSError:
            sizes = []
        return _os.path.join(images, sizes[-1]) if sizes else ""
    return path


def pictures(folder, limit=PICTURES_SHOWN):
    """The pictures in `folder` and the folders directly in it, newest
    first: [{"path", "name"}]. Hidden files and folders are left alone."""
    found = []

    def look(where, deeper):
        try:
            entries = list(_os.scandir(where))
        except OSError:
            return
        for e in entries:
            if e.name.startswith("."):
                continue
            try:
                if e.is_dir(follow_symlinks=False):
                    if deeper:
                        look(e.path, False)
                elif e.is_file() and e.name.lower().endswith(PICTURE_KINDS):
                    info = e.stat()
                    if info.st_size > 0:
                        found.append((info.st_mtime, e.path))
            except OSError:
                continue
    if folder:
        look(folder, True)
    found.sort(key=lambda item: (-item[0], item[1]))
    return [{"path": p, "name": _os.path.splitext(_os.path.basename(p))[0]}
            for _, p in found[:limit]]


def wallpaper_choices(current, found):
    """Ralden's own first, then the person's pictures; the one on the
    desktop marked. The one on the desktop is among them even when it is
    from somewhere else, so that it is never shown as not chosen."""
    choices = [{"path": RALDEN_WALLPAPER, "name": "Alpine Mist",
                "preview": wallpaper_preview(RALDEN_WALLPAPER)}]
    seen = {RALDEN_WALLPAPER}
    for p in found:
        if p["path"] not in seen:
            choices.append({"path": p["path"], "name": p["name"], "preview": p["path"]})
            seen.add(p["path"])
    if current and current not in seen:
        choices.insert(1, {"path": current,
                           "name": _os.path.splitext(_os.path.basename(current))[0],
                           "preview": wallpaper_preview(current)})
    from urllib.parse import quote
    for c in choices:
        c["chosen"] = c["path"] == current
        # As a URL the page can hand to an Image: a name with a space, a #
        # or a ? in it is still the file it names.
        c["url"] = "file://" + quote(c["preview"]) if c["preview"] else ""
    return choices


# ---- Apps: the programs, and which opens what -----------------------------------------
#
# The programs are the desktop's own list of them: the .desktop files in
# /usr/share/applications and ~/.local/share/applications. Which opens a
# kind of file is the freedesktop.org rule every desktop follows: the first
# [Default Applications] entry, in ~/.config/mimeapps.list, then
# /etc/xdg/mimeapps.list (Ralden's own choices), then the system's lists,
# that names a program this computer has.

APP_KINDS = (
    # (key, what a person calls it, the kind asked about, every kind set)
    ("browser", "Web browser", "x-scheme-handler/https",
     ("x-scheme-handler/http", "x-scheme-handler/https", "text/html",
      "application/xhtml+xml")),
    ("email", "Email", "x-scheme-handler/mailto", ("x-scheme-handler/mailto",)),
    ("folders", "Folders", "inode/directory", ("inode/directory",)),
    ("music", "Music", "audio/mpeg",
     ("audio/mpeg", "audio/flac", "audio/ogg", "audio/x-vorbis+ogg", "audio/mp4",
      "audio/x-wav")),
    ("videos", "Videos", "video/mp4",
     ("video/mp4", "video/x-matroska", "video/webm", "video/quicktime",
      "video/x-msvideo")),
    ("pictures", "Pictures", "image/jpeg",
     ("image/jpeg", "image/png", "image/gif", "image/webp", "image/bmp")),
    ("text", "Text", "text/plain", ("text/plain",)),
    ("pdf", "PDF documents", "application/pdf", ("application/pdf",)),
)
APP_KIND_KEYS = {k[0]: k for k in APP_KINDS}


def desktop_entry(text):
    """The [Desktop Entry] of a .desktop file -> {"name", "type", "mime",
    "icon", "hidden"}; None when it has no such group."""
    group, values = None, {}
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("["):
            if group == "[Desktop Entry]":
                break
            group = line
            continue
        if group != "[Desktop Entry]" or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values.setdefault(key.strip(), value.strip())
    if group is None and not values:
        return None
    if "Name" not in values:
        return None

    def yes(key):
        return values.get(key, "").lower() == "true"
    return {"name": values["Name"], "type": values.get("Type", ""),
            "mime": [m for m in values.get("MimeType", "").split(";") if m],
            "icon": values.get("Icon", ""),
            "hidden": yes("NoDisplay") or yes("Hidden")}


def desktop_entries(dirs):
    """{desktop file id: entry with its "path"} for every program in `dirs`,
    the first directory winning (the person's own over the system's). An id
    is the file's path under the directory with "/" written "-", as the
    specification says."""
    found = {}
    for top in dirs:
        for where, _subdirs, files in _os.walk(top):
            rel = _os.path.relpath(where, top)
            if rel != "." and rel.count(_os.sep) >= 1:
                continue                      # one level down is enough
            for name in files:
                if not name.endswith(".desktop"):
                    continue
                ident = name if rel == "." else rel.replace(_os.sep, "-") + "-" + name
                if ident in found:
                    continue
                path = _os.path.join(where, name)
                try:
                    with open(path, encoding="utf-8", errors="replace") as f:
                        entry = desktop_entry(f.read(65536))
                except OSError:
                    continue
                if entry and entry["type"] == "Application":
                    entry["path"] = path
                    found[ident] = entry
    return found


def mimeapps_defaults(text):
    """{kind: [desktop file ids]} out of a mimeapps.list's [Default Applications]."""
    group, out = None, {}
    for line in (text or "").splitlines():
        line = line.strip()
        if line.startswith("["):
            group = line
            continue
        if group == "[Default Applications]" and "=" in line and not line.startswith("#"):
            kind, value = line.split("=", 1)
            out[kind.strip()] = [v.strip() for v in value.split(";") if v.strip()]
    return out


def default_program(kind, lists, entries):
    """The program that opens `kind`: the first id in the first list that
    names one this computer has. "" when no list chooses one."""
    for text in lists:
        for ident in mimeapps_defaults(text).get(kind, []):
            if ident in entries:
                return ident
    return ""


def programs_for(entries, kind):
    """[{"key", "label"}] - the programs that say they open `kind`, by name."""
    out = [{"key": ident, "label": e["name"]} for ident, e in entries.items()
           if kind in e["mime"] and not e["hidden"]]
    out.sort(key=lambda p: (p["label"].casefold(), p["key"]))
    return out


def app_kinds(entries, lists):
    """Every kind of file the Apps page offers a choice for, with what opens
    it now and what could."""
    out = []
    for key, label, kind, _all in APP_KINDS:
        options = programs_for(entries, kind)
        current = default_program(kind, lists, entries)
        if current and current not in [o["key"] for o in options]:
            # Chosen but not shown in menus (NoDisplay): still the one that
            # opens it, so still in the list.
            options.insert(0, {"key": current, "label": entries[current]["name"]})
        out.append({"key": key, "label": label, "current": current,
                    "currentLabel": entries[current]["name"] if current else "",
                    "options": options})
    return out


def installed_programs(entries):
    """[{"key", "label", "icon"}] - the programs a menu would show, by name."""
    out = [{"key": ident, "label": e["name"], "icon": e["icon"]}
           for ident, e in entries.items() if not e["hidden"]]
    out.sort(key=lambda p: (p["label"].casefold(), p["key"]))
    return out


# ---- Updates ----------------------------------------------------------------------------
#
# What is waiting is apt's own answer from the lists it last fetched (`apt
# list --upgradable`, which any account may ask); when it last fetched them
# is the stamp apt's daily job leaves on success. Installing is Discover's:
# it asks for the password, shows the progress, and says when a restart is
# wanted - all things this page would only do worse.

UPDATE_STAMP = "/var/lib/apt/periodic/update-success-stamp"
PK_SECONDS_RE = re.compile(r"\(uint32 (\d+),?\)")
PK_NEVER = 2 ** 32 - 1


def pk_seconds(text):
    """gdbus's answer to PackageKit's GetTimeSinceAction -> seconds, or None
    when it has never done it (PackageKit answers G_MAXUINT) or did not
    answer."""
    m = PK_SECONDS_RE.search(text or "")
    if not m:
        return None
    seconds = int(m.group(1))
    return None if seconds >= PK_NEVER else seconds


def last_looked(stamp, pk_seconds_ago, now):
    """When the lists were last fetched: the newer of apt's daily stamp
    and PackageKit's last refresh (Discover's), either of which may be
    None."""
    import datetime
    pk = now - datetime.timedelta(seconds=pk_seconds_ago) if pk_seconds_ago is not None else None
    known = [t for t in (stamp, pk) if t is not None]
    return max(known) if known else None
UPGRADABLE_RE = re.compile(
    r"^(?P<name>[A-Za-z0-9.+-]+)/(?P<suite>\S+)\s+(?P<version>\S+)\s+\S+"
    r"(?:\s+\[upgradable from: (?P<old>[^\]]+)\])?")


def apt_upgradable(text):
    """`apt list --upgradable` -> [{"name", "version", "old", "security"}],
    by name. "Listing..." and apt's warning about its own interface are not
    packages."""
    out = []
    for line in (text or "").splitlines():
        m = UPGRADABLE_RE.match(line.strip())
        if not m:
            continue
        out.append({"name": m.group("name"), "version": m.group("version"),
                    "old": m.group("old") or "",
                    "security": "security" in m.group("suite")})
    out.sort(key=lambda p: p["name"])
    return out


def apt_periodic(text):
    """`apt-config dump APT::Periodic` -> {"Unattended-Upgrade": "1", ...}."""
    out = {}
    for line in (text or "").splitlines():
        m = re.match(r'^APT::Periodic::([A-Za-z-]+)\s+"([^"]*)";', line.strip())
        if m:
            out[m.group(1)] = m.group(2)
    return out


# Ralden's own parts: the package ralden, and where its updates come
# from (/etc/apt/sources.list.d/ralden.sources, which the installer
# writes; the disc has none). Its version is VERSION and the build's time,
# 0.1.39+202610220350 (tools/prepare-packages.py).

RALDEN_SOURCES = "/etc/apt/sources.list.d/ralden.sources"
APT_LISTS = "/var/lib/apt/lists"
RALDEN_VERSION_RE = re.compile(r"^(\d+\.\d+\.\d+)\+(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})$")


def ralden_version(text, local=None):
    """dpkg-query's answer -> {"version": "0.1.39", "built": date or None};
    None when ralden is not installed.

    The time in the version is the build's, in UTC (tools/prepare-packages.py);
    the date shown is this computer's for that moment. Shown as the UTC date,
    build 40 - made on the evening of 26 October in Texas - said "Built
    October 27" (seen on the test machine). `local` turns a UTC datetime into
    this computer's time; by default the system's own zone."""
    text = (text or "").strip()
    if not text:
        return None
    m = RALDEN_VERSION_RE.match(text)
    if not m:
        return {"version": text, "built": None}
    y, mo, d, h, mi = (int(m.group(i)) for i in range(2, 7))
    try:
        when = _datetime.datetime(y, mo, d, h, mi, tzinfo=_datetime.timezone.utc)
    except ValueError:
        return {"version": m.group(1), "built": None}
    local = local or (lambda t: t.astimezone())
    return {"version": m.group(1), "built": local(when).date()}


def ralden_address(text):
    """The URIs of ralden.sources, or "" when there is no such file or no
    URIs in it."""
    for line in (text or "").splitlines():
        line = line.strip()
        if line.lower().startswith("uris:"):
            return line.split(":", 1)[1].strip()
    return ""


def apt_list_name(address):
    """The start of the name apt gives the files it keeps from an address:
    http://10.0.2.2:8640/ -> 10.0.2.2:8640_ (its scheme gone, every / a _)."""
    rest = re.sub(r"^[a-z]+://", "", address.strip()).rstrip("/")
    return rest.replace("/", "_") + "_"


def when_words(moment, now):
    """A moment as a person says it, beside now: "today at 6:12 AM",
    "yesterday at 9:40 PM", "on October 18". Both are local datetimes."""
    if moment is None:
        return ""
    days = (now.date() - moment.date()).days
    if days == 0:
        return "today at " + clock_text(moment)
    if days == 1:
        return "yesterday at " + clock_text(moment)
    if moment.year == now.year:
        return "on %s %d" % (MONTH_NAMES[moment.month - 1], moment.day)
    return "on %s %d, %d" % (MONTH_NAMES[moment.month - 1], moment.day, moment.year)


# ---- Bluetooth -----------------------------------------------------------------------
#
# What /usr/lib/ralden/settings/bluetooth prints: BlueZ's own objects as
# JSON for `show` and `scan`, one word (and BlueZ's reason) for the rest.

DEVICE_KINDS = (
    ("audio-headset", "Headphones"), ("audio-headphones", "Headphones"),
    ("audio-card", "Speaker"), ("input-keyboard", "Keyboard"),
    ("input-mouse", "Mouse"), ("input-gaming", "Game controller"),
    ("input-tablet", "Drawing tablet"), ("phone", "Phone"),
    ("computer", "Computer"), ("printer", "Printer"), ("camera", "Camera"),
)


def device_kind(icon):
    """BlueZ's icon name for a device -> what a person calls it."""
    for prefix, words in DEVICE_KINDS:
        if (icon or "").startswith(prefix):
            return words
    return "Bluetooth device"


def bluetooth_state(text):
    """`bluetooth show` -> {"adapter", "powered", "name", "devices"}; None
    when it is not that."""
    try:
        data = json.loads(text or "")
    except ValueError:
        return None
    if not isinstance(data, dict) or "adapter" not in data:
        return None
    devices = []
    for d in data.get("devices") or []:
        if not isinstance(d, dict) or not d.get("address"):
            continue
        devices.append({"address": str(d["address"]), "name": str(d.get("name") or d["address"]),
                        "named": bool(d.get("named")), "kind": device_kind(d.get("icon", "")),
                        "paired": bool(d.get("paired")), "connected": bool(d.get("connected"))})
    return {"adapter": bool(data.get("adapter")), "powered": bool(data.get("powered")),
            "name": str(data.get("name") or ""), "devices": devices}


def bluetooth_outcome(out, failed):
    """What the helper printed -> "" when it was done, else the sentence:
    `failed` ("Headphones were not paired") and BlueZ's reason."""
    lines = (out or "").strip().splitlines()
    word, _, rest = (lines[-1].strip() if lines else "").partition(" ")
    if word == "done":
        return ""
    if word == "no-adapter":
        return "This computer has no Bluetooth."
    if word == "not-found":
        return "%s: the device is no longer in range." % failed
    reason = rest.strip().rstrip(".")
    if "AuthenticationFailed" in reason or "Authentication Failed" in reason:
        reason = "the code was not confirmed on both, or was wrong"
    elif "AuthenticationCanceled" in reason or "Canceled" in reason:
        reason = "it was cancelled"
    return "%s: %s." % (failed, reason) if reason else failed + "."


# ---- Accounts --------------------------------------------------------------------------
#
# AccountsService (org.freedesktop.Accounts), read and changed through
# busctl --json=short, which prints each answer as {"type": ..., "data": ...}
# - one a line when several properties are asked for at once.

ACCOUNT_PROPS = ("UserName", "RealName", "AccountType", "IconFile", "SystemAccount", "Uid",
                 "HomeDirectory")


def busctl_values(text):
    """Every "data" in what busctl --json=short printed, in order."""
    out = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if isinstance(value, dict) and "data" in value:
            out.append(value["data"])
    return out


def busctl_path(text):
    """The object path a FindUserByName answers with, or ""."""
    values = busctl_values(text)
    if values and isinstance(values[0], list) and values[0]:
        value = values[0][0]
    elif values and isinstance(values[0], str):
        value = values[0]
    else:
        return ""
    return value if isinstance(value, str) and value.startswith("/org/freedesktop/Accounts/") else ""


def busctl_paths(text):
    """The object paths ListCachedUsers answers with."""
    values = busctl_values(text)
    if not values:
        return []
    first = values[0]
    if isinstance(first, list) and first and isinstance(first[0], list):
        first = first[0]
    return [p for p in first if isinstance(p, str) and p.startswith("/org/freedesktop/Accounts/")] \
        if isinstance(first, list) else []


def account(text):
    """The properties of one account (ACCOUNT_PROPS, in that order) ->
    {"login", "name", "admin", "picture", "system", "uid", "home"}; None when
    they are not all there."""
    values = busctl_values(text)
    if len(values) < len(ACCOUNT_PROPS):
        return None
    login, name, kind, picture, system, uid, home = values[:7]
    if not isinstance(login, str) or not login:
        return None
    return {"login": login, "name": name if isinstance(name, str) else "",
            "admin": kind == 1, "picture": picture if isinstance(picture, str) else "",
            "system": bool(system), "uid": uid if isinstance(uid, int) else -1,
            "home": home if isinstance(home, str) else ""}


def signed_in(text):
    """`loginctl list-users --no-legend` -> the logins signed in now."""
    found = set()
    for line in (text or "").splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0].isdigit():
            found.add(parts[1])
    return found


def suggest_login(name, reserved=()):
    """A username out of a person's name: "Ana María López" -> "ana". The
    First Start's own rule (ralden-first-start; a test holds the two
    equal): the first word, accents folded, only a-z and 0-9."""
    words = (name or "").strip().split()
    if not words:
        return ""
    folded = _unicodedata.normalize("NFKD", words[0])
    plain = "".join(ch for ch in folded if not _unicodedata.combining(ch))
    login = re.sub(r"[^a-z0-9]", "", plain.lower())
    login = login.lstrip("0123456789")[:31]
    if login in reserved:
        login += "1"
    return login


def people_outcome(out, failed):
    """What Settings' people helper printed -> what the page says ("" when
    it was done). `failed` begins the sentence: "Ana was not added"."""
    lines = (out or "").strip().splitlines()
    word, _, rest = (lines[-1].strip() if lines else "").partition(" ")
    rest = rest.strip()
    if word in ("added", "removed"):
        return ""
    if word == "not-allowed":
        return ("%s. Adding or removing someone needs the password of an administrator "
                "of this computer." % failed)
    if word == "refused" and rest:
        return rest
    if word == "failed" and rest:
        return "%s. %s" % (failed, rest)
    return "%s: Settings' helper did not answer." % failed


NAME_RE = re.compile(r"^[^\x00-\x1f:,=]{1,64}$")


def valid_real_name(name):
    """A name for a person, as /etc/passwd can hold it: no colons or
    commas (they separate its fields), nothing unprintable, 64 at most."""
    if not isinstance(name, str):
        return None
    name = " ".join(name.split())
    return name if NAME_RE.match(name) else None


PASSWORD_OUTCOMES = {
    "changed": "",
    "wrong-password": "That is not your current password.",
}


def password_outcome(out):
    """What account-password printed -> what the page says ("" when it
    changed)."""
    lines = (out or "").strip().splitlines()
    word, _, rest = (lines[-1].strip() if lines else "").partition(" ")
    if word in PASSWORD_OUTCOMES:
        return PASSWORD_OUTCOMES[word]
    rest = rest.strip()
    if rest.upper().startswith("BAD PASSWORD:"):
        rest = rest[len("BAD PASSWORD:"):].strip()
    if word == "refused":
        return "That new password was not accepted%s" % (": " + rest.rstrip(".") + "." if rest else ".")
    return "The password was not changed%s" % (": " + rest.rstrip(".") + "." if rest else ".")
