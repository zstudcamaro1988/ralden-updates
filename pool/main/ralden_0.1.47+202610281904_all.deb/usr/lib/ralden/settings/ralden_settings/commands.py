# SPDX-License-Identifier: Ralden-Source
#
# Ralden OS - Settings: what is run to change something
#
# Every change Settings makes is one of these: a program and its arguments,
# as a list, run directly - never a line handed to a shell. A name that
# came from the machine (a sound device, a screen) goes in as one argument
# and cannot become a second command, whatever it contains. Each is written
# here once, so that tests/test_settings.py can say exactly what each
# control runs, and the self-test can run the same thing.
#
# No Qt here either; areas.py runs these.

NIGHT_LIGHT = "/usr/lib/ralden/night-light"

# ---- reading ----------------------------------------------------------------
READ_SINKS = ["pactl", "-f", "json", "list", "sinks"]
READ_SOURCES = ["pactl", "-f", "json", "list", "sources"]
READ_SOUND_DEFAULTS = ["pactl", "-f", "json", "info"]
READ_SCREENS = ["kscreen-doctor", "-j"]
READ_BACKLIGHT = ["brightnessctl", "-m", "-c", "backlight"]
READ_NIGHT = [NIGHT_LIGHT, "show"]
READ_HOST = ["hostnamectl", "--json=short"]
READ_GRAPHICS = ["lspci", "-mm"]
READ_PLASMA = ["plasmashell", "--version"]
READ_DISKS = ["lsblk", "-J", "-b", "-d", "-o", "NAME,SIZE,TYPE,MODEL,RM"]
READ_PROFILE = ["powerprofilesctl", "get"]
READ_PROFILES = ["powerprofilesctl", "list"]


# ---- Plasma's own settings files ------------------------------------------------
#
# Read through kreadconfig6 and written through kwriteconfig6, never by
# parsing the files here: a setting can come from the person's own file,
# from Plasma's look-and-feel defaults (~/.config/kdedefaults) or from the
# image's (/etc/xdg), and KConfig is the one thing that knows which wins.

def read_config(name, group, key, default):
    return ["kreadconfig6", "--file", name, "--group", group, "--key", key,
            "--default", default]


def write_config(name, group, key, value, kind=None):
    argv = ["kwriteconfig6", "--file", name, "--group", group, "--key", key]
    if kind:
        argv += ["--type", kind]
    return argv + [value]


# ---- KWin ----------------------------------------------------------------------------

# Asks KWin to read kwinrc again: what kwinrc says takes effect at once.
KWIN_RECONFIGURE = ["busctl", "--user", "call", "org.kde.KWin", "/KWin",
                    "org.kde.KWin", "reconfigure"]

VDM = ["org.kde.KWin", "/VirtualDesktopManager", "org.kde.KWin.VirtualDesktopManager"]
READ_DESKTOPS = ["busctl", "--user", "--json=short", "get-property"] + VDM + ["desktops"]


def add_desktop(position):
    # An empty name is KWin's own "Desktop N".
    return ["busctl", "--user", "call"] + VDM + ["createDesktop", "us", str(int(position)), ""]


def remove_desktop(desktop_id):
    return ["busctl", "--user", "call"] + VDM + ["removeDesktop", "s", desktop_id]


# The overview, as its own shortcut opens it.
SHOW_OVERVIEW = ["busctl", "--user", "call", "org.kde.kglobalaccel", "/component/kwin",
                 "org.kde.kglobalaccel.Component", "invokeShortcut", "s", "Overview"]


# ---- the screen ---------------------------------------------------------------

def set_brightness(value):
    # Never to nothing: a screen turned fully off by a slider is a machine a
    # person cannot find the slider on again. The Control Center keeps the
    # same floor.
    return ["brightnessctl", "-c", "backlight", "set", "%d%%" % max(3, min(100, int(value)))]


def set_night(warmth, adaptive):
    return [NIGHT_LIGHT, "set", str(max(0, min(100, int(warmth)))), "1" if adaptive else "0"]


def set_mode(output, mode_id):
    return ["kscreen-doctor", "output.%s.mode.%s" % (output, mode_id)]


ROTATION_WORDS = ("none", "left", "inverted", "right")


def set_rotation(output, rotation):
    if rotation not in ROTATION_WORDS:
        raise ValueError(rotation)
    return ["kscreen-doctor", "output.%s.rotation.%s" % (output, rotation)]


# ---- sound ----------------------------------------------------------------------

def set_default_sink(name):
    return ["pactl", "set-default-sink", name]


def set_default_source(name):
    return ["pactl", "set-default-source", name]


def set_sink_volume(value):
    return ["pactl", "set-sink-volume", "@DEFAULT_SINK@", "%d%%" % max(0, min(100, int(value)))]


def set_source_volume(value):
    return ["pactl", "set-source-volume", "@DEFAULT_SOURCE@", "%d%%" % max(0, min(100, int(value)))]


def set_sink_mute(muted):
    return ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1" if muted else "0"]


def set_source_mute(muted):
    return ["pactl", "set-source-mute", "@DEFAULT_SOURCE@", "1" if muted else "0"]


# ---- about ------------------------------------------------------------------------

def set_hostname(name):
    # hostnamectl asks systemd-hostnamed, which asks polkit whether this
    # person may: an administrator is asked for their own password.
    return ["hostnamectl", "set-hostname", name]


# ---- power --------------------------------------------------------------------------

PROFILES = ("power-saver", "balanced", "performance")


def set_profile(name):
    if name not in PROFILES:
        raise ValueError(name)
    return ["powerprofilesctl", "set", name]


# ---- the keyboard ---------------------------------------------------------------------

READ_XKB = ["setxkbmap", "-query"]


def set_repeat(on):
    return ["xset", "r", "on" if on else "off"]


def set_repeat_rate(delay, rate):
    # xset takes the delay in milliseconds and the rate in presses a second.
    return ["xset", "r", "rate", str(max(100, min(1000, int(delay)))),
            str(max(1, min(100, int(rate))))]


def set_layouts(keys):
    """setxkbmap for the layouts named, in order: what changes the keyboard
    now, while kxkbrc is what Plasma sets it to next time."""
    from . import readers
    pairs = [readers.split_layout_key(k) for k in keys]
    if not pairs or any(p is None for p in pairs):
        raise ValueError(keys)
    return ["setxkbmap", "-layout", ",".join(p[0] for p in pairs),
            "-variant", ",".join(p[1] for p in pairs)]


# Tells Plasma's keyboard service (kded's keyboard module) to read kxkbrc
# again: its layout list, and the shortcut that switches between them.
KEYBOARD_RELOAD = ["gdbus", "emit", "--session", "--object-path", "/Layouts",
                   "--signal", "org.kde.keyboard.reloadConfig"]


# ---- global shortcuts -------------------------------------------------------------------

SHORTCUTS = "/usr/lib/ralden/settings/global-shortcuts"
READ_SHORTCUTS = [SHORTCUTS, "list"]


def set_shortcut(component, action, component_name, action_name, key=None):
    argv = [SHORTCUTS, "set", component, action, component_name, action_name]
    if key is not None:
        if int(key) <= 0:
            raise ValueError(key)
        argv.append(str(int(key)))
    return argv


# ---- what points ---------------------------------------------------------------------

INPUT_DEVICES = "/proc/bus/input/devices"


# ---- the clock -------------------------------------------------------------------------
#
# systemd's timedated, through timedatectl, as live-zone and the First Start
# do. A change it needs an administrator for, it asks for itself: timedated
# asks polkit, and polkit asks the person through Plasma's own password
# window. So these are run with time to type a password in (areas.py).

READ_TIMEDATE = ["timedatectl", "show"]


def set_auto_time(on):
    return ["timedatectl", "set-ntp", "true" if on else "false"]


def set_time_zone(zone):
    # A name the tables list and the system has a file for (readers.known_zone);
    # one argument, whatever it is.
    return ["timedatectl", "set-timezone", zone]


def set_time(moment):
    # "2026-10-20 19:05:00", from readers.manual_time.
    return ["timedatectl", "set-time", moment]


# ---- the network -------------------------------------------------------------------------
#
# NetworkManager, through nmcli, as the Control Center's tiles read it; and
# a network with a password through wifi-join, which hands the password to
# NetworkManager over D-Bus so that it is never on a command line.

WIFI_JOIN = "/usr/lib/ralden/settings/wifi-join"

READ_NET_DEVICES = ["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device"]
# WIFI-HW is the switch or key on the computer itself; WIFI is NetworkManager's.
READ_WIFI_RADIO = ["nmcli", "-t", "-f", "WIFI-HW,WIFI", "radio"]
READ_SAVED_NETWORKS = ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"]
# "auto": looked for again when the last look is more than half a minute old.
READ_NETWORKS = ["nmcli", "-t", "-f", "IN-USE,SSID,SECURITY,SIGNAL", "device",
                 "wifi", "list", "--rescan", "auto"]


def read_address(device):
    return ["nmcli", "-t", "-f", "IP4.ADDRESS", "device", "show", device]


def set_wifi_radio(on):
    return ["nmcli", "radio", "wifi", "on" if on else "off"]


def join_open(ssid):
    return ["nmcli", "device", "wifi", "connect", ssid]


def join_saved(name):
    return ["nmcli", "connection", "up", "id", name]


def join_secured(ssid, kind):
    # The password goes on wifi-join's standard input (areas.py), not here.
    if kind not in ("psk", "sae"):
        raise ValueError(kind)
    return [WIFI_JOIN, ssid, kind]


def disconnect_device(device):
    return ["nmcli", "device", "disconnect", device]


def forget_network(name):
    return ["nmcli", "connection", "delete", "id", name]

# Plasma's own window for what the Network page does not do yet.
MORE_NETWORK_SETTINGS = ["kcmshell6", "kcm_networkmanagement"]


# ---- Personalization ------------------------------------------------------------------
#
# The desktop's picture with Plasma's own tool for it; the lock screen's in
# its own file, which the locker reads each time it locks. The login screen
# is drawn before anybody has signed in, from a picture only an
# administrator may change: Settings leaves it alone, and says so.

def set_wallpaper(path):
    # A picture, or a wallpaper package's folder (Ralden's own).
    return ["plasma-apply-wallpaperimage", path]


LOCK_GROUPS = ["--file", "kscreenlockerrc", "--group", "Greeter"]
LOCK_PLUGIN = ["kwriteconfig6"] + LOCK_GROUPS + ["--key", "WallpaperPlugin", "org.kde.image"]


def set_lock_picture(path):
    return (["kwriteconfig6"] + LOCK_GROUPS
            + ["--group", "Wallpaper", "--group", "org.kde.image", "--group", "General",
               "--key", "Image", path])


# ---- Apps ----------------------------------------------------------------------------------
#
# Which program opens a kind of file is written where every desktop reads
# it, ~/.config/mimeapps.list [Default Applications]; then KDE's own list of
# programs is told to read it again (kbuildsycoca6), so Plasma's programs
# follow at once as well as xdg-open.

def set_default_program(kind, ident):
    return ["kwriteconfig6", "--file", "mimeapps.list", "--group",
            "Default Applications", "--key", kind, ident + ";"]


REREAD_PROGRAMS = ["kbuildsycoca6"]
DISCOVER = ["plasma-discover"]


def start_program(path):
    # A program by its .desktop file, the way the menu starts it.
    return ["gio", "launch", path]


# ---- Updates -------------------------------------------------------------------------------

READ_UPGRADABLE = ["apt", "list", "--upgradable"]
READ_PERIODIC = ["apt-config", "dump", "APT::Periodic"]
# How long since PackageKit last fetched the lists - which is what Discover
# (and so Look now) does. 13 is PackageKit's "refresh cache" role. apt's own
# daily stamp is not touched by that: on the test machine, a minute after
# Look now, the page still said "Not looked for yet" (build 41).
READ_PK_REFRESHED = ["gdbus", "call", "--system", "--dest", "org.freedesktop.PackageKit",
                     "--object-path", "/org/freedesktop/PackageKit",
                     "--method", "org.freedesktop.PackageKit.GetTimeSinceAction", "13"]
DISCOVER_UPDATES = ["plasma-discover", "--mode", "update"]
# An update that is only finished by a restart leaves this behind (Debian's
# way; the ralden package writes it on an update, as a new kernel does).
# Discover does not say so on Ralden: Settings does (the VAIO, 28 October
# 2026, an update installed and no restart offered).
REBOOT_REQUIRED = "/run/reboot-required"
RESTART = ["systemctl", "reboot"]
# Ralden's own parts are the package ralden (usr/lib/ralden/package/
# make-package); which version this computer has.
READ_RALDEN_VERSION = ["dpkg-query", "-W", "-f=${Version}", "ralden"]


# ---- Bluetooth ------------------------------------------------------------------------------
#
# BlueZ over D-Bus, through Settings' own helper - so that a device asking
# to confirm a number is asked about by Plasma's Bluetooth agent, on the
# screen, and not by a bluetoothctl nobody is typing into.

BLUETOOTH = "/usr/lib/ralden/settings/bluetooth"
READ_BLUETOOTH = [BLUETOOTH, "show"]
MORE_BLUETOOTH = ["kcmshell6", "kcm_bluetooth"]


def bluetooth_power(on):
    return [BLUETOOTH, "power", "on" if on else "off"]


def bluetooth_scan(seconds=12):
    return [BLUETOOTH, "scan", str(int(seconds))]


def bluetooth_device(verb, address):
    if verb not in ("pair", "connect", "disconnect", "remove"):
        raise ValueError(verb)
    return [BLUETOOTH, verb, address]


# ---- Accounts ----------------------------------------------------------------------------
#
# AccountsService over D-Bus, through busctl - which marks its calls as
# ones polkit may ask the person about, so a change that needs an
# administrator's password asks for it in Plasma's window. Your own
# password through passwd itself (account-password), the passwords on its
# standard input only. Someone added or removed through Settings' own
# helper (people), what is asked on its standard input - the new person's
# password with it.

ACCOUNTS = ["org.freedesktop.Accounts"]
ACCOUNT_PASSWORD = "/usr/lib/ralden/settings/account-password"
PEOPLE = "/usr/lib/ralden/settings/people"
ADD_PERSON = [PEOPLE, "add"]
REMOVE_PERSON = [PEOPLE, "remove"]
# Who is signed in now: UID, login, linger, state - one a line.
READ_SIGNED_IN = ["loginctl", "list-users", "--no-legend"]
MORE_ACCOUNTS = ["kcmshell6", "kcm_users"]


def find_account(login):
    return ["busctl", "--system", "--json=short", "call", "org.freedesktop.Accounts",
            "/org/freedesktop/Accounts", "org.freedesktop.Accounts", "FindUserByName",
            "s", login]


READ_ACCOUNTS = ["busctl", "--system", "--json=short", "call", "org.freedesktop.Accounts",
                 "/org/freedesktop/Accounts", "org.freedesktop.Accounts", "ListCachedUsers"]


def read_account(path):
    return (["busctl", "--system", "--json=short", "get-property", "org.freedesktop.Accounts",
             path, "org.freedesktop.Accounts.User"]
            + ["UserName", "RealName", "AccountType", "IconFile", "SystemAccount", "Uid",
               "HomeDirectory"])


def set_real_name(path, name):
    return ["busctl", "--system", "call", "org.freedesktop.Accounts", path,
            "org.freedesktop.Accounts.User", "SetRealName", "s", name]


def set_picture(path, picture):
    return ["busctl", "--system", "call", "org.freedesktop.Accounts", path,
            "org.freedesktop.Accounts.User", "SetIconFile", "s", picture]


# ---- Privacy ---------------------------------------------------------------------------------
#
# The files opened lately are remembered in two places: Plasma's activity
# manager's database (org.kde.ActivityManager, ResourcesScoring), which the
# Search panel's "lately" reads, and the freedesktop.org list
# (~/.local/share/recently-used.xbel), which Files' Recents reads and most
# programs write. Forgetting clears both.

FORGET_RECENT = ["busctl", "--user", "call", "org.kde.ActivityManager",
                 "/ActivityManager/Resources/Scoring",
                 "org.kde.ActivityManager.ResourcesScoring", "DeleteRecentStats",
                 "sis", "", "0", "everything"]
MORE_RECENT = ["kcmshell6", "kcm_recentFiles"]
RECENTLY_USED = "~/.local/share/recently-used.xbel"
EMPTY_XBEL = ('<?xml version="1.0" encoding="UTF-8"?>\n'
              '<xbel version="1.0" xmlns:bookmark="http://www.freedesktop.org/standards/desktop-bookmarks"'
              ' xmlns:mime="http://www.freedesktop.org/standards/shared-mime-info">\n</xbel>\n')
