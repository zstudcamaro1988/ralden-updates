# SPDX-License-Identifier: Ralden-Source
#
# Ralden OS - Settings. readers and commands are plain Python; areas and
# app need PySide6.
