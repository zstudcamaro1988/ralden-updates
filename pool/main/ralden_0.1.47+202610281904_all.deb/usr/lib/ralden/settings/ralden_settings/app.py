# SPDX-License-Identifier: Ralden-Source
#
# Ralden OS - Settings: the window
#
# One window, drawn by /usr/share/ralden/settings/Main.qml from the owner's
# picture (reference/2d-settings.jpg), handed one object per part of the
# machine (areas.py). Started again while it is open, it does not open a
# second window: the one already open comes forward, at the page asked for
# - so the Control Center's gear and the search panel can each say "Settings,
# the Display page" and get the window that is there.
#
#   ralden-settings [page]      page: system, display, sound, notifications,
#                                power, multitasking, keyboard, layouts,
#                                shortcuts, pointing, bluetooth, network,
#                                personalization, apps, accounts, privacy,
#                                updates, time, timezone, about

import os
import sys

PAGES = ("system", "display", "sound", "notifications", "power", "multitasking",
         "keyboard", "layouts", "shortcuts", "pointing", "bluetooth", "network",
         "personalization", "apps", "accounts", "privacy", "updates", "time",
         "timezone", "about")

QML = "/usr/share/ralden/settings/Main.qml"


def find_qml():
    if os.path.exists(QML):
        return QML
    here = os.path.dirname(os.path.abspath(__file__))
    candidate = os.path.normpath(os.path.join(
        here, "..", "..", "..", "..", "share", "ralden", "settings", "Main.qml"))
    return candidate if os.path.exists(candidate) else QML


def main(argv):
    page = argv[0] if argv and argv[0] in PAGES else "system"
    try:
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QGuiApplication, QIcon
        from PySide6.QtNetwork import QLocalServer, QLocalSocket
        from PySide6.QtQml import QQmlApplicationEngine
    except ImportError:
        sys.stderr.write("Settings needs PySide6 (python3-pyside6.qtquick).\n")
        return 2

    from . import areas

    app = QGuiApplication(sys.argv[:1])
    app.setApplicationName("ralden-settings")
    app.setApplicationDisplayName("Settings")
    app.setOrganizationName("Ralden")
    # The dock and the window frame find the program's name and picture by
    # this, the name of its .desktop file.
    app.setDesktopFileName("org.ralden.settings")
    app.setWindowIcon(QIcon.fromTheme("preferences-system"))

    # One window. A second start hands its page to the first and leaves.
    key = "ralden-settings-%d" % os.getuid()
    socket = QLocalSocket()
    socket.connectToServer(key)
    if socket.waitForConnected(300):
        socket.write(page.encode())
        socket.waitForBytesWritten(300)
        socket.disconnectFromServer()
        return 0
    QLocalServer.removeServer(key)
    server = QLocalServer()
    server.listen(key)

    runner = areas.Runner()
    parts = {
        "display": areas.DisplayArea(runner),
        "sound": areas.SoundArea(runner),
        "power": areas.PowerArea(runner),
        "multitasking": areas.MultitaskingArea(runner),
        "keyboard": areas.KeyboardArea(runner),
        "shortcuts": areas.ShortcutsArea(runner),
        "pointing": areas.PointingArea(runner),
        "bluetooth": areas.BluetoothArea(runner),
        "network": areas.NetworkArea(runner),
        "look": areas.LookArea(runner),
        "apps": areas.AppsArea(runner),
        "accounts": areas.AccountsArea(runner),
        "privacy": areas.PrivacyArea(runner),
        "updates": areas.UpdatesArea(runner),
        "time": areas.TimeArea(runner),
        "about": areas.AboutArea(runner, clipboard=app.clipboard()),
    }

    engine = QQmlApplicationEngine()
    engine.setInitialProperties({"areas": parts, "startPage": page})
    engine.load(QUrl.fromLocalFile(find_qml()))
    if not engine.rootObjects():
        sys.stderr.write("Settings: the window did not load.\n")
        return 1
    window = engine.rootObjects()[0]

    def asked():
        conn = server.nextPendingConnection()
        if conn is None:
            return

        def read():
            wanted = bytes(conn.readAll()).decode("utf-8", "replace").strip()
            window.setProperty("page", wanted if wanted in PAGES else "system")
            window.show()
            window.raise_()
            window.requestActivate()
        conn.readyRead.connect(read)
    server.newConnection.connect(asked)

    return app.exec()
